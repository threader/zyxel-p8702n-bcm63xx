
    $(document).ready(function() {
    $('#MoreInfo').hide();
    $('#Retry').hide();

    FINVars.CurrentLanguage = 'NO';
    FINVars.CurrentNode = 'N000';


    FINVars.CurrentScreen = Nodes[FINVars.CurrentNode].ScreenID;

    $('#Next').click(function() {

        if (Nodes[FINVars.CurrentNode].Paths) {
            FINControl.NextClicked(Nodes[FINVars.CurrentNode].Paths);
        } else {
            //FINControl.ErrorReport("No Next node - CurrentNode = " + FINVars.CurrentNode);	
        }
    });

    $('#Back').click(function() {
        FINControl.BackClicked();
    });

    $('#Exit').click(function() {
        FINFunctions.ExitFIN();
    });

    $('#Finish').click(function() {
        FINFunctions.ExitFIN();
    });

});


var WinWidth = document.width;
var BrowserType;
var MinBrowserWidth = 540;

var isMobile = {
    Android: function() {
        return navigator.userAgent.match(/Android/i) ? true : false;
    },
    BlackBerry: function() {
        return navigator.userAgent.match(/BlackBerry/i) ? true : false;
    },
    iOS: function() {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i) ? true : false;
    },
    Windows: function() {
        return navigator.userAgent.match(/IEMobile/i) ? true : false;
    },
    any: function() {
        return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Windows());
    }
};

window.onorientationchange = function() {
    var orientation = window.orientation;
	
	
	
	if(BrowserType=="Mobile")
	{
		ButtonPositioning(); 
	}
	/*
    switch (orientation) {
        case 0:
            //Portrait mode button bottom
            //alert("0");
			RotatePortrait();
            return;
        case 90:
            // Landscape rotate left
            //alert("90");
			RotateLandscape();
            return;
        case -90:
            //Landscape rotate right
            //alert("-90");
			RotateLandscape();
            return;
        case 180:
            //Portrait mode button top
            //alert("180");
			RotatePortrait();
            return;

    }
	*/
	
}

function RotateLandscape()
{
	
	/*
	// hide text 
	$('#Container').hide();
	// load the image into layer //
	var TheImageHTML = $(".ImageLayerStyle").html();//document.getElementById('this_one');
	// remove style from img tag
	if(TheImageHTML)
		{
		TheImageHTML = TheImageHTML.replace(/(<[^>]+) style=".*?"/g, '$1');
		// use regular expression to get image id from html
		var ImageId='';
		var regex = /id=[\'\"]{0,1}(\w+)/;
		var MatchResult = regex.exec(TheImageHTML);
		if (MatchResult !== null){
			ImageId =MatchResult[1];	
		 }
		var image_x = document.getElementById(ImageId);
		image_x.parentNode.removeChild(image_x);
		TheImageHTML=TheImageHTML.replace(">",'class="OrientLayerImage">');
		 // update html on ImageOrinet div
		 $("#ImageOrient").html(TheImageHTML);
		// get img width and height
		var ThisImage = document.getElementById(ImageId); 
		var ImageWidth = ThisImage.clientWidth;
		var ImageHeight = ThisImage.clientHeight;	
		var Orient = '';
		if(ImageWidth<ImageHeight)
		{
			Orient='Portrait';
		} else {
			Orient='Landscape';
		}
		// add css class
		$("#"+ImageId).addClass(Orient); // jquery - add css class portrait or landscape
		// show image layer 
	}
	document.getElementById("ImageOrient").style.visibility="visible";
	*/
	
}

function RotatePortrait()
{
	// hide image layer
	//document.getElementById("ImageOrient").style.visibility="hidden";
	// show the text layer.
	//$('#Container').show();
	
}



var supportsOrientationChange = "onorientationchange" in window, orientationEvent = supportsOrientationChange ? "orientationchange" : "resize";



function removejscssfile(filename, filetype){
 var targetelement=(filetype=="js")? "script" : (filetype=="css")? "link" : "none" //determine element type to create nodelist from
 var targetattr=(filetype=="js")? "src" : (filetype=="css")? "href" : "none" //determine corresponding attribute to test for
 var allsuspects=document.getElementsByTagName(targetelement)
 for (var i=allsuspects.length; i>=0; i--){ //search backwards within nodelist for matching elements to remove
  if (allsuspects[i] && allsuspects[i].getAttribute(targetattr)!=null && allsuspects[i].getAttribute(targetattr).indexOf(filename)!=-1)
   allsuspects[i].parentNode.removeChild(allsuspects[i]) //remove element by calling parentNode.removeChild()
 }
}


function loadjscssfile(filename, filetype){
 if (filetype=="js"){ 
	  var fileref=document.createElement('script')
	  fileref.setAttribute("type","text/javascript")
	  fileref.setAttribute("src", filename)
 }
 else if (filetype=="css"){ 
	  var fileref=document.createElement("link")
	  fileref.setAttribute("rel", "stylesheet")
	  fileref.setAttribute("type", "text/css")
	  fileref.setAttribute("href", filename)
 }
 if (typeof fileref!="undefined")
  document.getElementsByTagName("head")[0].appendChild(fileref)
}

function MobileBrowser()
{
	if( isMobile.any() ){
	    BrowserType = "Mobile";
	}
	else 
	{
		BrowserType="NotMobile";
    }
	
	if (navigator.userAgent.match(/iPad/i)) {
	    BrowserType = ScreenSize(); // just for iPad and iPad mini
	}	
	
	FINVars.BrowserType=BrowserType;
	
}

function MobileBrowserCSS()
{
	MobileBrowser();
	//
	//console.log("supportsOrientationChange = " + supportsOrientationChange);
	//console.log("os = " + os);
	//BrowserType = ScreenSize();
	//if (navigator.userAgent.match(/iPad/i)) {
	  //  BrowserType = ScreenSize(); // just for iPad and iPad mini
	//}
	if(BrowserType=="Mobile")
	{
		loadjscssfile("css/Mobile.css", "css");
		UpdateFlagIcons();
    }
    else 
	{
		loadjscssfile("css/NonMobile.css", "css");
		UpdateFlagIcons();
	}
}

function UpdateFlagIcons()
{
	if(BrowserType=="Mobile")
	{
		$('#NOFlag').attr('src', 'images/FIN/flag-No-64.png');
		$('#ENFlag').attr('src', 'images/FIN/flag-En-64.png');
		
	} else {
		
		$('#NOFlag').attr('src', 'images/FIN/flag_norway.png');
		$('#ENFlag').attr('src', 'images/FIN/flag_united_kingdom.png');
	}
	
}


function ScreenRatio(a, b) {
    return (b == 0) ? a : ScreenRatio(b, a % b);
}

function ScreenSize()
{
    var w = screen.width;
    var h = screen.height;
    var r = ScreenRatio(w, h);
    
    var corH = 1;
    var corW = 1;
    var aratio = "" + w / r + ":" + h / r;

    var DivSize = document.getElementById("SizeDiv");
    var x_dpi = $(DivSize).outerWidth(true);
    var y_dpi = $(DivSize).outerHeight(true);

    if (navigator.userAgent.match(/iPad/i)) 
    {
        x_dpi = x_dpi * 1.3801;
        y_dpi = x_dpi * 1.3801;
    }

    var width_in_inches = screen.width / x_dpi;
    var height_in_inches = screen.height / y_dpi;
    var diagonal_in_inches = Math.round(10 * Math.sqrt(width_in_inches * width_in_inches + height_in_inches * height_in_inches)) / 10;
    //var optputT = "pixel.width = " + screen.width + " pixel.height = " + screen.height + " aspect ration = " + aratio + " dpi x = " + x_dpi + " dpi y = " + y_dpi + " width = " + width_in_inches + " inches" + " height = " + height_in_inches + " inches" + " diagonal = " + diagonal_in_inches + " inches";
    //console.log(optputT);

	//alert("screen size : diagonal width  = " + diagonal_in_inches + " inches.");

    if (diagonal_in_inches >= 7.5 && navigator.userAgent.match(/iPad/i)) // this allows the iPad not mini
    {
       return "NonMobile"; // uncomment this later.... just for testing
    }
    else 
    {
        return "Mobile";
    }
}

function windowResize()
{
    WinWidth = document.width;
	//if(WinWidth<MinBrowser || BrowserType=="Mobile")
	//{
	//	loadjscssfile("css/Mobile.css", "css");
	//}
}

// This is to fix javascript issue in IE8

if (window.addEventListener) 
{
    window.addEventListener(orientationEvent, function() {
	    var DeviceOrientation= window.orientation;
	    var DeviceScreenWidth = screen.width;
	    //console.log(DeviceOrientation);
	    //console.log(DeviceScreenWidth);
    }, false);
}


function MobileImageHandler(HTML)
{
	if(BrowserType=="Mobile"){
		//HTML = HTML + '<div id="FlipImageIcon" class="FlipImageHolder">&nbsp;</div>';
	}
	return HTML;
}
