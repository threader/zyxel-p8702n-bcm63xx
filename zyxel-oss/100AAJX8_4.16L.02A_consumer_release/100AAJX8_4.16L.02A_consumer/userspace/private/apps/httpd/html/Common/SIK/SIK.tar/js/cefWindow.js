var SWP_NOSIZE          = 0x0001;
var SWP_NOMOVE          = 0x0002;
var SWP_NOZORDER        = 0x0004;
var SWP_NOREDRAW        = 0x0008;
var SWP_NOACTIVATE      = 0x0010;
var SWP_FRAMECHANGED    = 0x0020;  
var SWP_SHOWWINDOW      = 0x0040;
var SWP_HIDEWINDOW      = 0x0080;
var SWP_NOCOPYBITS      = 0x0100;
var SWP_NOOWNERZORDER   = 0x0200;  
var SWP_NOSENDCHANGING  = 0x0400 ;

var SWP_DRAWFRAME       = SWP_FRAMECHANGED;
var SWP_NOREPOSITION    = SWP_NOOWNERZORDER;

var SWP_DEFERERASE      = 0x2000;
var SWP_ASYNCWINDOWPOS  = 0x4000;


var HWND_TOP        = 0;
var HWND_BOTTOM     = 1;
var HWND_TOPMOST    = -1;
var HWND_NOTOPMOST  = -2;

var SW_HIDE             = 0;
var SW_SHOWNORMAL       = 1;
var SW_NORMAL           = 1;
var SW_SHOWMINIMIZED    = 2;
var SW_SHOWMAXIMIZED    = 3;
var SW_MAXIMIZE         = 3;
var SW_SHOWNOACTIVATE   = 4;
var SW_SHOW             = 5;
var SW_MINIMIZE         = 6;
var SW_SHOWMINNOACTIVE  = 7;
var SW_SHOWNA           = 8;
var SW_RESTORE          = 9;
var SW_SHOWDEFAULT      = 10;
var SW_FORCEMINIMIZE    = 11;
var SW_MAX              = 11;


var NovusWindowId_ConnectionManager = "ConnectionManager";
var NovusWindowId_PUKDialog = "PUKDialog";
var NovusWindowId_RoamingDialog = "RoamingDialog";
var NovusWindowId_WifiSecKey = "WifiSecKey";
var NovusWindowId_SettingsWindow = "SettingsWindow";
var NovusWindowId_SettingsPinProtection = "SettingsPinProtection";
var NovusWindowId_SettingsNetworkType = "SettingsNetworkType";
var NovusWindowId_SettingsNetworkSelection = "SettingsNetworkSelection";
var NovusWindowId_MessagesWindow = "MessagesWindow";
var NovusWindowId_NewSmsWindow = "NewSmsWindow";
var NovusWindowId_ServicesWindow = "ServicesWindow";
var NovusWindowId_HelpWindow = "HelpWindow";
var NovusWindowId_FailedToConnectWindow = "FailedToConnectWindow";
var NovusWindowId_AppExitCloseConnectionWindow = "AppExitCloseConnectionWindow";
var NovusWindowId_BetterConnectionAvailableWindow = "BetterConnectionAvailableWindow";
var NovusWindowId_NoRoamingAllowedWindow = "NoRoamingAllowedWindow";
var NovusWindowId_AutoDisconnectDialogWindow = "AutoDisconnectDialogWindow";
var NovusWindowId_Help_AboutWindow = "HelpAboutWindow";
var NovusWindowId_Help_CustomerSupportWindow = "HelpCustomerSupportWindow";
var NovusWindowId_Help_SystemReportWindow = "HelpSystemReportWindow";
var NovusWindowId_Messages_DeleteConfirmWindow = "DeleteMessagesConfirm";
var NovusWindowId_SendSystemReportWindow = "SendSystemReportWindow";


function CefRunning()
{
	if(window.cefWindow)
		return true;
		
	return false;
}

function OpenHelpWindow(flowCode)
{
	if (CefRunning())
	{
		cef.application.IncrimentUsage("Dialler.Help." + flowCode);
		cef.FixItNow.SetCurrentFlow(flowCode);
		cef.application.OpenNovusWindow(NovusWindowId_HelpWindow);
	}
}
