
var language = FINVars.CurrentLanguage; 
	
	function translate(){
	    var all = document.getElementsByTagName("*"); 
		for (var i=0, max=all.length; i < all.length; i++) { 

			var transId = all[i].getAttribute("transID"); 


			var temp = all[i].nodeName;
			
					if(all[i].nodeName == 'TITLE'){
					    var transResult = getTrans(transId, true)
					    
					}else{
						if(transId){
							all[i].innerHTML = getTrans(transId);
						}
					}
		}
	}
	
	function getTrans(transId,returnCodeOnlyOnFail){

		
		var trans ='';
		var lang = FINVars.CurrentLanguage;
		if(transId!=undefined){
			//var tagDebug = all[i].tagName;
			//var tagDebug2 = all[i].id;
			//$('#debugTXT').html(tagDebug+':'+tagDebug2);
				
				
				var transIdSplit = transId.split(".");
				if(transIdSplit[0] != undefined && transIdSplit[1] != undefined)
				{
					
					var result ='';// = 'NOOBJECT';
					
					if(translations[transIdSplit[0]]){
						if(translations[transIdSplit[0]][transIdSplit[1]]){
							//result = 'NOLANG';
							if(translations[transIdSplit[0]][transIdSplit[1]][lang]){
								
								result = translations[transIdSplit[0]][transIdSplit[1]][lang];
							}
						}	
					}
					
			
					
					if(!result){
						
						if(translations[transIdSplit[0]] &&
						translations[transIdSplit[0]][transIdSplit[1]] &&
						translations[transIdSplit[0]][transIdSplit[1]]['EN'])
						{
							
							var tooltippy = transId +'.'+ lang
							if(!returnCodeOnlyOnFail){
								trans = "<x title="+tooltippy+"><font color=red>*</font>" + translations[transIdSplit[0]][transIdSplit[1]]['EN']+"</x>";
							}else{
								trans = transId+'.'+ lang;
							}
						}
						else
						{
							trans = transId +'.'+ lang
						}
					} else {
						trans = result
						//$("#" + itemId).html(result); 
					}
				}
				else
					
					if(!returnCodeOnlyOnFail){
								trans = "<font color='red'>#</font><font>" + transId + "</font>"; 
							}else{
								trans = transId;
							}
			}
			
			return trans;
		
	}
	
	function translateUpdateItem(lang, itemId, newTransId){
	    var theItem = document.getElementById(itemId); 
		
		if(theItem!=undefined)
		{
			theItem.setAttribute("transID",newTransId);
			
			var transIdSplit = newTransId.split(".");
			if(transIdSplit[0] != undefined && transIdSplit[1] != undefined)
			{
				var x;
				if(translations && translations[transIdSplit[0]] && translations[transIdSplit[0]][transIdSplit[1]])
				x = translations[transIdSplit[0]][transIdSplit[1]][lang]; 
				if(x==undefined)
				{
					var tooltippy = newTransId + "." + lang + "<font color='red'>*</font>"; // undefined error
					$("#"+itemId).html(tooltippy); //"<font color=red>## "+document.getElementsByTagName("*")[itemId].id+" ("+lang+") ##</font>"); 
				}
				else
				{
					$("#"+itemId).html(x); 
				}
			}
			else
				$("#" + itemId).html("<font color=aqua>" + transId + "</font>"); 		
		}
	}
	
	
	translateInString=function(Content)
	{
		if(!Content)
			return;
		
		var InThere = Content.match(/\$\$(.*?)\$\$/);
		
		if(InThere != null)
		{
			var FindMatch;
			for(i=0;i<Content.length;i++)
			{
				FindMatch= Content.match(/\$\$(.*?)\$\$/);
				
				if(FindMatch!=null){
					var Replacement = FindMatch[1];
					//var ReplacementBranded = Replacement + "_" + FINVars.Brand;
					
					var VarArray = Replacement.split('.');
					var a =VarArray[0];
					var b =VarArray[1];
					var ReplaceText;
					
					if(translations[a] && translations[a][b] && translations[a][b][language])
						ReplaceText = translations[a][b][language];
					
					//var BrandedArray= ReplacementBranded.split('.');
					//var c =BrandedArray[0];
					//var d =BrandedArray[1];
					//var ReplaceTextBranded = window[c][d];	
					
					if(ReplaceText != undefined)
						Content = Content.replace(FindMatch[0],ReplaceText); 
					else
						Content = Content.replace(FindMatch[0], '<font color=\'red\'>*</font>' + FindMatch[0]); 
						
				}
				else
				{
					break;
				}
			}
		}
		
		return Content;
	}	

	$(window).load(function()
	{
		
		if(CefRunning())
		{
			translate();
		}
		else
		{
			translate();
		}
	});