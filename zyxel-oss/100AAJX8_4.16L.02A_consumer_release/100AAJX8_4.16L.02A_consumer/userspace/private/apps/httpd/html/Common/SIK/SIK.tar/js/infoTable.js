function setInfoTable(reportOBJ, tableID){
	
	var list1HTML = '';

	for(var i=0; i<reportOBJ.length;i++){
		
		
		
		if(reportOBJ[i].Type){
			if(reportOBJ[i].Type == 'Header'){
				list1HTML += '<h5>'+getTrans(reportOBJ[i].Label1)+'</h5>';
			
			}
			
			
		}
		else if(reportOBJ[i].DontShowInReport)
		{
		}
		else if(reportOBJ[i].Label1 != undefined)
		{
			var header = " ";
			if(reportOBJ[i].Label1 != "" && reportOBJ[i].Label1 != undefined)
				header = getTrans(reportOBJ[i].Label1);
			
			var value = reportOBJ[i].Label2;
			if(reportOBJ[i].TranslateLabel2)
				value = getTrans(reportOBJ[i].Label2);
				
			list1HTML += '<label class="ReportLabel">' + header + ' </label><label class="ReportValue">' + value + '</label></br>';
		}
		else{

			list1HTML += '</br></br>';

		}
		
	}
	
	if(!tableID){
		$('.InfoList').empty();	
		$('.InfoList').append(list1HTML);
	}else{
		
		$(tableID).empty();	
		$(tableID).append(list1HTML);
	}
   hideStatusBar();
	
}