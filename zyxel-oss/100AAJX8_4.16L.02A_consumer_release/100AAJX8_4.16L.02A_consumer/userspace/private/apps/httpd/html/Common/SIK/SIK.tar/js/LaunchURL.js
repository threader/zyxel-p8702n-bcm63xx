
function launchURL(url)
{
	if(CefRunning())
	{
		cef.application.LaunchURL(url);
	}
	else
		window.open(url);
}
function launchURLCode(url)
{
	if(CefRunning())
	{
		cef.application.LaunchURLCode(url);
	}
	else
		window.open(url);
}