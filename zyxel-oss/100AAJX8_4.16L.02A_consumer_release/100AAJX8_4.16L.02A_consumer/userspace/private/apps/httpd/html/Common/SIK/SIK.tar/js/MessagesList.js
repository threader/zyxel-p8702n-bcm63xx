var selectedID = '';
var selectedID_InboxList = '';
var selectedID_SentList = '';


var listDataInbox = new Array;
var listDataSent = new Array;
var currentTab = 'InboxTab';

var MessageCategory_Inbox = 1;
var MessageCategory_Sent = 2;

var numUnreadMsgs = 0;

var mobileDevicePresent = false;


var shifted = false;


  var lastChecked = null;


var multipleItemsList = [];

function itemClickedWithMouse(event){
	//Checks for multiple selections using SHIFT or CNTRL before selecting the last clicked item...
	
	justClickedID = event.currentTarget.id
	
	var listData =[];
	if(currentTab == 'SentTab')
	{
		listData = listDataSent;
	}else{
		listData = listDataInbox;
	}
	
	//Find the index of the clicked item
	var justClickedIndex = -1;
	var lastCheckedIndex = -1;
	for(var i=0;i<listData.length;i++)
		{
			if(listData[i].ID == justClickedID){
				justClickedIndex = i;
			}
			if(listData[i].ID == lastChecked){
				lastCheckedIndex = i;
			}
		}
		
	//If the item is selected, de-select it: or vice-versa
	var setORForget = true;	
	if(listData[justClickedIndex].selected){
		setORForget = false;
	}
	
	
	//Shift is down.. select multiple based on new item selected state.
	if(event.shiftKey) {	
	
		//First ensure that the previously selected item is still in the list..
		if(lastCheckedIndex != -1){
				var startSelectingItems = false;
				for(var i=0;i<listData.length;i++)
				{
					
					if(startSelectingItems){
						listData[i].selected = setORForget;
					}
					
					if(listData[i].ID == justClickedID){
						startSelectingItems = !startSelectingItems;
						listData[i].selected = setORForget;
					}
					if(listData[i].ID == lastChecked){
						startSelectingItems = !startSelectingItems;
						listData[i].selected = setORForget;
					}	
				}
		}else{
			//Clear selection history
			for(var i=0;i<listData.length;i++)
			{
				listData[i].selected = false;
			};	
		}
		
		//Select or de-select clicked item
	listData[justClickedIndex].selected = setORForget;
	
	}else if(event.ctrlKey)
	{
		//If control key is down, do not clear list..
		//Select or de-select clicked item
		listData[justClickedIndex].selected = setORForget;
	}
	else
	{
		//If no keys down, clear all selected items..
		//Clear selection history
		for(var i=0;i<listData.length;i++)
		{
			listData[i].selected = false;
		}
		
		//Select or de-select clicked item
		listData[justClickedIndex].selected = true;
	}
	
	//active the selection process
	
	itemSelected(justClickedID);

	//remember the last selected item for next time.
	lastChecked = justClickedID;
}


function CheckMobileDevicePresent()
{
	if(CefRunning())
	{
		window.cefWindow.OutputDebugString("CheckMobileDevicePresent Start");
		
		var mobileInfo = cef.mobile.GetInfo();

		if(mobileInfo.deviceConnectedState == MobileDeviceConnectionStateConnected
			&& mobileInfo.simStatus.pinType == MobilePinTypeReady)
			mobileDevicePresent = true;
		else
			mobileDevicePresent = false;
			
		window.cefWindow.OutputDebugString("mobileInfo.deviceConnectedState = " + mobileInfo.deviceConnectedState + " mobileInfo.simStatus=" + mobileInfo.simStatus.pinType);	
	
	
	if(mobileDevicePresent)
	{
			enableButton('newSMSButton');
			
			var listData;
			if(currentTab == 'SentTab')
				listData = listDataSent;
			else
				listData = listDataInbox;	
			
			if(selectedID != '')
			{
				var isNotification = false;
				var foundItem = false;
				for(var i=0;i<listData.length;i++)
				{
					if(listData[i].ID == selectedID)
					{
						if(listData[i].Type == "Notification")
							isNotification = true;
					
						break;
					}
				}
			
				if(!isNotification)
				{
					if(currentTab == 'InboxTab')
						enableButton('replyButton');
						
					enableButton('forwardButton');
					enableButton('deleteButton');	
				}
			}
			else
			{
				disableButton('replyButton');
				disableButton('forwardButton');
				disableButton('deleteButton');	
			}
	}
	else
	{
		disableButton('newSMSButton');
		disableButton('replyButton');
		disableButton('forwardButton');
		disableButton('deleteButton');		
	}
	
	}
}

function DeleteCurrentItemConfirm()
{
	if(CefRunning())
	{
		cef.application.OpenNovusWindow(NovusWindowId_Messages_DeleteConfirmWindow);
	}
	//DeleteCurrentItem();
}

function DeleteCurrentItem()
{
	//var delIndex = 0;
	var listData;
	
	if(currentTab == 'SentTab')
		listData = listDataSent;
	else
		listData = listDataInbox;



 	var deleteArray = [];
	var deleteIDArray = [];
	for(var i=0;i<listData.length;i++)
	{
		if(listData[i].selected)
		{			
			
			deleteArray.push(listData[i]);
			deleteIDArray.push(i);
			
		}
	}
	
	if(CefRunning())
	{
		cef.messages.DeleteMessage(deleteArray);
		
		//if(numUnreadMsgs>0)
		//	numUnreadMsgs--;
		//var info = cef.messages.GetInfo();
		//numUnreadMsgs = info.UnreadMessages;
		//UpdateUnreadMessagesNote();
	}
			

	var count = 0;
	for(var j=0;j<deleteIDArray.length;j++)
	{
		var index = deleteIDArray[j];
		listData.splice(index-count, 1);
		count ++;
	}
	
	
	TabClicked(currentTab);
}

function highlightSelections()
{
	
	
}

function messagesLaunchURL(url)
{
	launchURL(url);
}

function messagesLaunchURLNotification(url, id)
{
	if(CefRunning())
		cef.application.SendNotificationLog({"Id":id, "Status":AdStateClicked});
		
	launchURL(url);
}

var replaceObj = {
      callback: function( text, href )
	  {
	    var res = href ? '<a href="#" title="' + href + '" onclick="messagesLaunchURL(\'' + href + '\')">' + text + '</a>' : text;
        return res;
      },
      punct_regexp: /(?:[!?.,:;'"]|(?:&|&amp;)(?:lt|gt|quot|apos|raquo|laquo|rsaquo|lsaquo);)$/
    };

function itemSelected(selectedIDTemp)
{
	
	var listData;
	var dateText = getTrans('Messages.MessageReceived')+' ';
	
	if(currentTab == 'SentTab')
	{
		//selectedID_SentList = selectedIDTemp;
		listData = listDataSent;
		dateText = 'Sent: ';
	}
	else
	{
		//selectedID_InboxList = selectedIDTemp;
		listData = listDataInbox;
	}


	//Hide Tab Content
	selectedID = selectedIDTemp;
	//Deselect Menu Items
	$(".List li a").removeClass("currentTab");
	
	for(var i=0;i<listData.length;i++)
	{
		if(listData[i].selected || listData[i].ID == selectedID)
		{
			$("#"+listData[i].ID).addClass("currentTab");
		}
	}
	
	//$("#"+selectedID).addClass("currentTab");
	$("#"+selectedID).removeClass("unread");
	
	var isNotification = false;
	var foundItem = false;
	for(var i=0;i<listData.length;i++)
	{
		if(listData[i].ID == selectedID)
		{
			if(listData[i].Sender != 'ISP')
			{
				$('#MessageHeader').html(listData[i].Sender);
			}
			else
			{
				$('#MessageHeader').html('<img src="images/icon16.png" class="ISPLogo"></img>');
			}
		
			var newMessage = "";
			if(listData[i].Type == "Notification")
				newMessage += "<h2>" + listData[i].Heading + "</h2>";
			
			newMessage += linkify(listData[i].Message, replaceObj);
			if(listData[i].Link && listData[i].LinkLabel)
			{
				newMessage += '<br/><br/><a href="#" title="' + listData[i].Link + '" onclick="messagesLaunchURLNotification(\'' + listData[i].Link + '\', \'' + selectedID + '\')">' + listData[i].LinkLabel + '</a>';
			}		
		
			$('#MessageBody').html(newMessage);
			
				//Populate message info bar
			var receivedText = '';
			var messageTypeText = '';
			
			if(listData[i].Date)
			{
				receivedText = '<span>'+dateText+listData[i].Date+'</span>';
			}
			if(listData[i].Type)
			{
				messageTypeText = '<span>'+getTrans('Messages.MessageType')+' '+getTrans('Messages.Type'+listData[i].Type)+'</span>';
			}
			
			$('#MessageInfo').html(receivedText + messageTypeText);
			
			if(CefRunning() && !listData[i].Read)
			{
				listData[i].Read = true;
				cef.messages.MarkAsRead(selectedID, listData[i].Type);
				
				if(numUnreadMsgs>0)
					numUnreadMsgs--;
				//var info = cef.messages.GetInfo();
				//numUnreadMsgs = info.UnreadMessages;
				UpdateUnreadMessagesNote();
			}
			
			if(listData[i].Type == "Notification")
				isNotification = true;
			foundItem = true;		
			break;
		}
	}
	
	//window.cefWindow.OutputDebugString("itemSelected - foundItem:" + foundItem + " mobileDevicePresent:" + mobileDevicePresent);
	if(foundItem && mobileDevicePresent && !isNotification)
	{
		if(currentTab == 'InboxTab')
			enableButton('replyButton');
			
		enableButton('deleteButton');			
		enableButton('forwardButton');		
	}
	else if(foundItem)
	{
		enableButton('deleteButton');	
		
		disableButton('replyButton');			
		disableButton('forwardButton');			
	}
}
	


function truncate(string, length){
	
	//var length = 3;  // set to the number of characters you want to keep
	var clipped =  string.substring(0, Math.min(length,string.length));
	
	if(length <= string.length){
		clipped += '...';
	}
 return clipped; 
}


function updateMessagesList(listDataTemp)
{
	hideStatusBar();
	//if(window.cefWindow)
	//	window.cefWindow.OutputDebugString("updateMessagesList(listDataTemp=" + listDataTemp + ")");


	//listData = listDataTemp;
	//Clear list if already populated
	$('.List').empty();	
	
	var selectedIDStillInList = false;
	
	//Add new list items
	for(var i=0;i<listDataTemp.length;i++)
	{
		if(listDataTemp[i].ID == selectedID)
			selectedIDStillInList = true;
		
		var LiClass = "Signal"+listDataTemp[i].SignalStrength;
		var mess = listDataTemp[i].Message//truncate(listDataTemp[i].Message, 80)
		var readVal = 'read';
		if(listDataTemp[i].Read != undefined)
		{
			if(listDataTemp[i].Read == false)
			{
				readVal = 'unread';
			}
		}
		
		//Remove any html formatting in the message so it doesnt mess up the list view.
		var html = listDataTemp[i].Message;
		var div = document.createElement("div");
		div.innerHTML = html;
		var text = div.textContent || div.innerText || "";

		//Create the list item.
		if(listDataTemp[i].Type == "Notification")	
			$('.List').append('<li ><a class="'+readVal+'" id="'+listDataTemp[i].ID+'" href="#" onClick="itemClickedWithMouse(event)"><img src="images/icon16.png" class="ISPLogo"></img><p>'+listDataTemp[i].Heading+' - ' + text + '</p></a></li>');		
		else if(listDataTemp[i].Sender != 'ISP')
		{
			$('.List').append('<li ><a class="'+readVal+'" id="'+listDataTemp[i].ID+'" href="#" onClick="itemClickedWithMouse(event)"><h3>'+listDataTemp[i].Sender+'</h3><p>'+text+'</p></a></li>');
		}
		else
		{
			$('.List').append('<li ><a class="'+readVal+'" id="'+listDataTemp[i].ID+'" href="#" onClick="itemClickedWithMouse(event)"><img src="images/icon16.png" class="ISPLogo"></img><p>'+text+'</p></a></li>');
		}
		
		//<span style="float:right">'+'asdfasdfasdf'+'</span>
	}
	
	//$('.List').append('<a class="moreLink">Next 25 messages..</a>');
	
	
	if(!selectedIDStillInList)
	{
		//Disable connect button if selected item no longer exists
		selectedID = '';
	//	itemSelected(selectedID, false);
		//enableMainButton(false);	
		
		
		$('#MessageHeader').html('');
			$('#MessageBody').html(getTrans('Messages.NoMessageSelected'));
			$('#MessageInfo').html('');
	}
	else
		itemSelected(selectedID, false);
		
	UpdateUnreadMessagesNote();
}

function UpdateUnreadMessagesNote()
{
	$('#UnreadMessagesNote').html(getTrans('Messages.YouHave')+" " + numUnreadMsgs +" " + getTrans('Messages.UnreadMessages'));
}




//DEBUG FUNCTION
function setMessageList_InboxFake()
{
	//if(window.cefWindow)
	//	window.cefWindow.OutputDebugString("setWiFiList_Fake");

	//var listData = new Array;
	listDataInbox[0] = new Object;
	listDataInbox[0].ID = "inbox1";
	listDataInbox[0].Date = '11.11.2011'
	listDataInbox[0].Type = 'Notification'
	listDataInbox[0].Sender = "DNA";
	listDataInbox[0].Message = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vitae ipsum purus, ut feugiat sapien. Etiam scelerisque purus vel ante mattis fringilla. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque id lorem justo, eu viverra erat. <br/><br/><a>pharetra in facilisis nec, dignissim in arcu</a>'
	listDataInbox[0].Read = false;
	
	listDataInbox[1] = new Object;
	listDataInbox[1].ID ="inbox2";
	listDataInbox[1].Date = '05.11.2011'
	listDataInbox[1].Type = 'SMS'
	listDataInbox[1].Sender = "DNA";
	listDataInbox[1].Message = '<b>Nteger facilisis congue</b> tellus eu vehicula. Donec placerat ligula nec velit semper in lobortis nunc convallis. Pellentesque tristique odio a odio tincidunt aliquet. Nam et dapibus enim. Sed malesuada consequat purus.<a href="https://kauppa.dnapro.fi/puheliittyma/"  target="_blank" ></br><img alt="Tutustu DNA Pro -puheliittymiin" width="220" height="276" src="http://www.dnapro.fi/image/image_gallery?uuid=5779d8bc-1240-4339-a9ed-68afde3b5b98&amp;groupId=4010691&amp;t=1314595367795" /></a><a href="https://kauppa.dnapro.fi/laajakaistapaketti/"><img alt="Tutustu DNA Pro Liikkuva Laajakaista -paketteihin" width="220" height="276" src="http://www.dnapro.fi/image/image_gallery?uuid=58246ce4-46fa-4927-b64c-d3b609bf502b&groupId=4010691&t=1314595367791" /></a><p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vitae ipsum purus, ut feugiat sapien. Etiam scelerisque purus vel ante mattis fringilla. Lorem ipsum dolor sit amet, <a>consectetur adipiscing elit</a> .Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vitae ipsum purus, ut feugiat sapien. Etiam scelerisque purus vel ante mattis fringilla. Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vitae ipsum purus, ut feugiat sapien. Etiam scelerisque purus vel ante mattis fringilla. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>';
	listDataInbox[1].Read = false;
	
	listDataInbox[2] = new Object;
	listDataInbox[2].ID ="inbox3";
	listDataInbox[2].Date = '05.11.2011'
	listDataInbox[2].Type = 'Notification'
	listDataInbox[2].Sender = "DNA";
	listDataInbox[2].Message = 'Semper in lobortis nunc convallis. Pellentesque tristique odio a odio tincidunt aliquet. Nam et dapibus enim. Sed malesuada consequat purus.<a href="https://kauppa2.welho.fi/laitteet/"  target="_blank" ></br><img style="padding-left: 100px;" alt="Tutustu DNA Pro -puheliittymiin" src="http://www.dna.fi/verkkokauppa/PublishingImages/etusivu/Viihdelaitteet.png" /></a>';
	listDataInbox[2].Read = true;
	listDataInbox[3] = new Object;
	listDataInbox[3].ID ="JimmysPizzaShack";
	listDataInbox[3].Date = '03.11.2011'
	listDataInbox[3].Type = 'SMS'
	listDataInbox[3].Sender = "+63 402 567 432";
	listDataInbox[3].Message = 'Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.';
	listDataInbox[3].Read = true;
	
	listDataInbox[4] = new Object;
	listDataInbox[4].ID = "inbox4";
	listDataInbox[4].Date = '22.10.2011'
	listDataInbox[4].Type = 'SMS'
	listDataInbox[4].Sender = "DNA";
	listDataInbox[4].Message = 'Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum.';
	listDataInbox[4].Read = true;
	
	listDataInbox[5] = new Object;
	listDataInbox[5].ID = "inbox5";
	listDataInbox[5].Date = '12.10.2011'
	listDataInbox[5].Type = 'Notification'
	listDataInbox[5].Sender = "DNA";
	listDataInbox[5].Message = 'Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.';
	listDataInbox[5].Read = true;

	listDataInbox[6] = new Object;
	listDataInbox[6].ID ="inbox6";
		listDataInbox[6].Received = '05.11.2011'
	listDataInbox[6].Type = 'Notification'
	listDataInbox[6].Sender = "Emotum";
	listDataInbox[6].Message = 'Semper in lobortis nunc convallis. Pellentesque tristique odio a odio tincidunt aliquet. Nam et dapibus enim. Sed malesuada consequat purus.<a href="https://kauppa2.welho.fi/laitteet/"  target="_blank" ></br><img style="padding-left: 100px;" alt="Tutustu DNA Pro -puheliittymiin" src="http://www.dna.fi/verkkokauppa/PublishingImages/etusivu/Viihdelaitteet.png" /></a>';
listDataInbox[6].Read = true;
	
	listDataInbox[7] = new Object;
	listDataInbox[7].ID ="inbox7";
		listDataInbox[7].Received = '03.11.2011'
	listDataInbox[7].Type = 'SMS'
	listDataInbox[7].Sender = "+63 402 567 432";
	listDataInbox[7].Message = 'Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.';
	listDataInbox[7].Read = true;
	
	listDataInbox[8] = new Object;
	listDataInbox[8].ID = "inbox8";
		listDataInbox[8].Received = '22.10.2011'
	listDataInbox[8].Type = 'SMS'
	listDataInbox[8].Sender = "Emotum";
	listDataInbox[8].Message = 'Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum.';
	listDataInbox[8].Read = true;
	
	listDataInbox[9] = new Object;
	listDataInbox[9].ID = "inbox9";
	listDataInbox[9].Received = '12.10.2011'
	listDataInbox[9].Type = 'Notification'
	listDataInbox[9].Sender = "Emotum";
	listDataInbox[9].Message = 'Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.';
	listDataInbox[9].Read = true;
	
	
}

function setMessageList_SentFake()
{
	//if(window.cefWindow)
	//	window.cefWindow.OutputDebugString("setWiFiList_Fake");

	//var listData = new Array;
	listDataSent[0] = new Object;
	listDataSent[0].ID = "sent1";
	listDataSent[0].Date = '11.11.2011'
	listDataSent[0].Type = 'Notification'
	listDataSent[0].Sender = "+61 402 991 115";
	listDataSent[0].Message = 'Nulla vitae ipsum purus, ut feugiat sapien. Etiam scelerisque purus vel ante mattis fringilla. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque id lorem justo, eu viverra erat. Phasellus odio lacus, pharetra in facilisis nec, dignissim in arcu.'
	
	listDataSent[1] = new Object;
	listDataSent[1].ID ="sent2";
	listDataSent[1].Date = '05.11.2011'
	listDataSent[1].Type = 'SMS'
	listDataSent[1].Sender = "+61 402 991 115";
	listDataSent[1].Message = 'Congue tellus eu vehicula. Donec placerat ligula nec velit semper in lobortis nunc convallis. Pellentesque tristique odio a odio tincidunt aliquet. Nam et dapibus enim. Sed malesuada consequat purus, at dignissim mauris porttitor non. Donec faucibus ligula sed mauris commodo commodo.';
	
	listDataSent[2] = new Object;
	listDataSent[2].ID ="sent3";
	listDataSent[2].Date = '05.11.2011'
	listDataSent[2].Type = 'Notification'
	listDataSent[2].Sender = "+61 402 991 115";
	listDataSent[2].Message = 'Sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.';
}

function sortList(a,b)
{
	return a.Date < b.Date;
}

function MessageList_GetList()
{
	setStatusBar('General.PleaseWait');
	if(CefRunning())
	{		
		var listDataSentTmp = cef.messages.GetList(MessageCategory_Sent);
		var listDataInboxTmp = cef.messages.GetList(MessageCategory_Inbox);
		
		listDataInboxTmp.sort(sortList);
		listDataSentTmp.sort(sortList);
		
		var info = cef.messages.GetInfo();
		if(info)
			numUnreadMsgs = info.UnreadMessages;
		
		var selectedItems = [];		
		//Loop through and transfer selected items
		for(var i=0; i<listDataSent.length; i++)
		{
			if(listDataSent[i].selected)
				selectedItems.push(listDataSent[i].ID);
		}
		for(var i=0; i<listDataSentTmp.length; i++)
		{
			for(var j=0; j<selectedItems.length; j++)
			{
				if(selectedItems[j] == listDataSentTmp[i].ID)
					listDataSentTmp[i].selected = true;
			}
		}
		
		selectedItems = [];	
		for(var i=0; i<listDataInbox.length; i++)
		{
			if(listDataInbox[i].selected)
				selectedItems.push(listDataInbox[i].ID);
		}
		for(var i=0; i<listDataInboxTmp.length; i++)
		{
			for(var j=0; j<selectedItems.length; j++)
			{
				if(selectedItems[j] == listDataInboxTmp[i].ID)
					listDataInboxTmp[i].selected = true;
			}
		}		
		
		listDataSent = listDataSentTmp;
		listDataInbox = listDataInboxTmp;
	}
	else
	{
		setMessageList_SentFake();
		setMessageList_InboxFake();
	}
}

function Update()
{
	MessageList_GetList();
	TabClicked(currentTab);
}

function TabClicked(tabName)
{
	if(tabName != currentTab)
	{
		for(var i=0;i<listDataInbox.length;i++)
			listDataInbox[i].selected = false;
		for(var i=0;i<listDataSent.length;i++)
			listDataSent[i].selected = false;	

		selectedID = '';			
	}
	
	currentTab = tabName;
	$('#InboxTab').removeClass('ActiveTab')
	$('#InboxTab').addClass('Tab')
	$('#SentTab').removeClass('ActiveTab')
	$('#SentTab').addClass('Tab')
	
	$('#'+tabName).removeClass('Tab')
	$('#'+tabName).addClass('ActiveTab')
	
	if(tabName == 'SentTab')
	{
		//selectedID_InboxList = selectedID;
		//selectedID = selectedID_SentList;
		updateMessagesList(listDataSent);
	}
	else
	{
		//selectedID_SentList = selectedID;
		//selectedID = selectedID_InboxList;
		updateMessagesList(listDataInbox);
	}
	
	CheckMobileDevicePresent();
}

function Button_NewSMS()
{
	var to = "";
	var msg = "";

	if(CefRunning())
	{
		cef.messages.SetNewMessageValues(to, msg);
		cef.application.OpenNovusWindow(NovusWindowId_NewSmsWindow);
	}
}

function Button_Forward()
{
	var to = "";
	var msg = "";

	var listData;
	
	if(currentTab == 'SentTab')
		listData = listDataSent;
	else
		listData = listDataInbox;

	for(var i=0;i<listData.length;i++)
	{
		if(listData[i].ID == selectedID)
		{
			//to = listData[i].Sender;
			msg = listData[i].Message;
			break;
		}
	}

	if(CefRunning())
	{
		cef.messages.SetNewMessageValues(to, msg);
		cef.application.OpenNovusWindow(NovusWindowId_NewSmsWindow);
	}
}

function Button_Reply()
{
	var to = "";
	var msg = "";

	var listData;
	
	if(currentTab == 'SentTab')
		listData = listDataSent;
	else
		listData = listDataInbox;

	for(var i=0;i<listData.length;i++)
	{
		if(listData[i].ID == selectedID)
		{
			to = listData[i].Sender;
			//msg = listData[i].Message;
			break;
		}
	}

	if(CefRunning())
	{
		cef.messages.SetNewMessageValues(to, msg);
		cef.application.OpenNovusWindow(NovusWindowId_NewSmsWindow);
	}
}

function Button_Delete()
{
	
	DeleteCurrentItemConfirm();
}

function Button_Refresh()
{
	
	if(CefRunning())
		cef.messages.Refresh();
		
	MessageList_GetList();
}

function disableAllMessagesTools()
{
	disableButton('newSMSButton');
	disableButton('replyButton');
	disableButton('forwardButton');
	disableButton('deleteButton');
	//disableButton('refreshButton');
}

function enableAllMessagesTools()
{
	enableButton('newSMSButton');
	enableButton('replyButton');
	enableButton('forwardButton');
	enableButton('deleteButton');
	enableButton('refreshButton');
}

function disableButton(buttonID)
{
	$('#'+buttonID).attr('disabled','disabled');
}
function enableButton(buttonID)
{
	$('#'+buttonID).attr('disabled','');
}