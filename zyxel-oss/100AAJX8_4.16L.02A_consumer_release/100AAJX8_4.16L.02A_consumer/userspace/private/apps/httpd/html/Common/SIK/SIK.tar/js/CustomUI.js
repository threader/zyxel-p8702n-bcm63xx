


$(window).load(function()
{
//	barWidth =  $('#timerBarProgress').width();
	//$('#timerBarProgress').html('<div id="timerBarProgressBarStyle" style="width:'+barWidth+'px"></div>');
	//$('.StatusBar').attr('opacity',100);
	
	//setStatusBar('General.PleaseWait');
});

function setStatusBar(val)
{
	if(val)
	{
		var divCode = '<div class="StatusBar""></div>';
		var temp = $('.StatusBar').length;
		
		if(temp == 0){
			$("body").append(divCode);
		}
		
		$(".StatusBar").css({ opacity: 1 });
			$(".StatusBar").html(getTrans(val));
	}
	else
	{
		hideStatusBar();
	}
}

function hideStatusBar()
{
	$(".StatusBar").css({ opacity: 0 });
		$(".StatusBar").html('');
}

var barWidth = 200;
var t;
var timerCount;
var timerCountMax;

var timer_is_on=0;
var timer_update_interval=10;

var startTime;
	
var currentTime;
var timerLengthSec;
var elapsed = '0.0';  

function GetCurrentTime()
{
	var my_current_timestamp;
	my_current_timestamp = new Date();		
	
	return my_current_timestamp.getTime();
}

function initialiseProgressBar()
{
	barWidth =  $('#timerBarProgress').width();
	$('#timerBarProgress').html('<div id="timerBarProgressBarStyle" style="width:'+barWidth+'px"></div>');	
}
	
function setTimerBarDuration(sec){
		
	//initialiseProgressBar();
	
	timerLengthSec = sec;
	startTime = GetCurrentTime();
	//timerCount = 0;
	//timerCountMax = (sec*1000)/timer_update_interval;

	t = setTimeout("timedCount()",timer_update_interval);
}

function timedCount()
{
	currentTime  = GetCurrentTime();
	
	var timeDiff =  (currentTime -startTime)/1000;
	var percentToSet = (timeDiff/timerLengthSec)*100;
	
    //update timer;
	if(percentToSet>100)
	{
		setTimerBarProgressINTERNAL(percentToSet);
		clearTimeout(t);
		timerCompleteEvent();
	}
	else
	{		
		setTimerBarProgressINTERNAL(percentToSet);
				
		t=setTimeout("timedCount()",timer_update_interval);
	}
}

function setTimerBarProgress(perc)
{
			initialiseProgressBar()
			setTimerBarProgressINTERNAL(perc)
}

function setTimerBarProgressINTERNAL(perc)
{
	initialiseProgressBar()
	
	var percentToSet = 0;
	if(perc>0)
	{
		var widthFactor = barWidth/100;
		percentToSet = perc*widthFactor +2;
	}
	var StyleTmp = document.getElementById("timerBarProgressBarStyle");
	if (StyleTmp || FINVars.StopTimerNow < 1)
	document.getElementById("timerBarProgressBarStyle").style.clip = 'rect(0px '+percentToSet+'px 1000000px 0px)'
}
