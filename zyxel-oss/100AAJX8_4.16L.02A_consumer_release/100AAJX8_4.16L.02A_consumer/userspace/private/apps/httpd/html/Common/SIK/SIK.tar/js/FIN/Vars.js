var FINVars = new Object();


FINVars.SIK = true;
FINVars.NewValue = 0;
FINVars.StopTimerInterval = 0;
FINVars.TimeOut = 0;
FINVars.xdslstatus = "";
FINVars.ShowtimeC = 0;
FINVars.StartTime = 0;

FINVars.Rating = 0;
FINVars.Comment = "";

FINVars.DEBUG = 'false';
FINVars.FINPath;
FINVars.CurrentTab;
FINVars.CurrentNode;
FINVars.CurrentScreen;
FINVars.LastScreen;

FINVars.CurrentLanguage = 'NO';
FINVars.c = 0;
FINVars.TimerIntervalCall = 0;
FINVars.TimerIsOn = 0;
FINVars.SignalStrength = 0;

FINVars.AsyncNativeTimerId = 0;

FINVars.OperatingSystem = '';           // Windows IOS Android Mac Linux?
FINVars.OperatingSystemVersion = '';    // XP, Vista, Win7, Win8 IOS6.01 MacLion
FINVars.ServicePack = '';               // SP0, SP1 etc to SPn...
FINVars.BitLevel = '';                  // 32-bit 0r 64-bit

///////////////////

FINVars.AppVersion = '2.1.0.45';        // Version of FWSIK
FINVars.InstallID = '';                 // Hashed value
FINVars.PublicIP = '';                  // Returned value 
FINVars.UserAgent = '';                 // std user agent
FINVars.Screen = '';                    // Actual screen size
FINVars.ConnInfo = '';                  // Connection Information

FINVars.HelpDeskNumber = "05000";
FINVars.CompanyName = "Telenor Norway";
FINVars.SupportWebsite = "http://www.telenor.no/privat/kundeservice/bredbandshjelp/";
FINVars.ProductName = "Self Installation Kit";


FINVars.IgnoreImageRotation = Array("INTRODUCTION","NEW_COMPONENTS");

///////////////////



// The following vars are hard coded.
FINVars.ModemType = 'ZY-P8702';
FINVars.ConnectionType = 'ADSL';
FINVars.FixedCableType = '';

FINVars.CableType = 'Fibre';
FINVars.Brand = "Canal Digital";

FINVars.HasProfileSSID = '';


FINVars.TimerHeader = "";
FINVars.ErrorHeader = "";
FINVars.ErrorMain = "";
FINVars.SuccessHeader = "";
FINVars.SuccessMain = "";
FINVars.BrowserType = "";

// The following VARS are Hard Coded for CC4 Demo //
// they will need to be DYNAMIC

FINVars.InternetStatus="Not Connected";
FINVars.InternetISPName="Telenor";
FINVars.InternetPublicIP = "88.88.88.88";
FINVars.ISPThumbnail="images/ticket/ISP_None.png";


FINVars.DeviceStatus="Not Connected";

// END Hard Coded cc4 demo vars 

var FINState = new Object();

FINState.NodeHistory = Array();
FINState.TabHistory = Array();
FINState.Breadcrumbs = Array();
