
var tempfield = "";
var erroroff = false;

var FINFunctions = new Object();
var DEBUG_FINFLOW = false;
var FIN;
var InternetOn = false;
var ShowtimeC = 0;
var JsonObj = new Object();

//// All SetIntervals use this ID
var intervalID;

//FINVars.TimerHeader = getTrans("General.Testing");


if (!FIN)
	FIN = {};
	
// End of Vars ////////////////////////////////////////

// Start of functions /////////////////////////////////

FINFunctions.Preload = function(arrayOfImages) {

    $(arrayOfImages).each(function(){
        $('<img/>')[0].src = this;
        // (new Image()).src = this;
    });
}

FINFunctions.StartPreload = function()
{
	FINFunctions.Preload([
			'images/FIN/EditorImages/IMG10_2013_0612_01_0011.png',
			'images/FIN/EditorImages/IMG14_2013_0620_04_5819.png',
			'images/FIN/EditorImages/IMG18_2013_0621_10_2944.png',
			'images/FIN/EditorImages/IMG1_2013_0612_09_2608.png',
			'images/FIN/EditorImages/IMG23_2013_0624_12_5705.png',
			'images/FIN/EditorImages/IMG24_2013_0624_01_0941.png',
			'images/FIN/EditorImages/IMG27_2013_0624_04_4123.png',
			'images/FIN/EditorImages/IMG30_2013_0624_06_3653.png',
			'images/FIN/EditorImages/IMG31_2013_0624_06_3653.png',
			'images/FIN/EditorImages/IMG32_2013_0624_06_3653.png',
			'images/FIN/EditorImages/IMG35_2013_0624_09_0540.png',
			'images/FIN/safe_image.png',
			'images/FIN/EditorImages/IMG40_2013_0723_01_2158.png',    
			'images/FIN/EditorImages/IMG42_2013_0723_01_4110.png',  
			'images/FIN/EditorImages/IMG43_2013_0723_01_5319.png',    
			'images/FIN/EditorImages/IMG44_2013_0723_02_3153.png',    
			'images/FIN/EditorImages/IMG45_2013_0723_02_3808.png',    
			'images/FIN/EditorImages/IMG46_2013_0723_02_4922.png',    
			'images/FIN/EditorImages/IMG47_2013_0723_03_0624.png',    
			'images/FIN/EditorImages/IMG48_2013_0723_03_0627.png',    
			'images/FIN/EditorImages/IMG39_2013_0722_01_1521.png'    
        ]);
}


FINFunctions.OpenURL = function(FunctionName) 
{
    window.location.href = "http://online.no";
    returnCode = "Succeed";   
}

FINFunctions.StartTimerWithParam = function(FunctionName)
{
	var HText;
	var MText;
	var FTime = 0;
	FINVars.NewValue = 0;
	FINVars.StopTimerNow = 0;
	FINVars.ShowtimeC = 0;
    document.getElementById("NOEN").style.visibility = "hidden";

    if (FunctionName.Param == "TestForInternet") 
    {
	    FINFunctions.StartPreload(); 
	    HText = "TimerTestInternetHead";
        MText = "TimerTestInternetMain";
        FTime = 60;
        ShowtimeC = 0;
    }
    else if (FunctionName.Param == "TestForShowTime") 
    {	
        HText = "TimerTestShowTimeHead";
        MText = "TimerTestShowTimeMain";
        FTime = 200;
        ShowtimeC = 0;

    }
    else
    {
    	var ReturnValue=FINFunctions[FunctionName.Param]();
    	return;
    }

    var timerParams = {
			Timeout : FTime,
			ShowProgress : true,
			HeaderText : HText,
			MainText : MText			 
		};
    FINFunctions.FINWait(timerParams);
	
	var ReturnValue=FINFunctions[FunctionName.Param]();
}

FINFunctions.TestInternet = function(param) {

    FINVars.NewValue = FINVars.NewValue + 1;
    if (FINVars.NewValue > 2) {

        FINShowtime();

        if (FINVars.xdslstatus == "down") {
            if (FINVars.NewValue > (FINVars.TimeOut)) {
                FINVars.StopTimerNow = 1;
                returnCode = "Fail";
            }
            else return;
        }

        var xmlHttp = null;

        if (navigator.userAgent.match(/MSIE 8/i) || navigator.userAgent.match(/MSIE 9/i)) {
            if (window.ActiveXObject) {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
            else if (window.XMLHttpRequest) {
                xmlHttp = new XMLHttpRequest();
            }
            else {
                xmlHttp = null;
            }
        }
        else {
            xmlHttp = new XMLHttpRequest();
        }

        if (xmlHttp) {
            try {
                xmlHttp.open("GET", 'https://hjelpen.telenor.net/telenorhjelpen/apps/myip.aspx', false);
                xmlHttp.send();
                if (xmlHttp.responseText != "") {
                    JsonObj.Field5 = xmlHttp.responseText;
                    FINVars.StopTimerNow = 1;
                    returnCode = "Succeed";
                    document.getElementById("OnlineNO").style.visibility = "visible";
                    document.getElementById("Waitnow").style.visibility = "visible";
                    FINFunctions.Finish();
                }
            }
            catch (e) {
                try {
                    xmlHttp = null;
                    xmlHttp = new XDomainRequest();
                    xmlHttp.open("GET", 'http://hjelpen.telenor.net/telenorhjelpen/apps/myip.aspx', false);
                    xmlHttp.send();
                    if (xmlHttp.responseText != "") {
                        JsonObj.Field5 = xmlHttp.responseText;
                        FINVars.StopTimerNow = 1;
                        returnCode = "Succeed";
                        document.getElementById("OnlineNO").style.visibility = "visible";
                        document.getElementById("Waitnow").style.visibility = "visible";
                        FINFunctions.Finish();
                    }
                }
                catch (e) {
                }
            }
        }
    }
    if (FINVars.NewValue > (FINVars.TimeOut)) {
        FINVars.StopTimerNow = 1;
        returnCode = "Fail";
        document.getElementById("NOEN").style.visibility = "visible";
    }
}

FINFunctions.TestShowTime = function(param) {
    FINVars.NewValue = FINVars.NewValue + 1;

    if (FINVars.NewValue > 2) {

        FINShowtime();
        
        if (FINVars.xdslstatus == "down") {
            if (FINVars.NewValue > (FINVars.TimeOut)) {
                FINVars.StopTimerNow = 1;
                returnCode = "Fail";
            }
            else return;
        }
        
        var xmlHttp = null;

        if (navigator.userAgent.match(/MSIE 8/i) || navigator.userAgent.match(/MSIE 9/i)) {
            if (window.ActiveXObject) {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
            else if (window.XMLHttpRequest) {
                xmlHttp = new XMLHttpRequest();
            }
            else {
                xmlHttp = null;
            }
        }
        else {
            xmlHttp = new XMLHttpRequest();
        }

        if (xmlHttp) {
            try {
                xmlHttp.open("GET", 'https://hjelpen.telenor.net/telenorhjelpen/apps/myip.aspx', false);
                xmlHttp.send();
                if (xmlHttp.responseText != "") {
                    JsonObj.Field5 = xmlHttp.responseText;
                    FINVars.StopTimerNow = 1;
                    returnCode = "Succeed";
                    document.getElementById("OnlineNO").style.visibility = "visible";
                    document.getElementById("Waitnow").style.visibility = "visible";
                    FINFunctions.Finish();
                }
            }
            catch (e) {
                try {
                    xmlHttp = null;
                    xmlHttp = new XDomainRequest();
                    xmlHttp.open("GET", 'http://hjelpen.telenor.net/telenorhjelpen/apps/myip.aspx', false);
                    xmlHttp.send();
                    if (xmlHttp.responseText != "") {
                        JsonObj.Field5 = xmlHttp.responseText;
                        FINVars.StopTimerNow = 1;
                        returnCode = "Succeed";
                        document.getElementById("OnlineNO").style.visibility = "visible";
                        document.getElementById("Waitnow").style.visibility = "visible";
                        FINFunctions.Finish();
                    }
                }
                catch (e) {
                }
            }
        }
    }
    if (FINVars.NewValue > (FINVars.TimeOut)) {
        FINVars.StopTimerNow = 1;
        returnCode = "Fail";
    }
}

FINFunctions.TestForInternet = function(param) {
    var TimeOut;
    FINVars.TimeOut = 30;

    if (FINVars.StopTimerNow > 0) {
        clearTimeout(TimeOut);
        $('#NavButtons').show();
        FINControl.FunctionReturn(returnCode);
    }
    else {
        FINFunctions.TestInternet();
        TimeOut = setTimeout(function() { FINFunctions.TestForInternet(); }, 1000);
    }
}

FINFunctions.TestForShowTime=function(param)
{
var TimeOut;
FINVars.TimeOut = 160;

    if(FINVars.StopTimerNow > 0)
    {
        clearTimeout(TimeOut);
        $('#NavButtons').show();
		
        FINControl.FunctionReturn(returnCode);
        if (returnCode == "Succeed") {
            document.getElementById("OnlineNO").style.visibility = "visible";
        }
        else 
        {
            document.getElementById("NOEN").style.visibility = "visible";
        }
    }
	else 
	{
	    FINFunctions.TestShowTime();
	    TimeOut = setTimeout(function() { FINFunctions.TestForShowTime(); }, 1000);
	}
}


FINFunctions.Log = function(param) 
{
    
	FINControl.FunctionReturn("Succeed");
}

// FINFunctions.FINWait
// Sets a timer going, with corresponding timer bar. Timeout is defined in the function
// node (Nodes.js)

FINFunctions.FINWait = function(param) 
{
    //var TheTimerHeader = getTrans("General.Testing"); // default
    //var TheTimerText = getTrans("General.PleaseWait"); // default
    var TimerLength = 20;
    var ShowProgress = false;

    if (param != undefined) 
    {
        if (param.HeaderText != undefined) 
        {
            TheTimerHeader = getTrans("General." + param.HeaderText);
        }
        if (param.MainText != undefined) 
        {
            TheTimerText = getTrans("General." + param.MainText);
        }
        if (param.Timeout != undefined) 
        {
            TimerLength = param.Timeout;
        }
        if (param.ShowProgress != undefined) 
        {
            ShowProgress = param.ShowProgress;
        }
    }
    
    FINVars.TimerHeader = TheTimerHeader;
    FINVars.TimerText = TheTimerText;
    StartDurationTimer(TimerLength, ShowProgress);
}

// FINFunctions.Counter
// Used internally for counter notes.

FINFunctions.Counter = function(param) 
{
    //FINVars.TimerText = getTrans("General.PleaseWait");	
    FINControl.FunctionReturn(Nodes[FINVars.CurrentNode].AccessCount.toString());
}

// FINFunctions.Finish	
// function executes when Finish button is clicked

FINFunctions.Finish = function(param) {
    FINFunctions.ExitFIN(param);
}

// FINFunctions.ExitFIN
// Terminates FIN and shows standard Help Window content

FINFunctions.ExitFIN = function(param) {
    document.getElementById("NOEN").style.visibility = "hidden";
    document.getElementById("OnlineNO").style.visibility = "visible";
    document.getElementById("Waitnow").style.visibility = "visible";

    var ScreenTmp = [FINVars.CurrentNode].ScreenID;

    $('#MenuContainer').show();
    $('#UserHeader').show();
    $('#TicketMenu').show();
    $('#TicketStatus').show();

    $('#Back').hide();
    $('#Next').hide();
    $('#Container').hide();
    FINControl.ClearStates(); // clear State arrays
    FINControl.UpdateTesting(); // update text fields
    document.getElementById("testingForm").style.display = "none";

    FINActive = false;

    if (FINVars.LastScreen == "FIBRE_001" || FINVars.LastScreen == "FAIL_SCREEN" || FINVars.LastScreen == "ORDER_EXPERT" || FINVars.LastScreen == "EXPERT_MULTI_SOCKET") {
        window.close();
        return "Exit";
    }
    else {
        JsonObj.Field1 = FINVars.AppVersion;
        JsonObj.Field2 = FINVars.InstallID;
        JsonObj.Field3 = FINVars.UserAgent;
        JsonObj.Field4 = FINVars.Screen;
        JsonObj.Field7 = FINVars.CurrentLanguage;
        JsonObj.Field8 = FINVars.ModemType;

        if (navigator.userAgent.match(/MSIE/i))
            JsonObj.Field9 = navigator.systemLanguage;
        else
            JsonObj.Field9 = window.navigator.language;

        var d = new Date();
        var n = d.getTime();

        JsonObj.Field10 = n - FINVars.StartTime;    // Duration of SIK
        JsonObj.Field11 = tempfield;
        
            
        var s = document.createElement("script");
        s.type = "text/javascript";
        s.src = "https://wg.telenor.net/4asdnqw.js?jsonp=CIDCallback";
        $("head").append(s);

        GetCID().done(StartLicLog);
    }
}

GetCID = function() {
    var r = $.Deferred();
    window.CIDCallback = function(str) {
        JsonObj.Field6 = str;
    }

    setTimeout(function() { r.resolve(); }, 2500);
    return r;
};


var StartLicLog = function() {

    var xhr = null;
    xhr = new XMLHttpRequest();

    try {
        xhr.open('POST', 'https://hjelpen.telenor.net/telenorhjelpen/fwsikwebapi/api/install', true);
        xhr.setRequestHeader("Method", "POST " + 'https://hjelpen.telenor.net/telenorhjelpen/fwsikwebapi/api/install' + " HTTP/1.1");
        xhr.setRequestHeader('Content-type', 'application/json; charset=utf-8');
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4) {
                document.location.href = "http://online.no";
            }
        };
        xhr.send(JSON.stringify(JsonObj));
    }
    catch (e) {
        try {
            xhr = null;
            xhr = new XDomainRequest();
            xhr.open('POST', 'http://hjelpen.telenor.net/telenorhjelpen/fwsikwebapi/api/installnossl');
            xhr.onload = function() {
                document.location.href = "http://online.no";
            };
            xhr.send(JSON.stringify(JsonObj));
        }
        catch (e) {
        }
    }
    if (navigator.userAgent.match(/MSIE 8/i) || navigator.userAgent.match(/MSIE 9/i))
        document.location.href = "http://online.no";        
};


function CloseUp() {

}

// StartProblemLog

FINFunctions.StartProblemLog = function(param) 
{
    FINControl.FunctionReturn("Succeed");
}

// FinishProblemLog

FINFunctions.FinishProblemLog = function(param) 
{
    FINControl.FunctionReturn("Succeed");
}

// FIN.Timer* Functions
FIN.TimerComplete = function TimerComplete() 
{
    $('#NavButtons').show();
    FINVars.TimerIsOn = 0;
    $('#progressbar').hide();
}

FIN.StartTimer = function StartTimer(baseValue) 
{
    if (typeof (baseValue) === 'undefined')
        baseValue = 0;
    
    FINVars.CurrentScreen = "TIMER";
    FINControl.TimerScreen();

    FIN.UpdateTimer(baseValue);
    FINVars.TimerIsOn = 0;
    TimerIsOn = 1;
    $('#NavButtons').hide();
    $('#progressbar').show();
}

FIN.UpdateTimer = function UpdateTimer(val) 
{
    setTimerBarProgress(val);
}

function timerCompleteEvent() 
{
    FIN.TimerComplete();
	/*
    if (FINVars.StopTimerNow < 1){
       FINControl.FunctionReturn('Succeed'); // This is for the timer that just times out for a given time
	}
	*/
}

// Duration Timer Functions
// These are for internal use only. This initiates an automatic timer screen that runs for a set duration.
// Starts a duration timer
function StartDurationTimer(timeout, showProgress) 
{
	if (typeof (showProgress) === 'undefined') 
		showProgress = true;
    if (!FINVars.TimerIsOn) 
    {
       FIN.StartTimer(showProgress ? 0 : 100);
        setTimerBarDuration(timeout, showProgress);
    }

}

FINFunctions.FINPathJump = function() {
    var FINPath = document.getElementById('FINPath').value;
    var DecisionNode = document.getElementById('DecisionNode').value;
    
    selected = FINPath;

    FINControl.HandleNextNode(DecisionNode);
}


// set BrowserType var within FIN screen
FINFunctions.SetBrowserTypeFIN= function(param)
{
	if(BrowserType!=param.BrowserType)
	{
		BrowserType=param.BrowserType;
	
		if(BrowserType=="Mobile")
		{
			loadjscssfile("css/Mobile.css", "css");	
			removejscssfile("css/NonMobile.css", "css"); //remove all occurences "somestyle.css" on page
			UpdateFlagIcons();
		} else {
			loadjscssfile("css/NonMobile.css", "css");
			removejscssfile("css/Mobile.css", "css"); //remove all occurences "somestyle.css" on page
			UpdateFlagIcons();
		}
	}
	
	FINControl.FunctionReturn("Succeed");
}


// End of functions.js ////////////////////////////////
///////////////////////////////////////////////////////