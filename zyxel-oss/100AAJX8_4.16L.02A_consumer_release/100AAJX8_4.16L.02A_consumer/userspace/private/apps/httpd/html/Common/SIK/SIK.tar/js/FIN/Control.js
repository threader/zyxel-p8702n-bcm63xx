var FINControl=new Object();
var imagesPath =  'images/FIN/EditorImages/';
    FINControl.ResetFIN=function()
	{
		FINControl.ClearAccessCount();
        FINVars.CurrentLanguage = language;
        FINVars.CurrentNode = 'N000';
		FINVars.CurrentTab = 'T001';
		FINState.TabHistory[0] = FINVars.CurrentTab;
		FINControl.UpdateTesting();
        FINVars.CurrentScreen = Nodes[FINVars.CurrentNode].ScreenID;
        FINControl.HandleNodeType();
		FINControl.ChangeSignalStrengthImage();
		FINVars.ErrorHeader = getTrans("General.ErrorGenericHeader");
		FINVars.ErrorMain = getTrans("General.ErrorGenericMain");
		FINVars.SuccessHeader = getTrans("General.SuccessGenericHeader");
		FINVars.SuccessMain = getTrans("General.SuccessGenericMain");
    }
    
	 FINControl.ClearAccessCount=function(){
		for (var NodeName in Nodes) {
			Nodes[NodeName].AccessCount = 0;
		}

}
	
    FINControl.ClearStates=function()
	{
	   FINControl.ClearAccessCount();
	   FINVars.CurrentNode = '';
        FINVars.CurrentScreen = '';
		if(document.testing.Screen){
				document.testing.Screen.value = "";
		}
		FINState.NodeHistory=Array();
		FINState.TabHistory=Array();
		FINState.Breadcrumbs = Array();
    }
    
	FINControl.BackClicked=function(){
		FINVars.CurrentNode = FINState.Breadcrumbs[FINState.Breadcrumbs.length - 1];
		FINState.Breadcrumbs.pop();
		FINControl.PopNodeHistory(FINVars.CurrentNode);
		FINControl.UpdateTesting();
		FINState.Breadcrumbs.pop();
		FINControl.HandleNodeType();
	}
	
	FINControl.PopNodeHistory=function(NodeScreen){
		var Lengths = FINState.NodeHistory.length;
		for(i=0;i<=Lengths;i++){ 
			var Pop = FINState.NodeHistory.pop(); 
			if(Pop){
				var ThisTab = Nodes[Pop].ParentTab; 
				if(ThisTab==FINVars.CurrentTab){
					var PopTab = FINState.TabHistory.pop();	
					FINVars.CurrentTab = FINState.TabHistory[FINState.TabHistory.length-1];
				}
				if(Nodes[Pop].ScreenID){
					if (Pop != NodeScreen && Nodes[Pop].ScreenID!=''){
						FINVars.CurrentNode = Pop;
						break;	
					} 
				} else if (Nodes[Pop].Type=="function"){
					if(Nodes[Pop].Function=="Counter"){ 
						Nodes[Pop].AccessCount--; 
					}
				}
			} else {
				FINControl.ErrorReport('No parent node');
			}
		}
	}

	FINControl.NextClicked=function(NewNode){
		clearInterval(intervalID);
		FINControl.HandleNextNode(NewNode);
			
	}

	FINControl.HandleNodeType=function()
	{	
		FINState.NodeHistory[FINState.NodeHistory.length] = FINVars.CurrentNode;
		var nodeType = Nodes[FINVars.CurrentNode].Type; 
		FINControl.UpdateTesting();
		FINControl.UpdateTabHistory();
		
		FINLog.HandleNode(Nodes[FINVars.CurrentNode]);
		if (nodeType=='screen'){
			FINControl.NodeScreen();
		} else if(nodeType=='selection'){	
			FINControl.NodeSelection();
		} else if(nodeType=='function'){	
		
			FINControl.NodeFunction();
		} else if(nodeType=='decision'){
			FINControl.NodeDecision();
			
		} else if(nodeType=='tab'){ 
			FINControl.NodeTab();
		} else if(nodeType=='start'){ 
			FINControl.NodeStart();
		} else if(nodeType=='end'){ 
			FINControl.NodeEnd();
		} else {	
			alert("Error: Unknown Screen Type");	
		}
	}
	
	FINControl.UpdateTabHistory=function(){
		FINVars.CurrentNodeTab = Nodes[FINVars.CurrentNode].ParentTab;
		if(FINVars.CurrentNodeTab!=FINVars.CurrentTab){
			FINVars.CurrentTab=	FINVars.CurrentNodeTab;
			FINState.TabHistory[FINState.TabHistory.length] = FINVars.CurrentTab;
			FINControl.UpdateTesting();
		}
	}

	FINControl.UpdateTesting=function(){
		document.testing.Breadcrumbs.value = FINState.Breadcrumbs;
		document.testing.NodeHistory.value = FINState.NodeHistory;
		document.testing.TabHistory.value = FINState.TabHistory;	
		
		if(Nodes[FINVars.CurrentNode]){
			if(Nodes[FINVars.CurrentNode].ScreenID){
				document.testing.Screen.value = Nodes[FINVars.CurrentNode].ScreenID; 
			} 
		}
	}

	FINControl.OptionSelected=function(Selected){
		FINVars.SelectedID = Selected.id; 
		
		var nodes = FINControl.GetByClass("RadioBoxSelected"), i=-1, node; 
		while (node=nodes[++i]) {
			node.setAttribute("class", "RadioBox"); 
		}
		var Box = "Box" + FINVars.SelectedID;
		document.getElementById(Box).setAttribute("class", "RadioBoxSelected"); 
		
		
		
		$('#Next').removeAttr("disabled");
		if(Nodes[FINVars.CurrentNode].Variable)
		{
			var Variable = Nodes[FINVars.CurrentNode].Variable;
			FINVars[Variable]=FINVars.SelectedID;
		}
		if (FINVars.OperatingSystem == 'IOS' || FINVars.OperatingSystem == 'Android')
			FINControl.NextClicked(Nodes[FINVars.CurrentNode].Paths);
		
	}
	
	FINControl.OptionSelected2=function(Selected){
		FINVars.SelectedID = Selected.id; 
		
		var nodes = FINControl.GetByClass("RadioBoxSelectedSmall RadioBoxSmall"), i=-1, node; 

		while (node=nodes[++i]) {
			node.setAttribute("class", "RadioBox RadioBoxSmall"); 
		}
	
		var Box = "Box" + FINVars.SelectedID;
		document.getElementById(Box).setAttribute("class", "RadioBoxSelectedSmall RadioBoxSmall"); 


		$('#Next').removeAttr("disabled");
		
		if(Nodes[FINVars.CurrentNode].Variable)
		{
			var Variable = Nodes[FINVars.CurrentNode].Variable;
			FINVars[Variable]=FINVars.SelectedID;
		}
		if (FINVars.OperatingSystem == 'IOS'|| FINVars.OperatingSystem == 'Android')
			FINControl.NextClicked(Nodes[FINVars.CurrentNode].Paths);	
	}	 
	
	FINControl.GetByClass = function(className, parent) {
	  parent || (parent=document);
	  var descendants=parent.getElementsByTagName('*'), i=-1, e, result=[];
	  while (e=descendants[++i]) {
		((' '+(e['class']||e.className)+' ').indexOf(' '+className+' ') > -1) && result.push(e);
	  }
	  return result;
	}
	
	FINControl.ActivateOptionSelection=function(Content){
		if(Content){
		FINVars.SelectedID=''; 
		var FindThis = 'class="Radio"';
		var ReplaceWith = 'class="Radio" onClick="FINControl.OptionSelected(this);"';
		Content = Content.replace(new RegExp(FindThis, 'g'),ReplaceWith);
		
		
		var FindThis2 = 'class="Radio RadioSmall"';
		var ReplaceWith2 = 'class="Radio RadioSmall" onClick="FINControl.OptionSelected2(this);"';
		Content = Content.replace(new RegExp(FindThis2, 'g'),ReplaceWith2);		
		}
		return Content;
	}

	FINControl.getRadioValue = function() {

	    if (document.forms.selection) {
	        if (FINVars.SelectedID) {
	            RadioValue = FINVars.SelectedID;
	            return RadioValue;
	        } else {
	            if (FINVars.CurrentLanguage == "EN") {
	                FINFunctions.AlertUser('You must select an option to continue.'); 
	            } else if (FINVars.CurrentLanguage == "NO") {
	                FINFunctions.AlertUser('Du må velge et alternativ for å fortsette.'); 
	            }
	        }
	    }
	}
	
	FINControl.ErrorReport=function(TheError){
		
	}
	
	FINControl.HandleNextNode=function(NewNode)
	{		
		if (NewNode instanceof Object)
		{
			var SelectValue = FINControl.getRadioValue();
			
			if(SelectValue)
			{
				if(NewNode[SelectValue]==undefined && NewNode['ELSE'])
				{
					FINVars.CurrentNode = NewNode['ELSE']; 
				}
				else
				{
					FINVars.CurrentNode = NewNode[SelectValue]; 
				}
				FINVars.CurrentScreen = Nodes[FINVars.CurrentNode].ScreenID; 
				
				var nodeType = Nodes[FINVars.CurrentNode].Type; 
				FINControl.HandleNodeType();
			}
		}
		else
		{
			if(NewNode)
			{
				FINVars.CurrentNode = NewNode;
				if(!Nodes[NewNode])
				{
					FINControl.ErrorReport('Cannot find node in Nodes[] - CurrentNode = ' + FINVars.CurrentNode);
				}
				else if(Nodes[NewNode].ScreenID)
				{
					FINVars.CurrentScreen = Nodes[NewNode].ScreenID;
				}
				var nodeType = Nodes[FINVars.CurrentNode].Type;
				FINControl.HandleNodeType();
			
			}
			else
			{
				if(FINVars.CurrentNode!='ENDFIN')
				{
				
					FINControl.ErrorReport('No Node Specified:'+NewNode+':CurrentNode = ' + FINVars.CurrentNode);
				}
			}
			
		}
	}
	
	FINControl.ChangeSignalStrengthImage = function(SignalStrength) {
	    //if(!SignalStrength)
	    //	return;

	    if (SignalStrength == undefined) {
	    }
	    else 
	    {
	        FINVars.SignalStrength = SignalStrength;
	    }
	    
	    if (document.getElementById("SignalStrength")) {
	        document.getElementById("SignalStrength").src = "images/SignalStrength/" + FINVars.SignalStrength + ".png";
	    }
	}
	
	FINControl.ReplaceVarsInString=function(Content)
	{
		if(!Content)
			return;
		
		var InThere = Content.match(/\$\$(.*?)\$\$/);
		
		if(InThere!=null){
			var FindMatch;
			for(i=0;i<Content.length;i++){
				FindMatch= Content.match(/\$\$(.*?)\$\$/);
				
				if(FindMatch!=null){
					var Replacement = FindMatch[1];
					var ReplacementBranded = Replacement + "_" + FINVars.Brand;
					
					var VarArray = Replacement.split('.');
					var a =VarArray[0];
					var b =VarArray[1];
					var ReplaceText = window[a][b];
					
					var BrandedArray= ReplacementBranded.split('.');
					var c =BrandedArray[0];
					var d =BrandedArray[1];
					var ReplaceTextBranded = window[c][d];					
					
					if(ReplaceTextBranded==undefined){
						if(ReplaceText==undefined){
							Content = Content.replace(FindMatch[0],'<span class="highlighter">Unknown Variable (' + a + '.' + b + ')</span>'); 
						} else {
							Content = Content.replace(FindMatch[0],ReplaceText); 
						}						
					} else {
						Content = Content.replace(FindMatch[0],ReplaceTextBranded); 
					}
				} else {
					break;
				}
			}
		}
		return Content;
	}
	
	FINControl.ScreenContent=function(Content)
	{
		Content = FINControl.ReplaceVarsInString(Content);
		
		Content = FINControl.ActivateOptionSelection(Content);
		$('#ScreenContent').html(Content);
		
	}
	
	FINControl.ScreenContentWithPath=function(Content,divID)
	{
		Content = FINControl.ReplaceVarsInString(Content);
		Content = FINControl.ActivateOptionSelection(Content);
		$('#'+divID).html(Content);
	}	
		
	FINControl.DisableButton=function(Button){
		$('#'+Button).hide(); 
		//$('#'+Button+'Disabled').show(); 
	}
	
	
	FINControl.EnableButton=function(Button){
		$('#'+Button).show(); 
		$('#'+Button).removeAttr("disabled");
		//$('#'+Button+'Disabled').hide(); 		
	}
	
	
	FINControl.DisableAllButtons=function(){
		FINControl.DisableButton('Back');
		FINControl.DisableButton('Next');
		FINControl.DisableButton('Exit');
		FINControl.DisableButton('Finish');
		FINControl.DisableButton('Retry'); 
	}
		
	FINControl.Buttons=function(ButtonsArray){
		FINControl.DisableAllButtons();
		for (x in ButtonsArray){
			FINControl.EnableButton(ButtonsArray[x]);			
		}
	}
	
	FINControl.TimerScreen = function() {
	    if (Screens[FINVars.CurrentScreen]) {
	        if (Screens[FINVars.CurrentScreen][FINVars.CurrentLanguage]) {
	            var HTMLContent = '<div class="ImageLayerStyle">' + Screens[FINVars.CurrentScreen][FINVars.CurrentLanguage] + '</div>';
	            if (Screens[FINVars.CurrentScreen][FINVars.CurrentLanguage + '_ImageLayer']) {
	                HTMLContent = '<div class="ImageLayerStyle">' + Screens[FINVars.CurrentScreen][FINVars.CurrentLanguage + '_ImageLayer'] + '</div>' + '<div class="TextLayerStyle">' + HTMLContent + '</div>';
	            }
	            FINControl.ScreenContent(HTMLContent);
	        } else {
	            FINControl.ErrorReport('No Content or Translation for Timer Screen # ' + FINVars.CurrentScreen);
	        }
	    } else {
	        FINControl.ErrorReport('No content for Screen ID # ' + FINVars.CurrentScreen);
	    }
	}
	
	FINControl.NodeScreen = function() {

	    if (Nodes[FINVars.CurrentNode].ScreenID) {
	        FINVars.CurrentScreen = Nodes[FINVars.CurrentNode].ScreenID; 
	        FINVars.LastScreen = FINVars.CurrentScreen;
	    } else {
	        FINControl.ErrorReport('No Content or Translation for Screen # ' + FINVars.CurrentScreen + ' * '); 
	    }

	    if (Nodes[FINVars.CurrentNode].Buttons) {
	        FINControl.Buttons(Nodes[FINVars.CurrentNode].Buttons); 
	    } else {
	        FINControl.Buttons(['Next', 'Back']);
	    }

	    FINState.Breadcrumbs[FINState.Breadcrumbs.length] = FINVars.CurrentNode; 

	    FINControl.ScreenContent(getScreenContent(Nodes[FINVars.CurrentNode].ScreenID, FINVars.CurrentLanguage));
		
		if(BrowserType=="Mobile")
		{
			// if Mobile browser loop through all Paragraphs and remove annoying empty paragraphs in HTML code
			$('p').each(function(index, item) { // Loop thru all P tags
				if($.trim($(item).text()) === "" || $.trim($(item).text())=="<br>") { // is content of P empty?
					$(item).remove(); // remove this item ;
				}
			});
			
			$('#Container').css({ overflow: "visible" });	

			ButtonPositioning();
		}

	    FINControl.UpdateTesting(); 
	}
	
	
	function ButtonPositioning()
	{
			var HeightDiv =540;
			if(BrowserType=="Mobile"){
				if(IsContentsScreen==-1)
				{
					var H = $("#TextLayerStyle").height();
					//var p1 = $("#TextLayerStyle").css('padding-top');
					//var p2 = $("#TextLayerStyle").css('padding-bottom');
					HeightDiv = (60 + H)+10;
				}
				$("#NavButtons").css({top: HeightDiv+'px'});
			}
	}
	
	var IsContentsScreen=-1;
	
    function getScreenContent(screenID,lang){
		//screenID = Nodes[FINVars.CurrentNode].ScreenID;
		//lang = FINVars.CurrentLanguage;
		lang = lang.toUpperCase();
		var HTMLCombined = '';
		var HTML = Screens[screenID][lang];
		if(!HTML){
			HTML = '';
		}
		//FINControl.ScreenContent(HTML);
		var HTML_Custom = ''
		if(Screens[screenID].Custom){
			HTML_Custom = Screens[screenID].Custom;
		}else{
			HTML_Custom = '';
		}		
		HTML_IMG = '';
		if(Screens[screenID].Images){
			if(Screens[screenID].Images[lang]){
				var imgArr = Screens[screenID].Images[lang];
				for(var j=0;j<imgArr.length;j++){
					var id = 'image'+(j+1);
					var ImageID = imgArr[j].ImageID
					var top = imgArr[j].Y
					var left = imgArr[j].X
					var ML = imgArr[j].ML;
					var MR = imgArr[j].MR;
					var X2 = imgArr[j].X2;								
					var imageURL = getImageURLWithSwitch(ImageID);
					//var isSuperImage =  Images[ImageID].SwitchVariable;
					var imagePath = imageURL //imagesPath+Images[ImageID].URL
					var zindex = j;
					if(imgArr[j].Z){
						var zindex = imgArr[j].Z;
					}
					var allLang = '';
					if(imgArr[j].languageLink){
						allLang = 'languageLink="'+imgArr[j].languageLink+'"';
					}
					var StyleString = "";
					var TopPos;
					var LeftPos;
					IsContentsScreen=HTML.indexOf('<div id="Components">'); // we should only move image if not part of Components screen
					var C1='';
					var C2='';
					
					//if(BrowserType=="Mobile" && IsContentsScreen==-1)
					//{
					//	TopPos ='';
					//	LeftPos=' margin-left:auto;margin-right:auto;left: 0px; right: 0px;';
					//	C1='<center><div class="centredmob">';
					//	C2='</div></center>';						
						
						
					//} else {
						TopPos='top:'+top+'px;';
						LeftPos=' left:'+left+'px;';
					//}
					
					//position: absolute
					//var PosAb="position: absolute;";
					
					if(ML=='auto' && MR=='auto' || (BrowserType=="Mobile" && IsContentsScreen==-1))
					{
						
						LeftPos='left: 0px; right: 0px;';
						
						if(BrowserType=="Mobile" && IsContentsScreen==-1){
							TopPos ='';
						}
						// css style for centering image on screen
						StyleString = 'style="position:relative;'+TopPos+' '+LeftPos+' margin-left:auto;margin-right:auto; z-index:'+zindex+';"';
						if(BrowserType!="Mobile"){
							C1='<div class="centred">';
							C2='</div>';
						}else {
							C1='<center><div class="centredmob">';
							C2='</div></center>';	
						}
					} else {
						StyleString = 'style="position:absolute;'+TopPos+''+LeftPos+'z-index:'+zindex+';"';
					}			
									
					HTML_IMG +=C1+'<img '+allLang+' id="'+id+'" lang="'+lang+'" ImageID='+ImageID+' src="'+imagePath+'" '+StyleString+' />'+C2;		
				}
			}
		}
		if(HTML_IMG){
			//FINControl.ScreenContentWithPath(HTML_IMG,'ImageLayer_'+lang);
			$('#ImageLayer_'+lang).html(HTML_IMG);
			HTML=MobileImageHandler(HTML);					
		}else{
			$('#ImageLayer_'+lang).html('');
		}
		//$('.ImageLayerStyle img').css('position','absolute');

		
		if(BrowserType=="Mobile" && IsContentsScreen==-1)
		{
			HTML = '<div id="TextLayerStyle" class="TextLayerStyle">' +HTML+HTML_IMG+'</div>';
			HTML_Custom = '<div>' +HTML_Custom+'</div>';
			HTML_IMG='';
			//HTML_IMG = '<div class="ImageLayerStyle"></div>';
			HTMLCombined = HTML_Custom  + HTML_IMG+ HTML;
		} else {
			HTML = '<div id="TextLayerStyle" class="TextLayerStyle">' +HTML+'</div>';
			///if(BrowserType=="Mobile"){HTML=HTML+'';}
			HTML_Custom = '<div>' +HTML_Custom+'</div>';
			HTML_IMG = '<div class="ImageLayerStyle">' +HTML_IMG+'</div>';
			HTMLCombined = HTML_Custom  + HTML_IMG+ HTML;		
		}

		return HTMLCombined;
		//// '<div id="clearDivs" style="clear:both"></div>';
    }



    function getImageURLWithSwitch(imageID){
	    //FINVars.ModemType = 'Novatel_MC545';
	    if(!Images[imageID]) return '';
	    if(Images[imageID].URL){
		    var result = imagesPath+Images[imageID].URL;
	    return result;
	    }
	    if(!Images[imageID].Default) return '';
	    //if(!Images[Images[imageID].Default]) return '';

	    //SwitchVariable
				    /*	Images.IMG14 = new Object();
				    Images.IMG14.Default = 'IMG10';
				    Images.IMG14.SwitchVariable = 'ModemType';
				    Images.IMG14.SwitchValues = new Array();
				    Images.IMG14.SwitchValues[0] = new Object();
				    Images.IMG14.SwitchValues[0].Value = 'Huawei_E367';
				    Images.IMG14.SwitchValues[0].ImageID = 'IMG2';
				    Images.IMG14.SwitchValues[1] = new Object();
				    Images.IMG14.SwitchValues[1].Value = 'Novatel_MC545';
				    Images.IMG14.SwitchValues[1].ImageID = 'IMG6';*/
    				
				    var newImageID = Images[imageID].Default;
				    if(Images[imageID].SwitchVariable){

					    var switchVar = Images[imageID].SwitchVariable;
					    if(FINVars[switchVar]){
					    var switchValuesArray = Images[imageID].SwitchValues;
						    if(switchValuesArray){
							    for(var i=0;i<switchValuesArray.length;i++){
								    if(FINVars[switchVar] == switchValuesArray[i].Value){
									    newImageID = switchValuesArray[i].ImageID;
								    }
							    }
						    }
    					
					    }
				    }
    	
	    return getImageURLWithSwitch(newImageID)
    }
	
	FINControl.NodeTab=function(){
		var NewTab =Nodes[FINVars.CurrentNode].TabID; 
		if(Tabs[NewTab]){
			var NewNode = Tabs[NewTab].FirstNode;
			FINControl.HandleNextNode(NewNode); 		
		} else {
			FINControl.ErrorReport('undefined tab, current node = '+FINVars.CurrentNode);
		}
	}
	

	FINControl.NodeStart=function()
	{	
		var NewNode =Nodes[FINVars.CurrentNode].Paths; 
		FINControl.HandleNextNode(NewNode); 
	}
	
	FINControl.NodeEnd=function(){
		var ThisTab = FINVars.CurrentTab;
		var AllTabs = new Array();
		for(x=0;x<FINState.TabHistory.length;x++){
			AllTabs[x] = FINState.TabHistory[x];
		}
		var PrevTab = AllTabs.pop();
		PrevTab = AllTabs.pop();
		var AllNodes = new Array();
		for(e=0;e<FINState.NodeHistory.length;e++){
			AllNodes[e] = FINState.NodeHistory[e];
		}
		var NodeLengths = AllNodes.length;
		
		for(i=0;i<=NodeLengths;i++){ 
			var Pop = AllNodes.pop(); 
			if(Nodes[Pop]==undefined){
				FINControl.ErrorReport('Current Node is undefined*');
				break;
			} else {
				
				if(Nodes[Pop].ParentTab){
					var ThisTab = Nodes[Pop].ParentTab; 
					if(ThisTab==PrevTab){ 
						var TheNextNode = Nodes[Pop].Paths;
						break;
					}
				} else {
					FINControl.ErrorReport('No parent tab set for: ' + Nodes[Pop]);
					
				}
			}
		}
		FINControl.UpdateTesting();
		if(TheNextNode){
			var x = FINState.TabHistory.pop();
			FINVars.CurrentTab = PrevTab;
			FINControl.HandleNextNode(TheNextNode);
		} else {
			FINControl.ErrorReport('Next node is undefined');
		}
	}


	FINControl.NodeSelection=function(){
		FINControl.NodeScreen();
		//document.getElementById("Next").style.display="none";
		//document.getElementById("NextDisabled").style.display="block";
		$('#Next').attr('disabled','true');
		
	}

	FINControl.NodeFunction = function() {
	    if (Nodes[FINVars.CurrentNode] && Nodes[FINVars.CurrentNode].Function == 'Counter') 
	    {

	        if (Nodes[FINVars.CurrentNode].AccessCount == undefined) {
	            Nodes[FINVars.CurrentNode].AccessCount = 1;
	        }
	        else {
	            Nodes[FINVars.CurrentNode].AccessCount++;
	        }

	        FINControl.FunctionPath(Nodes[FINVars.CurrentNode].AccessCount.toString());
	    }
	    else if (FINVars.SIK) {
	        FINControl.FunctionPath();
	    }
	    else {
	        FINControl.DisableButton('Back');
	        FINControl.DisableButton('Finish');
	        FINControl.DisableButton('Next');
	        FINControl.DisableButton('Exit'); 
	        FINControl.DisableButton('Retry');
	        var obj = Nodes[FINVars.CurrentNode].Paths; 
	        var FunctionName = Nodes[FINVars.CurrentNode].Function; 
	        var Variable = Nodes[FINVars.CurrentNode].Variable;
	        var str = '<BR><div class="decider functions">(function) <b>' + FunctionName + '</b> : Click one of the following:<br><br><select  onchange="FINControl.FunctionPath();" name=SelectOptions id="SelectOptions"><option></option>';
	        Object.keys(obj).forEach(function(key) {
	            str = str + "<option value=\"" + key + "\">" + key + "</option>";
	        });
	        str = str + "</select></div>";
	        FINControl.ScreenContent(str);
	    }
	}
	
	FINControl.FunctionReturn=function(ReturnValue)
	{
	    if (Nodes[FINVars.CurrentNode] == undefined) {
			FINControl.ErrorReport('Current Node is undefined ');
		} else {
			if(Nodes[FINVars.CurrentNode].Paths){
				var NextNodes =Nodes[FINVars.CurrentNode].Paths;
				
				var NewNode = NextNodes[ReturnValue]; 
				FINControl.HandleNextNode(NewNode);
			} else {
				FINControl.ErrorReport('No NextNode set for :' + FINVars.CurrentNode);
				
			}
		}	
	}

	FINControl.FunctionPath = function(thePath) {
	    var ReturnValue;
	    var FunctionName = Nodes[FINVars.CurrentNode].Function;
	    var FunctionParam = Nodes[FINVars.CurrentNode].FunctionParam;

	    if (thePath) {
	        FINControl.FunctionReturn(thePath);
	    }
	    else if (FINVars.SIK) {

	    if (FunctionName == "FINExit") {
	        FINFunctions.ExitFIN();
	        }
	        else
	            FINFunctions[FunctionName](FunctionParam);
	    }
	    else {
	        ReturnValue = $("#SelectOptions").val();
	        if (ReturnValue != "undefined") {
	            FINControl.FunctionReturn(ReturnValue);
	        }

	    }
	}

	FINControl.NodeDecision=function()
	{
	    if (FINVars.SIK)
		{
			FINControl.DecisionPath();
		}
		else
		{	
			FINControl.DisableButton('Finish');
			FINControl.DisableButton('Back');
			FINControl.DisableButton('Next');
			FINControl.DisableButton('Exit'); 
			FINControl.DisableButton('Retry'); 
			var obj = Nodes[FINVars.CurrentNode].Paths; 
			var Variable = Nodes[FINVars.CurrentNode].Variable;
			var str = '<BR><div class="decider">DECISION: <b>Click one of the following:</b><br><br><select  onchange="FINControl.DecisionPath();" name=SelectOptions id="SelectOptions"><option></option>';
			Object.keys(obj).forEach(function(key) {
					str=str+"<option value=\""+key+"\">"+key+"</option>";
			});		
			str = str + "</select></div>";		
			FINControl.ScreenContent(str);

		}
	}
	
	FINControl.DecisionPath=function()
	{	
		var selected;
		var Variable = Nodes[FINVars.CurrentNode].Variable;
		
		if (FINVars.SIK)
		{
			selected = FINVars[Variable];
		}
		else
			selected = $("#SelectOptions").val();
		
		var Paths = Nodes[FINVars.CurrentNode].Paths; 
		var ThePath = Paths[selected]; 
		
		if(ThePath == undefined)
			ThePath = Paths['ELSE']; 
		
		FINControl.HandleNextNode(ThePath); 		
		
	}

	FINControl.ChangeLanguage = function(NewLanguage) {

	    if (NewLanguage == FINVars.CurrentLanguage) {
	        return;
	    }
	    else {
	        FINVars.CurrentLanguage = NewLanguage;

	        FINControl.NodeScreen();

	        translateUpdateItem(NewLanguage, "Next", "Help.Next");
	        document.getElementById("Next").style.width = "122px";
	        
	        translateUpdateItem(NewLanguage, "Finish", "Help.Finish");
	        document.getElementById("Finish").style.width = "122px";

	        translateUpdateItem(NewLanguage, "Retry", "Help.Retry");
	        document.getElementById("Retry").style.width = "122px";

	        translateUpdateItem(NewLanguage, "Back", "Help.Back");
	        document.getElementById("Back").style.width = "122px";

	        translateUpdateItem(NewLanguage, "MoreInfo", "Help.MoreInfo");
	        document.getElementById("MoreInfo").style.width = "122px";

	        translateUpdateItem(NewLanguage, "Exit", "Help.Exit");
	        document.getElementById("Exit").style.width = "122px";
	        
	        if (document.forms.selection) {
	            $('#Next').attr('disabled', 'true');
	        }
	    }
	}

