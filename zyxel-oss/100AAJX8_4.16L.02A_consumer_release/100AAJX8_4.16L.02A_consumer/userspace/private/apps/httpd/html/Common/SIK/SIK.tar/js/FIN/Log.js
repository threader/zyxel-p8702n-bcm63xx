var FINLog=new Object();

FINLog.GetDateTime = function()
{
	var out = "";
	
	var currentTime = new Date();
	var month = currentTime.getMonth() + 1;
	var day = currentTime.getDate();
	var year = currentTime.getFullYear();
	var hours = currentTime.getHours();
	var minutes = currentTime.getMinutes();
	var seconds = currentTime.getSeconds();
	if (minutes < 10)
		minutes = "0" + minutes;
	if (seconds < 10)
		seconds = "0" + seconds;
		
	out = year + "/" + month + "/" + day + " " + hours + ":" + minutes + ":" + seconds;
	
	return out;
}

FINLog.RecordSession=function()
{
	if(FINLog.currentLog != undefined)
	{
		var currentEpoch = (new Date()).getTime() / 1000;
		
		FINLog.currentLog.finished = FINLog.GetDateTime();
		FINLog.currentLog.finishedEpoch = currentEpoch;
		FINLog.currentLog.result = "Cancelled";
		FINLog.currentLog.supportType = "";
		FINLog.currentLog.duration = FINLog.currentLog.finishedEpoch - FINLog.currentLog.startedEpoch;
		
		FINLog.session.problems.push(FINLog.currentLog);
		FINLog.currentLog = undefined;
		
		FINLog.session.finished = FINLog.GetDateTime();
		FINLog.session.finishedEpoch = currentEpoch;
		FINLog.session.result = "Cancelled";	
	}

	if(CefRunning() && FINLog.session)
	{
		cef.FixItNow.RecordSession(FINLog.session);
	}
	
	FINLog.session = undefined;
}

FINLog.HandleNode=function(node)
{
	if(!node.Log) 
		return;
	
	if(node.Log.Function == "StartSession")
	{
		
		FINLog.session = new Object();
		FINLog.session.problems = new Array();	
		
		FINLog.session.started = FINLog.GetDateTime();
		FINLog.session.startedEpoch = (new Date()).getTime() / 1000;
		FINLog.session.type = node.Log.Code;
	}
	else if(node.Log.Function == "FinishSession")
	{
		
		FINLog.session.finished = FINLog.GetDateTime();
		FINLog.session.finishedEpoch = (new Date()).getTime() / 1000;
		FINLog.session.result = node.Log.Code;	
	}
	else if(node.Log.Function == "StartProblem")
	{
		if(FINLog.currentLog)
		{
			var a = 0;
			return;
		}
	
		FINLog.currentLog = new Object();
		FINLog.currentLog.started = FINLog.GetDateTime();
		FINLog.currentLog.startedEpoch = (new Date()).getTime() / 1000;
		FINLog.currentLog.problem = node.Log.Code;
		FINLog.currentLog.type = FINLog.session.type;
		FINLog.currentLog.resolutions = new Array();
	}	
	else if(node.Log.Function == "FinishProblem")
	{
		if(FINLog.currentLog == undefined)
		{
			var a = 0;
			return;
		}
		
		var currentEpoch = (new Date()).getTime() / 1000;
	
		FINLog.currentLog.finished = FINLog.GetDateTime();
		FINLog.currentLog.finishedEpoch = currentEpoch;
		FINLog.currentLog.result = node.Log.Code;
		FINLog.currentLog.supportType = node.Log.SupportType;
		FINLog.currentLog.duration = FINLog.currentLog.finishedEpoch - FINLog.currentLog.startedEpoch;

		FINLog.session.problems.push(FINLog.currentLog);
		FINLog.currentLog = undefined;
		
		if(node.Log.Code == "CompletedFailed") 
		{
			FINLog.session.finished = FINLog.GetDateTime();
			FINLog.session.finishedEpoch = currentEpoch;
			FINLog.session.result = "Fail";	
		}
	}
	else if(node.Log.Function == "SetResolution")
	{
		if(!FINLog.currentLog)
		{
			return;
		}
			
		FINLog.currentLog.resolutions.push(node.Log.Code);
	}	
	else if(node.Log.Function == "StartSessionAndProblem")
	{
		
		if(FINLog.currentLog)
		{
			var a = 0;
			return;
		}		
		
		FINLog.session = new Object();
		FINLog.session.problems = new Array();	
		
		FINLog.session.started = FINLog.GetDateTime();
		FINLog.session.startedEpoch = (new Date()).getTime() / 1000;
		FINLog.session.type = node.Log.Code;
	
		FINLog.currentLog = new Object();
		FINLog.currentLog.started = FINLog.GetDateTime();
		FINLog.currentLog.startedEpoch = (new Date()).getTime() / 1000;
		FINLog.currentLog.problem = node.Log.Code;
		FINLog.currentLog.type = FINLog.session.type;
		FINLog.currentLog.resolutions = new Array();	
	}
	else if(node.Log.Function == "FinishProblemAndSession")
	{		
		var currentEpoch = (new Date()).getTime() / 1000;
	
		if(FINLog.currentLog)
		{
			FINLog.currentLog.finished = FINLog.GetDateTime();
			FINLog.currentLog.finishedEpoch = currentEpoch;
			FINLog.currentLog.result = node.Log.Code;
			FINLog.currentLog.supportType = node.Log.SupportType;
			FINLog.currentLog.duration = FINLog.currentLog.finishedEpoch - FINLog.currentLog.startedEpoch;

			FINLog.session.problems.push(FINLog.currentLog);
			FINLog.currentLog = undefined;
		}
		
		FINLog.session.finished = FINLog.GetDateTime();
		FINLog.session.finishedEpoch = currentEpoch;
		FINLog.session.result = node.Log.Code;		
	}


	
	// node.LogFunction
	// node.LogResult
	// node.LogType
	// node.LogProblem
}