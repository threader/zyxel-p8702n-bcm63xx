﻿var langFile='Japan';

/* for all buttons */
var _button=[{
		'_OK':'  OK  ',
		'_Cancel':'キャンセル',
		'_Apply':'適用',
		'_Reset':'リセット',
		'_Synchronize_Now':'同期する',
		'_Import':'インポート',
		'_Refresh':'最新の情報に更新',
		'_Export':'エクスポート',
		'_Export_Certificate':'証明エクスポート',
		'_Export_Certificate_Only':'証明のみエクスポート',
		'_Export_Certificate_with_Private_Key':'秘密鍵付きで証明をエクスポート',
		'_Show_Filter':'フィルター表示',
		'_Hide_Filter':'フィルター非表示',
		'_Search':'検索',
		'_Email_Log_Now':'ログメール',
		'_Clear_Log':'ログ消去',
		'_Active_Log_Summary':'アクティブログのサマリー',
		'_Flush_Data':'データ消去',
		'_Start_Collection':'収集開始',
		'_Stop_Collection':'収集停止',
		'_Collect_Now':'収集',
		'_Close':'閉じる',
		'_Download':'ダウンロード',
		'_Reboot':'再起動',
		'_Please_wait_collecting':'収集していますしばらくお待ちください...',
		'_Done_the_collection':'収集完了',
		'_Update':'更新',
		'_Service_License_Refresh':'サービスライセンスの更新',
		'_Copy':'コピー',
		'_Rename':'名前変更',
		'_Delete':'削除',
		'_Upload':'アップロード',
		'_Run':'実行',
		'_Edit_static_DHCP_table':'静的 DHCP テーブル編集',
		'_Add_New_VPN_Gateway':'新規 VPN ゲートウェイ追加',
		'_Advanced':'詳細...',
		'_Sync_Now':'同期する',
		'_Change':'変更... ',
		'_New':'新規...',
		'_Switch_to_query_view':'クエリビューに切替',
		'_Switch_to_group_view':'グループビューに切替',
		'_Save':'  保存  ',
		'_Delete':'削除',
		'_Export':'エクスポート',
		'_Update_Now':'更新',
		'_Flush':'消去',
		'_Add':'追加',
		'_Basic_cfilter':'基本',
		'_Advanced_cfilter':'詳細',
		'_Test_Against_Local_Cache':'ローカルキャッシュテスト',
		'_Test_Against_Web_Filter_Server':'ウェブフィルターサーバーテスト',
		'_Login':'ログイン',
		'_Refresh_Now':'更新',
		'_Clear_Warning_Message':'警告メッセージ消去',
		'_Back':'<戻る',
		'_Next':'次へ>',
		'_Check':'チェック',
		'_Set_Interval':'間隔設定',
		'_Stop':'停止',
		'_Clear_RX_Message':'受信メッセージ消去',
		'_Change_Display_Style':'表示形式変更',
		'_Advanced_':'詳細>>',
		'_Basic_':'基本<<',
		'_Expand':'展開',
		'_Collapse':'閉じる',
		'_Reset_Default':'ロゴをデフォルトにリセット',
		'_Preview':'プレビュー',
		'_Logout':'Logout',
		'_Renew':'更新'
		}];
		
/* Global Title Tag */
var _globalTag=[{
		/* Spare bar*/
		'_General_Setup':'一般設定',
		'_Policies':'ポリシー',
		'_Configuration':'設定',
		/* Registration */
		'_Registration':'登録',
		'_Service':'サービス',
		/* Update */
		'_IDP_App_Patrol':'IDP/アプリケーションパトロール',
		'_System_Protect':'システム保護',
		'_Anti_Virus':'アンチウィルス',
		/* Network */
		'_Interface_Summary':'インターフェースサマリー',
		'_Ethernet':'イーサネット',
		'_Port_Grouping':'ポートグループ化',
		'_VLAN':'VLAN',
		'_Bridge':'ブリッジ',
		'_PPPoE_PPTP':'PPPoE/PPTP',
		'_Auxiliary':'予備',
		'_Trunk':'トランク',
		'_Policy_Route':'ポリシールート',
		'_Static_Route':'静的ルート',
		'_RIP':'RIP',
		'_OSPF':'OSPF',
		/* IPSec VPN */
		'_VPN_Connection':'VPN 接続',
		'_VPN_Gateway':'VPN ゲートウェイ',
		'_Concentrator':'コンセントレーター',
		'_SA_Monitor':'SA モニター',
		/* SSL VPN */
		'_Access_Privilege':'アクセス権限',
		'_Connection_Monitor':'接続モニター',
		'_Global_Setting':'グローバル設定',
		/* L2TP VPN */
		'_L2TP_VPN':'L2TP VPN',
		'_Session_Monitor':'セッションモニター',
		/* AppPatrol */
		'_General':'一般',
		'_Common':'共通',
		'_Instant_Messenger':'インスタントメッセンジャー',
		'_Peer_to_Peer':'ピア・ツー・ピア',
		'_VoIP':'VoIP',
		'_Streaming':'ストリーミング',
		'_Other':'その他',
		'_Statistics':'統計',
		/* Anti-X > Anti-Virus */
		'_Summary':'サマリー',
		'_Setting':'設定',
		'_Signature':'シグネチャ',
		/* Anti-X > IDP */
		'_General':'一般',
		'_Profile':'プロファイル',
		'_Custom_Signatures':'カスタムシグネチャ',
		'_Protocol_Anomaly':'プロトコル異常',
		'_Traffic_Anomaly':'トラフィック異常',
		/* Anti-X > Content Filter */
		'_General_CF':'一般',
		'_Filter_Profile':'フィルタープロファイル ',
		'_Cache':'キャッシュ',
		/* Device HA */
		'_VRRP_Group':'VRRP グループ',
		'_Synchronize':'同期',
		/* Object */
		'_User':'ユーザー',
		'_Group':'グループ',
		'_Setting':'設定',
		'_Address':'アドレス',
		'_Address_Group':'アドレスグループ',
		'_Service':'サービス',
		'_Service_Group':'サービスグループ',
		'_Active_Directory':'アクティブディレクトリ',
		'_LDAP':'LDAP',
		'_RADIUS':'RADIUS',
		'_My_Certificates':'自己証明',
		'_Trusted_Certificates':'信頼された証明',
		/* File Manager */
		'_Configuration_File':'設定ファイル',
		'_Firmware_Package':'ファームウェアパッケージ',
		'_Shell_Script':'シェルスクリプト',
		/* Log */
		'_View_Log':'ログ表示',
		'_Log_Setting':'ログ設定',
		/* Traffic */
		'_Traffic':'トラフィック',
		'_Session':'セッション',
		'_IDP':'IDP',
		'_Anti_Virus':'アンチウィルス',
		/* Member List popup*/
		'_Member_List':'メンバーリスト',
		'_Available':'利用可能',
		'_Member':'メンバー',
		'_Please_Select':'メンバーを選択してください'
		}];

/* about.html */
var _about=[{
		'_ZyWALL_1050':'ZyWALL 1050',
		'_USG_300':'ZyWALL USG 300',
		'_Copyright':'(C) Copyright 2007 by ZyXEL Communications Corp.',
		'_Did_you_check':'Did you check ',
		'_www_zyxel_com':'www.zyxel.com',
		'_today':' today?'
		}];

/* tx.html */
var _tx=[{
		'_CLI_Message':'CLI メッセージ',
		'_Start_CLI_command':'CLI コマンド開始',
		'_End_CLI_command':'CLI コマンド終了'
		}];

/* rx.html */
var _rx=[{'_RX_Message':'受信メッセージ'}];

/* status.html */
var _status=[{
		'_Message':'メッセージ',
		'_Ready':'準備完了'
		}];

/* grant_access.html */
var _grant_access=[{'_ZyWALL_has_granted_your_access':'ZyWALL はアクセスを許可しました'}];

/* fwDone.html */
var _fwDone=[{'_Please_Wait':'お待ちください...'}];

/* fwDone.html */
var _fwupdone=[{'_Please_Wait':'お待ちください...',
			'_warning_message1':'Firmware upload is in progress -- Do not turn off the power or reset the ZyWALL.',
			'_warning_message2':'The complete firmware update may take up to 5 minutes.'
			}];

/* vpndial.html */		
var _vpndial=[{'_Please_Wait':'お待ちください...'}];

/* apacheDone.html */
var _apacheDone=[{'_Please_Wait':'お待ちください...'}];

/* rebootDone.html */
var _rebootDone=[{'_Please_Wait':'お待ちください...'}];

/* homedial.html */
var _homedial=[{'_Please_Wait':'お待ちください...'}];

/* waitdial.html */
var _waitdial=[{'_Please_Wait':'お待ちください...'}];

//warning.html file
var _warning=[{'_Warning_Message':'警告メッセージ'}];

//waitdata.html file
var _waitdata=[{'_Please_Wait':'お待ちください...'}];

/*----- Status -----*/

/* home.html */
var _home=[{			
		/* Device Information */
		'_Device_Information':'デバイス情報',
		'_System_Name':'システム名',
		'_Model_Name':'モデル名',
		'_Serial_Number':'シリアルナンバー',
		'_MAC_Address_Range':'MAC アドレス範囲',
		'_Firmware_Version':'ファームウェアバージョン',			
		/* System Resource */
		'_System_Resources':'システムリソース',
		'_CPU_Usage':'CPU 使用状況',
		'_Memory_Usage':'メモリ使用状況',
		'_Flash_Usage':'フラッシュ使用状況',
		'_Active_Sessions':'アクティブセッション',			
		/* Interface Status Summary */
		'_Interface_Status_Summary':'インターフェースステータスサマリー',
		'_Name':'名前',
		'_Status':'ステータス',
		'_HA_Status':'HA ステータス',
		'_Zone':'ゾーン',
		'_IP_Address':'IP アドレス',
		'_Renew_Dial':'更新/ダイヤル',			
		/* System Status */
		'_System_Status':'システムステータス',
		'_System_Uptime':'システム稼働時間',
		'_Current_Date_Time':'日付/時刻',
		'_VPN_Status':'VPN ステータス',
		'_DHCP_Table':'DHCP テーブル',
		'_Statistics':'ポート統計',
		'_Current_User_List':'ログインユーザー',
		'_Current_Login_User':'ログインユーザー',
		'_Number_of_Login_Users':'ログインユーザー数',			
		/* Licensed Service Status */
		'_Licensed_Service_Status':'ライセンスサービスステータス',
		'_IDP':'IDP',
		'_License_Status_Remaining_days':'ライセンスステータス:残りの日数',
		'_Signature_Version':'シグネチャバージョン',
		'_Last_Update_Time':'前回更新時刻',
		'_Total_Signature_Number':'全シグネチャ数',
		'_Anti_Virus':'アンチウィルス',
		'_Content_Filter':' コンテンツフィルター',
		/* Top 5 Intrusion & Virus Detection*/
		'_Top5':'侵入及びウィルス検出のトップ5',
		'_Rank':'ランク',
		'_Intrusion_Detected':'侵入検出',
		'_Virus_Detected':'ウィルス検出',
		/* Refresh */
		'_Refresh_Interval':'更新の間隔',
		'_Refresh_Now':'更新',
		/* force logout */		
		'_User_ID':'ユーザー ID',
		'_Reauth_Lease_T_':'リースタイムの再許可',
		'_Type':'タイプ',
		'_IP_address':'IP アドレス',
		'_Force_Logout':'強制ログアウト'
		}];

/*----- Licensing > Registration -----*/ 
/* vpnitval.html */
var _vpnitval=[{'_Poll_Interval':'調査間隔(1～60秒):'}];

/* vpnstatus.html */
var _vpnstatus=[{
		'_VPN_Table':'VPN テーブル',
		'_Name':'名前',
		'_Encapsulation':'カプセル化',
		'_IPSec_Algorithm':'IPSec アルゴリズム'
		}];

/* dhcpstatus.html */
var _dhcpstatus=[{
		'_DHCP_Table':'DHCP テーブル',
		'_Interface':'インターフェース',
		'_IP_Address':'IP アドレス',
		'_Host_Name':'ホスト名',
		'_MAC_Address':'MAC アドレス',
		'_Reserve':'リザーブ'
		}];

/* ifacestatus.html */
var _ifacestatus=[{
		'_Statistics_Table':'統計テーブル',
		'_Port':'ポート',
		'_status':'ステータス',
		'_TxPkts':'送信パケット',
		'_RxPkts':'受信パケット',
		'_Collisions':'衝突',
		'_Tx':'1秒あたりの送信ビット',
		'_Rx':'1秒あたりの受信ビット',
		'_Up_Time':'稼働時間',
		'_System_Up_Time':'システム稼働時間'
		}];
		
/* ifaceitval.html */
var _ifaceitval=[{'_Poll_Interval':'調査間隔(1～60秒):'}];		

/*----- Licensing > Registration -----*/

/* regist.html */
var _regist=[{
		'_Device_Registration':'デバイス登録',
		'_Trial_Service_Activation':'トライアルサービスを有効にする',
		'_regtext1':'このデバイスは myZyXEL.com で登録されていません次の情報を入力し、デバイスを<b>登録</b>してください',
		'_regtext2':'すでに myZyXEL.com アカウントをお持ちで、ユーザー名またはパスワードをお忘れの場合は¯、 ',
		'_regtext3':'',
		'_regtext4':'<a href="http://www.myZyXEL.com"><font color="#FF0000"><i><u>www.myZyXEL.com</u></i></font></a>へアクセスしてください',
		'_regtext5':'',
		'_new_myZyXEL_com_account':'新規 myZyXEL.com アカウント',
		'_existing_myZyXEL_com_account':'既存の myZyXEL.com アカウント',
		'_User_Name':'ユーザー名',
		'_you_can_click':'クリックをしてユーザー名がすでに使用されているかをチェックすることができます',
		'_Password':'パスワード',
		'_Confirm_Password':'パスワードの確認',
		'_E_Mail_Address':'メールアドレス',
		'_Country_Code':'国コード',
		'_Trial_Service_Activation':'トライアルサービスを有効にする',
		'_IDP':'IDP/アプリケーションパトロール',
		'_Anti_Virus':'アンチウィルス',
		'_Content_Filter':'コンテンツフィルター'
		}];

/* registmgn.html */
var _registmgn=[{
		'_Service_Management':'サービス管理',
		'_Service':'サービス',
		'_Status':'ステータス',
		'_Registration_Type':'登録タイプ',
		'_Expiration_day':'有効期限',
		'_Count':'有効',
		'_License_Upgrade':'ライセンスアップグレード',
		'_License_Key':'ライセンスキー',
		'_Note':'注意: myZyXEL.com と同期し、ライセンス情報をダウンロードしてください'													
		}];

/*----- Licensing > Update -----*/

/* idpfile.html */
var _idpfile=[{
		'_Signature_Information':'シグネチャ情報',
		'_Current_Version':'バージョン',
		'_Signature_Number':'シグネチャ数',
		'_Released_Date':'発行日',
		'_Remote_Update':'リモート更新',				
		'_Synchronize_the_IDP':'オンラインサーバーで IDP シグネチャパッケージを最新のバージョンに同期してください(myZyXEL.com の登録が必要です)',
		'_Auto_Update':'自動更新',
		'_Hourly':'毎時間',
		'_Daily':'毎日',
		'_Hour':'(時間)',
		'_Weekly':'毎週',
		'_Day':'(日)'
		}];

/* idpfile.html */
var _idpfile_1=[{
		'_Signature_Information':'シグネチャ情報',
		'_Current_Version':'バージョン',
		'_Signature_Number':'シグネチャ数',
		'_Released_Date':'発行日',
		'_Remote_Update':'リモート更新',				
		'_Synchronize':'オンライン更新サーバーでシステム保護シグネチャパッケージを最新バージョンに同期してください',
		'_Auto_Update':'自動更新',
		'_Hourly':'毎時間',
		'_Daily':'毎日',
		'_Hour':'(時間)',
		'_Weekly':'毎週',
		'_Day':'(日)'
		}];

/* antiupdate.html */
var _antiupdate=[{
		'_Signature_Information':'シグネチャ情報',
		'_Current_Version':'バージョン',
		'_Signature_Number':'シグネチャ数',
		'_Released_Date':'発行日',
		'_Remote_Update':'リモート更新',
		'_Synchronize':'オンラインサーバーで IDP シグネチャパッケージを最新のバージョンに同期してください(myZyXEL.com の登録が必要です)',
		'_Auto_Update':'自動更新',
		'_Hourly':'毎時間',
		'_Daily':'毎日',
		'_Hour':'(時間)',
		'_Weekly':'毎週',
		'_Day':'(日)'
		}];

/* upd.html */
var _upd=[{
		'_Rendering':'レンダリング...',
		'_ZyWALL':'ZyWALL オンライン更新サーバー'
		}];
		
/*----- Network > Interface -----*/

/* ifacesummary.html */
var _ifacesummary=[{
		'_Interface_Summary':'インターフェースサマリー',
		'_Name':'名前',
		'_Status':'ステータス',
		'_HA_Status':'HA ステータス',
		'_Zone':'ゾーン',
		'_IP_Netmask':'IP アドレス/ネットマスク',
		'_IP_Assignment':'IP 割当',
		'_Services':'サービス',
		'_Renew_Dial':'更新/ダイヤル',
		'_Statistics':'インターフェース統計',
		'_Tx_Pkts':'送信パケット',
		'_Rx_Pkts':'受信パケット',
		'_Collision':'衝突',
		'_Tx_Bs':'1秒あたりの送信ビット',
		'_Rx_Bs':'1秒あたりの受信ビット'
		}]

/* Interface.html */
var _Interface=[{
		'_Configuration':'設定',
		'_Name':'名前',
		'_IP_Address':'IP アドレス',
		'_Mask':'マスク',
		'_Modify':'変更'
		}];

/* ifEdit.html file */
var _ifEdit=[{
		'_Ethernet_Interface_Properties':'イーサネットインターフェースのプロパティ',
		'_Enable':'有効',
		'_Interface_Name':'インターフェース名',
		'_Description':'説明',
		'_Optional':'(オプション)',
		'_IP_Address_Assignment':'IP アドレスの割当',
		'_Get_Automatically':'自動取得',
		'_Use_Fixed_IP_Address':'ユーザー固定 IP アドレス',
		'_IP_Address':'IP アドレス',
		'_Subnet_Mask':'サブネットマスク',
		'_Gateway':'ゲートウェイ',
		'_Metric':'メトリック',
		'_Interface_Parameters':'インターフェースパラメーター',
		'_Upstream_Bandwidth':'アップストリーム帯域',
		'_Downstream_Bandwidth':'ダウンストリーム帯域',
		'_Kbps':'Kbps',
		'_MTU':'MTU',
		'_Bytes':'バイト',
		'_RIP_Setting':'RIP 設定',
		'_Enable_RIP':'RIP 有効',
		'_Direction':'方向',
		'_Send_Version':'送信バージョン',
		'_Receive_Version':'受信バージョン',
		'_V2_Broadcast':'V2 ブロードキャスト',
		'_OSPF_Setting':'OSPF 設定',
		'_Area':'エリア',
		'_Priority':'優先度',
		'_Link_Cost':'リンクコスト',
		'_Passive_Interface':'受動インターフェース',
		'_Authentication':'認証',
		'_Text_Authentication_Key':'テキスト認証キー',
		'_MD5_Authentication_ID':'MD5認証 ID',
		'_MD5_Authentication_Key':'MD5 認証キー',
		'_Type':'タイプ',
		'_Authentication':'認証',
		'_DHCP_Setting':'DHCP 設定',
		'_DHCP':'DHCP',
		'_Relay_Server_1':'リレーサーバー1',
		'_Relay_Server_2':'リレーサーバー2',
		'_IP_Address_1':'(IP アドレス)',
		'_IP_Pool_Start_Address_Optional':'IP プールアドレス (オプション)',
		'_Pool_Size':'プールサイズ',
		'_First_DNS_Server_Optional':'1st DNS サーバー(オプション)',
		'_Second_DNS_server_Optional':'2nd DNS サーバー(オプション)',
		'_Third_DNS_Server_Optional':'3rd DNS サーバー(オプション)',
		'_First_WINS':'1st WINS サーバー(オプション)',
		'_Second_WINS':'2nd WINS サーバー(オプション)',
		'_Lease_time':'リースタイム',
		'_infinite':'無制限',
		'_days':'日',
		'_hours_Optional':'時間(オプション)',
		'_minutes_Optional':'分(オプション)',
		'_Static_DHCP_Table':'静的 DHCP テーブル',
		'_Ping_Check':'Ping チェック',
		'_seconds':'秒',
		'_Domain_Name_or_IP_Address':'(ドメイン名または IP アドレス)',
		'_Check_Period':'チェック間隔',
		'_Check_Timeout':'タイムアウトのチェック',
		'_Check_Fail_Tolerance':'許容値のチェック',
		'_Ping_Default_Gateway':'デフォルトゲートウェイにPing',
		'_Ping_this_address':'このアドレスにPing'
		}];

/* viredit.html */
var _viredit=[{
		'_Virtual_Interface_Properties':'仮想インターフェースのプロパティ',
		'_Interface_Name':'インターフェース名',
		'_Description':'説明',
		'_Optional':'(オプション)',
		'_IP_Address_Assignment':'IP アドレスの割当',
		'_IP_Address':'IP アドレス',
		'_Subnet_Mask':'サブネットマスク',
		'_Gateway':'ゲートウェイ',
		'_Metric':'メトリック',
		'_Interface_Parameters':'インターフェースパラメーター',
		'_Upstream_Bandwidth':'アップストリーム帯域',
		'_Downstream_Bandwidth':'ダウンストリーム帯域',
		'_Kbps':'Kbps'
		}];
		
/* portgrouping.html */
var _portgrouping=[{
		'_Port_Grouping':'ポートグループ化',
		'_Representative_Interface':'基本インターフェース',
		'_Physical_Port':'物理ポート'
		}];

/* vlan.html */
var _vlan=[{
		'_Configuration':'設定',
		'_Name':'名前',
		'_Port_VID':'ポート/VID',
		'_IP_Address':'IP アドレス',
		'_Mask':'マスク'
		}];

/* vlanedit.html */
var _vlanedit=[{
		'_VLAN_Interface_Properties':'VLAN インターフェースのプロパティ',
		'_Enable':'有効',
		'_Interface_Name':'インターフェース名',
		'_Port':'ポート',
		'_Virtual_LAN_Tag':'仮想 LAN タグ',
		'_Description':'説明',
		'_Optional':'(オプション)',
		'_IP_Address_Assignment':'IP アドレスの割当',
		'_Get_Automatically':'自動取得',
		'_Use_Fixed_IP_Address':'ユーザー固定 IP アドレス',
		'_IP_Address':'IP アドレス',
		'_Subnet_Mask':'サブネットマスク',
		'_Gateway':'ゲートウェイ',
		'_Metric':'メトリック',
		'_Interface_Parameters':'インターフェースパラメーター',
		'_Upstream_Bandwidth':'アップストリーム帯域',
		'_Downstream_Bandwidth':'ダウンストリーム帯域',		
		'_Kbps':'Kbps',
		'_MTU':'MTU',
		'_Bytes':'バイト',	
		'_DHCP_Setting':'DHCP 設定',
		'_DHCP':'DHCP',
		'_Relay_Server_1':'リレーサーバー1',
		'_Relay_Server_2':'リレーサーバー2',		
		'_IP_Address_1':'(IP アドレス)',
		'_IP_Pool_Start_Address_Optional':'IP プールアドレス (オプション)',
		'_Pool_Size':'プールサイズ',
		'_First_DNS_Server_Optional':'1st DNS サーバー(オプション)',
		'_Second_DNS_server_Optional':'2nd DNS サーバー(オプション)',
		'_Third_DNS_Server_Optional':'3rd DNS サーバー(オプション)',
		'_First_WINS':'1st WINS サーバー(オプション)',
		'_Second_WINS':'2nd WINS サーバー(オプション)',
		'_Lease_time':'リースタイム',
		'_infinite':'無制限',
		'_days':'日',
		'_hours_Optional':'時間(オプション)',
		'_minutes_Optional':'分(オプション)',
		'_Static_DHCP_Table':'静的 DHCP テーブル',
		'_Ping_Check':'Ping チェック',
		'_seconds':'秒',
		'_Domain_Name_or_IP_Address':'(ドメイン名または IP アドレス)',
		'_Check_Period':'チェック間隔',
		'_Check_Timeout':'タイムアウトのチェック',
		'_Check_Fail_Tolerance':'許容値のチェック',
		'_Ping_Default_Gateway':'デフォルトゲートウェイにPing',
		'_Ping_this_address':'このアドレスにPing'
		}];

/* bridge.html */
var _bridge=[{
		'_Configuration':'設定',
		'_Name':'名前',
		'_IP_Address':'IP アドレス',
		'_Member':'メンバー'
		}];

/* bridgeedit.html */
var _bridgeedit=[{
		'_Bridge_Interface_Properties':'ブリッジインターフェースのプロパティ',
		'_Enable':'有効',
		'_Interface_Name':'インターフェース名',
		'_Description':'説明',
		'_Optional':'(オプション)',
		'_Member_Configuration':'メンバー設定',
		'_Available':'利用可能',
		'_Member':'メンバー',
		'_IP_Address_Assignment':'IP アドレスの割当',
		'_Get_Automatically':'自動取得',
		'_Use_Fixed_IP_Address':'ユーザー固定 IP アドレス',
		'_IP_Address':'IP アドレス',
		'_Subnet_Mask':'サブネットマスク',
		'_Gateway':'ゲートウェイ',
		'_Metric':'メトリック',
		'_Interface_Parameters':'インターフェースパラメーター',
		'_Upstream_Bandwidth':'アップストリーム帯域',
		'_Downstream_Bandwidth':'ダウンストリーム帯域',
		'_Kbps':'Kbps',
		'_MTU':'MTU',
		'_Bytes':'バイト',
		'_DHCP_Setting':'DHCP 設定',
		'_DHCP':'DHCP',
		'_Relay_Server_1':'リレーサーバー1',
		'_Relay_Server_2':'リレーサーバー2',		
		'_IP_Address_1':'(IP アドレス)',
		'_IP_Pool_Start_Address_Optional':'IP プールアドレス (オプション)',
		'_Pool_Size':'プールサイズ',
		'_First_DNS_Server_Optional':'1st DNS サーバー(オプション)',
		'_Second_DNS_server_Optional':'2nd DNS サーバー(オプション)',
		'_Third_DNS_Server_Optional':'3rd DNS サーバー(オプション)',
		'_First_WINS':'1st WINS サーバー(オプション)',
		'_Second_WINS':'2nd WINS サーバー(オプション)',
		'_Lease_time':'リースタイム',
		'_infinite':'無制限',
		'_days':'日',
		'_hours_Optional':'時間(オプション)',
		'_minutes_Optional':'分(オプション)',
		'_Static_DHCP_Table':'静的 DHCP テーブル',
		'_Ping_Check':'Ping チェック',
		'_seconds':'秒',
		'_Domain_Name_or_IP_Address':'(ドメイン名または IP アドレス)',
		'_Check_Period':'チェック間隔',
		'_Check_Timeout':'タイムアウトのチェック',
		'_Check_Fail_Tolerance':'許容値のチェック',
		'_Ping_Default_Gateway':'デフォトゲートウェイにPing',
		'_Ping_this_address':'このアドレスにPing'
		}];

/* dhcp.html */
var _dhcp=[{
		'_Static_DHCP':'静的 DHCP',
		'_IP_Address':'IP アドレス',
		'_MAC':'MAC'
		}];
			
/* pppoe.html */
var _pppoe=[{
		'_Name':'名前',
		'_Base_Interface':'基本インターフェース',		
		'_Account_Profile':'アカウントプロファイル'
		}];

/* pppedit.html */
var _pppedit=[{
		'_PPP_Interface_Properties':'PPP インターフェースのプロパティ',
		'_Enable':'有効',
		'_Interface_Name':'インターフェース名',
		'_Nailed_Up':'常時接続',
		'_Dial_on_Demand':'ダイヤル・オンデマンド',
		'_Description':'説明',
		'_Optional':'(オプション)',
		'_Base_Interface':'基本インターフェース',
		'_Account_Profile':'アカウントプロファイル',
		'_Protocol':'プロトコル',
		'_User_Name':'ユーザー名',
		'_Service_Name':'サービス名',
		'_IP_Address_Assignment':'IP アドレスの割当',
		'_Get_Automatically':'自動取得',
		'_Use_Fixed_IP_Address':'ユーザー固定 IP アドレス',
		'_IP_Address':'IP アドレス',
		'_Gateway':'ゲートウェイ',
		'_Metric':'メトリック',
		'_Interface_Parameters':'インターフェースパラメーター',
		'_Upstream_Bandwidth':'アップストリーム帯域',
		'_Downstream_Bandwidth':'ダウンストリーム帯域',
		'_Kbps':'Kbps',
		'_MTU':'MTU',
		'_Bytes':'バイト',
		'_Ping_Check':'Ping チェック',
		'_seconds':'秒',
		'_Domain_Name_or_IP_Address':'(ドメイン名または IP アドレス)',
		'_Check_Period':'チェック間隔',
		'_Check_Timeout':'タイムアウトのチェック',
		'_Check_Fail_Tolerance':'許容値のチェック',
		'_Ping_Default_Gateway':'デフォルトゲートウェイにPing',
		'_Ping_this_address':'このアドレスにPing'
		}];

/* auxiliary.html */
var _auxiliary=[{
		'_Auxiliary_Interface_Properties':'補助インターフェースのプロパティ',
		'_Enable':'有効',
		'_Description':'説明',
		'_Optional':'(オプション)',
		'_Port_Speed':'ポート速度',
		'_Dialing_Type':'ダイヤルタイプ',
		'_Tone':'トーン',
		'_Pulse':'パルス',
		'_Initial_String':'初期文字列',
		'_Auxiliary_Configuration':'補助設定',
		'_Phone_Number':'電話番号',
		'_User_Name':'ユーザー名',
		'_Password':'パスワード',
		'_Retype_to_confirm':'再入力して確認',
		'_Authentication_Type':'認証タイプ',
		'_Timeout':'タイムアウト',
		'_Seconds':'(秒)',
		'_Idle_timeout':'アイドルタイムアウト'
		}];

/* groups.html */
var _groups=[{
		'_Name':'名前',
		'_Algorithm':'アルゴリズム'
		}];

/* gpedit.html */
var _gpedit=[{
		'_Trunk_Members':'トランクメンバー',
		'_Name':'名前',
		'_Load_Balancing_Algorithm':'負荷分散アルゴリズム',
		'_Member':'メンバー',
		'_Mode':'モード',
		'_Weight':'重量',
		'_Downstream_Bandwidth':'ダウンストリーム帯域',
		'_Upstream_Bandwidth':'アップストリーム帯域',
		'_Spillover':'過剰'
		}];

/*----- Network > Routing -----*/

/* policyroute.html */
var _policyroute=[{
		'_User':'ユーザー',
		'_Schedule':'スケジュール',
		'_Incoming':'受信',
		'_Source':'送信元',
		'_Destination':'送信先',
		'_Service':'サービス',
		'_Next_Hop':'次のホップ',
		'_SNAT':'SNAT',
		'_BWM':'BWM'
		}];

/* proutedit.html */
var _proutedit=[{
		'_Configuration':'設定',
		'_Enable':'有効',
		'_Description':'説明',
		'_Optional':'(オプション)',
		'_Criteria':'基準',
		'_User':'ユーザー',
		'_Incoming':'受信',
		'_Source_Address':'送信元アドレス',
		'_Destination_Address':'送信先アドレス',
		'_Schedule':'スケジュール',
		'_Service':'サービス',
		'_Next_Hop':'次のホップ',
		'_Type':'タイプ',
		'_Gateway':'ゲートウェイ',
		'_Interface':'インターフェース',
		'_VPN_Tunnel':'VPN トンネル',
		'_Trunk':'トランク',
		'_Address_Translation':'アドレス変換',
		'_Source_Network_Address_Translation':'送信元ネットワークアドレス変換',
		'_Port_Triggering':'ポートトリガ',
		'_Incoming_Service':'受信サービス',
		'_Trigger_Service':'トリガサービス',
		'_Bandwidth_Shaping':'帯域形成',
		'_Maximum_Bandwidth':'最大帯域',
		'_Bandwidth_Priority':'帯域優先度',
		'_is_highest_priority':'が最優先',
		'_MBU':'帯域の最大値'
		}];
		
/* staticroute.html */
var _staticroute=[{
		'_Destination':'送信先',
		'_Subnet_Mask':'サブネットマスク',
		'_Next_Hop':'次のホップ',
		'_Metric':'メトリック'
		}];

/* stroutedit.html */
var _stroutedit=[{
		'_Static_Route_Setting':'静的ルート設定',
		'_Destination_IP':'送信先 IP',
		'_Subnet_Mask':'サブネットマスク',
		'_Gateway_IP':'ゲートウェイ IP',
		'_Interface':'インターフェース',
		'_Metric':'メトリック'
		}];
		
/* rip.html */
var _rip=[{
		'_Authentication':'認証',
		'_Text_Authentication_Key':'テキスト認証キー',
		'_MD5_Authentication_ID':'MD5認証 ID',
		'_MD5_Authentication_Key':'MD5 認証キー',
		'_Redistribute':'再分配',
		'_Active':'アクティブ',
		'_Name':'名前',
		'_Metric':'メトリック',
		'_OSPF':'OSPF',
		'_Static_Route':'静的ルート'
		}];

/* ospf.html */
var _ospf=[{
		'_OSPF_Router_ID_IP_Address':'OSPF ルーター ID (IP アドレス)',
		'_Default':'デフォルト',
		'_User_Defined':'ユーザー定義',
		'_Redistribute':'再分配',
		'_Active':'アクティブ',
		'_Route':'ルート',
		'_Type':'タイプ',
		'_Metric':'メトリック',
		'_RIP':'RIP',
		'_Static_Route':'静的ルート',
		'_Area':'エリア',
		'_Authentication':'認証'
		}];

/* ospfedit.html */
var _ospfedit=[{
		'_Area_Setting':'エリア設定',
		'_Area_ID':'エリア ID',
		'_Type':'タイプ',
		'_Authentication':'認証',
		'_Text_Authentication_Key':'テキスト認証キー',
		'_MD5_Authentication_ID':'MD5認証 ID',
		'_MD5_Authentication_Key':'MD5 認証キー',
		'_Virtual_Link':'仮想リンク',
		'_Peer_Router_ID':'ピアルーター ID'
		}];

/*----- Network > Zone -----*/

/* zone.html */
var _zone=[{
		'_Configuration':'設定',
		'_Name':'名前',
		'_Block_Intra_zone_Traffic':'内部ゾーントラフィックブロック',
		'_Member':'メンバー'
		}];

/* zoneedit.html */
var _zoneedit=[{
		'_Group_Members':'グループメンバー',
		'_Name':'名前',
		'_Block_Intra_zone_Traffic':'内部ゾーントラフィックブロック'
		}];

/*----- Network > DDNS -----*/

/* ddns.html */
var _ddns=[{
		'_My_Domain_Names':'マイドメイン名',
		'_Profile_Name':'プロファイル名',
		'_Domain_Name':'ドメイン名',
		'_DDNS_Type':'DDNS タイプ',
		'_Wildcard':'ワイルドカード',
		'_IP_Address_Update_Policy':'IP アドレス更新ポリシー',
		'_WAN_Interface':'WAN インターフェース',
		'_HA__Interface':'HA* インターフェース'
		}];

/* ddnsed.html */
var _ddnsed=[{
		'_DDNS_Profile':'DDNS プロファイル',
		'_Profile_Name':'プロファイル名',
		'_DDNS_Type':'DDNS タイプ',
		'_Username':'ユーザー名',
		'_Password':'パスワード',
		'_Domain_name':'ドメイン名',
		'_wildcard':' ワイルドカード',
		'_IP_Address_Update_Policy':'IP アドレス更新ポリシー',
		'_Custom_IP':'カスタム IP',
		'_WAN_Interface':'WAN インターフェース',
		'_HA_Interface':'HA インターフェース',
		'_Mail_Exchanger':'メール交換器',
		'_Optional':'(オプション)',
		'_Backup_mail_exchanger':' バックアップメールエクスチェンジャー'
		}];

/*----- Network > Virtual Server -----*/

/* virsvr.html */
var _virsvr=[{
		'_Virtual_Server':'仮想サーバー',
		'_Total_Virtual_Servers':'仮想サーバー数: ',
		'_entries_per_page':'1ページあたりの登録',
		'_Page':'ページ',
		'_Name':'名前',
		'_Interface':'インターフェース',
		'_Original_IP':'オリジナル IP',
		'_Mapped_IP':'マップ IP',
		'_Protocol':'プロトコル',
		'_Original_Port':'オリジナルポート',
		'_Mapped_Port':'マップポート'
		}];

/* virsvredit.html */
var _virsvredit=[{
		'_Enable':'有効',
		'_Name':'名前',
		'_Interface':'インターフェース',
		'_Original_IP':'オリジナル IP',
		'_User_Defined':'ユーザー定義',
		'_Mapped_IP':'マップ IP',
		'_IP_Address':'(IP アドレス)',
		'_Original_Port':'オリジナルポート',
		'_Mapped_Port':'マップポート',
		'_Mapping_Type':'マッピングタイプ',
		'_Protocol_Type':'プロトコルタイプ',		
		'_Original_Port':'オリジナルポート',
		'_Original_Start_Port':'オリジナル開始ポート',
		'_Original_End_Port':'オリジナル終了ポート',
		'_Mapped_Start_Port':'マップ開始ポート',
		'_Mapped_End_Port':'マップ終了ポート',
		'_Please1':'*ファイアウォールが仮想サーバートラフィックを許可するよう確認してください',
		'_Please2':'*仮想サーバーもクライアントへの接続を確立する場合、対応するポリシールート (NAT 1:1) を作成してください '
		}];

/*----- Network > HTTP Redirect -----*/

/* httpred.html */
var _httpred=[{
		'_Configuration':'設定',
		'_Name':'名前',
		'_Interface':'インターフェース',
		'_Proxy_Server':'プロキシサーバー',
		'_Port':'ポート'
		}];

/* httprededit.html */
var _httprededit=[{
		'_Enable':'有効',
		'_Name':'名前',
		'_Interface':'インターフェース',
		'_Proxy_server':'プロキシサーバー',
		'_Port':'ポート'
		}];

/*----- Network > ALG -----*/

/* VoipAlg.html */
var _VoipAlg=[{
		'_SIP_Setting':'SIP 設定',
		'_Enable_SIP_Transformations':'SIP変換 有効',
		'_SIP_Signaling_Port':'SIPシグナルポート',
		'_Additional_SIP_Signaling_Port':'変換用の追加 SIP シグナルポート (UDP):(オプション)',		
		'_SIP_Signaling_inactivity_time_out':'SIP シグナル静止タイムアウト',
		'_seconds':'(秒)',
		'_SIP_Media_inactivity_time_out' :'SIP Media 静止タイムアウト',		
		'_H_323_Setting':'H.323 設定',
		'_Enable_H_323_transformations':'H.323 変換 有効',
		'_H_323_Signaling_Port':'H.323 シグナルポート',
		'_Additional_H_323_Signaling_Port':'変換用の追加 H.323 シグナルポート:(オプション)',
		'_FTP_Setting':'SIP 設定',
		'_Enable_FTP_transformations':'FTP 変換 有効',
		'_FTP_Signaling_Port':'FTP シグナルポート',
		'_Additional_FTP_Signaling_Port':'変換用の追加 FTP シグナルポート:(オプション)'
		}];

/*----- Firewall -----*/

/* firewall.html */
var _firewall=[{
		'_Global_Setting':'グローバル設定',
		'_Enable_Firewall':'ファイアウォール 有効',
		'_Allow_Asymmetrical_Route':'非対称ルート許可',
		'_Maximum_session_per_Host':'1ホストで利用できるセッション',
		'_Firewall_rule':'ファイアウォールルール',
		'_Through_ZyWALL_rules':'ZyWALL ルール経由',
		'_Zone_Pairs':'ゾーンペア',
		'_All_rules':'すべてのルール',
		'_To_ZyWALL_rules':'ZyWALL ルールへ',
		'_From_Zone':'ゾーンから',
		'_To_Zone':'ゾーンへ',
		'_Priority':'優先度',
		'_Schedule':'スケジュール',
		'_User':'ユーザー',
		'_Source':'送信元',
		'_Destination':'送信先',
		'_Service':'サービス',
		'_Access':'アクセス',
		'_Log':'ログ',		
		'_From':'From',
		'_To':'To'
		}];

/* firewalledit.html */
var _firewalledit=[{
		'_Configuration':'設定',
		'_Enable':'有効',
		'_Description':'説明',
		'_Optional':'(オプション)',
		'_Schedule':'スケジュール',
		'_User':'ユーザー',
		'_Source':'送信元',
		'_Destination':'送信先',
		'_Service':'サービス',
		'_Access':'アクセス',
		'_Log':'ログ',				
		'_From':'From',
		'_To':'To'
		}];

/*----- VPN > IPSec VPN -----*/

/* vpnc.html */
var _vpnc=[{
		'_Configuration':'設定',
		'_Total_Connection':'接続数',
		'_connection_per_page':'1ページあたりの接続',
		'_Page':'ページ',
		'_Name':'名前',
		'_VPN_Gateway':'VPN ゲートウェイ',
		'_Encapsulation':'カプセル化',
		'_Algorithm':'アルゴリズム',
		'_Policy':'ポリシー'
		}];
	
/* vpncmkedit.html */
var _vpncmkedit=[{
		'_VPN_Connection':'VPN 接続',
		'_Connection_Name':'接続名',
		'_VPN_Gateway':'VPN ゲートウェイ',
		'_Name':'名前',
		'_Manual_Key':'マニュアルキー',
		'_SPI':'SPI',
		'_Encapsulation_Mode':'カプセル化モード',
		'_Active_Protocol':'アクティブプロトコル',
		'_Encryption_Algorithm':'暗号化アルゴリズム',
		'_Authentication_Algorithm':'認証アルゴリズム',
		'_Encryption_Key':'暗号化キー',
		'_Authentication_Key':'認証キー',
		'_Policy':'ポリシー',
		'_Local_Policy':'ローカルポリシー',
		'_Remote_Policy':'リモートポリシー',
		'_Property':'プロパティ',
		'_My_Address':'マイアドレス',
		'_Secure_Gateway_Address':'セキュリティゲートウェイアドレス',
		'_Enable_NetBIOS_broadcast_over_IPSec':'IPSec を経たNetBIOS ブロードキャスト 有効',
		'_Inbound_Outbound_Traffic_NAT':'受信/送信トラフィック NAT',
		'_Outbound_Traffic':'送信トラフィック',
		'_Source_NAT':'送信元 NAT',
		'_Source':'送信元',
		'_Destination':'送信先',
		'_SNAT':'SNAT',
		'_Inbound_Traffic':'受信トラフィック',
		'_Source_NAT':'送信元 NAT',
		'_Destination_NAT':'送信先 NAT',
		'_Original_IP':'オリジナル IP',
		'_Mapped_IP':'マップ IP',
		'_Protocol':'プロトコル',
		'_Original_Port':'オリジナルポート',
		'_Mapped_Port':'マップポート'
		}];

/* vpncikeedit.html */
var _vpncikeedit=[{
		'_VPN_Connection':'VPN 接続',
		'_Connection_Name':'接続名',
		'_VPN_Gateway':'VPN ゲートウェイ',
		'_Name':'名前',
		'_Phase_2':'フェーズ2',
		'_Active_Protocol':'アクティブプロトコル',
		'_Encapsulation':'カプセル化',
		'_Proposal':'提案',
		'_SA_Life_Time':'SA ライフタイム(秒)',
		'_Perfect_Forward_Secrecy':'PFS (Perfect Forward Secrecy)',
		'_Policy':'ポリシー',
		'_Policy_Enforcement':'ポリシー実行',
		'_Local_policy':'ローカルポリシー',
		'_Remote_policy':'リモートポリシー',
		'_Property':'プロパティ',
		'_Nailed_Up':'常時接続',
		'_Enable_Replay_Detection':'リプレイ検出 有効',
		'_Enable_NetBIOS_broadcast_over_IPSec':'IPSec を経たNetBIOS ブロードキャスト 有効',
		'_Inbound_Outbound_traffic_NAT':'受信/送信トラフィック NAT',
		'_Outbound_Traffic':'送信トラフィック',
		'_Source_NAT':'送信元 NAT',
		'_Source':'送信元',
		'_Destination':'送信先',
		'_SNAT':'SNAT',
		'_Inbound_Traffic':'受信トラフィック',
		'_Destination_NAT':'送信先 NAT',
		'_Original_IP':'オリジナル IP',
		'_Mapped_IP':'マップ IP',
		'_Protocol':'プロトコル',
		'_Original_Port':'オリジナルポート',
		'_Mapped_Port':'マップポート',
		'_Encryption':'暗号化',
		'_Authentication':'認証'
		}];

/* vpng.html */
var _vpng=[{
		'_Configuration':'設定',
		'_Name':'名前',
		'_My_address':'マイアドレス',
		'_Secure_Gateway':'セキュリティゲートウェイ',
		'_VPN_Connection':'VPN 接続'
		}];

/* vpngedit.html */
var _vpngedit=[{
		'_VPN_Gateway':'VPN ゲートウェイ',
		'_VPN_Gateway_Name':'VPN ゲートウェイ名',
		'_IKE_Phase_1':'IKE フェーズ1',
		'_Negotiation_Mode':'ネゴシエーションモード',
		'_Proposal':'提案',
		'_Encryption':'暗号化',
		'_Authentication':'認証',
		'_Key_Group':'キーグループ',
		'_SA_Life_Time_Seconds':'SA ライフタイム(秒)',
		'_NAT_Traversal':'NAT トラバーサル',
		'_Dead_Peer_Detection_DPD':'(DPD) Dead Peer Detection',
		'_Property':'プロパティ',
		'_My_Address':'マイアドレス',
		'_Interface':'インターフェース',
		'_Domain_Name':'ドメイン名',
		'_Secure_Gateway_Address':'セキュリティゲートウェイアドレス',
		'_Authentication_Method':'認証方法',
		'_Pre_Shared_Key':'プリシェアードキー',
		'_Certificate':'証明',
		'_See':'表示',
		'_My_Certificates':'自己証明',
		'_Local_ID_Type':'ローカル ID タイプ',
		'_Content':'コンテンツ',
		'_Peer_ID_Type':'ピア ID タイプ',
		'_Extended_Authentication':'拡張認証',
		'_Enable_Extended_Authentication':'拡張認証 有効',
		'_Server_Mode':'サーバーモード',
		'_Client_Mode':'クライアントモード',
		'_User_Name':'ユーザー名',
		'_Password':'パスワード'
		}];

/* contra.html */
var _contra=[{
		'_Configuration':'設定',
		'_Name':'名前'
		}];

/* contraedit.html */
var _contraedit=[{
		'_Group_Members':'グループメンバー',
		'_Name':'名前',
		'_Member':'メンバー'
		}];
		
/* vpnsa.html */
var _vpnsa=[{
		'_Current_IPSec_Security_Associations':'IPSec セキュリティ関連',
		'_Name':'名前',
		'_Encapsulation':'カプセル化',
		'_Policy':'ポリシー',
		'_Algorithm':'アルゴリズム',
		'_Up_Time':'稼働時間',
		'_Timeout':'タイムアウト',
		'_Inbound':'受信(バイト)',
		'_Outbound':'送信(バイト)'
		}];

/*----- VPN > SSL VPN -----*/

/* sslvpnac.html */
var _sslvpnac=[{
		'_Configuration':'設定',		
		'_Name':'名前',
		'_User_Group':'ユーザー/グループ',
		'_Application':'アプリケーション'
		}];
/* sslvpnacedit.html */
var _sslvpnacedit=[{
		'_Configuration':'設定',
		'_Enable':'有効',
		'_Name':'名前',
		'_Description':'説明',
		'_Optional':'(オプション)',		
		'_User_Group_Optional':'ユーザー/グループ (オプション)',		
		'_Available':'利用可能',
		'_Member':'メンバー',
		'_SSL_Application_List_Optional':'SSL アプリケーションリスト (オプション)',
		'_Network_Extension_Optional':'ネットワーク拡張 (オプション)',
		'_Enable_Network_Extension':'ネットワーク拡張 有効',
		'_Assign_IP_Pool':'IP プールの割当',
		'_DNS_Server_1':'DNS サーバー1',
		'_DNS_Server_2':'DNS サーバー2',
		'_Wins_Server_1':'WINS サーバー1',
		'_Wins_Server_2':'WINS サーバー2',
		'_Network_List':'ネットワークリスト'
		}];
				
/* sslvpnmonitor.html */
var _sslvpnmonitor=[{
		'_Current_SSL_VPN_Connection':'SSL VPN 接続',		
		'_User':'ユーザー',
		'_Access':'アクセス',
		'_Login_Addr':'ログインアドレス',
		'_Connected_Time':'接続時間',
		'_In_Bytes':'受信(バイト)',
		'_Out_Bytes':'送信(バイト)'
		}];	
			
/* sslvpnglobal.html */
var _sslvpnglobal=[{
		'_Global_Setting':'グローバル設定',
		'_Network_Extension_Local_IP':'ネットワーク拡張ローカル IP',		
		'_Message':'メッセージ',
		'_Login_Message':'ログインメッセージ',		
		'_Logout_Message':'ログアウトメッセージ',
		'_Update_Client':'クライアント仮想デスクトップの更新',
		'_To_upload_a_GIF':'GIF (Logo.gif) ファイルをアップロードするには、ファイルの場所を参照し、[アップロード] をクリックします',
		'_File_Path':'ファイルパス:'
		}];	

/*----- VPN > L2TP VPN -----*/

/* l2tps.html */
var _l2tps=[{
		'_Configuration':'設定',
		'_Enable_L2TP_Over_IPSec':'L2TP ブロードキャストを IPSec で有効',
		'_VPN_Connection':'VPN 接続',
		'_IP_Address_Pool':'IP アドレスプール',
		'_Authentication_Method':'認証方法',
		'_Allowed_User':'許可されたユーザー',
		'_Keep_Alive_Timer':'有効タイマー維持',
		'_seconds':'秒',
		'_First_DNS':'1st DNS サーバー(オプション)',
		'_Second_DNS':'2nd DNS サーバー(オプション)',
		'_First_WINS':'1st WINS サーバー(オプション)',
		'_Second_WINS':'2nd WINS サーバー(オプション)'
		}];

/* l2tps_sm.html */
var _l2tps_sm=[{
		'_Current_L2TP_Session':'L2TP セッション',
		'_User_Name':'ユーザー名',
		'_Hostname':'ホスト名',
		'_Assigned_IP':'割り当てられた IP',
		'_Public_IP':'パブリック IP'
		}];	

/*----- AppPatrol -----*/

/* appgeneral.html */
var _appgeneral=[{
		'_General_Setup':'一般設定',
		'_Enable_Application_Patrol':'アプリケーションパトロール 有効',
		'_Registration':'登録',
		'_Registration_Status':'登録ステータス',
		'_Registration_Type':'登録タイプ',
		'_Apply_New_Registration':'新規登録適用',
		'_Signature_Information':'シグネチャ情報',
		'_Current_Version':'バージョン',
		'_Signature_Number':'シグネチャ数',
		'_Released_Date':'発行日',
		'_Update_Signatures':'シグネチャ更新'
		}];
				
/* appCommon.html */
var _appCommon=[{
		'_Common_Protocols':'共通プロトコル',
		'_Service':'サービス',
		'_Default_Access':'デフォルトアクセス',
		'_Classify':'分類',
		'_Modify':'変更'
		}];

/* appCommon.html */
var _appIM=[{
		'_Instant_Messenger':'インスタントメッセンジャー',
		'_Service':'サービス',
		'_Default_Access':'デフォルトアクセス',
		'_Classify':'分類',
		'_Modify':'変更'
		}];
				
/* appCommon.html */
var _appP2P=[{
		'_P2P':'ピア・ツー・ピア',
		'_Service':'サービス',
		'_Default_Access':'デフォルトアクセス',
		'_Classify':'分類',
		'_Modify':'変更'
		}];
				
/* appCommon.html */
var _appVoIP=[{
		'_VoIP':'VoIP',
		'_Service':'サービス',
		'_Default_Access':'デフォルトアクセス',
		'_Classify':'分類',
		'_Modify':'変更'
		}];

/* appCommon.html */
var _appStream=[{
		'_Streaming_Protocols':'ストリーミングプロトコル',
		'_Service':'サービス',
		'_Default_Access':'デフォルトアクセス',
		'_Classify':'分類',
		'_Modify':'変更'
		}];

/* aplpatroledit.html */
var _aplpatroledit=[{
		'_Service':'サービス',
		'_Enable_Service':'サービス 有効',
		'_Service_Identification':'サービス ID',
		'_Name':'名前',
		'_Auto':'自動',
		'_Service_Ports':'サービスポート',
		'_Classification':'分類',
		'_Service_Port':'サービスポート',
		'_Policy':'ポリシー',
		'_Port':'ポート',
		'_Schedule':'スケジュール',
		'_User':'ユーザー',
		'_From':'From',
		'_To':'To',
		'_Source':'送信元',
		'_Destination':'送信先',
		'_Access':'アクセス',
		'_BWM':'BWM 入/出/事前',
		'_Log':'ログ'
		}];

/* appedit.html */
var _appedit=[{
		'_Configuration':'設定',
		'_Bandwidth_Management':'帯域管理',
		'_Inbound':'受信',
		'_kbp1':'kbps',
		'_Outbound':'送信',
		'_kbp2':'kbps&nbsp;(0 : 無効)',
		'_Priority':'優先度',
		'_MBU':'帯域の最大値',
		'_Enable_Policy':'ポリシー 有効',
		'_Port':'ポート',
		'_any':'(0 : すべて)',
		'_Schedule':'スケジュール',
		'_User':'ユーザー',
		'_From':'From',
		'_To':'To',
		'_Source':'送信元',
		'_Destination':'送信先',
		'_Access':'アクセス',
		'_Action_Block':'アクションブロック',
		'_Login':'ログイン',
		'_Message':'メッセージ',
		'_Audio':'オーディオ',
		'_Video':'ビデオ',
		'_File_Transfer':'ファイル転送',
		'_Log':'ログ'
		}];

/* aplother.html */
var _aplother=[{
		'_Policy':'ポリシー',
		'_Port':'ポート',
		'_Schedule':'スケジュール',
		'_User':'ユーザー',
		'_From':'From',
		'_To':'To',
		'_Source':'送信元',
		'_Destination':'送信先',
		'_Protocol':'プロトコル',
		'_Access':'アクセス',
		'_BWM':'BWM 入/出/事前',
		'_Log':'ログ'
		}];

/* aplotheredit.html */
var _aplotheredit=[{
		'_Configuration':'設定',
		'_Bandwidth_Management':'帯域管理',
		'_Inbound':'受信',
		'_Outbound':'送信',
		'_kbps1':'kbps',
		'_kbps2':'kbps&nbsp;(0 : 無効)',
		'_MBU':'帯域の最大値',
		'_Enable':'有効',
		'_Port':'ポート',
		'_any':'(0 : すべて)',
		'_Schedule':'スケジュール',
		'_User':'ユーザー',
		'_From':'From',
		'_To':'To',
		'_Source':'送信元',
		'_Destination':'送信先',
		'_Protocol':'プロトコル',
		'_Priority':'優先度',
		'_Access':'アクセス',
		'_Log':'ログ'
		}];
					
/* appStatic.html */
var _appStatic=[{
		'_Options':'オプション',
		'_Refresh_Interval':'更新の間隔',
		'_Display_Protocols':'表示プロトコル',
		'_Select_All':'すべて選択',
		'_Clear_All':'すべて消去',
		'_Bandwidth_Statistics':'帯域統計',
		'_Protocol_Statistics':'プロトコル統計',
		'_Service':'サービス',
		'_Forwarded_Data':'転送されたデータ (KB)',
		'_Dropped_Data':'ドロップされたデータ (KB)',
		'_Rejected_Data':'拒否されたデータ (KB)',
		'_Matched_Auto':'一致した自動接続',
		'_Matched_Service_Ports':'一致したサービスポート接続',
		'_Rule':'ルール',
		'_Inbound_Kbps':'受信 Kbps',
		'_Outbound_Kbps':'送信 Kbps',
		'_Forwarded_Data':'転送されたデータ (KB)',
		'_Dropped_Data':'ドロップされたデータ (KB)',
		'_Rejected_Data':'拒否されたデータ (KB)',
		'_Destination':'送信先',
		'_Protocol':'プロトコル',
		'_Access':'アクセス',
		'_Log':'ログ'
		}];

/*----- Anti-X > Anti-Virus -----*/
				
/* antivirus.html */
var _antivirus=[{
		'_Configuration':'設定',
		'_Enable_Anti_Virus':'アンチスパイウェアを経たアンチウィルス ブロードキャスト 有効',
		'_Priority':'優先度',
		'_From':'From',
		'_To':'To',
		'_Protocol':'プロトコル',
		'_Registration':'登録',
		'_Registration_Status':'登録ステータス',
		'_Registration_Type':'登録タイプ',
		'_Apply_New_Registration':'新規登録適用',
		'_Signature_Information':'シグネチャ情報',
		'_Current_Version':'バージョン',
		'_Signature_Number':'シグネチャ数',
		'_Released_Date':'発行日',
		'_Update_Signatures':'シグネチャ更新'
		}];

/* avedit.html */
var _avedit=[{
		'_Configuration':'設定',
		'_Direction':'方向',
		'_Enable':'有効',
		'_Log':'ログ',
		'_From':'From',
		'_To':'To',
		'_Protocols_to_Scan':'スキャンするプロトコル',
		'_HTTP':'HTTP',
		'_FTP':'FTP',
		'_SMTP':'SMTP',
		'_POP3':'POP3',
		'_IMAP4':'IMAP4',
		'_Actions_When_Matched':'一致時のアクション',		
		'_Destroy':'感染したファイル破棄',
		'_Send':'Windows  メッセージ送信',
		'_White_List_Black_List':'ホワイトリスト/ブラックリストチェック',
		'_Bypass_white_list':'ホワイトリストチェック省略',
		'_Bypass_black_list':'ブラックリストチェック省略',
		'_File_decompression':'ファイル解凍',
		'_Enable_file_decompression':'ファイル解凍 有効 (ZIP と RAR)',
		'_Destroy_compressed_files':'解凍できない圧縮ファイルを破棄'
		}];

/* antisetting.html */
var _antiset=[{
		'_General_Setting':'一般設定',
		'_Scan_EICAR':'EICAR をスキャン',
		'_White_List':'ホワイトリスト',
		'_Enable_White_List':'ホワイトリスト 有効',
		'_Total_Rule':'ルール数:',
		'_Page':'ページ',
		'_File_Pattern':'ファイルパターン',
		'_Black_List':'ブラックリスト',
		'_Enable_Black_List':'ブラックリスト 有効',
		'_rules_per_page':'1ページあたりのルール'
		}];

/* antisetedit.html */
var _antisetedit=[{
		'_Configuration':'設定',
		'_Enable':'有効',
		'_File_Pattern':'ファイルパターン'
		}];

/* avsignature.html */
var _avsignature=[{
		'_Query_Signatures':'シグネチャのクエリ',
		'_Signatures_Search':'シグネチャ検索',
		'_Query_all_signs':'すべてのシグネチャをクエリしてエクスポート',
		'_Query_Result':'クエリ結果',
		'_Total_Signature':'全シグネチャ数:',
		'_signatures_per_page':'1ページあたりのシグネチャ',
		'_Page':'ページ',
		'_Name':'名前',
		'_ID':'ID',
		'_Severity':'深刻度',
		'_Category':'カテゴリ'
		}];
				
/*----- Anti-X > IDP -----*/

/* idpgl.html */
var _idpgl=[{
		'_General_Setup':'一般設定',
		'_Enable_Signature_Detection':'シグネチャ検出 有効',
		'_Bindings':'バインディング',
		'_Priority':'優先度',	
		'_From':'From',		
		'_To':'To',
		'_IDP_Profile':'IDP プロファイル',		
		'_Registration':'登録',
		'_Registration_Status':'登録ステータス:',
		'_Registration_Type':'登録タイプ:',
		'_Apply_New_Registration':'新規登録適用',
		'_Signature_Information':'シグネチャ情報',
		'_Current_Version':'バージョン:',
		'_Signature_Number':'シグネチャ数:',
		'_Released_Date':'発行日:',
		'_Update_Signatures':'シグネチャ更新',
		/* idpgl_1.html */
		'_Enable_Anomaly_Detection':'例外検出 有効',
		'_Anomaly_Profile':'例外プロファイル',
		/* idpzoneedit page*/
		'_Configuration':'設定',
		'_Direction':'方向',
		'_Profile_Selection':'プロファイル選択',
		'_Enable':'有効',
		'_ADP_Profile':'ADP プロファイル'
		}];

/* dataiframe.html */
var _dataiframe=[{
		'_GoTo':'ジャンプ',
		'_Page':'ページ'
		}];

/* idppf.html */
var _idppf=[{
		'_Update':'更新',
		'_Profile_Management':'プロファイル管理',
		'_Name':'名前',
		'_Base_Profile':'基本プロファイル',
		'_Please_select_IDP_Profile':'IDP 基本プロファイルを1つ選択してください'
		}];

/* idppfedit.html */
var _idppfedit=[{
		'_Name':'名前',
		'_Signature_Group':'シグネチャグループ',
		'_Service':'サービス',
		'_Activation':'有効',
		'_Log':'ログ',
		'_Action':'アクション',
		'_Message':'メッセージ',
		'_SID':'SID',
		'_Severity':'深刻度',
		'_Policy_Type':'ポリシータイプ'		
		}];

/* idpfedat.html */
var _idpfedat=[{		
		'_Name':'名前',
		'_Scan_Detection':'スキャン検出',
		'_Sensitivity':'強度',
		'_Block_Period':'ブロック間隔',
		'_1_3600_seconds':'(1～3600秒)',
		'_Flood_Detection':'フラッド検出',
		'_Activation':'有効',
		'_Log':'ログ',
		'_Action':'アクション',
		'_Threshold':'しきい値'
		}];

/* idpfedpa.html */
var _idpfedpa=[{
		'_Name':'名前',
		'_HTTP_Inspection':'HTTP 検査',
		'_TCP_Decoder':'TCP デコーダ',
		'_UDP_Decoder':'UDP デコーダ',
		'_ICMP_Decoder':'ICMP デコーダ',
		'_Activation':'有効',
		'_Log':'ログ',
		'_Action':'アクション'
		}];		

/* idpquery.html */
var _idpquery=[{
		'_Name':'名前',
		'_Query_Signatures':'シグネチャのクエリ',
		'_Search_all_custom_signature':'すべてのカスタムシグネチャ検索',
		'_Optional':'(オプション)',
		'_Signature_ID':'シグネチャ ID',
		'_Severity':'深刻度',
		'_Attack_Type':'アタックタイプ',
		'_Platform':'プラットフォーム',
		'_Service':'サービス',
		'_Activation':'有効',
		'_Log':'ログ',
		'_Action':'アクション',
		'_Page':'ページ:',
		'_Actions_hold':'アクション',
		'_Query_Result':'クエリ結果',
		'_Total_IDP':'IDP 合計',
		'_IDP_per_page':'1ページあたりの IDP',
		'_SID':'SID'
		}];

/* idpcs.html */
var _idpcs=[{
		'_Creating':'作成',
		'_SID':'SID',
		'_Name':'名前',		
		'_Importing':'インポート',
		'_Import_name':'インポート名.ルール; カスタム.ルール = デバイスカスタムシグネチャファイル.',
		'_File_Path':'ファイルパス'
		}];

/* idpcsedit.html */
var _idpcsedit=[{
		'_Name':'名前',
		'_Signature_ID':'シグネチャ ID',
		'_Information':'情報',
		'_Severity':'深刻度',
		'_Platform':'プラットフォーム',
		'_All':'すべて',
		'_Solaris':'Solaris',
		'_Other_Unix':'その他-Unix',
		'_Network_Device':'ネットワークデバイス',
		'_Service':'サービス',
		'_Policy_Type':'ポリシータイプ',
		'_Frequency':'頻度',
		'_Threshold':'しきい値',
		'_Packet':'パケット',
		'_Second':'秒',
		'_Header_Options':'ヘッダオプション',
		'_Network_Protocol':'ネットワークプロトコル',
		'_Type_of_Service':'サービスタイプ',
		'_Identification':'ID',
		'_Fragmentation':'フラグメンテーション',
		'_Reserved_Bit':'リザーブビット',
		'_Dont_Fragment':'Don\'t Fragment',
		'_More_Fragment':'その他のフラグメント',
		'_Fragment_Offset':'フラグメントオフセット',
		'_Time_to_Live':'残り時間',
		'_IP_Options':'IP オプション',
		'_Same_IP':'同一 IP',
		'_Transport_Protocol':'転送プロトコル',
		'_Port':'ポート',
		'_Source_Port':'送信元ポート',
		'_Destination_Port':'送信先ポート',
		'_Flow':'フロー',
		'_Flags':'フラグ',
		'_Type':'タイプ',
		'_Code':'コード',
		'_Reserved':'リザーブ',
		'_Sequence_Number':'シーケンス',
		'_Ack_Number':'ACK',
		'_Window_Size':'ウィンドウサイズ',
		'_Payload_Options':'ペイロードオプション',
		'_Payload_Size':'ペイロードサイズ',
		'_Byte':'バイト',
		'_Patterns':'パターン',
		'_Win95_98':'Win95/98',
		'_WinNT':'WinNT',
		'_WinXP_2000':'WinXP/2000',
		'_Linux':'Linux',
		'_FreeBSD':'FreeBSD',
		'_SGI':'SGI',
		'_IPv4':'IPv4',
		'_SYN':'SYN',
		'_FIN':'FIN',
		'_RST':'RST',
		'_PSH':'PSH',
		'_ACK':'ACK',
		'_URG':'URG',
		'_1':'1 (MSB)',
		'_2':'2',
		'_ID':'ID',
		'_Offset':'オフセット',
		'_Relative_to_start_of_payload':'ペイロード開始部分',
		'_Content':'コンテンツ',
		'_Relative_to_end_of_last_match':'終わりの一致部分',
		'_Case_insensitive':'大文字と小文字を区別',
		'_Within':'内 ',
		'_Bytes':' バイト',
		'_Decode_as_URI':'URI としてデコード'
		}];

/* idpimport.html */
var _idpimport=[{
		'_Custom_Signature':'カスタムシグネチャ',
		'_SID':'SID',
		'_Name':'名前'
		}];

/*----- Anti-X > Content Filter -----*/

/* cfilter.html */
var _cfilter=[{
		'_General_Setup':'一般設定',
		'_Enable_Content_Filter':'コンテンツフィルター 有効',
		'_Block':'ポリシーが適用されていない場合は Web アクセスをブロック',
		'_Policies':'ポリシー',
		'_Address':'アドレス',
		'_Schedule':'スケジュール',
		'_User':'ユーザー',
		'_Filter_Profile':'フィルタープロファイル ',
		'_Message':'サイトがブロックされたときに表示するメッセージ',
		'_Denied_Access_Message':'アクセス拒否メッセージ',
		'_Redirect_URL':'URLの変更',
		'_Registration':'登録',
		'_Registration_Status':'登録ステータス:',
		'_Registration_Type':'登録タイプ:',
		'_Apply_New_Registration':'新規登録適用'
		}];

/* cfilteredit.html */
var _cfilteredit=[{
		'_Configuration':'設定',
		'_Schedule':'スケジュール',
		'_Address':'アドレス',
		'_Filter_Profile':'フィルタープロファイル ',
		'_User_Group':'ユーザー/グループ'
		}];

/* cfprofile.html */
var _cfprofile=[{
		'_Profile_Management':'プロファイル管理',
		'_Filter_Profile_Name':'フィルタープロファイル名'
		}];

/* cfpcyedit.html */
var _cfpcyedit=[{
		'_Categories':'カテゴリ',
		'_Customization':'カスタム化',
		'_Filter_Profile':'フィルタープロファイル ',
		'_Name':'名前',
		'_Auto':'自動 Web カテゴリ設定',
		'_External':'外部 Web フィルターサービスステータス',
		'_Enable':'外部 Web フィルターサービス 有効',
		'_Block':'ブロック',
		'_Log':'ログ',
		'_Matched_Web_Pages':'一致した Web ページ',
		'_Unrated_Web_Pages':'レート未対応 Web ページ',
		'_When':'Web フィルターサーバーが利用可能な場合',
		'_Content':'コンテンツフィルターサービス利用不可タイムアウト',
		'_Seconds':'秒',
		'_Select_Categories':'カテゴリ選択',
		'_Select_All_Categories':'すべてのカテゴリ選択',
		'_Clear_All_Categories':'すべてのカテゴリ消去',
		/* check list */
		'_Adult_Mature_Content':'ポルノグラフィー/成人コンテンツ',
		'_Pornography':'ポルノグラフィー',
		'_Sex_Education':'性教育',
		'_Intimate_Apparel_Swimsuit':'下着/水着',
		'_Nudity':'ヌード',
		'_Alcohol_Tobacco':'アルコール/タバコ',
		'_Illegal_Questionable':'違法/不審',
		'_Gambling':'ギャンブル',
		'_Violence_Hate_Racism':'暴力/嫌悪/差別',
		'_Weapons':'武器',
		'_Abortion':'中絶',
		'_Hacking':'ハッキング',
		'_Phishing':'フィッシング詐欺',
		'_Arts_Entertainment':'アート/エンターテイメント',
		'_Business_Economy':'ビジネス/経済',
		'_Alternative_Spirituality_Occult':'幽霊/オカルト',
		'_Illegal_Drugs':'不法ドラッグ',
		'_Education':'教育',
		'_Cultural_Institutions':'文化/慈善事業',
		'_Financial_Services':'金融サービス',
		'_Brokerage_Trading':'仲買/貿易',
		'_Online_Games':'オンラインゲーム',
		'_Government_Legal':'政府/法律',
		'_Military':'軍事',
		'_Political_Activist_Group':'政治/活動団体',
		'_Health':'健康',
		'_Computers_Internet':'コンピュータ/インターネット',		
		'_Search_Engines_Portals':'検索エンジン/ポータル',		
		'_Spyware_Malware_Sources':'スパイウェア/マルウェア',
		'_Spyware_Effects_Privacy_Concerns':'個人情報搾取/プライバシー関連',		
		'_Job_Search_Careers':'就職/転職',
		'_News_Media':'ニュース/メディア',
		'_Personals_Dating':'パーソナル/出会い',
		'_Reference':'辞典/辞書',
		'_Open_Image_Media_Search':'画像/動画 検索',
		'_Chat_Instant_Messaging':'チャット/インスタントメッセージ',
		'_Email':'メール',		
		'_Blogs_Newsgroups':'ブログ/ニュースグループ',
		'_Religion':'宗教',		
		'_Social_Networking':'ソーシャルネットワークサービス(SNS)',		
		'_Online_Storage':'オンラインストレージ',		
		'_Remote_Access_Tools':'リモートアクセスツール',		
		'_Shopping':'ショッピング',
		'_Auctions':'オークション',
		'_Real_Estate':'不動産',
		'_Society_Lifestyle':'社会/生活',		
		'_Sexuality_Alternative_Lifestyles':'性/ライフスタイル',		
		'_Restaurants_Dining_Food':'レストラン/食事/食べ物',
		'_Sports_Recreation_Hobbies':'スポーツ/娯楽/趣味',
		'_Travel':'旅行',
		'_Vehicles':'乗り物',
		'_Humor_Jokes':'ユーモア/ジョーク',
		'_Software_Downloads':'ソフトウェアダウンロード',
		'_Pay_to_Surf':'有料サイト',
		'_Peer_to_Peer':'ピア・ツー・ピア',
		'_Streaming_Media_MP3s':'配信/MP3',
		'_Proxy_Avoidance':'プロキシ回避',
		'_For_Kids':'For Kids',
		'_Web_Advertisements':'Web 広告',
		'_Web_Hosting':'Web ホスティング',
		/* end check list */
		'_Test1':'Web サイトカテゴリのテスト',
		'_URL_to_test':'テストする URL'
		}];

/* cfpcsedit.html */
var _cfpcsedit=[{
		'_Categories':'カテゴリ',
		'_Customization':'カスタム化',
		'_Filter_Profile':'フィルタープロファイル ',
		'_Name':'名前',
		'_Customization_Setup':'カスタム化セットアップ',
		'_Enable':'Web サイトカスタム化 有効',
		'_Allow1':'信頼された Web サイトのみの Web トラフィックを許可',
		'_Restricted_Web_Features':'制限された Web 機能',
		'_Block':'ブロック',
		'_ActiveX':'ActiveX',
		'_Java':'Java',
		'_Cookies':'Cookies',
		'_Web_Proxy':'Web プロキシ',
		'_Allow2':'信頼された Web サイトに Java/ActiveX/Cookies/Web プロキシを許可します',
		'_Trusted_Web_Sites':'信頼された Web サイト',
		'_Add_Trusted_Web_Site':'信頼された Web サイト追加',
		'_Forbidden_Web_Sites':'禁止 Web サイト',
		'_Add_Forbidden_Web_Site':'禁止 Web サイト追加',
		'_Blocked_URL_Keywords':'ブロックする URL キーワード',
		'_Add_Blocked_URL_Keyword':'ブロックする URL キーワード追加'
		}];	

/* cfcache.html */
var _cfcache=[{
		'_URL_Cache_Entry':'URL キャッシュ登録',
		'_Total_cache_entries':'全キャッシュ登録数:',
		'_entries_per_page':'1ページあたりの登録',
		'_Page':'ページ',
		'_Category':'カテゴリ',
		'_URL':'URL',
		'_Remaining_Time_minutes':'残り時間 (分)',
		'_Remove':'削除',
		'_URL_Cache_Setup':'URL キャッシュセットアップ',
		'_Maximum_TTL':'最大 TTL',
		'_hours':'(1～720時間)'
		}];

/*----- Device HA -----*/

/* vrrpgrp.html */
var _vrrpgrp=[{
		'_Configuration':'設定',
		'_Enable':'有効',
		'_Link_Monitoring':'リンク監視',
		'_VRRP_Group':'VRRP グループ',
		'_Name':'名前',
		'_VRID':'VRID',
		'_Role':'役割',
		'_Interface':'インターフェース',
		'_Note_LINK':'注意：マスタZyWALLのVRRPインターフェースリンクがダウンした場合、全てのマスタVRRPインターフェースをシャットダウンしてください。ZyWALLバックアップ機が通信を受け継ぎます。.',
		'_HA_Status':'HA ステータス'
		}];

/* vrrpgedit.html */
var _vrrpgedit=[{
		'_Basic_Setting':'基本設定',
		'_Enable':'有効',
		'_Name':'名前',
		'_VRID':'VRID',
		'_Description':'説明',
		'_Optional':'(オプション)',
		'_VRRP_Interface':'VRRP インターフェース',
		'_Role':'役割',
		'_Master':'マスタ',
		'_Backup':'バクアップ',
		'_Priority':'優先度',
		'_range_check_for_backup':'バックアップ範囲のチェック:',
		'_Preempt':'事前設定',
		'_Manage_IP':'IP 管理',
		'_Manage_IP_Subnet_Mask':'IP サブネットマスク管理',
		'_Authentication':'認証',
		'_None':'なし',
		'_Text':'テキスト',
		'_IP_AH_MD5':'IP AH (MD5)',
		'_Authentication_key':'認証キー'
		}];

/* devhasync.html */
var _devhasync=[{
		'_Authentication':'認証',
		'_Password':'パスワード',
		'_Synchronize_from':'同期元',
		'_IP_or_FQDN':'(IPまたはFQDN)',
		'_on_port':'ポート',
		'_Auto_Synchronize':'自動同期',
		'_Interval':'間隔',
		'_minutes':'分'
		}];
		
/* dha.html */
var _dha=[{
		'_Synchronize_now':'ZyWALL 同期',
		'_Rendering':'レンダリング...'
		}];
		
/*----- Object > User/Group -----*/

/* users.html */
var _users=[{
		'_Configuration':'設定',
		'_User_Name':' ユーザー名',
		'_Description':' 説明'
		}];

/* usersedit.html */
var _usersedit=[{
		'_User_Configuration':'ユーザー設定',
		'_User_Name':'ユーザー名',
		'_User_Type':'ユーザータイプ',
		'_Password':'パスワード',
		'_Retype':'再入力',
		'_Description':'説明',
		'_Lease_Time':'リースタイム',
		'_Reauthentication_Time':'再認証時間',
		'_minutes_is_unlimited':'(0-1440 分、0 は制限なし)'
		}];

/* grps.html */
var _grps=[{
		'_Configuration':'設定',
		'_Group_Name':'グループ名',
		'_Description':'説明',
		'_Member':'メンバー'
		}];

/* grpsedit.html */
var _grpsedit=[{
		'_Configuration':'設定',
		'_Name':'名前',
		'_Description':'説明',
		'_Member':'メンバー',
		'_Optional':'(オプション)'
		}];

/* usrset.html */
var _usrset=[{
		'_User_Default_Setting':'ユーザー基本設定',
		'_User_Type':'ユーザータイプ',
		'_Lease_Time':'リースタイム',
		'_minutes':'分',
		'_minutes_is_unlimited':'(0-1440 分、0 は制限なし)',
		'_Reauthentication_Time':'再認証時間',
		'_User_Logon_Setting':'ユーザーログオン設定',
		'_Limit1':'管理者アカウントに対し同時ログインできる人数を制限する',
		'_Maximum1':'1つの管理者アカウントで利用できる人数',
		'_Limit2':'アクセスアカウントに対し同時ログインできる人数を制限する',
		'_Maximum2':'1つのアカウントで利用できる人数',
		'_User_Lockout_Setting':'ユーザーロックアウト設定',
		'_Enable_logon_retry_limit':'ログオン再試行制限 有効',
		'_Maximum_retry_count':'再試行可能回数',
		'_Lockout_period':'ロックアウトタイム',
		'_User_Miscellaneous_Settings':'ユーザーのその他の設定',
		'_Allow':'リースタイムを自動的に更新できるよう許可',
		'_Enable_user_idle_detection':'アイドルユーザー検出 有効',
		'_User_idle_timeout':'アイドルユーザータイムアウト',
		'_Force_User_Authentication_Policy':'ユーザー認証ポリシーの強制',
		'_Total_Policy':'全ポリシー数',
		'_Policy_per_page':'1ページあたりのポリシー',
		'_Page':'ページ',
		'_Schedule':'スケジュール',
		'_Source':'送信元',
		'_Destination':'送信先',
		'_Authenticate':'認証'
		}];

/* usrsetedit.html */
var _usrsetedit=[{
		'_Configuration':'設定',
		'_Enable':'有効',
		'_Description':'説明',
		'_Optional':'(オプション)',
		'_Authentication':'認証',
		'_Criteria':'基準',
		'_Source_Address':'送信元アドレス',
		'_Destination_Address':'送信先のアドレス',
		'_Schedule':'スケジュール'
		}];

/*----- Object > Address -----*/

/* address.html */
var _address=[{
		'_Configuration':'設定',
		'_Name':'名前',
		'_Type':'タイプ',
		'_Address':'アドレス'
		}];

/* addredit.html */
var _addredit=[{
		'_Configuration':'設定',
		'_Name':'名前',
		'_Address_Type':'アドレスタイプ',
		'_Network':'ネットワーク',
		'_Netmask':'ネットマスク',
		'_IP_Address':'IP アドレス',
		'_Starting_IP_Address':'開始 IP アドレス',
		'_End_IP_Address':'終了 IP アドレス'
		}];
				
/* addrgps.html */
var _addrgps=[{
		'_Configuration':'設定',
		'_Name':'名前',
		'_Description':'説明'
		}];

/* addrgpsedit.html */
var _addrgpsedit=[{
		'_Group_Members':'グループメンバー',
		'_Name':'名前',
		'_Description':'説明'
		}];

/*----- Object > Service -----*/

/* service.html */
var _service=[{
		'_Configuration':'設定',
		'_Total_Services':'全サービス',
		'_services_per_page':'1ページあたりのサービス',
		'_Page':'ページ',
		'_Name':'名前',
		'_Content':'コンテンツ'
		}];

/* svredit.html */
var _svredit=[{
		'_Configuration':'設定',
		'_Name':'名前',
		'_IP_Protocol':'IP プロトコル',
		'_Starting_Port':'開始ポート',
		'_ICMP_Type':'ICMP タイプ',
		'_IP_Protocol_Number':'IP プロトコル番号',
		'_Ending_Port':'終了ポート'
		}];

/* svrgrp.html */
var _svrgrp=[{
		'_Configuration':'設定',
		'_Name':'名前',
		'_Description':'説明'
		}];


/* svrgrpedit.html */
var _svrgrpedit=[{
		'_Configuration':'設定',
		'_Name':'名前',
		'_Description':'説明'
		}];

/*----- Object > Schedule -----*/

/* schedule.html */
var _schedule=[{
		'_One_Time':'1度',
		'_Name':'名前',
		'_Start_Day':'開始日',
		'_Stop_Day':'停止日',
		'_Time':'時刻',
		'_Recurring':'繰り返し',
		'_Start_Time':'開始時刻',
		'_Stop_Time':'停止時刻'
		}];

/* schedit.html */
var _schedit=[{
		'_Configuration':'設定',
		'_Name':'名前',
		'_Day_Time':'日時',
		'_Item':'アイテム',
		'_Date':'日付',
		'_Time':'時刻',
		'_Year':'年',
		'_Month':'月',
		'_Day':'日',
		'_Hour':'時間',
		'_minute':'分',
		'_Start':'開始',
		'_Stop':'停止',
		'_Weekly':'毎週',
		'_Week_Days':'平日',
		'_Monday':'月曜',
		'_Tuesday':'火曜',
		'_Wednesday':'水曜',
		'_Thursday':'木曜',
		'_Friday':'金曜',
		'_Saturday':'土曜',
		'_Sunday':'日曜',
		/* Inline object. */
		'_Type':'タイプ'
		}];
			
/*----- Object > AAA Server -----*/

/* activeDir_d.html */
var _ad=[{
		'_Default':'デフォルト',
		'_Group':'グループ',
		'_Configuration':'設定',
		'_Host':'ホスト',
		'_IP_FQDN':'(IPまたはFQDN)',
		'_Port':'ポート',
		'_Bind_DN':'バインド DN',
		'_Optional':'(オプション)',
		'_Password':'パスワード',
		'_Base_DN':'基本 DN',
		'_CN_Identifier':'CN識別',
		'_Search_time_limit':'検索時間制限',
		'_Use_SSL':'SSL 使用'
		}];
	      
/* activeDir_g.html */
var _adg=[{
		'_Default':'デフォルト',
		'_Group':'グループ',
		'_Configuration':'設定',
		'_Group_Name':'グループ名'
		}];

/* adgedit.html */
var _adgedit=[{
		'_Default':'デフォルト',
		'_Group':'グループ',
		'_Configuration':'設定',
		'_Name':'名前',
		'_Port':'ポート',
		'_Bind_DN':'バインド DN',
		'_Optional':'(オプション)',
		'_Password':'パスワード',
		'_Base_DN':'基本 DN',
		'_CN_Identifier':'CN識別',
		'_Search_time_limit':'検索時間制限',
		'_Use_SSL':'SSL 使用',
		'_Host_Members':'ホストメンバー',
		'_Members':'メンバー (IP または FQDN)'
		}];

/* aldapd.html */
var _aldapd=[{
		'_Default':'デフォルト',
		'_Group':'グループ',
		'_Configuration':'設定',
		'_Host':'ホスト',
		'_IP_or_FQDN':'(IPまたはFQDN)',
		'_Port':'ポート',
		'_Bind_DN':'バインド DN',
		'_Optional':'(オプション)',
		'_Password':'パスワード',
		'_Base_DN':'基本 DN',
		'_CN_Identifier':'CN識別',
		'_Search_time_limit':'検索時間制限',
		'_Use_SSL':'SSL 使用'
		}];

/* aldapg.html */
var _aldapg=[{
		'_Configuration':'設定',
		'_Default':'デフォルト',
		'_Group':'グループ',
		'_Group_Name':'グループ名'
		}];

/* aldapgedit.html */
var _aldapgedit =[{
		'_Configuration':'設定',
		'_Default':'デフォルト',
		'_Group':'グループ',
		'_Name':'名前',
		'_Port':'ポート',
		'_Bind_DN':'バインド DN',
		'_Optional':'(オプション)',
		'_Password':'パスワード',
		'_Base_DN':'基本 DN',
		'_CN_Identifier':'CN識別',
		'_Search_time_limit':'検索時間制限',
		'_Use_SSL':'SSL 使用',
		'_Host_Members':'ホストメンバー',
		'_Members':'メンバー (IP または FQDN)'
		}];

/* aradiusd.html */
var _aradiusd=[{
		'_Configuration':'設定',
		'_Default':'デフォルト',
		'_Group':'グループ',
		'_Host':'ホスト',
		'_IP_or_FQDN':'(IPまたはFQDN)',
		'_Authentication_Port':'認証ポート',
		'_Key':'キー',
		'_Timeout':'タイムアウト'
		}];

/* aradiusg.html */
var _aradiusg=[{
		'_Configuration':'設定',
		'_Default':'デフォルト',
		'_Group':'グループ',
		'_Group_Name':'グループ名'
		}];

/* aradiusgedit.html */
var _aradiusgedit=[{
		'_Configuration':'設定',
		'_Default':'デフォルト',
		'_Group':'グループ',
		'_Name':'名前',
		'_Host_Members':'ホストメンバー',
		'_Authentication_Port':'認証ポート',
		'_Key':'キー',
		'_Timeout':'タイムアウト',
		'_Members':'メンバー'
		}];
				  	
/*----- Object > Auth. method -----*/
		
/* Authmeth.html */
var _Authmeth=[{
		'_Configuration':'設定',
		'_Method_Name':'メソッド名',
		'_Method_List':'メソッドリスト'
		}];

/* authedit.html */
var _authedit=[{
		'_Configuration':'設定',
		'_Name':'名前',
		'_Method_List':'メソッドリスト'
		}];

/*----- Object > Certificate -----*/

/* cert.html */
var _cert=[{
		'_PKI_Storage_Space_in_Use':'PKI ストレージ使用率',
		'_My_Certificates_Setting':'自己証明設定',
		'_Name':'名前',
		'_Type':'タイプ',
		'_Subject':'件名',
		'_Issuer':'発行元',
		'_Valid_From':'発効日',
		'_Valid_To':'有効期限'
		}];

/* certimpt.html */
var _certimpt=[{
		'_Please':'インポートする証明ファイルの場所を指定してください.証明ファイルは次のいずれかの形式である必要があります.',
		'_Binary1':'バイナリ X.509',
		'_PEM1':'PEM (Base-64) エンコード X.509',
		'_Binary2':'バイナリ PKCS#7',
		'_PEM2':'PEM (Base-64) エンコード PKCS#7',
		'_Binary3':'バイナリ PKCS#12',
		'_For':'自己証明のインポートを行うには、インポートされた証明に対応する要求が ZyWALL に存在している必要があります,インポート後、証明の要求は自動的に削除されます.',
		'_File_Path':'ファイルパス',
		'_Password':'パスワード',
		'_PKCS':'(PKCS#12 のみ)'
		}];

/* certcrat.html */
var _certcrat=[{
		'_Name':'名前',
		'_Subject_Information':'件名情報',
		'_Common_Name':'コマンド名',
		'_Host_IP_Address':'ホスト IP アドレス',
		'_Host_Domain_Name':'ホストドメイン名',
		'_E_Mail':'メール',
		'_Organizational_Unit':'組織',
		'_Optional':'(オプション)',
		'_Organization':'企業',
		'_Country':'国',
		'_Key_Type':'キータイプ',
		'_Key_Length':'キーの長さ',
		'_bits':'ビット',
		'_Enrollment_Options':'登録オプション',
		'_Create1':'自己証明作成',
		'_Create2':'証明書の要求を作成し、ローカルに保存して後から手動登録用に使用',
		'_Create3':'証明書の要求を作成し、すぐにオンラインで証明を登録',
		'_Enrollment_Protocol':'登録プロトコル',
		'_CA_Server_Address':'CA サーバーアドレス',
		'_CA_Certificate':'CA 証明',
		'_See':'表示',
		'_Trusted_CAs':'信頼された CA',
		'_Request_Authentication':'認証要求',
		'_Reference_Number':'リファレンスナンバー',
		'_Key':'キー'
		}];

/* certself.html */
var _certself=[{
		'_Name':'名前',
		'_Certification_Path':'証明パス',
		'_Certificate_Information':'証明情報',
		'_Type':'タイプ',
		'_Version':'バージョン',
		'_Serial_Number':'シリアルナンバー',
		'_Subject':'件名',
		'_Issuer':'発行元',
		'_Signature_Algorithm':'シグネチャアルゴリズム',
		'_Valid_From':'発効日',
		'_Valid_To':'有効期限',
		'_Key_Algorithm':'キーアルゴリズム',
		'_Subject_Alternative_Name':'代替名',
		'_Key_Usage':'キーの用途',
		'_Basic_Constraint':'基本制限',
		'_MD5_Fingerprint':'MD5 Fingerprint',
		'_SHA1_Fingerprint':'SHA1 Fingerprint',
		'_Certificate':'PEM(Base-64) エンコード形式の証明',
		'_Password':'パスワード'
		}];
		
/* trscert.html */
var _trscert=[{
		'_PKI_Storage_Space_in_Use':'PKI ストレージ使用率',
		'_Trusted_Certificates_Setting':'信頼された証明設定',
		'_Name':'名前',
		'_Subject':'件名',
		'_Issuer':'発行元',
		'_Valid_From':'発効日',
		'_Valid_To':'有効期限'
		}];

/* trsedit.html */
var _trsedit=[{
		'_Name':'名前',
		'_Certification_Path':'証明パス',
		'_Certificate_Validation':'証明の検証',
		'_Enable':'X.509v3 CRL分配点と OCSP チェック 有効',
		'_OCSP_Server':'OCSP サーバー',
		'_URL':'URL',
		'_ID':'ID',
		'_Password':'パスワード',
		'_LDAP_Server':'LDAP サーバー',
		'_Address':'アドレス',
		'_Port':'ポート',
		'_Certificate_Information':'証明情報',
		'_Type':'タイプ',
		'_Version':'バージョン',
		'_Serial_Number':'シリアルナンバー',
		'_Subject':'件名',
		'_Issuer':'発行元',
		'_Signature_Algorithm':'シグネチャアルゴリズム',
		'_Valid_From':'発効日',
		'_Valid_To':'有効期限',
		'_Key_Algorithm':'キーアルゴリズム',
		'_Subject_Alternative_Name':'代替名',
		'_Key_Usage':'キーの用途',
		'_Basic_Constraint':'基本制限',
		'_MD5_Fingerprint':'MD5 Fingerprint',
		'_SHA1_Fingerprint':'SHA1 Fingerprint',
		'_Certificate':'PEM(Base-64) エンコード形式の証明'
		}];

/* trsimpt.html */
var _trsimpt=[{
		'_Please':'インポートする証明ファイルの場所を指定してください,証明ファイルは次のいずれかの形式である必要があります',
		'_Binary1':'バイナリ X.509',
		'_PEM1':'PEM (Base-64) エンコード X.509',
		'_Binary2':'バイナリ PKCS#7',
		'_PEM2':'PEM (Base-64) エンコード PKCS#7',
		'_File_Path':'ファイルパス'
		}];
		
/*----- Object > ISP Account -----*/

/* Account.html */
var _Account=[{
		'_Configuration':'設定',
		'_Profile_Name':'プロファイル名',
		'_Protocol':'プロトコル',
		'_Authentication_Type':'認証タイプ',
		'_User_Name':'ユーザー名'
		}];

/* acctedit.html */
var _acctedit=[{
		'_Configuration':'設定',
		'_Profile_Name':'プロファイル名',
		'_Protocol':'プロトコル',
		'_Encryption_Method':'暗号化方法',
		'_Authentication_Type':'認証タイプ',
		'_User_Name':'ユーザー名',
		'_Password':'パスワード',
		'_Connection_ID':'接続 ID',	
		'_Retype_to_confirm':'再入力して確認',	
		'_Server_IP':'サーバー IP',
		'_IP_Address':'(IP アドレス)',
		'_Optional':'(オプション)',
		'_Service_Name':'サービス名',
		'_Compression':'圧縮',
		'_On':'オン',
		'_Off':'オフ',
		'_Idle_timeout':'アイドルタイムアウト',
		'_Seconds':'(秒)'
		}];

/*----- Object > SSL Application -----*/

/* application.html */
var _application=[{
		'_Configuration':'設定',
		'_Name':'名前',
		'_Address':'アドレス',
		'_Type':'タイプ'
		}];
		
/* applicationedit.html */
var _applicationedit=[{
		'_Object':'オブジェクト',
		'_Type':'タイプ',
		'_Web_Application':'Web アプリケーション',
		'_Name':'名前',
		'_URL':'URL',
		'_Server_Type':'サーバータイプ',
		'_File_Sharing':'ファイル共有',	
		'_Entry_Point':'登録ポイント',
		'_Optional':'(オプション)',
		'_NameC':'名前',
		'_Shared_Path':'共有パス',	
		'_Web_Page_Encryption':'Web ページの暗号化'
		}];	

/*----- System > Host Name -----*/

/* hostname.html */
var _hostname=[{
		'_General_settings':'一般設定',
		'_System_Name':'システム名',
		'_Optional':'(オプション)',
		'_Domain_Name':'ドメイン名'
		}];

/*----- System > Date/Time -----*/

/* myclock.html */
var _myclock=[{
		'_Current_Time_and_Date':'時刻と日付',
		'_Current_Time':'時刻',
		'_Current_Date':'日付',
		'_Time_and_Date_Setup':'時刻と日付の設定',
		'_Manual':'手動',
		'_New_Time':'新しい時刻 (hh:mm:ss)',
		'_New_Date':'新しい日付 (yyyy-mm-dd)',
		'_Get_from_Time_Server':'タイムサーバーから取得',
		'_Time_Server_Address':'タイムサーバーアドレス*',
		'_Optional1':'*オプション. あらかじめ定義された NTP タイムサーバーリストがあります.',
		'_Time_Zone_Setup':'タイムゾーン設定',
		'_Time_Zone':'タイムゾーン',
		'_Enable_Daylight_Saving':'サマータイム 有効',
		'_Start_Date':'開始日',
		'_End_Date':'終了日',
		'_Offset':'オフセット',
		'_hours':'時間',
		'_of':'of',
		'_at':'at'
		}];

/*----- System > Console Speed -----*/

/* baudrate.html */
var _baudrate=[{
		'_Configuration':'設定',
		'_Console_Port_Speed':'コンソールポート速度'
		}];

/*----- System > DNS -----*/

/* dns.html */
var _dns=[{
		'_DNS_Server':'DNS サーバー',
		'_Address_PTR_Record':'アドレス/PRT 記録',
		'_IP_Address':'IP アドレス',
		'_Domain_Zone':'ドメインゾーン',
		'_From':'From',
		'_Domain_Zone_Forwarder':'ドメインゾーン転送',
		'_MX_Record':'MX 記録 (My FQDN 用)',
		'_Domain_Name':'ドメイン名',
		'_Service_Control':'サービスコントロール',
		'_Zone':'ゾーン',
		'_Address':'アドレス',
		'_FQDN':'FQDN',
		'_IP_FQDN':'IP/FQDN',
		'_Action':'アクション'
		}];

/* adnsedit.html */
var _adnsedit=[{
		'_Configuration':'設定',
		'_IP_Address':'IP アドレス',
		'_FQDN':'FQDN'
		}];

/* nsdnsedit.html */
var _nsdnsedit=[{
		'_Configuration':'設定',
		'_Domain_Zone':'ドメインゾーン',
		'_DNS_Server':'DNS サーバー',
		'_DNS_Server1':'ISP からの DNS サーバー',
		'_First_DNS_Server':'1st DNS サーバー',
		'_Second_DNS_Server':'2nd DNS サーバー',
		'_Third_DNS_Server':'3rd DNS サーバー',
		'_Public_DNS_Server':'パブリック DNS サーバー',
		'_Private_DNS_Server':'プライベート DNS サーバー'
		}];

/* mxdnsedit.html */
var _mxdnsedit=[{
		'_Configuration':'設定',
		'_Domain_Name':'ドメイン名',
		'_IP_Address_FQDN':'IP アドレス/FQDN'
		}];

/* dnsedit.html */
var _dnsedit=[{
		'_Service_Control':'サービスコントロール',
		'_Address_Object':'アドレスオブジェクト',
		'_Zone':'ゾーン',
		'_Action':'アクション'
		}];

/*----- System > WWW -----*/

/* buinsrv.html */
var _buinsrv=[{
		'_HTTPS':'HTTPS',
		'_Enable':'有効 ',
		'_Server_Port':'サーバーポート',
		'_Authenticate_Client_Certificates':'クライアント証明認証',
		'_See':'表示',
		'_Trusted_CAs':'信頼された CA',
		'_Server_Certificate':'サーバー証明',
		'_My_Certificates':'自己証明',
		'_Redirect_HTTP_to_HTTPS':'HTTP から HTTPS への変更',
		'_Admin_Service_Control':'管理サービスコントロール',
		'_Zone':'ゾーン',
		'_Address':'アドレス',
		'_Action':'アクション',
		'_User_Service_Control':'ユーザーサービスコントロール',
		'_HTTP':'HTTP',	
		'_Authentication':'認証',
		'_Client_Authentication_Method':'クライアント認証方法'
		}];

/* httpsedit.html */
var _httpsedit=[{
		'_Admin_Service_Control':'管理サービスコントロール',
		'_Address_Object':'アドレスオブジェクト',
		'_Zone':'ゾーン',
		'_Action':'アクション'
		}];

/* httpsuseredit.html */
var _httpsuseredit=[{
		'_User_Service_Control':'ユーザーサービスコントロール',
		'_Address_Object':'アドレスオブジェクト',
		'_Zone':'ゾーン',
		'_Action':'アクション'
		}];

/* wwwedit.html */
var _wwwedit=[{
		'_Admin_Service_Control':'管理サービスコントロール',
		'_Address_Object':'アドレスオブジェクト',
		'_Zone':'ゾーン',
		'_Action':'アクション'
		}];

/* wwwuseredit.html */
var _wwwuseredit=[{
		'_User_Service_Control':'ユーザーサービスコントロール',
		'_Address_Object':'アドレスオブジェクト',
		'_Zone':'ゾーン',
		'_Action':'アクション'
		}];

/*----- System > SSH -----*/

/* ssh.html */
var _ssh=[{
		'_SSH':'SSH',
		'_Enable':'有効',
		'_Version_1':'バージョン1',
		'_Server_Port':'サーバーポート',
		'_Server_Certificate':'サーバー証明',
		'_See':'表示',
		'_My_Certificates':'自己証明',
		'_Service_Control':'サービスコントロール',
		'_Zone':'ゾーン',
		'_Address':'アドレス',
		'_Action':'アクション'	
		}];

/* sshedit.html */
var _sshedit=[{
		'_Service_Control':'サービスコントロール',
		'_Address_Object':'アドレスオブジェクト',
		'_Zone':'ゾーン',
		'_Action':'アクション'
		}];

/*----- System > Telnet -----*/

/* telnet.html */
var _telnet=[{
		'_TELNET':'TELNET',
		'_Enable':'有効',
		'_Server_Port':'サーバーポート',
		'_Service_Control':'サービスコントロール',
		'_Zone':'ゾーン',
		'_Address':'アドレス',
		'_Action':'アクション'
		}];

/* telnetedit.html */
var _telnetedit=[{
		'_Service_Control':'サービスコントロール',
		'_Address_Object':'アドレスオブジェクト',
		'_Zone':'ゾーン',
		'_Action':'アクション'
		}];
		
/*----- System > FTP -----*/

/* ftp.html */
var _ftp=[{
		'_FTP':'FTP',
		'_Enable':'有効',
		'_TLS_required':'TLS 要求',
		'_Server_Port':'サーバーポート',
		'_Server_Certificate':'サーバー証明',
		'_See':'表示',
		'_My_Certificates':'自己証明',
		'_Service_Control':'サービスコントロール',
		'_Zone':'ゾーン',
		'_Address':'アドレス',
		'_Action':'アクション'
		}];

/* ftpedit.html */
var _ftpedit=[{
		'_Service_Control':'サービスコントロール',
		'_Address_Object':'アドレスオブジェクト',
		'_Zone':'ゾーン',
		'_Action':'アクション'
		}];

/*----- System > SNMP-----*/

/* snmp.html */
var _snmp=[{
		'_SNMP_Configuration':'SNMP 設定',
		'_Enable':'有効',
		'_Server_Port':'サーバーポート',
		'_Get_Community':'コミュニティ取得',
		'_Set_Community':'コミュニティ設定',
		'_Trap':' トラップ:',
		'_Community':'コミュニティ',
		'_Destination':'送信先',
		'_Optional':'(オプション)',
		'_Service_Control':'サービスコントロール',
		'_Address':'アドレス',
		'_Zone':'ゾーン',
		'_Action':'アクション'
		}];

/* snmpedit.html */
var _snmpedit=[{
		'_Service_Control':'サービスコントロール',
		'_Address_Object':'アドレスオブジェクト',
		'_Zone':'ゾーン',
		'_Action':'アクション'
		}];

/*----- System > Dial-in Mgmt.-----*/

/* dialin.html */
var _dialin=[{
		'_Dial_in_Server_Properties':'ダイヤルインサーバーのプロパティ',
		'_Enable':'有効',
		'_Description':'説明',
		'_Optional':'(オプション)',
		'_Mute':'ミュート',
		'_Answer_Rings':'呼出応答',
		'_Rings':'(呼出)',
		'_Port_Speed':'ポート速度',
		'_Initial_String':'初期文字列'
		}];
	
/*----- System > Vantage CNM -----*/
	
/* cnm.html */
var _cnm=[{
		'_Vantage_CNM':'Vantage CNM',
		'_Enable':'有効',
		'_Server_IP_Address_FQDN':'サーバー IP アドレス/FQDN',
		'_Transfer_Protocol':'転送プロトコル',
		'_Device_Management_IP':'デバイス管理 IP',
		'_Custom_IP':'カスタム IP',
		'_Keepalive_Interval':'キープアライブ間隔',
		'_seconds':'秒',
		'_Periodic_Inform':'定期通知',
		'_Interval':'間隔',
		'_HTTPS_Authentication':'HTTPS 認証',
		'_Enable_Vantage':'Vantage  有効',
		'_Vantage_Certificate':'Vantage 証明',
		'_See':'表示',
		'_Trusted_CAs':'信頼された CA'
		}];

/*----- System > Language -----*/

/* language.html */
var _language = [{
		'_Configuration':'設定',
		'_Language_Setting':'言語設定'
		}];

/*----- Maintenance > File Manager -----*/

/* configfile.html */
var _configfile=[{
		'_Configuration_Files':'設定ファイル',
		'_Select_the_file':'ファイル選択',
		'_File_Name':'ファイル名',
		'_Size':'サイズ',
		'_Modify':'前回の変更',
		'_Upload_Configuration_File':'設定ファイルアップロード',
		'_To_upload_a_configuration':'設定ファイルをアップロードするには、ファイル(.conf)の場所を参照し、[アップロード] をクリックします',
		'_File_Path':'ファイルパス'
		}];

/* editfile.html */
var _editfile=[{
		'_Copy_File':'ファイルコピー',
		'_Rename':'名前変更', 
		'_Source_file':'ソースファイル',
		'_Target_file':'ターゲットファイル'
		}];
		
/* fwfile.html */
var _fwfile=[{
		'_Boot_Module':'起動モジュール',
		'_Current_Version':'バージョン',
		'_Released_Date':'発行日',
		'_To_upload_firmware_package':'ファームウェアパッケージをアップロードするには、ファイルの場所を参照し、[アップロード] をクリックします',
		'_File_Path':'ファイルパス',
		'_FW_Version':'バージョン',
		'_FW_Upload':'ファイルアップロード'
		}];

/* shellfile.html */
var _shellfile=[{
		'_Shell_Scripts':'シェルスクリプト',
		'_Select_the_file':'ファイル選択',
		'_File_Name':'ファイル名',
		'_Size':'サイズ',
		'_Modify':'前回の変更',
		'_Upload_Shell_Script':'シェルスクリプトアップロード',
		'_To_upload_a_shell_script':'シェルスクリプトアップロードするには、ファイル(.zysh)の場所を参照し、[アップロード] をクリックします.',
		'_File_Path':'ファイルパス'
		}];

/* edscriptfile.html */
var _edscriptfile=[{
		'_Copy_File':'ファイルコピー', 
		'_Rename':'名前変更',
		'_Source_file':'ソースファイル',
		'_Target_file':'ターゲットファイル'
		}];

/*----- Maintenance > Log -----*/

/* viewlogs.html */
var _viewlogs=[{
		'_Logs':'ログ',
		'_Display':'表示',
		'_Priority':'優先度',
		'_Source_Address':'送信元アドレス',
		'_Destination_Address':'送信先アドレス',
		'_Service':'サービス',
		'_Keyword':'キーワード',
		'_Total_logging_entries':'全ログ数:',
		'_entries_per_page':'1ページあたりの登録',
		'_Page':'ページ',
		'_Time':'時刻',
		'_Category':'カテゴリ',
		'_Message':'メッセージ',
		'_Source':'送信元',
		'_Destination':'送信先',
		'_Note':'注意'
		}];

/* errCode.html */
var _errCode=[{
		'_Certificate':'証明パス確認失敗の理由コード表',
		'_Code':'コード',
		'_Description':'説明'
		}];
		
/* logsetting.html */
var _logsetting=[{
		'_Log_Setting':'ログ設定',
		'_Name':'名前',
		'_Log_Format':'ログ形式',
		'_Summary':'サマリー',
		'_Modify':'変更'
		}];

/* intermail.html */
var _intermail=[{
		'_E_mail_Server_1':'メールサーバー1',
		'_Active':'アクティブ',
		'_Mail_Server':'メールサーバー',
		'_Outgoing':'(送信 SMTP サーバー名または IP アドレス)',
		'_Mail_Subject':'メール件名',
		'_Send_From':'送信者',
		'_E_Mail_Address':'(メールアドレス)',
		'_Send_Log_to':'ログの送信先',
		'_Send_Alerts_to':'警告の送信先',
		'_Sending_Log':'ログ送信中',
		'_Day_for_Sending_Log':'ログ送信日',
		'_Time_for_Sending_Log':'ログ送信時間',
		'_Hour':'(時間)',
		'_Minute':'(分)',
		'_SMTP_Authentication':'SMTP 認証',
		'_User_Name':'ユーザー名',
		'_Password':'パスワード',
		'_E_mail_Server_2':'メールサーバー2',
		'_Active_Log_and_Alert':'アクティブログと警告',
		'_Log_Category':'ログカテゴリ',
		'_System_Log':'システムログ',		
		'_Log_Consolidation':'ログ統合',
		'_Log_Consolidation_Interval':'ログ統合間隔(秒)'
		}];

/* remsvr.html */
var _remsvr=[{
		'_Log':'リモートサーバーのログ設定 ',
		'_Active':'アクティブ',
		'_Log_Format':'ログ形式',
		'_ZyXEL_VRPT':'ZyXEL VRPT',
		'_Server_Address':'サーバーアドレス',
		'_Server':'(サーバー名または IP アドレス)',
		'_Log_Facility':'ログについて',
		'_Active_Log':'アクティブログ',
		'_Log_Category':'ログカテゴリ',
		'_Selection':'選択'
		}];

/* logsummary.html */
var _logsummary=[{
		'_Active_Log_Summary':'アクティブログのサマリー',
		'_Log_Category':'ログカテゴリ',
		'_System_log':'システムログ',
		'_E_mail_Server_1':'メールサーバー1',
		'_E_mail_Server_2':'メールサーバー2',
		'_Remote_Server_1':'リモートサーバー1',
		'_Remote_Server_2':'リモートサーバー2',
		'_Remote_Server_3':'リモートサーバー3',
		'_Remote_Server_4':'リモートサーバー4',
		'_E_mail':'メール',
		'_Syslog':'システムログ'
		}];

/*----- Maintenance > Traffic -----*/

/* report.html */
var _report=[{
		'_Data_Collection':'データ収集',
		'_Collect_Statistics':'統計収集',
		'_Reports':'トラフィック',
		'_Interface':'インターフェース',
		'_Report_Type':'トラフィックタイプ',
		'_IP_Address_User':'IP アドレス/ユーザー',
		'_Direction':'方向',
		'_Amount':'計',
		'_Service_Port':'サービスポート',
		'_Web_Site':'Web サイト',
		'_Hits':'ヒット'
		}];

/* session.html */
var _session=[{
		'_Session':'セッション',
		'_View':'ビュー',
		'_User':'ユーザー',
		'_Protocol':'プロトコル',
		'_Source':'送信元',
		'_Destination':'送信先',
		'_Rx':'受信',
		'_Tx':'送信',
		'_Duration':'経過時間',
		'_Service':'サービス',
		'_Source_Address':'送信元アドレス',
		'_Destination_Address':'送信先アドレス',
		'_Active_Sessions':'アクティブセッション',
		'_sessions_per_page':'1ページあたりのセッション',
		'_Page':'ページ'
		}];
		
/* rptIDP.html */
var _rptIDP=[{
		'_Setup':'設定',
		'_Collect_Statistics':'統計収集',
		'_Summary':'サマリー',
		'_Total_Session_Scanned':'スキャンされたセッション数',
		'_Total_Packet_Dropped':'ドロップされたパケット数',
		'_Total_Packet_Reset':'リセットされたパケット数',
		'_Statistics':'統計',
		'_Top_Entry_By':'トップ登録ルート',
		'_Signature_Name':'シグネチャ',
		'_Type':'タイプ',
		'_Severity':'深刻度',
		'_Occurrence':'発生回数',
		'_Total':'合計',
		'_Source_IP':'送信元 IP',
		'_Destination_IP':'送信先 IP'
		}];

/* rptAV.html */
var _rptAV=[{
		'_Setup':'設定',
		'_Collect_Statistics':'統計収集',
		'_Summary':'サマリー',
		'_Total_Files_Scanned':'スキャンされたファイル数',
		'_Infected_Files_Detected':'感染ファイル検出',
		'_Statistics':'統計',
		'_Top_Entry_By':'トップ登録ルート',
		'_Virus_Name':'ウィルス名',
		'_Occurrence':'発生回数',
		'_Total':'合計',
		'_Source_IP':'送信元 IP',
		'_Destination_IP':'送信先 IP'
		}];
		
/*----- Maintenance > Diagnostics -----*/

/* debugCol.html */
var _debugCol=[{
		'_Diagnostic_Information_Collector':'診断情報収集',
		'_Filename':'ファイル名',
		'_Last_modified':'前回の変更',
		'_Size':'サイズ'
		}];

/* col.html */
var _col=[{
		'_Diagnostic_Information_Collecting_Status':'診断情報収集ステータス',
		'_Please_wait_collecting':'収集していますしばらくお待ちください...',
		'_Done_the_collection':'収集完了'
		}];

/*----- Maintenance > Reboot -----*/

/* reboot.html */
var _reboot=[{
		'_Reboot':'再起動',
		'_Click':'[再起動] ボタンをクリックし、デバイスを再起動しますログイン画面が表示されるまでお待ちください.ログイン画面が表示されない場合、Web ブラウザにデバイスの IP アドレスを入力してください.'
		}];

//access.html file
var _access=[{
		'_andrewc':'ログインできました',
		'_Clicking':'ログアウトボタンをクリックすると、セッションを終了します.ログインセッションの最大時間は20分間です.セキュリティ上の理由から、2時間40分後に再度ログインする必要があります.',  
		'_User':'ユーザー定義のリースタイム(最大20分)',
		'_Remaining1':'リースタイムまでの残り時間(mm:ss):',
		'_Remaining2':'認証までの残り時間 time (hh:mm):時間(hh:mm): '
		}];

//antispamedit.html file
var _antispamedit=[{
		'_Configuration':'設定',
		'_From_ZONE':'ゾーンから',
		'_To_ZONE':'ゾーンへ',
		'_SPAM_Score':'スパムスコア',
		'_SPAM_Log':'スパムログ',
		'_Protocol':'プロトコル',
		'_Action':'アクション',
		'_Mark_on_Subject':'サブジェクトマーク',
		'_Enable':'有効'
		}];

//asrbl.html file
var _asrbl=[{
		'_Summary':'サマリー',
		'_White_Black_List':'ホワイト/ブラックリスト',
		'_RBL_ORDBL':'RBL/ORDBL',
		'_Update':'更新',
		'_Configuration':'設定',
		'_Enable_RBL_ORDBL':'RBL/ORDBL  有効',
		'_Server_Query_Postfix':'サーバークエリポストフィックス',
		'_Maximum':'メール1件で利用できる RBL/ORDBL IP',
		'_Maximum_Query_IPs':'最大クエリ IP'
		}];

//asrbledit.html file
var _asrbledit=[{
		'_RBL_ORDBL_Server':'RBL/ORDBL サーバー',
		'_Enable':'有効',
		'_Server_Query_Postfix':'サーバークエリポストフィックス'
		}];

//assummary.html file
var _assummary=[{
		'_Summary':'サマリー',
		'_White_Black_List':'ホワイト/ブラックリスト',
		'_RBL_ORDBL':'RBL/ORDBL',
		'_Update':'更新',
		'_Configuration':'設定',
		'_Enable_Anti_Spam':'アンチスパム  有効',
		'_Notify':'SMTP 送信者通知 (DROP メール)',
		'_Incoming_ZONE':'受信ゾーン',
		'_Outgoing_ZONE':'送信ゾーン',
		'_Inspect_Mail_Protocol':'メールプロトコルの検査',
		'_Registration_Status':'登録ステータス',
		'_Please_go_to_the':'移動',
		'_Registration':'登録',
		'_page':'ページ.',
		'_Registration_Status':'登録ステータス:',
		'_Registration_Type':'登録タイプ:'
		}];

//asupspam.html file
var _asupspam=[{
		'_Summary':'サマリー',
		'_White_Black_List':'ホワイト/ブラックリスト',
		'_RBL_ORDBL':'RBL/ORDBL',
		'_Update':'更新',
		'_Signature_Information':'シグネチャ情報',
		'_Current_Version':'バージョン:',
		'_Remote_Update':'リモート更新',
		'_Synchronize':'オンライン更新サーバーで、アンチスパムのシグネチャパッケージを最新バージョンに更新してください (myZyXEL.com の有効が必要です)',
		'_Auto_Update':'繰り返し',
		'_Hourly':'毎時間',
		'_Daily':'毎日',
		'_Hour':'(時間)',
		'_Weekly':'毎週',
		'_Day':'(日)',
		'_Sunday':'日曜',
		'_Monday':'月曜',
		'_Tuesday':'火曜',
		'_Wednesday':'水曜',
		'_Thursday':'木曜',
		'_Friday':'金曜',
		'_Saturday':'土曜'
		}];

//aswblist.html file
var _aswblist=[{
		'_Summary':'サマリー',
		'_White_Black_List':'ホワイト/ブラックリスト',
		'_RBL_ORDBL':'RBL/ORDBL',
		'_Update':'更新',
		'_White_List':'ホワイトリスト',
		'_Enable_White_List':'ホワイトリスト 有効',
		'_Type':'タイプ',
		'_Content':'コンテンツ',
		'_Black_List':'ブラックリスト',
		'_Enable_Black_List':'ブラックリスト 有効'
		}];

//aswblistedit.html file
var _aswblistedit=[{
		'_Rule_Edit':'ルール編集',
		'_Enable':'有効',
		'_List':'リスト',
		'_Type':'タイプ',
		'_E_Mail_Address':'メールアドレス',
		'_IP_Address':'IP アドレス',
		'_Network_Mask':'ネットワークマスク',
		'_Mail_Header':'メールヘッダー',
		'_Value':'値'
		}];

//certcert.html file
var _certcert=[{
		'_Name':'名前',
		'_Certification_Path':'証明パス',
		'_Certificate_Information':'証明情報',
		'_Type':'タイプ',
		'_Version':'バージョン',
		'_Serial_Number':'シリアルナンバー',
		'_Subject':'件名',
		'_Issuer':'発行元',
		'_Signature_Algorithm':'シグネチャアルゴリズム',
		'_Valid_From':'発効日',
		'_Valid_To':'有効期限',
		'_Key_Algorithm':'キーアルゴリズム',
		'_MD5_Fingerprint':'MD5 Fingerprint',
		'_SHA1_Fingerprint':'SHA1 Fingerprint',
		'_Certificate':'PEM(Base-64) エンコード形式の証明'
		}];

//certreq.html file
var _certreq=[{
		'_Name':'名前',
		'_Certificate_Information':'証明情報',
		'_Type':'タイプ',
		'_Serial_Number':'シリアルナンバー',
		'_Subject':'件名',
		'_Issuer':'発行元',
		'_Signature_Algorithm':'シグネチャアルゴリズム',
		'_Valid_From':'発効日',
		'_Valid_To':'有効期限',
		'_Key_Algorithm':'キーアルゴリズム',
		'_Subject_Alternative_Name':'代替名',
		'_Key_Usage':'キーの用途',
		'_MD5_Fingerprint':'MD5 Fingerprint',
		'_SHA1_Fingerprint':'SHA1 Fingerprint',
		'_Certificate':'PEM(Base-64) エンコード形式の証明'
		}];

/* chgpw.html */
var _chgpw=[{
		'_Update_Admin_Info':'アップロード管理情報',
		'_As':'セキュリティ上の理由から、管理者パスワードを変更することを強く推奨します',
		'_New_Password':'新しいパスワード:',
		'_Retype_to_Confirm':'再入力して確認:',
		'_max':'(31文字の英数字、記号で設定しますスペースは使用できません)'
		}];
		
/* keyin.html */
var _1keyin=[{'_Please':'ファイル名を入力してください'}];

/* logout.html */
var _logout=[{
		'_Thank':'ZyXEL をご利用いただき、ありがとうございます.',
		'_Good_bye':'Good-bye!'
		}];

/* newvpng.html */
var _newvpng=[{
		'_VPN_Gateway':'VPN ゲートウェイ',
		'_VPN_Gateway_Name':'VPN ゲートウェイ名',
		'_IKE_Phase_1':'IKE フェーズ1',
		'_Negotiation_Mode':'ネゴシエーションモード',
		'_Main':'メイン',
		'_Aggressive':'アグレッシブ',
		'_Proposal':'提案',
		'_Encryption':'暗号化',
		'_Authentication':'認証',
		'_Key_Group':'キーグループ',
		'_SA_Life_Time':'SA ライフタイム(秒)',
		'_NAT_Traversal':'NAT トラバーサル',
		'_Dead_Peer_Detection':'(DPD) Dead Peer Detection',
		'_Property':'プロパティ',
		'_My_Address':'マイアドレス',
		'_Interface':'インターフェース',
		'_Domain_Name':'ドメイン名',
		'_Secure_Gateway_Address':'セキュリティゲートウェイアドレス',
		'_Authentication_Method':'認証方法',
		'_Pre_Shared_Key':'プリシェアードキー',
		'_Certificate':'証明',
		'_See':'表示',
		'_My_Certificates':'自己証明',
		'_Local_ID_Type':'ローカル ID タイプ',
		'_Content':'コンテンツ',
		'_Peer_ID_Type':'ピア ID タイプ',
		'_Extended_Authentication':'拡張認証',
		'_Enable_Extended_Authentication':'拡張認証 有効 ',
		'_Server_Mode':'サーバーモード',
		'_Client_Mode':'クライアントモード',
		'_User_Name':'ユーザー名',
		'_Password':'パスワード'
		}];

/* prdframe.html */
var _prdframe=[{
		'_Incoming':'受信',			
		'_Member_List':'メンバーリスト',
		'_Please':'メンバーを1人選択してください'
		}];


/* wizard.html */
var _wizard=[{
		'_Welcome':'ZyWALL ウィザードセットアップへようこそ',
		'_helps1':'(簡単な設定で ',
		'_helps1_1':' インターネット接続を安全に保ちます)',
		'_helps2':' 接続の安全を保ちます)',
		'_Installation_Setup_One_ISP':'インストールセットアップ(ISP 1つ)',
		'_Installation_Setup_Two_ISP':'インストールセットアップ(ISP 2つ)',
		'_VPN_Setup':'VPN セットアップ'
		}];

//wizisp1.html file
var _wizisp1=[{
		'_Installation_Setup_Wizard':'インストールセットアップウィザード',
		'_Internet_Access':'インターネットアクセス',
		'_ISP_Parameters':'ISP パラメーター',
		'_Encapsulation':'カプセル化:',
		'_WAN':'WAN IP アドレス割当',
		'_WAN_Interface':'WAN インターフェース:',
		'_Zone':'ゾーン:',
		'_STEP':'ステップ',
		'_IP_Address_Assignment':'IP アドレスの割当:',
		'_Second_WAN_Interface':'2nd WAN インターフェース',
		'_First_WAN_Interface':'1st WAN インターフェース'
		}];

//wizisp2.html file
var _wizisp2=[{
		'_Installation_Setup_Wizard':'インストールセットアップウィザード',
		'_Internet_Access':'インターネットアクセス',
		'_ISP_Parameters':'ISP パラメーター',
		'_Encapsulation':'カプセル化:',
		'_WAN':'WAN IP アドレス割当',
		'_WAN_Interface':'WAN インターフェース:',
		'_Zone':'ゾーン:',
		'_IP_Address_Assignment':'IP アドレスの割当:',
		'_Base_Interface':'基本インターフェース',
		'_Service_Name':'サービス名',
		'_Optional':'(オプション)',
		'_User_Name':'ユーザー名',
		'_Password':'パスワード',
		'_Retype_to_Confirm':'再入力して確認',
		'_Nailed_Up':'常時接続', 
		'_Idle_Timeout':'アイドルタイムアウト',
		'_Seconds':'(秒)',
		'_PPTP_Configuration':'PPTP 設定',
		'_Base_IP_Address':'基本 IP アドレス',
		'_IP_Subnet_Mask':'IP サブネットマスク',
		'_Server_IP':'サーバー IP',
		'_IP_Address':'(IP アドレス)',
		'_Connection_ID':'接続 ID',
		'_WAN_IP_Address_Assignments':'WAN IP アドレス割当',
		'_WAN_Interface':'WAN インターフェース',
		'_Zone':'ゾーン',
		'_IP_Address':'IP アドレス', 
		'_Auto':'自動',
		'_IP_Subnet_Mask':'IP サブネットマスク',
		'_Gateway_IP_Address':'ゲートウェイ IP アドレス',
		'_First_DNS_Server':'1st DNS サーバー',
		'_Second_DNS_Server':'2nd DNS サーバー',
		'_Second_WAN_Interface':'2nd WAN インターフェース',
		'_First_WAN_Interface':'1st WAN インターフェース',
		'_STEP':'ステップ'
		}];

//wizisp3.html file
var _wizisp3=[{
		'_Installation_Setup_Wizard':'インストールセットアップウィザード',
		'_Internet_Access':'インターネットアクセス',
		'_ISP_Parameters':'ISP パラメーター',
		'_You_can':'ご利用のネットワークに合わせてイーサネット、PPPoE、PPTP を選択することができます.',
		'_Encapsulation':'カプセル化:',
		'_WAN_IP_Address_Assignments':'WAN IP アドレス割当',
		'_The_ZyWall':'',
		'_The_ZyWall_1':' ポートの実行時間を設定できます.たとえば、前面パネルの左側にあるポート4を DMZ1 から LAN2 に変更することができます.ポート名も実行時間を設定できます(cute カード)',
		'_WAN_Interface':'WAN インターフェース:',
		'_IP_Address_Assignment':'IP アドレスの割当:',
		'_error':'エラー'
		}];

//wizisp4.html file
var _wizisp4=[{
		'_Installation_Setup_Wizard':'インストールセットアップウィザード',
		'_Internet_Detection':'インターネット検出',
		'_Please_wait_a_moment':'しばらくお待ちください... ',
		'_STEP':'ステップ',
		'_Check_User_Name':'ユーザー名チェック...',
		'_Auto_Configure_Device':'自動設定デバイス'
		}];

//wizisp5.html file
var _wizisp5=[{
		'_Installation_Setup_Wizard':'インストールセットアップウィザード',
		'_Internet_Access':'インターネットアクセス',
		'_Congratulations':'お疲れ様でした インターネットアクセスウィザードが完了しました',
		'_Summary':'インターネットアクセス設定のサマリー: ',
		'_You_can':'ZyWALL を <a href="http://www.myZyXEL.com" target=_top><span class="style">myZyXEL.com</span></a> で登録し、コンテンツファイルの "トライアル版" と ZyWALL の IDP サービスを有効にすることができます.',
		'_Click':'[次へ] をクリックすると、これらのサービスを無料でご利用できます',
		'_Setting':'設定:',
		'_First_Setting':'設定1:',
		'_Encapsulation':'カプセル化',
		'_Service_Name':'サービス名',
		'_User_Name':'ユーザー名',
		'_Nailed_Up':'常時接続',
		'_Idle_Timeout':'アイドルタイムアウト',
		'_Server_IP':'サーバー IP',
		'_User_Name':'ユーザー名',
		'_Connection_ID':'接続 ID',
		'_WAN_Interface':'WAN インターフェース',
		'_Zone':'ゾーン',
		'_First_WAN_Interface':'1st WAN インターフェース',
		'_IP_Assignment':'IP 割当',
		'_IP_Address':'IP アドレス',
		'_IP_Subnet_Mask':'IP サブネットマスク',
		'_Gateway_IP_Address':'ゲートウェイ IP アドレス',
		'_First_DNS_Server':'1st DNS サーバー',
		'_Second_DNS_Server':'2nd DNS サーバー',
		'_Second_Setting':'設定2:',
		'_Second_WAN_Interface':'2nd WAN インターフェース',
		'_STEP':'ステップ'
		}];
		
/* wizregist.html */
var _wizregist=[{
		'_Installation_Setup_Wizard':'インストールセットアップウィザード',
		'_Device_Registration':'デバイス登録',
		'_This_device':'<Font color="#FF0000">このデバイスは myZyXEL.com. に登録されていません 以下の情報を入力し、デバイスを<b>登録</b>してください</font> <font color="#FFFFFF">すでに myZyXEL.com アカウントをお持ちで、ユーザー名またはパスワードをお忘れの場合は、 www.myZyXEL.com へアクセスしてください.</font>',
		'_new':'新規 myZyXEL.com アカウント',
		'_existing':'既存の myZyXEL.com アカウント',
		'_User_Name':'ユーザー名',
		'_you_can':'クリックをしてユーザー名がすでに使用されているかをチェックすることができます ',
		'_Password':'パスワード',
		'_Confirm_Password':'パスワードの確認',
		'_E_Mail_Address':'メールアドレス',
		'_Country_Code':'国コード',
		'_Trial_Service_Activation':'トライアルを有効にする',
		'_IDP':'IDP/アプリケーションパトロール',
		'_Anti_Virus':'アンチウィルス',
		'_Content_Filter':'コンテンツフィルター',
		'_STEP':'ステップ'
		}];

//wizvpn1.html file
var _wizvpn1=[{
		'_VPN_Setup_Wizard':'VPN セットアップウィザード',
		'_Please':'設定したいVPN ポリシーのタイプを選択してください',
		'_Express':'エクスプレス',
		'_Advanced':'詳細',
		'_STEP':'ステップ'
		}];

//wizvpn2.html file
var _wizvpn2=[{
		'_VPN_Setup_Wizard':'VPN セットアップウィザード',
		'_VPN_Access':'VPN アクセス',
		'_Remote_Gateway':'リモートゲートウェイ',
		'_Name':'名前',
		'_Secure_Gateway':'セキュリティゲートウェイ',
		'_IP_DNS':'(IP/DNS)',
		'_Pre_Shared_Key':'プリシェアードキー',
		'_STEP':'ステップ'
		}];

//wizvpn3.html file
var _wizvpn3=[{
		'_VPN_Setup_Wizard':'VPN セットアップウィザード',
		'_VPN_Access':'VPN アクセス',
		'_Policy_Setting':'ポリシー設定',
		'_Local_Policy':'ローカルポリシー(IP/マスク)',
		'_Remote_Policy':'リモートポリシー(IP/マスク)',
		'_STEP':'ステップ'
		}];

//wizvpn4.html file
var _wizvpn4=[{
		'_VPN_Setup_Wizard':'VPN セットアップウィザード',
		'_VPN_Access':'VPN アクセス',
		'_Summary':'サマリー',
		'_Name':'名前',
		'_Secure_Gateway':'セキュリティゲートウェイ',
		'_Pre_Shared_Key':'プリシェアードキー',
		'_Local_Policy':'ローカルポリシー',
		'_Remote_Policy':'リモートポリシー',
		'_Configuration_for_Remote_Gateway':'リモートゲートウェイの設定',
		'_Uncomment':'CLI を以下の zysh スクリプトで使用する場合、コメントを削除します',
		'_configure_terminal':'端子設定',
		'_Click':'[保存] ボタンをクリックし、VPN 設定を ZyWALL に書き込みます',
		'_STEP':'ステップ'
		}];

//wizvpn5.html file
var _wizvpn5=[{
		'_VPN_Setup_Wizard':'VPN セットアップウィザード',
		'_VPN_Access':'VPN アクセス',
		'_Congratulations':'お疲れ様でした VPN アクセスウィザードが完了しました',
		'_Summary':'VPN アクセス設定のサマリー:',
		'_Now':'このデバイスを初めてインストールする場合、このリンク<a href="http://myZyXEL.com" target=_top><span class="style">myZyXEL.com</span></a> をクリックしてこのデバイスを登録し、高度なセキュリティ機能のトライアル版を起動させることができます (登録にはインターネット接続が必要です)',
		'_STEP':'ステップ',
		'_Encapsulation':'カプセル化:  ',
		'_Service_Name':'サービス名:  ',
		'_User_Name':'ユーザー名:  ',
		'_Idle_Timeout':'アイドルタイムアウト:  ',
		'_Server_IP':'サーバー IP:  ',		
		'_Connection_ID':'接続 ID :  ',
		'_WAN_Interface':'WAN インターフェース:  ',
		'_First_WAN_Interface':'1st WAN インターフェース:  ',
		'_IP_Assignment_Auto':'Auto:IP 割当: 自動 ',
		'_IP_Address':'IP アドレス:    ',
		'_IP_Subnet_Mask':'IP サブネットマスク:  ',
		'_Gateway_IP_Address':'ゲートウェイ IP アドレス:  ',
		'_IP_Assignment_Static':'ゲートウェイ IP アドレス:  ',
		'_Second_WAN_Interface':'2nd WAN インターフェース:  '
		}];

//wizvpna2.html file
var _wizvpna2=[{
		'_VPN_Setup_Wizard':'VPN セットアップウィザード',
		'_VPN_Advanced_Access':'VPN アドバンスアクセス',
		'_Remote_Gateway':'リモートゲートウェイ',
		'_Name':'名前',
		'_IP_DNS':'(IP/DNS)',
		'_Secure_Gateway':'セキュリティゲートウェイ',
		'_My_Address':'マイアドレス (インターフェース)',
		'_Authentication_Method':'認証方法',
		'_Pre_Shared_Key':'プリシェアードキー',
		'_Certificate':'証明',
		'_STEP':'ステップ'
		}];

//wizvpna3.html file
var _wizvpna3=[{
		'_VPN_Setup_Wizard':'VPN セットアップウィザード',
		'_VPN_Advanced_Access':'VPN アドバンスアクセス',
		'_Phase_1_Setting':'フェーズ1設定',
		'_Negotiation_Mode':'ネゴシエーションモード',
		'_Encryption_Algorithm':'暗号化アルゴリズム',
		'_Authentication_Algorithm':'認証アルゴリズム',
		'_Key_Group':'キーグループ',
		'_SA_Life_Time':'SA ライフタイム(秒)',
		'_NAT_Traversal':'NAT トラバーサル',
		'_Dead_Peer_Detection':'(DPD) Dead Peer Detection',
		'_STEP':'ステップ'
		}];

//wizvpna4.html file
var _wizvpna4=[{
		'_VPN_Setup_Wizard':'VPN セットアップウィザード',
		'_VPN_Advanced_Access':'VPN アドバンスアクセス',
		'_Phase_2_Setting':'フェーズ2設定',
		'_Active_Protocol':'アクティブプロトコル',
		'_Encapsulation':'カプセル化',
		'_Encryption_Algorithm':'暗号化アルゴリズム',
		'_Authentication_Algorithm':'認証アルゴリズム',
		'_SA_Life_Time':'SA ライフタイム(秒)',
		'_Perfect_Forward_Secrecy':'PFS (Perfect Forward Secrecy)',
		'_Policy_Setting':'ポリシー設定',
		'_Local_Policy':'ローカルポリシー(IP/マスク)',
		'_Incoming_Interface':'受信インターフェース',
		'_Remote_Policy':'リモートポリシー(IP/マスク)',
		'_Property':'プロパティ',
		'_Nailed_Up':'常時接続',
		'_STEP':'ステップ'
		}];

//wizvpna5.html file
var _wizvpna5=[{
		'_VPN_Setup_Wizard':'VPN セットアップウィザード',
		'_VPN_Access':'VPN アクセス',
		'_Summary':'サマリー',
		'_Name':'名前',
		'_Secure_Gateway':'セキュリティゲートウェイ',
		'_Pre_Shared_Key':'プリシェアードキー',
		'_Local_Policy':'ローカルポリシー',
		'_Remote_Policy':'リモートポリシー',
		'_Remote_Gateway_CLI':'リモートゲートウェイ CLI',
		'_Uncomment':'CLI を以下の zysh スクリプトで使用する場合、コメントを削除します',
		'_configure_terminal':'端子設定',
		'_Click':'[保存] ボタンをクリックし、VPN 設定を ZyWALL に書き込みます',
		'_STEP':'ステップ'
		}];

//wizvpna6.html file
var _wizvpna6=[{
		'_VPN_Setup_Wizard':'VPN セットアップウィザード',
		'_VPN_Access':'VPN アクセス',
		'_Congratulations':'お疲れ様でした VPN アクセスウィザードが完了しました',
		'_Summary':'VPN アクセス設定のサマリー:',
		'_Now':'このデバイスを初めてインストールする場合、このリンク<a href="http://myZyXEL.com" target=_top><span class="style">myZyXEL.com</span></a> をクリックしてこのデバイスを登録し、高度なセキュリティ機能のトライアル版を起動させることができます (登録にはインターネット接続が必要です)  ',
		'_STEP':'ステップ',
		'_Name':'名前',
		'_Secure_Gateway':'セキュリティゲートウェイ',
		'_Pre_Shared_Key':'プリシェアードキー',
		'_Local_Policy':'ローカルポリシー',
		'_Remote_Policy':'リモートポリシー',
		'_Secure_Gateway':'セキュリティゲートウェイ',
		'_My_Address_interface':'マイアドレス (インターフェース)',
		'_Pre_Shared_Key':'プリシェアードキー',
		'_Certificate':'証明',
		'_Phase_1':'フェーズ1',
		'_Negotiation_Mode':'ネゴシエーションモード',
		'_main':'メイン',
		'_Negotiation_Mode':'ネゴシエーションモード',
		'_aggressive':'主動',
		'_Encryption_Algorithm':'暗号化アルゴリズム',
		'_Authentication_Algorithm':'認証アルゴリズム',
		'_Key_Group':'キーグループ',
		'_SA_Life_Time_Seconds':'SA ライフタイム(秒)',
		'_NAT_Traversal':'NAT トラバーサル',
		'_Dead_Peer_Detection_DPD':'(DPD) Dead Peer Detection',
		'_Phase_2':'フェーズ2',
		'_Active_Protocol':'アクティブプロトコル',
		'_ESP':'ESP',
		'_AH':'AH',
		'_Encapsulation':'カプセル化',
		'_Tunnel':'トンネル',
		'_Transport':'転送',
		'_Encryption_Algorithm':'暗号化アルゴリズム',
		'_SA_Life_Time_Seconds':'SA ライフタイム(秒)',
		'_Perfect_Forward_Secrecy':'PFS (Perfect Forward Secrecy)',
		'_Policy':'ポリシー',
		'_Local_Policy':'ローカルポリシー',
		'_Remote_Policy':'リモートポリシー',
		'_Incoming_Interface':'受信インターフェース',
		'_Nailed_Up':'常時接続'
		}];

/* wizard_error.html */
var _wizard_error=[{
		'_ErrNo':'エラー番号:',
		'_ErrMsg':'エラーメッセージ:',
		'_Installation_Setup_Wizard':'インストールセットアップウィザード',
		'_Error':'エラー'
		}];

//wizvpnwait.html file
var _wizvpnwait=[{
		'_Installation_Setup_Wizard':'インストールセットアップウィザード',
		'_Internet_Detection':'インターネット検出',
		'_Auto_Configure_WAN':'WAN の自動設定',
		'_Please':'しばらくお待ちください...',
		'_STEP':'ステップ'
		}];

/*----- SiteMAP -----*/

//sitemap.html file
var _sitemap=[{
		'_Licensing':'ライセンス',
		'_Registration':'登録',
		'_Service':'サービス',
		'_File_Manager':'ファイルマネージャ',
		'_Configuration_File':'証明ファイル',
		'_Firmware_Package':'ファームウェアパッケージ',
		'_Shell_Script':'シェルスクリプト',
		'_Configuration':'設定',
		'_Network':'ネットワーク',
		'_Policy':'ポリシー',
		'_User_Group':'ユーザー/グループ',
		'_Interface':'インターフェース',
		'_Ethernet':'イーサネット',
		'_Route':'ルート',
		'_Policy_Route':'ポリシールート',
		'_User':'ユーザー',
		'_Port_Grouping':'ポートグループ化',
		'_Static_Route':'静的ルート',
		'_Group':'グループ',
		'_VLAN':'VLAN',
		'_Firewall':'ファイアウォール',
		'_Setting':'設定',
		'_Bridge':'ブリッジ',
		'_App_Patrol':'アプリケーションパトロール',
		'_Configuration':'設定',
		'_PPPoE_PPTP':'PPPoE/PPTP',
		'_Other_Protocol':'その他のプロトコル',
		'_Auxiliary':'予備',
		'_IDP':'IDP',
		'_General':'一般',
		'_Trunk':'トランク',
		'_Profile':'プロファイル',
		'_IPSec_VPN':'IPSec VPN',
		'_VPN_Connection':'VPN 接続',
		'_Custom_Signatures':'カスタムシグネチャ',
		'_VPN_Gateway':'VPN ゲートウェイ',
		'_Update':'更新',
		'_Concentrator':'コンセントレーター',
		'_Content_Filter':'コンテンツフィルター',
		'_General':'一般',
		'_SA_Monitor':'SA モニター',
		'_Filter_Profile':'フィルタープロファイル ',
		'_Routing_Protocol':'ルーティングプロトコル',
		'_RIP':'RIP',
		'_Cache':'キャッシュ',
		'_OSPF':'OSPF',
		'_Virtual_Server':'仮想サーバー',
		'_Zone':'ゾーン',
		'_HTTP_Redirect':'HTTP 変更',
		'_Device_HA':'デバイス HA',
		'_VRRP_Group':'VRRP グループ',
		'_VoIP_passThru':'VoIP パススルー',
		'_Synchronize':'同期',
		'_ISP_Account':'IP アカウント',
		'_DDNS':'DDNS',
		'_Object':'オブジェクト',
		'_System':'システム',
		'_Address':'アドレス',
		'_Address_Group':'アドレスグループ',
		'_Host_Name':'ホスト名',
		'_Service':'サービス',
		'_Date_Time':'日付/時刻',
		'_Service_Group':'サービスグループ',
		'_Console_Speed':'コンソール速度',
		'_Schedule':'スケジュール',
		'_ICMP':'ICMP',
		'_AAA_Server':'AAA サーバー',
		'_LDAP':'LDAP',
		'_DNS':'DNS',
		'_Default':'デフォルト',
		'_Group':'グループ',
		'_WWW':'WWW',
		'_RADIUS':'RADIUS',
		'_SSH':'SSH',
		'_TELNET':'TELNET',
		'_Auth_method':'認証方法',
		'_FTP':'FTP',
		'_Certificate':'証明',
		'_My_Certificates':'自己証明',
		'_SNMP':'SNMP',
		'_Trusted_Certificates':'信頼された証明',
		'_Maintenance':'メンテナンス',
		'_Log':'ログ',
		'_Traffic':'トラフィック',
		'_Reboot':'再起動',
		'_View_Log':'ログ表示',
		'_Log_Setting':'ログ設定',
		'_Session':'セッション',
		'_Diagnostics':'診断',
		'_System_Protect':'システム保護',
		'_Anti_Virus':'アンチウィルス',
		'_Interface_Summary':'インターフェースサマリー',
		'_Routing':'ルーティング',
		'_ALG':'ALG',
		'_VPN':'VPN',
		'_SSL_VPN':'SSL VPN',
		'_Access_Privilege':'アクセス権限',
		'_Connection_Monitor':'接続モニター',
		'_Global_Setting':'グローバル設定',
		'_L2TP_VPN':'L2TP VPN',
		'_Session_Monitor':'セッションモニター',
		'_General':'一般',
		'_Common':'共通',
		'_IM':'IM',
		'_Peer_to_Peer':'ピア・ツー・ピア',
		'_VoIP':'VoIP',
		'_Streaming':'ストリーミング',
		'_Other':'その他',
		'_Statistics':'統計',
		'_Anti_X':'アンチX',
		'_Anti_Virus':'アンチウィルス',
		'_Summary':'サマリー',
		'_Setting':'設定',
		'_Signature':'シグネチャ',
		'_ADP':'ADP',
		'_Active_Directory':'アクティブディレクトリ',
		'_SSL_Application':'SSL アプリケーション',
		'_Dial_in_Mgmt':'ダイヤルイン管理',
		'_Vantage_CNM':'Vantage CNM',
		'_Anti_Virus':'アンチウィルス',
		'_Diagnostics':'診断'
		}];

var LangReady=true;

