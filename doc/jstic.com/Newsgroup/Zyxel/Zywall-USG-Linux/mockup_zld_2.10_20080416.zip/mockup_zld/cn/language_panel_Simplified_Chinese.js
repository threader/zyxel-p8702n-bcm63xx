﻿var langFile='Simplex_Chinese';
//login.html & login_s.html files
var _login=[
		{'_USG_300':'ZyWALL USG 300',
		'_ZW1050':'ZyWALL 1050',	
		'_Enter_User':'请输入用户名与密码.',
		'_User_Name':'用户名:',
		'_Password':'密码:',
		'_One_Time':'One-Time Password:',
		'_Optional':'(可选)',
		'_max_alphanumeric':'(输入最长 31 个字符, 不允许空白)',
		'_Login_to':'登录到 SSL VPN 模式',
		'_Note':'附注:',
		'_Turn_on':'1. 请打开浏览器的 Javascript 与 Cookie 设定.',
		'_Turn_off':'2. 请关闭浏览器的 Popup Window Blocking 设定.',
		'_JRE_on':'3. 请打开浏览器的 Java Runtime Environment (JRE)设定.',		
		'_Login':'登录',
		'_Reset':'重置'
		}];	

//panel.html file
var _panel=[
		{'_Status':'状态',
		'_Licensing':'许可证',
		'_Update':'更新',
		'_Registration':'注册',
		'_File_Manager':'文件管理',
		'_Configuration':'配置',
		'_Network':'网络',
		'_Interface':'接口',
		'_VPN':'VPN',
		'_IPSec_VPN':'IPSec VPN',
		'_SSL_VPN':'SSL VPN',
		'_L2TP_VPN':'L2TP VPN',
		'_Routing':'路由',
		'_Route':'路由',
		'_Routing_Protocol':'路由协议',
		'_Zone':'区域',
		'_Device_HA':'设备高可用性',
		'_ISP_Account':'ISP帐户',
		'_DDNS':'DDNS',
		'_Policy':'策略',
		'_Firewall':'防火墙',
		'_App_Patrol':'应用控制',
		'_Anti_X':'Anti-X',
		'_Anti_Virus':'防病毒',
		'_Anti_Spam':'防垃圾邮件',
		'_IDP':'入侵检测与保护',
		'_ADP':'异常检测',
		'_Signature':'特征码',
		'_Anomaly':'异常',
		'_Content_Filter':'内容过滤',
		'_Virtual_Server':'虚拟服务器',		
		'_HTTP_Redirect':'HTTP重定向',
		'_ALG':'ALG',
		'_User_Group':'用户组',
		'_Object':'对象',
		'_Address':'地址',
		'_Service':'服务',
		'_Schedule':'时间表',
		'_AAA_Server':'AAA服务器',
		'_Auth_method':'验证方式',
		'_Certificate':'证书',
		'_SSL_Application':'SSL应用',
		'_System':'系统',
		'_Host_Name':'主机名称',
		'_Date_Time':'日期/时间',
		'_Console_Speed':'Console速度',
		'_DNS':'DNS',
		'_WWW':'WWW',
		'_SSH':'SSH',
		'_TELNET':'TELNET',
		'_FTP':'FTP',
		'_SNMP':'SNMP',
		'_Dial_in_Mgmt':'Dial-in管理.',
		'_System_Protect':'系统保护',
		'_Vantage_CNM':'Vantage CNM',
		'_Maintenance':'设备维护',
		'_Diagnostics':'诊断',
		'_Log':'日志',
		'_Report':'报告',
		'_Reboot':'重新启动',
		'_Language':'语言设置'
		}];					

//access.html file,  user away login page
var _access=[
		{'_You_now':'您已经登录。',
		'_Click_the_logout':'点击注销按钮结束访问。',
		'_You_could_renew':'您可以通过点击更新按钮延续登录时间。',
		'_For_security':'由于安全考虑您必须在 ',
		'_hours':' 小时 ',
		'_minutes':' 分钟之后登录.',
		'_Renew':'更新',
		'_Logout':'登出',
		'_User_defined':'用户定义的延续时间 (最多 ',
		'_Minutes':' 分钟):',
		'_Updating_lease':'自动更新延续时间',
		'_Remaining_lease':'延续时间截止前剩余时间 (hh:mm:ss): ',
		'_Remaining_auth':'验证截止前剩余时间 (hh:mm): '
		}];					
		
//chgpw.html file
var _chgpw=[
		{'_Update_Admin_Info':'更新管理员信息',
		'_As_a_security':'出于安全考虑, 强烈建议您更改管理员密码。',
		'_New_Password':'新密码:',
		'_Retype_to_Confirm':' 重新输入以便确认:',
		'_max_alphanumeric':'( 字母或数字，最长 31 个字符, 不允许空白 )',
		'_Apply':'应用',
		'_Ignore':'忽略'
		}];	
//waitdata.html file
var _waitdata=[
		{'_Please_Wait':'请稍候 ...'
		}];	
