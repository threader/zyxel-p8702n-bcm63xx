var langFile='English';
//login.html & login_s.html files
var _login=[
		{'_USG_300':'ZyWALL USG 300',
		'_ZW1050':'ZyWALL 1050',	
		'_Enter_User':'Enter User Name/Password and click to login.',
		'_User_Name':'User Name:',
		'_Password':'Password:',
		'_One_Time':'One-Time Password:',
		'_Optional':'(Optional)',
		'_max_alphanumeric':'( max. 31 alphanumeric, printable characters and no spaces )',
		'_Login_to':'Log into SSL VPN',
		'_Note':'Note:',
		'_Turn_on':'1. Turn on Javascript and Cookie setting in your web browser.',
		'_Turn_off':'2. Turn off Popup Window Blocking in your web browser.',
		'_JRE_on':'3. Turn on Java Runtime Environment (JRE) in your web browser.',
		'_Login':'Login',
		'_Reset':'Reset'
		}];			

//panel.html file
var _panel=[
		{'_Status':'Status',
		'_Licensing':'Licensing',
		'_Update':'Update',
		'_Registration':'Registration',
		'_File_Manager':'File Manager',
		'_Configuration':'Configuration',
		'_Network':'Network',
		'_Interface':'Interface',
		'_VPN':'VPN',
		'_IPSec_VPN':'IPSec VPN',
		'_SSL_VPN':'SSL VPN',
		'_L2TP_VPN':'L2TP VPN',
		'_Routing':'Routing',
		'_Route':'Route',
		'_Routing_Protocol':'Routing Protocol',
		'_Zone':'Zone',
		'_Device_HA':'Device HA',
		'_ISP_Account':'ISP Account',
		'_DDNS':'DDNS',
		'_Policy':'Policy',
		'_Firewall':'Firewall',
		'_App_Patrol':'AppPatrol',
		'_Anti_X':'Anti-X',
		'_Anti_Virus':'Anti-Virus',
		'_Anti_Spam':'Anti-Spam',
		'_IDP':'IDP',
		'_ADP':'ADP',
		'_Signature':'Signature',
		'_Anomaly':'Anomaly',
		'_Content_Filter':'Content Filter',
		'_Virtual_Server':'Virtual Server',		
		'_HTTP_Redirect':'HTTP Redirect',
		'_ALG':'ALG',
		'_User_Group':'User/Group',
		'_Object':'Object',
		'_Address':'Address',
		'_Service':'Service',
		'_Schedule':'Schedule',
		'_AAA_Server':'AAA Server',
		'_Auth_method':'Auth. method',
		'_Certificate':'Certificate',
		'_SSL_Application':'SSL Application',
		'_System':'System',
		'_Host_Name':'Host Name',
		'_Date_Time':'Date/Time',
		'_Console_Speed':'Console Speed',
		'_DNS':'DNS',
		'_WWW':'WWW',
		'_SSH':'SSH',
		'_TELNET':'TELNET',
		'_FTP':'FTP',
		'_SNMP':'SNMP',
		'_Dial_in_Mgmt':'Dial-in Mgmt.',
		'_System_Protect':'System Protect',
		'_Vantage_CNM':'Vantage CNM',
		'_Maintenance':'Maintenance',
		'_Diagnostics':'Diagnostics',
		'_Log':'Log',
		'_Report':'Report',
		'_Reboot':'Reboot',
		'_Language':'Language'
		}];					

//access.html file,  user away login page
var _access=[
		{'_You_now':'You now have logged in.',
		'_Click_the_logout':'Click the logout button to terminate the access session.',
		'_You_could_renew':'You could renew your lease time by clicking the Renew button.',
		'_For_security':'For security reason you must login in again after ',
		'_hours':' hours ',
		'_minutes':' minutes.',
		'_Renew':'Renew',
		'_Logout':'Logout',
		'_User_defined':'User-defined lease time (max ',
		'_Minutes':' minutes):',
		'_Updating_lease':'Updating lease time automatically',
		'_Remaining_lease':'Remaining time before lease timeout (hh:mm:ss): ',
		'_Remaining_auth':'Remaining time before auth. timeout (hh:mm): '
		}];					
		
//chgpw.html file 
var _chgpw=[
		{'_Update_Admin_Info':'Update Admin Info',
		'_As_a_security':'As a security precaution, it is highly recommended that you change the admin password.',
		'_New_Password':'New Password:',
		'_Retype_to_Confirm':' Retype to Confirm:',
		'_max_alphanumeric':'( max. 31 alphanumeric, printable characters and no spaces )',
		'_Apply':'Apply',
		'_Ignore':'Ignore'
		}];	
//waitdata.html file
var _waitdata=[
		{'_Please_Wait':'Please Wait ...'
		}];		
