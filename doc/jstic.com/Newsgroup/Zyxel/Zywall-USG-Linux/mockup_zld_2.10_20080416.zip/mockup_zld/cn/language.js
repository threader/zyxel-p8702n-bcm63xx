var langFile='English';

/* for all buttons */
var _button=[{
		'_OK':'  OK  ',
		'_Cancel':'Cancel',
		'_Apply':'Apply',
		'_Reset':'Reset',
		'_Synchronize_Now':'Synchronize Now',
		'_Import':'Import',
		'_Refresh':'Refresh',
		'_Export':'Export',
		'_Export_Certificate':'Export Certificate',
		'_Export_Certificate_Only':'Export Certificate Only',
		'_Export_Certificate_with_Private_Key':'Export Certificate with Private Key',
		'_Show_Filter':'Show Filter',
		'_Hide_Filter':'Hide Filter',
		'_Search':'Search',
		'_Email_Log_Now':'Email Log Now',
		'_Clear_Log':'Clear Log',
		'_Active_Log_Summary':'Active Log Summary',
		'_Flush_Data':'Flush Data',
		'_Start_Collection':'Start Collection',
		'_Stop_Collection':'Stop Collection',
		'_Collect_Now':'Collect Now',
		'_Close':'Close',
		'_Download':'Download',
		'_Reboot':'Reboot',
		'_Please_wait_collecting':'Please wait, collecting...',
		'_Done_the_collection':'Done the collection.',
		'_Update':'Update',
		'_Service_License_Refresh':'Service License Refresh',
		'_Copy':'Copy',
		'_Rename':'Rename',
		'_Delete':'Delete',
		'_Upload':'Upload',
		'_Run':'Run',
		'_Edit_static_DHCP_table':'Edit static DHCP table',
		'_Add_New_VPN_Gateway':'Add New VPN Gateway',
		'_Advanced':'Advanced ...',
		'_Sync_Now':'Sync. Now',
		'_Change':'Change... ',
		'_New':'New...',
		'_Switch_to_query_view':'Switch to query view',
		'_Switch_to_group_view':'Switch to group view',
		'_Save':'  Save  ',
		'_Delete':'Delete',
		'_Export':'Export',
		'_Update_Now':'Update Now',
		'_Flush':'Flush',
		'_Add':'Add',
		'_Basic_cfilter':'Basic',
		'_Advanced_cfilter':'Advanced',
		'_Test_Against_Local_Cache':'Test Against Local Cache',
		'_Test_Against_Web_Filter_Server':'Test Against Web Filter Server',
		'_Login':'_Login',
		'_Refresh_Now':'Refresh Now',
		'_Clear_Warning_Message':'Clear Warning Messages',
		'_Back':'< Back',
		'_Next':'Next >',
		'_Check':'Check',
		'_Set_Interval':'Set Interval',
		'_Stop':'Stop',
		'_Clear_RX_Message':'Clear RX Message',
		'_Change_Display_Style':'Change Display Style',
		'_Advanced_':'Advanced>>',
		'_Basic_':'Basic<<',
		'_Expand':'Expand',
		'_Collapse':'Collapse',
		'_Reset_Default':'Reset Logo to default',
		'_Preview':'Preview',
		'_Logout':'Logout',
		'_Renew':'Renew'
		}];
		
/* Global Title Tag */
var _globalTag=[{
		/* Spare bar*/
		'_General_Setup':'General Setup',
		'_Policies':'Policies',
		'_Configuration':'Configuration',
		/* Registration */
		'_Registration':'Registration',
		'_Service':'Service',
		/* Update */
		'_IDP_App_Patrol':'IDP/AppPatrol',
		'_System_Protect':'System Protect',
		'_Anti_Virus':'Anti-Virus',
		/* Network */
		'_Interface_Summary':'Interface Summary',
		'_Ethernet':'Ethernet',
		'_Port_Grouping':'Port Grouping',
		'_VLAN':'VLAN',
		'_Bridge':'Bridge',
		'_PPPoE_PPTP':'PPPoE/PPTP',
		'_Auxiliary':'Auxiliary',
		'_Trunk':'Trunk',
		'_Policy_Route':'Policy Route',
		'_Static_Route':'Static Route',
		'_RIP':'RIP',
		'_OSPF':'OSPF',
		/* IPSec VPN */
		'_VPN_Connection':'VPN Connection',
		'_VPN_Gateway':'VPN Gateway',
		'_Concentrator':'Concentrator',
		'_SA_Monitor':'SA Monitor',
		/* SSL VPN */
		'_Access_Privilege':'Access Privilege',
		'_Connection_Monitor':'Connection Monitor',
		'_Global_Setting':'Global Setting',
		/* L2TP VPN */
		'_L2TP_VPN':'L2TP VPN',
		'_Session_Monitor':'Session Monitor',
		/* AppPatrol */
		'_General':'General',
		'_Common':'Common',
		'_Instant_Messenger':'Instant Messenger',
		'_Peer_to_Peer':'Peer to Peer',
		'_VoIP':'VoIP',
		'_Streaming':'Streaming',
		'_Other':'Other',
		'_Statistics':'Statistics',
		/* Anti-X > Anti-Virus */
		'_Summary':'Summary',
		'_Setting':'Setting',
		'_Signature':'Signature',
		/* Anti-X > IDP */
		'_General':'General',
		'_Profile':'Profile',
		'_Custom_Signatures':'Custom Signatures',
		'_Protocol_Anomaly':'Protocol Anomaly',
		'_Traffic_Anomaly':'Traffic Anomaly',
		/* Anti-X > Content Filter */
		'_General_CF':'General',
		'_Filter_Profile':'Filter Profile ',
		'_Cache':'Cache',
		/* Device HA */
		'_VRRP_Group':'VRRP Group',
		'_Synchronize':'Synchronize',
		/* Object */
		'_User':'User',
		'_Group':'Group',
		'_Setting':'Setting',
		'_Address':'Address',
		'_Address_Group':'Address Group',
		'_Service':'Service',
		'_Service_Group':'Service Group',
		'_Active_Directory':'Active Directory',
		'_LDAP':'LDAP',
		'_RADIUS':'RADIUS',
		'_My_Certificates':'My Certificates',
		'_Trusted_Certificates':'Trusted Certificates',
		/* File Manager */
		'_Configuration_File':'Configuration File',
		'_Firmware_Package':'Firmware Package',
		'_Shell_Script':'Shell Script',
		/* Log */
		'_View_Log':'View Log',
		'_Log_Setting':'Log Setting',
		/* Traffic */
		'_Traffic':'Traffic',
		'_Session':'Session',
		'_IDP':'IDP',
		'_Anti_Virus':'Anti-Virus',
		/* Member List popup*/
		'_Member_List':'Member List',
		'_Available':'Available',
		'_Member':'Member',
		'_Please_Select':'Please select member.',
		/* app patrol & policy route BWM */
		'_BWM_Global_Setting':'BWM Global Setting',
		'_Enable_BWM':'Enable BWM'
		}];

/* about.html */
var _about=[{
		'_ZyWALL_1050':'ZyWALL 1050',
		'_USG_300':'ZyWALL USG 300',
		'_Copyright':'(C) Copyright 2007 by ZyXEL Communications Corp.',
		'_Did_you_check':'Did you check ',
		'_www_zyxel_com':'www.zyxel.com',
		'_today':' today?'
		}];

/* tx.html */
var _tx=[{
		'_CLI_Message':'CLI Message',
		'_Start_CLI_command':'Start CLI command',
		'_End_CLI_command':'End CLI command'
		}];

/* rx.html */
var _rx=[{'_RX_Message':'RX Message'}];

/* status.html */
var _status=[{
		'_Message':'Message',
		'_Ready':'Ready'
		}];

/* grant_access.html */
var _grant_access=[{'_ZyWALL_has_granted_your_access':'ZyWALL has granted your access.'}];

/* fwDone.html */
var _fwDone=[{'_Please_Wait':'Please Wait ... '}];

/* fwDone.html */
var _fwupdone=[{'_Please_Wait':'Please Wait ... ',
			'_warning_message1':'Firmware upload is in progress -- Do not turn off the power or reset the ZyWALL.',
			'_warning_message2':'The complete firmware update may take up to 5 minutes.'
			}];

/* vpndial.html */		
var _vpndial=[{'_Please_Wait':'Please Wait ... '}];

/* apacheDone.html */
var _apacheDone=[{'_Please_Wait':'Please Wait ... '}];

/* rebootDone.html */
var _rebootDone=[{'_Please_Wait':'Please Wait ... '}];

/* homedial.html */
var _homedial=[{'_Please_Wait':'Please Wait ... '}];

/* waitdial.html */
var _waitdial=[{'_Please_Wait':'Please Wait ...'}];

//warning.html file
var _warning=[{'_Warning_Message':'Warning Message'}];

//waitdata.html file
var _waitdata=[{'_Please_Wait':'Please Wait ...'}];

/*----- Status -----*/

/* home.html */
var _home=[{			
		/* Device Information */
		'_Device_Information':'Device Information',
		'_System_Name':'System Name',
		'_Model_Name':'Model Name',
		'_Serial_Number':'Serial Number',
		'_MAC_Address_Range':'MAC Address Range',
		'_Firmware_Version':'Firmware Version',			
		/* System Resource */
		'_System_Resources':'System Resources',
		'_CPU_Usage':'CPU Usage',
		'_Memory_Usage':'Memory Usage',
		'_Flash_Usage':'Flash Usage',
		'_Active_Sessions':'Active Sessions',			
		/* Interface Status Summary */
		'_Interface_Status_Summary':'Interface Status Summary',
		'_Name':'Name',
		'_Status':'Status',
		'_HA_Status':'HA Status',
		'_Zone':'Zone',
		'_IP_Address':'IP Address',
		'_Renew_Dial':'Renew/Dial',			
		/* System Status */
		'_System_Status':'System Status',
		'_System_Uptime':'System Uptime',
		'_Current_Date_Time':'Current Date/Time',
		'_VPN_Status':'VPN Status',
		'_DHCP_Table':'DHCP Table',
		'_Statistics':'Port Statistics',
		'_Current_User_List':'Current User List',
		'_Current_Login_User':'Current Login User',
		'_Number_of_Login_Users':'Number of Login Users',			
		/* Licensed Service Status */
		'_Licensed_Service_Status':'Licensed Service Status',
		'_IDP':'IDP',
		'_License_Status_Remaining_days':'License Status/Remaining days',
		'_Signature_Version':'Signature Version',
		'_Last_Update_Time':'Last Update Time',
		'_Total_Signature_Number':'Total Signature Number',
		'_Anti_Virus':'Anti-Virus',
		'_Content_Filter':' Content Filter',
		/* Top 5 Intrusion & Virus Detection*/
		'_Top5':'Top 5 Intrusion & Virus Detection',
		'_Rank':'Rank',
		'_Intrusion_Detected':'Intrusion Detected',
		'_Virus_Detected':'Virus Detected',
		/* Refresh */
		'_Refresh_Interval':'Refresh Interval',
		'_Refresh_Now':'Refresh Now',
		/* force logout */
		'_User_ID':'User ID',
		'_Reauth_Lease_T_':'Reauth Lease T.',
		'_Type':'Type',
		'_IP_address':'IP address',
		'_Force_Logout':'Force Logout'
		}];

/*----- Licensing > Registration -----*/ 
/* vpnitval.html */
var _vpnitval=[{'_Poll_Interval':'Poll Interval (1-60 seconds):'}];

/* vpnstatus.html */
var _vpnstatus=[{
		'_VPN_Table':'VPN Table',
		'_Name':'Name',
		'_Encapsulation':'Encapsulation',
		'_IPSec_Algorithm':'IPSec Algorithm'
		}];

/* dhcpstatus.html */
var _dhcpstatus=[{
		'_DHCP_Table':'DHCP Table',
		'_Interface':'Interface',
		'_IP_Address':'IP Address',
		'_Host_Name':'Host Name',
		'_MAC_Address':'MAC Address',
		'_Reserve':'Reserve'
		}];

/* ifacestatus.html */
var _ifacestatus=[{
		'_Statistics_Table':'Statistics Table',
		'_Port':'Port',
		'_status':'status',
		'_TxPkts':'TxPkts',
		'_RxPkts':'RxPkts',
		'_Collisions':'Collisions',
		'_Tx':'Tx B/s',
		'_Rx':'Rx B/s',
		'_Up_Time':'Up Time',
		'_System_Up_Time':'System Up Time'
		}];
		
/* ifaceitval.html */
var _ifaceitval=[{'_Poll_Interval':'Poll Interval (1-60 seconds):'}];		

/*----- Licensing > Registration -----*/

/* regist.html */
var _regist=[{
		'_Device_Registration':'Device Registration',
		'_Trial_Service_Activation':'Trial Service Activation',
		'_regtext1':'This device is not registered to myZyXEL.com.&nbsp; Please enter information below to <b>register</b> your device.',
		'_regtext2':'If you don\'t have myZyXEL.com account, please select &quot;new myZyXEL.com account&quot; below. If you have',
		'_regtext3':'a myZyXEL.com account, but you forget your User Name or Password, please go to ',
		'_regtext4':'<a href="http://www.myZyXEL.com"><font color="#FF0000"><i><u>www.myZyXEL.com</u></i></font></a>',
		'_regtext5':'for help.',
		'_new_myZyXEL_com_account':'new myZyXEL.com account',
		'_existing_myZyXEL_com_account':'existing myZyXEL.com account',
		'_User_Name':'User Name',
		'_you_can_click':'you can click to check if username exists',
		'_Password':'Password',
		'_Confirm_Password':'Confirm Password',
		'_E_Mail_Address':'E-Mail Address',
		'_Country_Code':'Country Code',
		'_Trial_Service_Activation':'Trial Service Activation',
		'_IDP':'IDP/AppPatrol',
		'_Anti_Virus':'Anti-Virus',
		'_Content_Filter':'Content Filter'
		}];

/* registmgn.html */
var _registmgn=[{
		'_Service_Management':'Service Management',
		'_Service':'Service',
		'_Status':'Status',
		'_Registration_Type':'Registration Type',
		'_Expiration_day':'Expiration date',
		'_Count':'Count',
		'_License_Upgrade':'License Upgrade',
		'_License_Key':'License Key',
		'_Note':'Note: Sync with myZyXEL.com to download license Info'													
		}];

/*----- Licensing > Update -----*/

/* idpfile.html */
var _idpfile=[{
		'_Signature_Information':'Signature Information',
		'_Current_Version':'Current Version',
		'_Signature_Number':'Signature Number',
		'_Released_Date':'Released Date',
		'_Remote_Update':'Remote Update',				
		'_Synchronize_the_IDP':'Synchronize the IDP Signature Package to the latest version with online update server.&nbsp; (myZyXEL.com activation required)',
		'_Auto_Update':'Auto Update',
		'_Hourly':'Hourly',
		'_Daily':'Daily',
		'_Hour':'(Hour)',
		'_Weekly':'Weekly',
		'_Day':'(Day)'
		}];

/* idpfile.html */
var _idpfile_1=[{
		'_Signature_Information':'Signature Information',
		'_Current_Version':'Current Version',
		'_Signature_Number':'Signature Number',
		'_Released_Date':'Released Date',
		'_Remote_Update':'Remote Update',				
		'_Synchronize':'Synchronize the System Protect Signature Package to the latest version with online update server.',
		'_Auto_Update':'Auto Update',
		'_Hourly':'Hourly',
		'_Daily':'Daily',
		'_Hour':'(Hour)',
		'_Weekly':'Weekly',
		'_Day':'(Day)'
		}];

/* antiupdate.html */
var _antiupdate=[{
		'_Signature_Information':'Signature Information',
		'_Current_Version':'Current Version',
		'_Signature_Number':'Signature Number',
		'_Released_Date':'Released Date',
		'_Remote_Update':'Remote Update',
		'_Synchronize':'Synchronize the Anti-Virus Signature Package to the latest version with online update server.&nbsp;(myZyXEL.com activation required)',
		'_Auto_Update':'Auto Update',
		'_Hourly':'Hourly',
		'_Daily':'Daily',
		'_Hour':'(Hour)',
		'_Weekly':'Weekly',
		'_Day':'(Day)'
		}];

/* upd.html */
var _upd=[{
		'_Rendering':'Rendering...',
		'_ZyWALL':'ZyWALL online Update Server'
		}];
		
/*----- Network > Interface -----*/

/* ifacesummary.html */
var _ifacesummary=[{
		'_Interface_Summary':'Interface Summary',
		'_Name':'Name',
		'_Status':'Status',
		'_HA_Status':'HA Status',
		'_Zone':'Zone',
		'_IP_Netmask':'IP Addr/Netmask',
		'_IP_Assignment':'IP Assignment',
		'_Services':'Services',
		'_Renew_Dial':'Renew/Dial',
		'_Statistics':'Interface Statistics',
		'_Tx_Pkts':'TxPkts',
		'_Rx_Pkts':'RxPkts',
		'_Collision':'Collision',
		'_Tx_Bs':'Tx B/s',
		'_Rx_Bs':'Rx B/s'
		}]

/* Interface.html */
var _Interface=[{
		'_Configuration':'Configuration',
		'_Name':'Name',
		'_IP_Address':'IP Address',
		'_Mask':'Mask',
		'_Modify':'Modify'
		}];

/* ifEdit.html file */
var _ifEdit=[{
		'_Ethernet_Interface_Properties':'Ethernet Interface Properties',
		'_Enable':'Enable',
		'_Interface_Name':'Interface Name',
		'_Description':'Description',
		'_Optional':'(Optional)',
		'_IP_Address_Assignment':'IP Address Assignment',
		'_Get_Automatically':'Get Automatically',
		'_Use_Fixed_IP_Address':'Use Fixed IP Address',
		'_IP_Address':'IP Address',
		'_Subnet_Mask':'Subnet Mask',
		'_Gateway':'Gateway',
		'_Metric':'Metric',
		'_Interface_Parameters':'Interface Parameters',
		'_Upstream_Bandwidth':'Upstream Bandwidth',
		'_Downstream_Bandwidth':'Downstream Bandwidth',
		'_Kbps':'Kbps',
		'_MTU':'MTU',
		'_Bytes':'Bytes',
		'_RIP_Setting':'RIP Setting',
		'_Enable_RIP':'Enable RIP',
		'_Direction':'Direction',
		'_Send_Version':'Send Version',
		'_Receive_Version':'Receive Version',
		'_V2_Broadcast':'V2-Broadcast',
		'_OSPF_Setting':'OSPF Setting',
		'_Area':'Area',
		'_Priority':'Priority',
		'_Link_Cost':'Link Cost',
		'_Passive_Interface':'Passive Interface',
		'_Authentication':'Authentication',
		'_Text_Authentication_Key':'Text Authentication Key',
		'_MD5_Authentication_ID':'MD5 Authentication ID',
		'_MD5_Authentication_Key':'MD5 Authentication Key',
		'_Type':'Type',
		'_Authentication':'Authentication',
		'_DHCP_Setting':'DHCP Setting',
		'_DHCP':'DHCP',
		'_Relay_Server_1':'Relay Server 1',
		'_Relay_Server_2':'Relay Server 2',
		'_IP_Address_1':'(IP Address)',
		'_IP_Pool_Start_Address_Optional':'IP Pool Start Address (Optional)',
		'_Pool_Size':'Pool Size',
		'_First_DNS_Server_Optional':'First DNS Server (Optional)',
		'_Second_DNS_server_Optional':'Second DNS server (Optional)',
		'_Third_DNS_Server_Optional':'Third DNS Server (Optional)',
		'_First_WINS':'First WINS Server (Optional)',
		'_Second_WINS':'Second WINS Server (Optional)',
		'_Lease_time':'Lease time',
		'_infinite':'infinite',
		'_days':'days',
		'_hours_Optional':'hours (Optional)',
		'_minutes_Optional':'minutes (Optional)',
		'_Static_DHCP_Table':'Static DHCP Table',
		'_Ping_Check':'Ping Check',
		'_seconds':'seconds',
		'_Domain_Name_or_IP_Address':'(Domain Name or IP Address)',
		'_Check_Period':'Check Period',
		'_Check_Timeout':'Check Timeout',
		'_Check_Fail_Tolerance':'Check Fail Tolerance',
		'_Ping_Default_Gateway':'Ping Default Gateway',
		'_Ping_this_address':'Ping this address'
		}];

/* viredit.html */
var _viredit=[{
		'_Virtual_Interface_Properties':'Virtual Interface Properties',
		'_Interface_Name':'Interface Name',
		'_Description':'Description',
		'_Optional':'(Optional)',
		'_IP_Address_Assignment':'IP Address Assignment',
		'_IP_Address':'IP Address',
		'_Subnet_Mask':'Subnet Mask',
		'_Gateway':'Gateway',
		'_Metric':'Metric',
		'_Interface_Parameters':'Interface Parameters',
		'_Upstream_Bandwidth':'Upstream Bandwidth',
		'_Downstream_Bandwidth':'Downstream Bandwidth',
		'_Kbps':'Kbps'
		}];
		
/* portgrouping.html */
var _portgrouping=[{
		'_Port_Grouping':'Port Grouping',
		'_Representative_Interface':'Representative Interface',
		'_Physical_Port':'Physical Port'
		}];

/* vlan.html */
var _vlan=[{
		'_Configuration':'Configuration',
		'_Name':'Name',
		'_Port_VID':'Port/VID',
		'_IP_Address':'IP Address',
		'_Mask':'Mask'
		}];

/* vlanedit.html */
var _vlanedit=[{
		'_VLAN_Interface_Properties':'VLAN Interface Properties',
		'_Enable':'Enable',
		'_Interface_Name':'Interface Name',
		'_Port':'Port',
		'_Virtual_LAN_Tag':'Virtual LAN Tag',
		'_Description':'Description',
		'_Optional':'(Optional)',
		'_IP_Address_Assignment':'IP Address Assignment',
		'_Get_Automatically':'Get Automatically',
		'_Use_Fixed_IP_Address':'Use Fixed IP Address',
		'_IP_Address':'IP Address',
		'_Subnet_Mask':'Subnet Mask',
		'_Gateway':'Gateway',
		'_Metric':'Metric',
		'_Interface_Parameters':'Interface Parameters',
		'_Upstream_Bandwidth':'Upstream Bandwidth',
		'_Downstream_Bandwidth':'Downstream Bandwidth',		
		'_Kbps':'Kbps',
		'_MTU':'MTU',
		'_Bytes':'Bytes',	
		'_DHCP_Setting':'DHCP Setting',
		'_DHCP':'DHCP',
		'_Relay_Server_1':'Relay Server 1',
		'_Relay_Server_2':'Relay Server 2',		
		'_IP_Address_1':'(IP Address)',
		'_IP_Pool_Start_Address_Optional':'IP Pool Start Address (Optional)',
		'_Pool_Size':'Pool Size',
		'_First_DNS_Server_Optional':'First DNS Server (Optional)',
		'_Second_DNS_server_Optional':'Second DNS server (Optional)',
		'_Third_DNS_Server_Optional':'Third DNS Server (Optional)',
		'_First_WINS':'First WINS Server (Optional)',
		'_Second_WINS':'Second WINS Server (Optional)',
		'_Lease_time':'Lease time',
		'_infinite':'infinite',
		'_days':'days',
		'_hours_Optional':'hours (Optional)',
		'_minutes_Optional':'minutes (Optional)',
		'_Static_DHCP_Table':'Static DHCP Table',
		'_Ping_Check':'Ping Check',
		'_seconds':'seconds',
		'_Domain_Name_or_IP_Address':'(Domain Name or IP Address)',
		'_Check_Period':'Check Period',
		'_Check_Timeout':'Check Timeout',
		'_Check_Fail_Tolerance':'Check Fail Tolerance',
		'_Ping_Default_Gateway':'Ping Default Gateway',
		'_Ping_this_address':'Ping this address'
		}];

/* bridge.html */
var _bridge=[{
		'_Configuration':'Configuration',
		'_Name':'Name',
		'_IP_Address':'IP Address',
		'_Member':'Member'
		}];

/* bridgeedit.html */
var _bridgeedit=[{
		'_Bridge_Interface_Properties':'Bridge Interface Properties',
		'_Enable':'Enable',
		'_Interface_Name':'Interface Name',
		'_Description':'Description',
		'_Optional':'(Optional)',
		'_Member_Configuration':'Member Configuration',
		'_Available':'Available',
		'_Member':'Member',
		'_IP_Address_Assignment':'IP Address Assignment',
		'_Get_Automatically':'Get Automatically',
		'_Use_Fixed_IP_Address':'Use Fixed IP Address',
		'_IP_Address':'IP Address',
		'_Subnet_Mask':'Subnet Mask',
		'_Gateway':'Gateway',
		'_Metric':'Metric',
		'_Interface_Parameters':'Interface Parameters',
		'_Upstream_Bandwidth':'Upstream Bandwidth',
		'_Downstream_Bandwidth':'Downstream Bandwidth',
		'_Kbps':'Kbps',
		'_MTU':'MTU',
		'_Bytes':'Bytes',
		'_DHCP_Setting':'DHCP Setting',
		'_DHCP':'DHCP',
		'_Relay_Server_1':'Relay Server 1',
		'_Relay_Server_2':'Relay Server 2',		
		'_IP_Address_1':'(IP Address)',
		'_IP_Pool_Start_Address_Optional':'IP Pool Start Address (Optional)',
		'_Pool_Size':'Pool Size',
		'_First_DNS_Server_Optional':'First DNS Server (Optional)',
		'_Second_DNS_server_Optional':'Second DNS server (Optional)',
		'_Third_DNS_Server_Optional':'Third DNS Server (Optional)',
		'_First_WINS':'First WINS Server (Optional)',
		'_Second_WINS':'Second WINS Server (Optional)',
		'_Lease_time':'Lease time',
		'_infinite':'infinite',
		'_days':'days',
		'_hours_Optional':'hours (Optional)',
		'_minutes_Optional':'minutes (Optional)',
		'_Static_DHCP_Table':'Static DHCP Table',
		'_Ping_Check':'Ping Check',
		'_seconds':'seconds',
		'_Domain_Name_or_IP_Address':'(Domain Name or IP Address)',
		'_Check_Period':'Check Period',
		'_Check_Timeout':'Check Timeout',
		'_Check_Fail_Tolerance':'Check Fail Tolerance',
		'_Ping_Default_Gateway':'Ping Default Gateway',
		'_Ping_this_address':'Ping this address'
		}];

/* dhcp.html */
var _dhcp=[{
		'_Static_DHCP':'Static DHCP',
		'_IP_Address':'IP Address',
		'_MAC':'MAC'
		}];
			
/* pppoe.html */
var _pppoe=[{
		'_Name':'Name',
		'_Base_Interface':'Base Interface',		
		'_Account_Profile':'Account Profile'
		}];

/* pppedit.html */
var _pppedit=[{
		'_PPP_Interface_Properties':'PPP Interface Properties',
		'_Enable':'Enable',
		'_Interface_Name':'Interface Name',
		'_Nailed_Up':'Nailed-Up',
		'_Dial_on_Demand':'Dial-on-Demand',
		'_Description':'Description',
		'_Optional':'(Optional)',
		'_Base_Interface':'Base Interface',
		'_Account_Profile':'Account Profile',
		'_Protocol':'Protocol',
		'_User_Name':'User Name',
		'_Service_Name':'Service Name',
		'_IP_Address_Assignment':'IP Address Assignment',
		'_Get_Automatically':'Get Automatically',
		'_Use_Fixed_IP_Address':'Use Fixed IP Address',
		'_IP_Address':'IP Address',
		'_Gateway':'Gateway',
		'_Metric':'Metric',
		'_Interface_Parameters':'Interface Parameters',
		'_Upstream_Bandwidth':'Upstream Bandwidth',
		'_Downstream_Bandwidth':'Downstream Bandwidth',
		'_Kbps':'Kbps',
		'_MTU':'MTU',
		'_Bytes':'Bytes',
		'_Ping_Check':'Ping Check',
		'_seconds':'seconds',
		'_Domain_Name_or_IP_Address':'(Domain Name or IP Address)',
		'_Check_Period':'Check Period',
		'_Check_Timeout':'Check Timeout',
		'_Check_Fail_Tolerance':'Check Fail Tolerance',
		'_Ping_Default_Gateway':'Ping Default Gateway',
		'_Ping_this_address':'Ping this address'
		}];

/* auxiliary.html */
var _auxiliary=[{
		'_Auxiliary_Interface_Properties':'Auxiliary Interface Properties',
		'_Enable':'Enable',
		'_Description':'Description',
		'_Optional':'(Optional)',
		'_Port_Speed':'Port Speed',
		'_Dialing_Type':'Dialing Type',
		'_Tone':'Tone',
		'_Pulse':'Pulse',
		'_Initial_String':'Initial String',
		'_Auxiliary_Configuration':'Auxiliary Configuration',
		'_Phone_Number':'Phone Number',
		'_User_Name':'User Name',
		'_Password':'Password',
		'_Retype_to_confirm':'Retype to confirm',
		'_Authentication_Type':'Authentication Type',
		'_Timeout':'Timeout',
		'_Seconds':'(Seconds)',
		'_Idle_timeout':'Idle timeout'
		}];

/* groups.html */
var _groups=[{
		'_Name':'Name',
		'_Algorithm':'Algorithm'
		}];

/* gpedit.html */
var _gpedit=[{
		'_Trunk_Members':'Trunk Members',
		'_Name':'Name',
		'_Load_Balancing_Algorithm':'Load Balancing Algorithm',
		'_Member':'Member',
		'_Mode':'Mode',
		'_Weight':'Weight',
		'_Downstream_Bandwidth':'Downstream Bandwidth',
		'_Upstream_Bandwidth':'Upstream Bandwidth',
		'_Spillover':'Spillover'
		}];

/*----- Network > Routing -----*/

/* policyroute.html */
var _policyroute=[{
		'_User':'User',
		'_Schedule':'Schedule',
		'_Incoming':'Incoming',
		'_Source':'Source',
		'_Destination':'Destination',
		'_Service':'Service',
		'_Next_Hop':'Next-Hop',
		'_SNAT':'SNAT',
		'_BWM':'BWM'
		}];

/* proutedit.html */
var _proutedit=[{
		'_Configuration':'Configuration',
		'_Enable':'Enable',
		'_Description':'Description',
		'_Optional':'(Optional)',
		'_Criteria':'Criteria',
		'_User':'User',
		'_Incoming':'Incoming',
		'_Source_Address':'Source Address',
		'_Destination_Address':'Destination Address',
		'_Schedule':'Schedule',
		'_Service':'Service',
		'_Next_Hop':'Next-Hop',
		'_Type':'Type',
		'_Gateway':'Gateway',
		'_Interface':'Interface',
		'_VPN_Tunnel':'VPN Tunnel',
		'_Trunk':'Trunk',
		'_Address_Translation':'Address Translation',
		'_Source_Network_Address_Translation':'Source Network Address Translation',
		'_Port_Triggering':'Port Triggering',
		'_Incoming_Service':'Incoming Service',
		'_Trigger_Service':'Trigger Service',
		'_Bandwidth_Shaping':'Bandwidth Shaping',
		'_Maximum_Bandwidth':'Maximum Bandwidth',
		'_Bandwidth_Priority':'Bandwidth Priority',
		'_is_highest_priority':'is highest priority',
		'_MBU':'Maximize Bandwidth Usage'
		}];
		
/* staticroute.html */
var _staticroute=[{
		'_Destination':'Destination',
		'_Subnet_Mask':'Subnet Mask',
		'_Next_Hop':'Next-Hop',
		'_Metric':'Metric'
		}];

/* stroutedit.html */
var _stroutedit=[{
		'_Static_Route_Setting':'Static Route Setting',
		'_Destination_IP':'Destination IP',
		'_Subnet_Mask':'Subnet Mask',
		'_Gateway_IP':'Gateway IP',
		'_Interface':'Interface',
		'_Metric':'Metric'
		}];
		
/* rip.html */
var _rip=[{
		'_Authentication':'Authentication',
		'_Text_Authentication_Key':'Text Authentication Key',
		'_MD5_Authentication_ID':'MD5 Authentication ID',
		'_MD5_Authentication_Key':'MD5 Authentication Key',
		'_Redistribute':'Redistribute',
		'_Active':'Active',
		'_Name':'Name',
		'_Metric':'Metric',
		'_OSPF':'OSPF',
		'_Static_Route':'Static Route'
		}];

/* ospf.html */
var _ospf=[{
		'_OSPF_Router_ID_IP_Address':'OSPF Router ID (IP Address)',
		'_Default':'Default',
		'_User_Defined':'User Defined',
		'_Redistribute':'Redistribute',
		'_Active':'Active',
		'_Route':'Route',
		'_Type':'Type',
		'_Metric':'Metric',
		'_RIP':'RIP',
		'_Static_Route':'Static Route',
		'_Area':'Area',
		'_Authentication':'Authentication'
		}];

/* ospfedit.html */
var _ospfedit=[{
		'_Area_Setting':'Area Setting',
		'_Area_ID':'Area ID',
		'_Type':'Type',
		'_Authentication':'Authentication',
		'_Text_Authentication_Key':'Text Authentication Key',
		'_MD5_Authentication_ID':'MD5 Authentication ID',
		'_MD5_Authentication_Key':'MD5 Authentication Key',
		'_Virtual_Link':'Virtual Link',
		'_Peer_Router_ID':'Peer Router ID'
		}];

/*----- Network > Zone -----*/

/* zone.html */
var _zone=[{
		'_Configuration':'Configuration',
		'_Name':'Name',
		'_Block_Intra_zone_Traffic':'Block Intra-zone',
		'_Member':'Member'
		}];

/* zoneedit.html */
var _zoneedit=[{
		'_Group_Members':'Group Members',
		'_Name':'Name',
		'_Block_Intra_zone_Traffic':'Block Intra-zone Traffic'
		}];

/*----- Network > DDNS -----*/

/* ddns.html */
var _ddns=[{
		'_My_Domain_Names':'My Domain Names',
		'_Profile_Name':'Profile Name',
		'_Domain_Name':'Domain Name',
		'_DDNS_Type':'DDNS Type',
		'_Wildcard':'Wildcard',
		'_IP_Address_Update_Policy':'IP Address Update Policy',
		'_WAN_Interface':'WAN Interface',
		'_HA__Interface':'HA* Interface'
		}];

/* ddnsed.html */
var _ddnsed=[{
		'_DDNS_Profile':'DDNS Profile',
		'_Profile_Name':'Profile Name',
		'_DDNS_Type':'DDNS Type',
		'_Username':'Username',
		'_Password':'Password',
		'_Domain_name':'Domain name',
		'_wildcard':' wildcard',
		'_IP_Address_Update_Policy':'IP Address Update Policy',
		'_Custom_IP':'Custom IP',
		'_WAN_Interface':'WAN Interface',
		'_HA_Interface':'HA Interface',
		'_Mail_Exchanger':'Mail Exchanger',
		'_Optional':'(Optional)',
		'_Backup_mail_exchanger':' Backup mail exchanger'
		}];

/*----- Network > Virtual Server -----*/

/* virsvr.html */
var _virsvr=[{
		'_Virtual_Server':'Virtual Server',
		'_Total_Virtual_Servers':'Total Virtual Servers: ',
		'_entries_per_page':'entries per page',
		'_Page':'Page',
		'_Name':'Name',
		'_Interface':'Interface',
		'_Original_IP':'Original IP',
		'_Mapped_IP':'Mapped IP',
		'_Protocol':'Protocol',
		'_Original_Port':'Original Port',
		'_Mapped_Port':'Mapped Port'
		}];

/* virsvredit.html */
var _virsvredit=[{
		'_Enable':'Enable',
		'_Name':'Name',
		'_Interface':'Interface',
		'_Original_IP':'Original IP',
		'_User_Defined':'User Defined',
		'_Mapped_IP':'Mapped IP',
		'_IP_Address':'(IP Address)',
		'_Original_Port':'Original Port',
		'_Mapped_Port':'Mapped Port',
		'_Mapping_Type':'Mapping Type',
		'_Protocol_Type':'Protocol Type',		
		'_Original_Port':'Original Port',
		'_Original_Start_Port':'Original Start Port',
		'_Original_End_Port':'Original End Port',
		'_Mapped_Start_Port':'Mapped Start Port',
		'_Mapped_End_Port':'Mapped End Port',
		'_Please1':'* Please make sure the firewall allows virtual server traffic.',
		'_Please2':'* Please create a corresponding policy route (NAT 1:1) if the virtual server will also establish connections to clients. '
		}];

/*----- Network > HTTP Redirect -----*/

/* httpred.html */
var _httpred=[{
		'_Configuration':'Configuration',
		'_Name':'Name',
		'_Interface':'Interface',
		'_Proxy_Server':'Proxy Server',
		'_Port':'Port'
		}];

/* httprededit.html */
var _httprededit=[{
		'_Enable':'Enable',
		'_Name':'Name',
		'_Interface':'Interface',
		'_Proxy_server':'Proxy server',
		'_Port':'Port'
		}];

/*----- Network > ALG -----*/

/* VoipAlg.html */
var _VoipAlg=[{
		'_SIP_Setting':'SIP Setting',
		'_Enable_SIP_Transformations':'Enable SIP Transformations',
		'_SIP_Signaling_Port':'SIP Signaling Port :',
		'_Additional_SIP_Signaling_Port':'Additional SIP Signaling port(UDP) for transformations :(Optional)',		
		'_SIP_Signaling_inactivity_time_out':'SIP Signaling inactivity time out :',
		'_seconds':'(seconds)',
		'_SIP_Media_inactivity_time_out' :'SIP Media inactivity time out :',		
		'_H_323_Setting':'H.323 Setting',
		'_Enable_H_323_transformations':'Enable H.323 transformations',
		'_H_323_Signaling_Port':'H.323 Signaling Port :',
		'_Additional_H_323_Signaling_Port':'Additional H.323 Signaling port for transformations :(Optional)',
		'_FTP_Setting':'FTP Setting',
		'_Enable_FTP_transformations':'Enable FTP transformations',
		'_FTP_Signaling_Port':'FTP Signaling Port :',
		'_Additional_FTP_Signaling_Port':'Additional FTP Signaling port for transformations :(Optional)'
		}];

/*----- Firewall -----*/

/* firewall.html */
var _firewall=[{
		'_Global_Setting':'Global Setting',
		'_Enable_Firewall':'Enable Firewall',
		'_Allow_Asymmetrical_Route':'Allow Asymmetrical Route',
		'_Maximum_session_per_Host':'Maximum session per Host',
		'_Firewall_rule':'Firewall rule',
		'_Through_ZyWALL_rules':'Through-ZyWALL rules',
		'_Zone_Pairs':'Zone Pairs',
		'_All_rules':'All rules',
		'_To_ZyWALL_rules':'To-ZyWALL rules',
		'_From_Zone':'From Zone',
		'_To_Zone':'To Zone',
		'_Priority':'Priority',
		'_Schedule':'Schedule',
		'_User':'User',
		'_Source':'Source',
		'_Destination':'Destination',
		'_Service':'Service',
		'_Access':'Access',
		'_Log':'Log',		
		'_From':'From',
		'_To':'To'
		}];

/* firewalledit.html */
var _firewalledit=[{
		'_Configuration':'Configuration',
		'_Enable':'Enable',
		'_Description':'Description',
		'_Optional':'(Optional)',
		'_Schedule':'Schedule',
		'_User':'User',
		'_Source':'Source',
		'_Destination':'Destination',
		'_Service':'Service',
		'_Access':'Access',
		'_Log':'Log',				
		'_From':'From',
		'_To':'To'
		}];

/*----- VPN > IPSec VPN -----*/

/* vpnc.html */
var _vpnc=[{
		'_Configuration':'Configuration',
		'_Total_Connection':'Total Connection',
		'_connection_per_page':'connection per page',
		'_Page':'Page',
		'_Name':'Name',
		'_VPN_Gateway':'VPN Gateway',
		'_Encapsulation':'Encapsulation',
		'_Algorithm':'Algorithm',
		'_Policy':'Policy'
		}];
	
/* vpncmkedit.html */
var _vpncmkedit=[{
		'_VPN_Connection':'VPN Connection',
		'_Connection_Name':'Connection Name',
		'_VPN_Gateway':'VPN Gateway',
		'_Name':'Name',
		'_Manual_Key':'Manual Key',
		'_SPI':'SPI',
		'_Encapsulation_Mode':'Encapsulation Mode',
		'_Active_Protocol':'Active Protocol',
		'_Encryption_Algorithm':'Encryption Algorithm',
		'_Authentication_Algorithm':'Authentication Algorithm',
		'_Encryption_Key':'Encryption Key',
		'_Authentication_Key':'Authentication Key',
		'_Policy':'Policy',
		'_Local_Policy':'Local Policy',
		'_Remote_Policy':'Remote Policy',
		'_Property':'Property',
		'_My_Address':'My Address',
		'_Secure_Gateway_Address':'Secure Gateway Address',
		'_Enable_NetBIOS_broadcast_over_IPSec':'Enable NetBIOS broadcast over IPSec',
		'_Inbound_Outbound_Traffic_NAT':'Inbound/Outbound Traffic NAT',
		'_Outbound_Traffic':'Outbound Traffic',
		'_Source_NAT':'Source NAT',
		'_Source':'Source',
		'_Destination':'Destination',
		'_SNAT':'SNAT',
		'_Inbound_Traffic':'Inbound Traffic',
		'_Source_NAT':'Source NAT',
		'_Destination_NAT':'Destination NAT',
		'_Original_IP':'Original IP',
		'_Mapped_IP':'Mapped IP',
		'_Protocol':'Protocol',
		'_Original_Port':'Original Port',
		'_Mapped_Port':'Mapped Port'
		}];

/* vpncikeedit.html */
var _vpncikeedit=[{
		'_VPN_Connection':'VPN Connection',
		'_Connection_Name':'Connection Name',
		'_VPN_Gateway':'VPN Gateway',
		'_Name':'Name',
		'_Phase_2':'Phase 2',
		'_Active_Protocol':'Active Protocol',
		'_Encapsulation':'Encapsulation',
		'_Proposal':'Proposal',
		'_SA_Life_Time':'SA Life Time (Seconds)',
		'_Perfect_Forward_Secrecy':'Perfect Forward Secrecy (PFS)',
		'_Policy':'Policy',
		'_Policy_Enforcement':'Policy Enforcement',
		'_Local_policy':'Local policy',
		'_Remote_policy':'Remote policy',
		'_Property':'Property',
		'_Nailed_Up':'Nailed-Up',
		'_Enable_Replay_Detection':'Enable Replay Detection',
		'_Enable_NetBIOS_broadcast_over_IPSec':'Enable NetBIOS broadcast over IPSec',
		'_Inbound_Outbound_traffic_NAT':'Inbound/Outbound traffic NAT',
		'_Outbound_Traffic':'Outbound Traffic',
		'_Source_NAT':'Source NAT',
		'_Source':'Source',
		'_Destination':'Destination',
		'_SNAT':'SNAT',
		'_Inbound_Traffic':'Inbound Traffic',
		'_Destination_NAT':'Destination NAT',
		'_Original_IP':'Original IP',
		'_Mapped_IP':'Mapped IP',
		'_Protocol':'Protocol',
		'_Original_Port':'Original Port',
		'_Mapped_Port':'Mapped Port',
		'_Encryption':'Encryption',
		'_Authentication':'Authentication'
		}];

/* vpng.html */
var _vpng=[{
		'_Configuration':'Configuration',
		'_Name':'Name',
		'_My_address':'My address',
		'_Secure_Gateway':'Secure Gateway',
		'_VPN_Connection':'VPN Connection'
		}];

/* vpngedit.html */
var _vpngedit=[{
		'_VPN_Gateway':'VPN Gateway',
		'_VPN_Gateway_Name':'VPN Gateway Name',
		'_IKE_Phase_1':'IKE Phase 1',
		'_Negotiation_Mode':'Negotiation Mode',
		'_Proposal':'Proposal',
		'_Encryption':'Encryption',
		'_Authentication':'Authentication',
		'_Key_Group':'Key Group',
		'_SA_Life_Time_Seconds':'SA Life Time (Seconds)',
		'_NAT_Traversal':'NAT Traversal',
		'_Dead_Peer_Detection_DPD':'Dead Peer Detection (DPD)',
		'_Property':'Property',
		'_My_Address':'My Address',
		'_Interface':'Interface',
		'_Domain_Name':'Domain Name',
		'_Secure_Gateway_Address':'Secure Gateway Address',
		'_Authentication_Method':'Authentication Method',
		'_Pre_Shared_Key':'Pre-Shared Key',
		'_Certificate':'Certificate',
		'_See':'See',
		'_My_Certificates':'My Certificates',
		'_Local_ID_Type':'Local ID Type',
		'_Content':'Content',
		'_Peer_ID_Type':'Peer ID Type',
		'_Extended_Authentication':'Extended Authentication',
		'_Enable_Extended_Authentication':'Enable Extended Authentication',
		'_Server_Mode':'Server Mode',
		'_Client_Mode':'Client Mode',
		'_User_Name':'User Name',
		'_Password':'Password'
		}];

/* contra.html */
var _contra=[{
		'_Configuration':'Configuration',
		'_Name':'Name'
		}];

/* contraedit.html */
var _contraedit=[{
		'_Group_Members':'Group Members',
		'_Name':'Name',
		'_Member':'Member'
		}];
		
/* vpnsa.html */
var _vpnsa=[{
		'_Current_IPSec_Security_Associations':'Current IPSec Security Associations',
		'_Name':'Name',
		'_Encapsulation':'Encapsulation',
		'_Policy':'Policy',
		'_Algorithm':'Algorithm',
		'_Up_Time':'Up Time',
		'_Timeout':'Timeout',
		'_Inbound':'Inbound(Bytes)',
		'_Outbound':'Outbound(Bytes)'
		}];

/*----- VPN > SSL VPN -----*/

/* sslvpnac.html */
var _sslvpnac=[{
		'_Configuration':'Configuration',		
		'_Name':'Name',
		'_User_Group':'User/Group',
		'_Application':'Application'
		}];
/* sslvpnacedit.html */
var _sslvpnacedit=[{
		'_Configuration':'Configuration',
		'_Enable':'Enable',
		'_Name':'Name',
		'_Description':'Description',
		'_Optional':'(Optional)',		
		'_User_Group_Optional':'User/Group (Optional)',		
		'_Available':'Available',
		'_Member':'Member',
		'_SSL_Application_List_Optional':'SSL Application List (Optional)',
		'_Network_Extension_Optional':'Network Extension (Optional)',
		'_Enable_Network_Extension':'Enable Network Extension',
		'_Assign_IP_Pool':'Assign IP Pool',
		'_DNS_Server_1':'DNS Server 1',
		'_DNS_Server_2':'DNS Server 2',
		'_Wins_Server_1':'WINS Server 1',
		'_Wins_Server_2':'WINS Server 2',
		'_Network_List':'Network List'
		}];
				
/* sslvpnmonitor.html */
var _sslvpnmonitor=[{
		'_Current_SSL_VPN_Connection':'Current SSL VPN Connection',		
		'_User':'User',
		'_Access':'Access',
		'_Login_Addr':'Login Address',
		'_Connected_Time':'Connected Time',
		'_In_Bytes':'Inbound (Bytes)',
		'_Out_Bytes':'Outbound (Bytes)'
		}];	
			
/* sslvpnglobal.html */
var _sslvpnglobal=[{
		'_Global_Setting':'Global Setting',
		'_Network_Extension_Local_IP':'Network Extension Local IP',		
		'_Message':'Message',
		'_Login_Message':'Login Message',		
		'_Logout_Message':'Logout Message',
		'_Update_Client':'Update Client Virtual Desktop Logo',
		'_To_upload_a_GIF':'To upload a logo file (*.gif/png/jpg), browse to the location of the file and then click Upload.',
		'_File_Path':'File Path:'
		}];	

/*----- VPN > L2TP VPN -----*/

/* l2tps.html */
var _l2tps=[{
		'_Configuration':'Configuration',
		'_Enable_L2TP_Over_IPSec':'Enable L2TP Over IPSec',
		'_VPN_Connection':'VPN Connection',
		'_IP_Address_Pool':'IP Address Pool',
		'_Authentication_Method':'Authentication Method',
		'_Allowed_User':'Allowed User',
		'_Keep_Alive_Timer':'Keep Alive Timer',
		'_seconds':'seconds',
		'_First_DNS':'First DNS Server (Optional)',
		'_Second_DNS':'Second DNS Server (Optional)',
		'_First_WINS':'First WINS Server (Optional)',
		'_Second_WINS':'Second WINS Server (Optional)'
		}];

/* l2tps_sm.html */
var _l2tps_sm=[{
		'_Current_L2TP_Session':'Current L2TP Session',
		'_User_Name':'User Name',
		'_Hostname':'Hostname',
		'_Assigned_IP':'Assigned IP',
		'_Public_IP':'Public IP'
		}];	

/*----- AppPatrol -----*/

/* appgeneral.html */
var _appgeneral=[{
		'_General_Setup':'General Setup',
		'_Enable_Application_Patrol':'Enable Application Patrol',
		'_Registration':'Registration',
		'_Registration_Status':'Registration Status',
		'_Registration_Type':'Registration Type',
		'_Apply_New_Registration':'Apply New Registration',
		'_Signature_Information':'Signature Information',
		'_Current_Version':'Current Version',
		'_Signature_Number':'Signature Number',
		'_Released_Date':'Released Date',
		'_Update_Signatures':'Update Signatures'
		}];
				
/* appCommon.html */
var _appCommon=[{
		'_Common_Protocols':'Common Protocols',
		'_Service':'Service',
		'_Default_Access':'Default Access',
		'_Classify':'Classify',
		'_Modify':'Modify'
		}];

/* appCommon.html */
var _appIM=[{
		'_Instant_Messenger':'Instant Messenger',
		'_Service':'Service',
		'_Default_Access':'Default Access',
		'_Classify':'Classify',
		'_Modify':'Modify'
		}];
				
/* appCommon.html */
var _appP2P=[{
		'_P2P':'Peer to Peer',
		'_Service':'Service',
		'_Default_Access':'Default Access',
		'_Classify':'Classify',
		'_Modify':'Modify'
		}];
				
/* appCommon.html */
var _appVoIP=[{
		'_VoIP':'VoIP',
		'_Service':'Service',
		'_Default_Access':'Default Access',
		'_Classify':'Classify',
		'_Modify':'Modify'
		}];

/* appCommon.html */
var _appStream=[{
		'_Streaming_Protocols':'Streaming Protocols',
		'_Service':'Service',
		'_Default_Access':'Default Access',
		'_Classify':'Classify',
		'_Modify':'Modify'
		}];

/* aplpatroledit.html */
var _aplpatroledit=[{
		'_Service':'Service',
		'_Enable_Service':'Enable Service',
		'_Service_Identification':'Service Identification',
		'_Name':'Name',
		'_Auto':'Auto',
		'_Service_Ports':'Service Ports',
		'_Classification':'Classification',
		'_Service_Port':'Service Port',
		'_Policy':'Policy',
		'_Port':'Port',
		'_Schedule':'Schedule',
		'_User':'User',
		'_From':'From',
		'_To':'To',
		'_Source':'Source',
		'_Destination':'Destination',
		'_Access':'Access',
		'_BWM':'BWM In/Out/Pri',
		'_Log':'Log'
		}];

/* appedit.html */
var _appedit=[{
		'_Configuration':'Configuration',
		'_Bandwidth_Management':'Bandwidth Management',
		'_Inbound':'Inbound',
		'_kbp1':'kbps',
		'_Outbound':'Outbound',
		'_kbp2':'kbps&nbsp;(0 : disabled)',
		'_Priority':'Priority',
		'_MBU':'Maximize Bandwidth Usage',
		'_Enable_Policy':'Enable Policy',
		'_Port':'Port',
		'_any':'(0 : any)',
		'_Schedule':'Schedule',
		'_User':'User',
		'_From':'From',
		'_To':'To',
		'_Source':'Source',
		'_Destination':'Destination',
		'_Access':'Access',
		'_Action_Block':'Action Block',
		'_Login':'Login',
		'_Message':'Message',
		'_Audio':'Audio',
		'_Video':'Video',
		'_File_Transfer':'File-Transfer',
		'_Log':'Log'
		}];

/* aplother.html */
var _aplother=[{
		'_Policy':'Policy',
		'_Port':'Port',
		'_Schedule':'Schedule',
		'_User':'User',
		'_From':'From',
		'_To':'To',
		'_Source':'Source',
		'_Destination':'Destination',
		'_Protocol':'Protocol',
		'_Access':'Access',
		'_BWM':'BWM In/Out/Pri',
		'_Log':'Log'
		}];

/* aplotheredit.html */
var _aplotheredit=[{
		'_Configuration':'Configuration',
		'_Bandwidth_Management':'Bandwidth Management',
		'_Inbound':'Inbound',
		'_Outbound':'Outbound',
		'_kbps1':'kbps',
		'_kbps2':'kbps&nbsp;(0 : disabled)',
		'_MBU':'Maximize Bandwidth Usage',
		'_Enable':'Enable',
		'_Port':'Port',
		'_any':'(0 : any)',
		'_Schedule':'Schedule',
		'_User':'User',
		'_From':'From',
		'_To':'To',
		'_Source':'Source',
		'_Destination':'Destination',
		'_Protocol':'Protocol',
		'_Priority':'Priority',
		'_Access':'Access',
		'_Log':'Log'
		}];
					
/* appStatic.html */
var _appStatic=[{
		'_Options':'Options',
		'_Refresh_Interval':'Refresh Interval',
		'_Display_Protocols':'Display Protocols',
		'_Select_All':'Select All',
		'_Clear_All':'Clear All',
		'_Bandwidth_Statistics':'Bandwidth Statistics',
		'_Protocol_Statistics':'Protocol Statistics',
		'_Service':'Service',
		'_Forwarded_Data':'Forwarded Data(KB)',
		'_Dropped_Data':'Dropped Data(KB)',
		'_Rejected_Data':'Rejected Data(KB)',
		'_Matched_Auto':'Matched Auto Connection',
		'_Matched_Service_Ports':'Matched Service Ports Connection',
		'_Rule':'Rule',
		'_Inbound_Kbps':'Inbound Kbps',
		'_Outbound_Kbps':'Outbound Kbps',
		'_Forwarded_Data':'Forwarded Data(KB)',
		'_Dropped_Data':'Dropped Data(KB)',
		'_Rejected_Data':'Rejected Data(KB)',
		'_Destination':'Destination',
		'_Protocol':'Protocol',
		'_Access':'Access',
		'_Log':'Log'
		}];

/*----- Anti-X > Anti-Virus -----*/
				
/* antivirus.html */
var _antivirus=[{
		'_Configuration':'Configuration',
		'_Enable_Anti_Virus':'Enable Anti-Virus and Anti-Spyware',
		'_Priority':'Priority',
		'_From':'From',
		'_To':'To',
		'_Protocol':'Protocol',
		'_Registration':'Registration',
		'_Registration_Status':'Registration Status',
		'_Registration_Type':'Registration Type',
		'_Apply_New_Registration':'Apply New Registration',
		'_Signature_Information':'Signature Information',
		'_Current_Version':'Current Version',
		'_Signature_Number':'Signature Number',
		'_Released_Date':'Released Date',
		'_Update_Signatures':'Update Signatures'
		}];

/* avedit.html */
var _avedit=[{
		'_Configuration':'Configuration',
		'_Direction':'Direction',
		'_Enable':'Enable',
		'_Log':'Log',
		'_From':'From',
		'_To':'To',
		'_Protocols_to_Scan':'Protocols to Scan',
		'_HTTP':'HTTP',
		'_FTP':'FTP',
		'_SMTP':'SMTP',
		'_POP3':'POP3',
		'_IMAP4':'IMAP4',
		'_Actions_When_Matched':'Actions When Matched',		
		'_Destroy':'Destroy infected file',
		'_Send':'Send windows message',
		'_White_List_Black_List':'White List / Black List Checking',
		'_Bypass_white_list':'Bypass white list checking',
		'_Bypass_black_list':'Bypass black list checking',
		'_File_decompression':'File decompression',
		'_Enable_file_decompression':'Enable file decompression (ZIP and RAR)',
		'_Destroy_compressed_files':'Destroy compressed files that could not be decompressed'
		}];

/* antisetting.html */
var _antiset=[{
		'_General_Setting':'General Setting',
		'_Scan_EICAR':'Scan EICAR',
		'_White_List':'White List',
		'_Enable_White_List':'Enable White List',
		'_Total_Rule':'Total Rule:',
		'_Page':'Page',
		'_File_Pattern':'File Pattern',
		'_Black_List':'Black List',
		'_Enable_Black_List':'Enable Black List',
		'_rules_per_page':'rules per page'
		}];

/* antisetedit.html */
var _antisetedit=[{
		'_Configuration':'Configuration',
		'_Enable':'Enable',
		'_File_Pattern':'File Pattern'
		}];

/* avsignature.html */
var _avsignature=[{
		'_Query_Signatures':'Query Signatures',
		'_Signatures_Search':'Signatures Search',
		'_Query_all_signs':'Query all signatures and export',
		'_Query_Result':'Query Result',
		'_Total_Signature':'Total Signature:',
		'_signatures_per_page':'signatures per page',
		'_Page':'Page',
		'_Name':'Name',
		'_ID':'ID',
		'_Severity':'Severity',
		'_Category':'Category'
		}];
				
/*----- Anti-X > IDP -----*/

/* idpgl.html */
var _idpgl=[{
		'_General_Setup':'General Setup',
		'_Enable_Signature_Detection':'Enable Signature Detection',
		'_Bindings':'Bindings',
		'_Priority':'Priority',	
		'_From':'From',		
		'_To':'To',
		'_IDP_Profile':'IDP Profile',		
		'_Registration':'Registration',
		'_Registration_Status':'Registration Status:',
		'_Registration_Type':'Registration Type:',
		'_Apply_New_Registration':'Apply New Registration',
		'_Signature_Information':'Signature Information',
		'_Current_Version':'Current Version:',
		'_Signature_Number':'Signature Number:',
		'_Released_Date':'Released Date:',
		'_Update_Signatures':'Update Signatures',
		/* idpgl_1.html */
		'_Enable_Anomaly_Detection':'Enable Anomaly Detection',
		'_Anomaly_Profile':'Anomaly Profile',
		/* idpzoneedit page*/
		'_Configuration':'Configuration',
		'_Direction':'Direction',
		'_Profile_Selection':'Profile Selection',
		'_Enable':'Enable',
		'_ADP_Profile':'ADP Profile'
		}];

/* dataiframe.html */
var _dataiframe=[{
		'_GoTo':'GoTo',
		'_Page':'Page'
		}];

/* idppf.html */
var _idppf=[{
		'_Update':'Update',
		'_Profile_Management':'Profile Management',
		'_Name':'Name',
		'_Base_Profile':'Base Profile',
		'_Please_select_IDP_Profile':'Please select one IDP Base Profile.'
		}];

/* idppfedit.html */
var _idppfedit=[{
		'_Name':'Name',
		'_Signature_Group':'Signature Group',
		'_Service':'Service',
		'_Activation':'Activation',
		'_Log':'Log',
		'_Action':'Action',
		'_Message':'Message',
		'_SID':'SID',
		'_Severity':'Severity',
		'_Policy_Type':'Policy Type'		
		}];

/* idpfedat.html */
var _idpfedat=[{		
		'_Name':'Name',
		'_Scan_Detection':'Scan Detection',
		'_Sensitivity':'Sensitivity',
		'_Block_Period':'Block Period',
		'_1_3600_seconds':'(1-3600 seconds)',
		'_Flood_Detection':'Flood Detection',
		'_Activation':'Activation',
		'_Log':'Log',
		'_Action':'Action',
		'_Threshold':'Threshold'
		}];

/* idpfedpa.html */
var _idpfedpa=[{
		'_Name':'Name',
		'_HTTP_Inspection':'HTTP Inspection',
		'_TCP_Decoder':'TCP Decoder',
		'_UDP_Decoder':'UDP Decoder',
		'_ICMP_Decoder':'ICMP Decoder',
		'_Activation':'Activation',
		'_Log':'Log',
		'_Action':'Action'
		}];		

/* idpquery.html */
var _idpquery=[{
		'_Name':'Name',
		'_Query_Signatures':'Query Signatures',
		'_Search_all_custom_signature':'Search all custom signatures',
		'_Optional':'Optional',
		'_Signature_ID':'Signature ID',
		'_Severity':'Severity',
		'_Attack_Type':'Attack Type',
		'_Platform':'Platform',
		'_Service':'Service',
		'_Activation':'Activation',
		'_Log':'Log',
		'_Action':'Action',
		'_Page':'Page:',
		'_Actions_hold':'Action',
		'_Query_Result':'Query Result',
		'_Total_IDP':'Total IDP',
		'_IDP_per_page':'IDP per page',
		'_SID':'SID'
		}];

/* idpcs.html */
var _idpcs=[{
		'_Creating':'Creating',
		'_SID':'SID',
		'_Name':'Name',		
		'_Importing':'Importing',
		'_Import_name':'Import name.rules; custom.rules = device custom signature file.',
		'_File_Path':'File Path'
		}];

/* idpcsedit.html */
var _idpcsedit=[{
		'_Name':'Name',
		'_Signature_ID':'Signature ID',
		'_Information':'Information',
		'_Severity':'Severity',
		'_Platform':'Platform',
		'_All':'All',
		'_Solaris':'Solaris',
		'_Other_Unix':'Other-Unix',
		'_Network_Device':'Network-Device',
		'_Service':'Service',
		'_Policy_Type':'Policy Type',
		'_Frequency':'Frequency',
		'_Threshold':'Threshold',
		'_Packet':'Packet',
		'_Second':'Second',
		'_Header_Options':'Header Options',
		'_Network_Protocol':'Network Protocol',
		'_Type_of_Service':'Type of Service',
		'_Identification':'Identification',
		'_Fragmentation':'Fragmentation',
		'_Reserved_Bit':'Reserved Bit',
		'_Dont_Fragment':'Don\'t Fragment',
		'_More_Fragment':'More Fragment',
		'_Fragment_Offset':'Fragment Offset',
		'_Time_to_Live':'Time to Live',
		'_IP_Options':'IP Options',
		'_Same_IP':'Same IP',
		'_Transport_Protocol':'Transport Protocol',
		'_Port':'Port',
		'_Source_Port':'Source Port',
		'_Destination_Port':'Destination Port',
		'_Flow':'Flow',
		'_Flags':'Flags',
		'_Type':'Type',
		'_Code':'Code',
		'_Reserved':'Reserved',
		'_Sequence_Number':'Sequence Number',
		'_Ack_Number':'Ack Number',
		'_Window_Size':'Window Size',
		'_Payload_Options':'Payload Options',
		'_Payload_Size':'Payload Size',
		'_Byte':'Byte(s)',
		'_Patterns':'Patterns',
		'_Win95_98':'Win95/98',
		'_WinNT':'WinNT',
		'_WinXP_2000':'WinXP/2000',
		'_Linux':'Linux',
		'_FreeBSD':'FreeBSD',
		'_SGI':'SGI',
		'_IPv4':'IPv4',
		'_SYN':'SYN',
		'_FIN':'FIN',
		'_RST':'RST',
		'_PSH':'PSH',
		'_ACK':'ACK',
		'_URG':'URG',
		'_1':'1 (MSB)',
		'_2':'2',
		'_ID':'ID',
		'_Offset':'Offset',
		'_Relative_to_start_of_payload':'Relative to start of payload ',
		'_Content':'Content',
		'_Relative_to_end_of_last_match':'Relative to end of last match ',
		'_Case_insensitive':'Case-insensitive',
		'_Within':'Within ',
		'_Bytes':' bytes',
		'_Decode_as_URI':'Decode as URI'
		}];

/* idpimport.html */
var _idpimport=[{
		'_Custom_Signature':'Custom Signature',
		'_SID':'SID',
		'_Name':'Name'
		}];

/*----- Anti-X > Content Filter -----*/

/* cfilter.html */
var _cfilter=[{
		'_General_Setup':'General Setup',
		'_Enable_Content_Filter':'Enable Content Filter',
		'_Block':'Block web access when no policy is applied',
		'_Policies':'Policies',
		'_Address':'Address',
		'_Schedule':'Schedule',
		'_User':'User',
		'_Filter_Profile':'Filter Profile ',
		'_Message':'Message to display when a site is blocked',
		'_Denied_Access_Message':'Denied Access Message',
		'_Redirect_URL':'Redirect URL',
		'_Registration':'Registration',
		'_Registration_Status':'Registration Status:',
		'_Registration_Type':'Registration Type:',
		'_Apply_New_Registration':'Apply New Registration'
		}];

/* cfilteredit.html */
var _cfilteredit=[{
		'_Configuration':'Configuration',
		'_Schedule':'Schedule',
		'_Address':'Address',
		'_Filter_Profile':'Filter Profile ',
		'_User_Group':'User / Group'
		}];

/* cfprofile.html */
var _cfprofile=[{
		'_Profile_Management':'Profile Management',
		'_Filter_Profile_Name':'Filter Profile  Name'
		}];

/* cfpcyedit.html */
var _cfpcyedit=[{
		'_Categories':'Categories',
		'_Customization':'Customization',
		'_Filter_Profile':'Filter Profile ',
		'_Name':'Name',
		'_Auto':'Auto Web Category Setup',
		'_External':'External Web Filter Service Status:',
		'_Enable':'Enable External Web Filter Service',
		'_Block':'Block',
		'_Log':'Log',
		'_Matched_Web_Pages':'Matched Web Pages',
		'_Unrated_Web_Pages':'Unrated Web Pages',
		'_When':'When Web Filter Server Is Unavailable',
		'_Content':'Content Filter Service Unavailable Timeout',
		'_Seconds':'Seconds',
		'_Select_Categories':'Select Categories',
		'_Select_All_Categories':'Select All Categories',
		'_Clear_All_Categories':'Clear All Categories',
		/* check list */
		'_Adult_Mature_Content':'Adult/Mature Content',
		'_Pornography':'Pornography',
		'_Sex_Education':'Sex Education',
		'_Intimate_Apparel_Swimsuit':'Intimate Apparel/Swimsuit',
		'_Nudity':'Nudity',
		'_Alcohol_Tobacco':'Alcohol/Tobacco',
		'_Illegal_Questionable':'Illegal/Questionable',
		'_Gambling':'Gambling',
		'_Violence_Hate_Racism':'Violence/Hate/Racism',
		'_Weapons':'Weapons',
		'_Abortion':'Abortion',
		'_Hacking':'Hacking',
		'_Phishing':'Phishing',
		'_Arts_Entertainment':'Arts/Entertainment',
		'_Business_Economy':'Business/Economy',
		'_Alternative_Spirituality_Occult':'Alternative Spirituality/Occult',
		'_Illegal_Drugs':'Illegal Drugs',
		'_Education':'Education',
		'_Cultural_Institutions':'Cultural/Charitable Organizations',
		'_Financial_Services':'Financial Services',
		'_Brokerage_Trading':'Brokerage/Trading',
		'_Online_Games':'Online Games',
		'_Government_Legal':'Government/Legal',
		'_Military':'Military',
		'_Political_Activist_Group':'Political/Activist Groups',
		'_Health':'Health',
		'_Computers_Internet':'Computers/Internet',		
		'_Search_Engines_Portals':'Search Engines/Portals',		
		'_Spyware_Malware_Sources':'Spyware/Malware Sources',
		'_Spyware_Effects_Privacy_Concerns':'Spyware Effects/Privacy Concerns',		
		'_Job_Search_Careers':'Job Search/Careers',
		'_News_Media':'News/Media',
		'_Personals_Dating':'Personals/Dating',
		'_Reference':'Reference',
		'_Open_Image_Media_Search':'Open Image/Media Search',
		'_Chat_Instant_Messaging':'Chat/Instant Messaging',
		'_Email':'Email',		
		'_Blogs_Newsgroups':'Blogs/Newsgroups',
		'_Religion':'Religion',		
		'_Social_Networking':'Social Networking',		
		'_Online_Storage':'Online Storage',		
		'_Remote_Access_Tools':'Remote Access Tools',		
		'_Shopping':'Shopping',
		'_Auctions':'Auctions',
		'_Real_Estate':'Real Estate',
		'_Society_Lifestyle':'Society/Lifestyle',		
		'_Sexuality_Alternative_Lifestyles':'Sexuality/Alternative Lifestyles',		
		'_Restaurants_Dining_Food':'Restaurants/Dining/Food',
		'_Sports_Recreation_Hobbies':'Sports/Recreation/Hobbies',
		'_Travel':'Travel',
		'_Vehicles':'Vehicles',
		'_Humor_Jokes':'Humor/Jokes',
		'_Software_Downloads':'Software Downloads',
		'_Pay_to_Surf':'Pay to Surf',
		'_Peer_to_Peer':'Peer-to-Peer',
		'_Streaming_Media_MP3s':'Streaming Media/MP3s',
		'_Proxy_Avoidance':'Proxy Avoidance',
		'_For_Kids':'For Kids',
		'_Web_Advertisements':'Web Advertisements',
		'_Web_Hosting':'Web Hosting',
		/* end check list */
		'_Test1':'Test Web Site Category',
		'_URL_to_test':'URL to test'
		}];

/* cfpcsedit.html */
var _cfpcsedit=[{
		'_Categories':'Categories',
		'_Customization':'Customization',
		'_Filter_Profile':'Filter Profile ',
		'_Name':'Name',
		'_Customization_Setup':'Customization Setup',
		'_Enable':'Enable Web site customization.',
		'_Allow1':'Allow web traffic for trusted web sites only.',
		'_Restricted_Web_Features':'Restricted Web Features',
		'_Block':'Block',
		'_ActiveX':'ActiveX',
		'_Java':'Java',
		'_Cookies':'Cookies',
		'_Web_Proxy':'Web Proxy',
		'_Allow2':'Allow Java/ActiveX/Cookies/Web proxy to trusted web sites.',
		'_Trusted_Web_Sites':'Trusted Web Sites',
		'_Add_Trusted_Web_Site':'Add Trusted Web Site',
		'_Forbidden_Web_Sites':'Forbidden Web Sites',
		'_Add_Forbidden_Web_Site':'Add Forbidden Web Site',
		'_Blocked_URL_Keywords':'Blocked URL Keywords',
		'_Add_Blocked_URL_Keyword':'Add Blocked URL Keyword'
		}];	

/* cfcache.html */
var _cfcache=[{
		'_URL_Cache_Entry':'URL Cache Entry',
		'_Total_cache_entries':'Total cache entries:',
		'_entries_per_page':'entries per page',
		'_Page':'Page',
		'_Category':'Category',
		'_URL':'URL',
		'_Remaining_Time_minutes':'Remaining Time (minutes)',
		'_Remove':'Remove',
		'_URL_Cache_Setup':'URL Cache Setup',
		'_Maximum_TTL':'Maximum TTL',
		'_hours':'(1~720 hours)'
		}];

/*----- Device HA -----*/

/* vrrpgrp.html */
var _vrrpgrp=[{
		'_Configuration':'Configuration',
		'_Enable':'Enable',
		'_Link_Monitoring':'Link Monitoring',
		'_VRRP_Group':'VRRP Group',
		'_Name':'Name',
		'_VRID':'VRID',
		'_Role':'Role',
		'_Interface':'Interface',
		'_Note_LINK':'Note:If a master ZyWALL VRRP interface\'s link is down, shut down all of the master\'s VRRP interfaces so the backup ZyWALL takes over completely.',
		'_HA_Status':'HA Status'
		}];

/* vrrpgedit.html */
var _vrrpgedit=[{
		'_Basic_Setting':'Basic Setting',
		'_Enable':'Enable',
		'_Name':'Name',
		'_VRID':'VRID',
		'_Description':'Description',
		'_Optional':'(Optional)',
		'_VRRP_Interface':'VRRP Interface',
		'_Role':'Role',
		'_Master':'Master',
		'_Backup':'Backup',
		'_Priority':'Priority',
		'_range_check_for_backup':'range check for backup:',
		'_Preempt':'Preempt',
		'_Manage_IP':'Manage IP',
		'_Manage_IP_Subnet_Mask':'Manage IP Subnet Mask',
		'_Authentication':'Authentication',
		'_None':'None',
		'_Text':'Text',
		'_IP_AH_MD5':'IP AH (MD5)',
		'_Authentication_key':'Authentication key'
		}];

/* devhasync.html */
var _devhasync=[{
		'_Authentication':'Authentication',
		'_Password':'Password',
		'_Synchronize_from':'Synchronize from',
		'_IP_or_FQDN':'(IP or FQDN)',
		'_on_port':'on port',
		'_Auto_Synchronize':'Auto Synchronize',
		'_Interval':'Interval',
		'_minutes':'minutes'
		}];
		
/* dha.html */
var _dha=[{
		'_Synchronize_now':'ZyWALL Synchronize now',
		'_Rendering':'Rendering...'
		}];
		
/*----- Object > User/Group -----*/

/* users.html */
var _users=[{
		'_Configuration':'Configuration',
		'_User_Name':' User Name',
		'_Description':' Description'
		}];

/* usersedit.html */
var _usersedit=[{
		'_User_Configuration':'User Configuration',
		'_User_Name':'User Name',
		'_User_Type':'User Type',
		'_Password':'Password',
		'_Retype':'Retype',
		'_Description':'Description',
		'_Lease_Time':'Lease Time',
		'_Reauthentication_Time':'Reauthentication Time',
		'_minutes_is_unlimited':'(0-1440 minutes, 0 is unlimited)'
		}];

/* grps.html */
var _grps=[{
		'_Configuration':'Configuration',
		'_Group_Name':'Group Name',
		'_Description':'Description',
		'_Member':'Member'
		}];

/* grpsedit.html */
var _grpsedit=[{
		'_Configuration':'Configuration',
		'_Name':'Name',
		'_Description':'Description',
		'_Member':'Member',
		'_Optional':'(Optional)'
		}];

/* usrset.html */
var _usrset=[{
		'_User_Default_Setting':'User Default Setting',
		'_User_Type':'User Type',
		'_Lease_Time':'Lease Time',
		'_minutes':'minutes',
		'_minutes_is_unlimited':'(0-1440 minutes, 0 is unlimited)',
		'_Reauthentication_Time':'Reauthentication Time',
		'_User_Logon_Setting':'User Logon Setting',
		'_Limit1':'Limit the number of simultaneous logons for administration account',
		'_Maximum1':'Maximum number per administration account',
		'_Limit2':'Limit the number of simultaneous logons for access account',
		'_Maximum2':'Maximum number per access account',
		'_User_Lockout_Setting':'User Lockout Setting',
		'_Enable_logon_retry_limit':'Enable logon retry limit',
		'_Maximum_retry_count':'Maximum retry count',
		'_Lockout_period':'Lockout period',
		'_User_Miscellaneous_Settings':'User Miscellaneous Settings',
		'_Allow':'Allow renewing lease time automatically',
		'_Enable_user_idle_detection':'Enable user idle detection',
		'_User_idle_timeout':'User idle timeout',
		'_Force_User_Authentication_Policy':'Force User Authentication Policy',
		'_Total_Policy':'Total Policy',
		'_Policy_per_page':'Policy per page',
		'_Page':'Page',
		'_Schedule':'Schedule',
		'_Source':'Source',
		'_Destination':'Destination',
		'_Authenticate':'Authenticate'
		}];

/* usrsetedit.html */
var _usrsetedit=[{
		'_Configuration':'Configuration',
		'_Enable':'Enable',
		'_Description':'Description',
		'_Optional':'(Optional)',
		'_Authentication':'Authentication',
		'_Criteria':'Criteria',
		'_Source_Address':'Source Address',
		'_Destination_Address':'Destination Address',
		'_Schedule':'Schedule'
		}];

/*----- Object > Address -----*/

/* address.html */
var _address=[{
		'_Configuration':'Configuration',
		'_Name':'Name',
		'_Type':'Type',
		'_Address':'Address'
		}];

/* addredit.html */
var _addredit=[{
		'_Configuration':'Configuration',
		'_Name':'Name',
		'_Address_Type':'Address Type',
		'_Network':'Network',
		'_Netmask':'Netmask',
		'_IP_Address':'IP Address',
		'_Starting_IP_Address':'Starting IP Address',
		'_End_IP_Address':'End IP Address'
		}];
				
/* addrgps.html */
var _addrgps=[{
		'_Configuration':'Configuration',
		'_Name':'Name',
		'_Description':'Description'
		}];

/* addrgpsedit.html */
var _addrgpsedit=[{
		'_Group_Members':'Group Members',
		'_Name':'Name',
		'_Description':'Description'
		}];

/*----- Object > Service -----*/

/* service.html */
var _service=[{
		'_Configuration':'Configuration',
		'_Total_Services':'Total Services',
		'_services_per_page':'services per page',
		'_Page':'Page',
		'_Name':'Name',
		'_Content':'Content'
		}];

/* svredit.html */
var _svredit=[{
		'_Configuration':'Configuration',
		'_Name':'Name',
		'_IP_Protocol':'IP Protocol',
		'_Starting_Port':'Starting Port',
		'_ICMP_Type':'ICMP Type',
		'_IP_Protocol_Number':'IP Protocol Number',
		'_Ending_Port':'Ending Port'
		}];

/* svrgrp.html */
var _svrgrp=[{
		'_Configuration':'Configuration',
		'_Name':'Name',
		'_Description':'Description'
		}];


/* svrgrpedit.html */
var _svrgrpedit=[{
		'_Configuration':'Configuration',
		'_Name':'Name',
		'_Description':'Description'
		}];

/*----- Object > Schedule -----*/

/* schedule.html */
var _schedule=[{
		'_One_Time':'One Time',
		'_Name':'Name',
		'_Start_Day':'Start Day',
		'_Stop_Day':'Stop Day',
		'_Time':'Time',
		'_Recurring':'Recurring',
		'_Start_Time':'Start Time',
		'_Stop_Time':'Stop Time'
		}];

/* schedit.html */
var _schedit=[{
		'_Configuration':'Configuration',
		'_Name':'Name',
		'_Day_Time':'Day Time',
		'_Item':'Item',
		'_Date':'Date',
		'_Time':'Time',
		'_Year':'Year',
		'_Month':'Month',
		'_Day':'Day',
		'_Hour':'Hour',
		'_minute':'Minute',
		'_Start':'Start',
		'_Stop':'Stop',
		'_Weekly':'Weekly',
		'_Week_Days':'Week Days',
		'_Monday':'Monday',
		'_Tuesday':'Tuesday',
		'_Wednesday':'Wednesday',
		'_Thursday':'Thursday',
		'_Friday':'Friday',
		'_Saturday':'Saturday',
		'_Sunday':'Sunday',
		/* Inline object. */
		'_Type':'Type'
		}];
			
/*----- Object > AAA Server -----*/

/* activeDir_d.html */
var _ad=[{
		'_Default':'Default',
		'_Group':'Group',
		'_Configuration':'Configuration',
		'_Host':'Host',
		'_IP_FQDN':'(IP or FQDN)',
		'_Port':'Port',
		'_Bind_DN':'Bind DN',
		'_Optional':'(Optional)',
		'_Password':'Password',
		'_Base_DN':'Base DN',
		'_CN_Identifier':'CN Identifier',
		'_Search_time_limit':'Search time limit',
		'_Use_SSL':'Use SSL'
		}];
	      
/* activeDir_g.html */
var _adg=[{
		'_Default':'Default',
		'_Group':'Group',
		'_Configuration':'Configuration',
		'_Group_Name':'Group Name'
		}];

/* adgedit.html */
var _adgedit=[{
		'_Default':'Default',
		'_Group':'Group',
		'_Configuration':'Configuration',
		'_Name':'Name',
		'_Port':'Port',
		'_Bind_DN':'Bind DN',
		'_Optional':'(Optional)',
		'_Password':'Password',
		'_Base_DN':'Base DN',
		'_CN_Identifier':'CN Identifier',
		'_Search_time_limit':'Search time limit',
		'_Use_SSL':'Use SSL',
		'_Host_Members':'Host Members',
		'_Members':'Members(IP or FQDN)'
		}];

/* aldapd.html */
var _aldapd=[{
		'_Default':'Default',
		'_Group':'Group',
		'_Configuration':'Configuration',
		'_Host':'Host',
		'_IP_or_FQDN':'(IP or FQDN)',
		'_Port':'Port',
		'_Bind_DN':'Bind DN',
		'_Optional':'(Optional)',
		'_Password':'Password',
		'_Base_DN':'Base DN',
		'_CN_Identifier':'CN Identifier',
		'_Search_time_limit':'Search time limit',
		'_Use_SSL':'Use SSL'
		}];

/* aldapg.html */
var _aldapg=[{
		'_Configuration':'Configuration',
		'_Default':'Default',
		'_Group':'Group',
		'_Group_Name':'Group Name'
		}];

/* aldapgedit.html */
var _aldapgedit =[{
		'_Configuration':'Configuration',
		'_Default':'Default',
		'_Group':'Group',
		'_Name':'Name',
		'_Port':'Port',
		'_Bind_DN':'Bind DN',
		'_Optional':'(Optional)',
		'_Password':'Password',
		'_Base_DN':'Base DN',
		'_CN_Identifier':'CN Identifier',
		'_Search_time_limit':'Search time limit',
		'_Use_SSL':'Use SSL',
		'_Host_Members':'Host Members',
		'_Members':'Members(IP or FQDN)'
		}];

/* aradiusd.html */
var _aradiusd=[{
		'_Configuration':'Configuration',
		'_Default':'Default',
		'_Group':'Group',
		'_Host':'Host',
		'_IP_or_FQDN':'(IP or FQDN)',
		'_Authentication_Port':'Authentication Port',
		'_Key':'Key',
		'_Timeout':'Timeout'
		}];

/* aradiusg.html */
var _aradiusg=[{
		'_Configuration':'Configuration',
		'_Default':'Default',
		'_Group':'Group',
		'_Group_Name':'Group Name'
		}];

/* aradiusgedit.html */
var _aradiusgedit=[{
		'_Configuration':'Configuration',
		'_Default':'Default',
		'_Group':'Group',
		'_Name':'Name',
		'_Host_Members':'Host Members',
		'_Authentication_Port':'Authentication Port',
		'_Key':'Key',
		'_Timeout':'Timeout',
		'_Members':'Members'
		}];
				  	
/*----- Object > Auth. method -----*/
		
/* Authmeth.html */
var _Authmeth=[{
		'_Configuration':'Configuration',
		'_Method_Name':'Method Name',
		'_Method_List':'Method List'
		}];

/* authedit.html */
var _authedit=[{
		'_Configuration':'Configuration',
		'_Name':'Name',
		'_Method_List':'Method List'
		}];

/*----- Object > Certificate -----*/

/* cert.html */
var _cert=[{
		'_PKI_Storage_Space_in_Use':'PKI Storage Space in Use',
		'_My_Certificates_Setting':'My Certificates Setting',
		'_Name':'Name',
		'_Type':'Type',
		'_Subject':'Subject',
		'_Issuer':'Issuer',
		'_Valid_From':'Valid From',
		'_Valid_To':'Valid To'
		}];

/* certimpt.html */
var _certimpt=[{
		'_Please':'Please specify the location of the certificate file to be imported. The certificate file must be in one of the following formats.',
		'_Binary1':'Binary X.509',
		'_PEM1':'PEM (Base-64) encoded X.509',
		'_Binary2':'Binary PKCS#7',
		'_PEM2':'PEM (Base-64) encoded PKCS#7',
		'_Binary3':'Binary PKCS#12',
		'_For':'For my certificate importation to be successful, a certification request corresponding to the imported certificate must already exist on ZyWALL. After the importation, the certification request will automatically be deleted.',
		'_File_Path':'File Path:',
		'_Password':'Password:',
		'_PKCS':'(PKCS#12 only)'
		}];

/* certcrat.html */
var _certcrat=[{
		'_Name':'Name',
		'_Subject_Information':'Subject Information',
		'_Common_Name':'Common Name',
		'_Host_IP_Address':'Host IP Address',
		'_Host_Domain_Name':'Host Domain Name',
		'_E_Mail':'E-Mail',
		'_Organizational_Unit':'Organizational Unit',
		'_Optional':'(Optional)',
		'_Organization':'Organization',
		'_Country':'Country',
		'_Key_Type':'Key Type',
		'_Key_Length':'Key Length',
		'_bits':'bits',
		'_Enrollment_Options':'Enrollment Options',
		'_Create1':'Create a self-signed certificate',
		'_Create2':'Create a certification request and save it locally for later manual enrollment',
		'_Create3':'Create a certification request and enroll for a certificate immediately online',
		'_Enrollment_Protocol':'Enrollment Protocol',
		'_CA_Server_Address':'CA Server Address',
		'_CA_Certificate':'CA Certificate',
		'_See':'See',
		'_Trusted_CAs':'Trusted CAs',
		'_Request_Authentication':'Request Authentication',
		'_Reference_Number':'Reference Number',
		'_Key':'Key'
		}];

/* certself.html */
var _certself=[{
		'_Name':'Name',
		'_Certification_Path':'Certification Path',
		'_Certificate_Information':'Certificate Information',
		'_Type':'Type',
		'_Version':'Version',
		'_Serial_Number':'Serial Number',
		'_Subject':'Subject',
		'_Issuer':'Issuer',
		'_Signature_Algorithm':'Signature Algorithm',
		'_Valid_From':'Valid From',
		'_Valid_To':'Valid To',
		'_Key_Algorithm':'Key Algorithm',
		'_Subject_Alternative_Name':'Subject Alternative Name',
		'_Key_Usage':'Key Usage',
		'_Basic_Constraint':'Basic Constraint',
		'_MD5_Fingerprint':'MD5 Fingerprint',
		'_SHA1_Fingerprint':'SHA1 Fingerprint',
		'_Certificate':'Certificate in PEM (Base-64) Encoded Format',
		'_Password':'Password:'
		}];
		
/* trscert.html */
var _trscert=[{
		'_PKI_Storage_Space_in_Use':'PKI Storage Space in Use',
		'_Trusted_Certificates_Setting':'Trusted Certificates Setting',
		'_Name':'Name',
		'_Subject':'Subject',
		'_Issuer':'Issuer',
		'_Valid_From':'Valid From',
		'_Valid_To':'Valid To'
		}];

/* trsedit.html */
var _trsedit=[{
		'_Name':'Name',
		'_Certification_Path':'Certification Path',
		'_Certificate_Validation':'Certificate Validation',
		'_Enable':'Enable X.509v3 CRL Distribution Points  and OCSP checking',
		'_OCSP_Server':'OCSP Server',
		'_URL':'URL',
		'_ID':'ID',
		'_Password':'Password',
		'_LDAP_Server':'LDAP Server',
		'_Address':'Address',
		'_Port':'Port',
		'_Certificate_Information':'Certificate Information',
		'_Type':'Type',
		'_Version':'Version',
		'_Serial_Number':'Serial Number',
		'_Subject':'Subject',
		'_Issuer':'Issuer',
		'_Signature_Algorithm':'Signature Algorithm',
		'_Valid_From':'Valid From',
		'_Valid_To':'Valid To',
		'_Key_Algorithm':'Key Algorithm',
		'_Subject_Alternative_Name':'Subject Alternative Name',
		'_Key_Usage':'Key Usage',
		'_Basic_Constraint':'Basic Constraint',
		'_MD5_Fingerprint':'MD5 Fingerprint',
		'_SHA1_Fingerprint':'SHA1 Fingerprint',
		'_Certificate':'Certificate in PEM (Base-64) Encoded Format'
		}];

/* trsimpt.html */
var _trsimpt=[{
		'_Please':'Please specify the location of the certificate file to be imported. The certificate file must be in one of the following formats.',
		'_Binary1':'Binary X.509',
		'_PEM1':'PEM (Base-64) encoded X.509',
		'_Binary2':'Binary PKCS#7',
		'_PEM2':'PEM (Base-64) encoded PKCS#7',
		'_File_Path':'File Path:'
		}];
		
/*----- Object > ISP Account -----*/

/* Account.html */
var _Account=[{
		'_Configuration':'Configuration',
		'_Profile_Name':'Profile Name',
		'_Protocol':'Protocol',
		'_Authentication_Type':'Authentication Type',
		'_User_Name':'User Name'
		}];

/* acctedit.html */
var _acctedit=[{
		'_Configuration':'Configuration',
		'_Profile_Name':'Profile Name',
		'_Protocol':'Protocol',
		'_Encryption_Method':'Encryption Method',
		'_Authentication_Type':'Authentication Type',
		'_User_Name':'User Name',
		'_Password':'Password',
		'_Connection_ID':'Connection ID',	
		'_Retype_to_confirm':'Retype to confirm',	
		'_Server_IP':'Server IP',
		'_IP_Address':'(IP Address)',
		'_Optional':'(Optional)',
		'_Service_Name':'Service Name',
		'_Compression':'Compression',
		'_On':'On',
		'_Off':'Off',
		'_Idle_timeout':'Idle timeout',
		'_Seconds':'(Seconds)'
		}];

/*----- Object > SSL Application -----*/

/* application.html */
var _application=[{
		'_Configuration':'Configuration',
		'_Name':'Name',
		'_Address':'Address',
		'_Type':'Type'
		}];
		
/* applicationedit.html */
var _applicationedit=[{
		'_Object':'Object',
		'_Type':'Type',
		'_Web_Application':'Web Application',
		'_Name':'Name',
		'_URL':'URL',
		'_Server_Type':'Server Type',
		'_File_Sharing':'File Sharing',	
		'_Entry_Point':'Entry Point',
		'_Optional':'(Optional)',
		'_NameC':'Name',
		'_Shared_Path':'Shared Path',	
		'_Web_Page_Encryption':'Web Page Encryption'
		}];	

/*----- System > Host Name -----*/

/* hostname.html */
var _hostname=[{
		'_General_settings':'General settings',
		'_System_Name':'System Name',
		'_Optional':'(Optional)',
		'_Domain_Name':'Domain Name'
		}];

/*----- System > Date/Time -----*/

/* myclock.html */
var _myclock=[{
		'_Current_Time_and_Date':'Current Time and Date',
		'_Current_Time':'Current Time',
		'_Current_Date':'Current Date',
		'_Time_and_Date_Setup':'Time and Date Setup',
		'_Manual':'Manual',
		'_New_Time':'New Time (hh:mm:ss)',
		'_New_Date':'New Date (yyyy-mm-dd)',
		'_Get_from_Time_Server':'Get from Time Server',
		'_Time_Server_Address':'Time Server Address*',
		'_Optional1':'*Optional. There is a pre-defined NTP time server list.',
		'_Time_Zone_Setup':'Time Zone Setup',
		'_Time_Zone':'Time Zone',
		'_Enable_Daylight_Saving':'Enable Daylight Saving',
		'_Start_Date':'Start Date',
		'_End_Date':'End Date',
		'_Offset':'Offset',
		'_hours':'hours',
		'_of':'of',
		'_at':'at'
		}];

/*----- System > Console Speed -----*/

/* baudrate.html */
var _baudrate=[{
		'_Configuration':'Configuration',
		'_Console_Port_Speed':'Console Port Speed'
		}];

/*----- System > DNS -----*/

/* dns.html */
var _dns=[{
		'_DNS_Server':'DNS Server',
		'_Address_PTR_Record':'Address/PTR Record',
		'_IP_Address':'IP Address',
		'_Domain_Zone':'Domain Zone',
		'_From':'From',
		'_Domain_Zone_Forwarder':'Domain Zone Forwarder',
		'_MX_Record':'MX Record (for My FQDN)',
		'_Domain_Name':'Domain Name',
		'_Service_Control':'Service Control',
		'_Zone':'Zone',
		'_Address':'Address',
		'_FQDN':'FQDN',
		'_IP_FQDN':'IP/FQDN',
		'_Action':'Action'
		}];

/* adnsedit.html */
var _adnsedit=[{
		'_Configuration':'Configuration',
		'_IP_Address':'IP Address',
		'_FQDN':'FQDN'
		}];

/* nsdnsedit.html */
var _nsdnsedit=[{
		'_Configuration':'Configuration',
		'_Domain_Zone':'Domain Zone',
		'_DNS_Server':'DNS Server',
		'_DNS_Server1':'DNS Server(s) from ISP',
		'_First_DNS_Server':'First DNS Server',
		'_Second_DNS_Server':'Second DNS Server',
		'_Third_DNS_Server':'Third DNS Server',
		'_Public_DNS_Server':'Public DNS Server',
		'_Private_DNS_Server':'Private DNS Server'
		}];

/* mxdnsedit.html */
var _mxdnsedit=[{
		'_Configuration':'Configuration',
		'_Domain_Name':'Domain Name',
		'_IP_Address_FQDN':'IP Address/FQDN'
		}];

/* dnsedit.html */
var _dnsedit=[{
		'_Service_Control':'Service Control',
		'_Address_Object':'Address Object',
		'_Zone':'Zone',
		'_Action':'Action'
		}];

/*----- System > WWW -----*/

/* buinsrv.html */
var _buinsrv=[{
		'_HTTPS':'HTTPS',
		'_Enable':'Enable ',
		'_Server_Port':'Server Port',
		'_Authenticate_Client_Certificates':'Authenticate Client Certificates',
		'_See':'See',
		'_Trusted_CAs':'Trusted CAs',
		'_Server_Certificate':'Server Certificate',
		'_My_Certificates':'My Certificates',
		'_Redirect_HTTP_to_HTTPS':'Redirect HTTP to HTTPS',
		'_Admin_Service_Control':'Admin Service Control',
		'_Zone':'Zone',
		'_Address':'Address',
		'_Action':'Action',
		'_User_Service_Control':'User Service Control',
		'_HTTP':'HTTP',	
		'_Authentication':'Authentication',
		'_Client_Authentication_Method':'Client Authentication Method'
		}];

/* httpsedit.html */
var _httpsedit=[{
		'_Admin_Service_Control':'Admin Service Control',
		'_Address_Object':'Address Object',
		'_Zone':'Zone',
		'_Action':'Action'
		}];

/* httpsuseredit.html */
var _httpsuseredit=[{
		'_User_Service_Control':'User Service Control',
		'_Address_Object':'Address Object',
		'_Zone':'Zone',
		'_Action':'Action'
		}];

/* wwwedit.html */
var _wwwedit=[{
		'_Admin_Service_Control':'Admin Service Control',
		'_Address_Object':'Address Object',
		'_Zone':'Zone',
		'_Action':'Action'
		}];

/* wwwuseredit.html */
var _wwwuseredit=[{
		'_User_Service_Control':'User Service Control',
		'_Address_Object':'Address Object',
		'_Zone':'Zone',
		'_Action':'Action'
		}];

/*----- System > SSH -----*/

/* ssh.html */
var _ssh=[{
		'_SSH':'SSH',
		'_Enable':'Enable',
		'_Version_1':'Version 1',
		'_Server_Port':'Server Port',
		'_Server_Certificate':'Server Certificate',
		'_See':'See',
		'_My_Certificates':'My Certificates',
		'_Service_Control':'Service Control',
		'_Zone':'Zone',
		'_Address':'Address',
		'_Action':'Action'	
		}];

/* sshedit.html */
var _sshedit=[{
		'_Service_Control':'Service Control',
		'_Address_Object':'Address Object',
		'_Zone':'Zone',
		'_Action':'Action'
		}];

/*----- System > Telnet -----*/

/* telnet.html */
var _telnet=[{
		'_TELNET':'TELNET',
		'_Enable':'Enable',
		'_Server_Port':'Server Port',
		'_Service_Control':'Service Control',
		'_Zone':'Zone',
		'_Address':'Address',
		'_Action':'Action'
		}];

/* telnetedit.html */
var _telnetedit=[{
		'_Service_Control':'Service Control',
		'_Address_Object':'Address Object',
		'_Zone':'Zone',
		'_Action':'Action'
		}];
		
/*----- System > FTP -----*/

/* ftp.html */
var _ftp=[{
		'_FTP':'FTP',
		'_Enable':'Enable',
		'_TLS_required':'TLS required',
		'_Server_Port':'Server Port',
		'_Server_Certificate':'Server Certificate',
		'_See':'See',
		'_My_Certificates':'My Certificates',
		'_Service_Control':'Service Control',
		'_Zone':'Zone',
		'_Address':'Address',
		'_Action':'Action'
		}];

/* ftpedit.html */
var _ftpedit=[{
		'_Service_Control':'Service Control',
		'_Address_Object':'Address Object',
		'_Zone':'Zone',
		'_Action':'Action'
		}];

/*----- System > SNMP-----*/

/* snmp.html */
var _snmp=[{
		'_SNMP_Configuration':'SNMP Configuration',
		'_Enable':'Enable',
		'_Server_Port':'Server Port',
		'_Get_Community':'Get Community',
		'_Set_Community':'Set Community',
		'_Trap':' Trap:',
		'_Community':'Community',
		'_Destination':'Destination',
		'_Optional':'(Optional)',
		'_Service_Control':'Service Control',
		'_Address':'Address',
		'_Zone':'Zone',
		'_Action':'Action'
		}];

/* snmpedit.html */
var _snmpedit=[{
		'_Service_Control':'Service Control',
		'_Address_Object':'Address Object',
		'_Zone':'Zone',
		'_Action':'Action'
		}];

/*----- System > Dial-in Mgmt.-----*/

/* dialin.html */
var _dialin=[{
		'_Dial_in_Server_Properties':'Dial-in Server Properties',
		'_Enable':'Enable',
		'_Description':'Description',
		'_Optional':'(Optional)',
		'_Mute':'Mute',
		'_Answer_Rings':'Answer Rings',
		'_Rings':'(Rings)',
		'_Port_Speed':'Port Speed',
		'_Initial_String':'Initial String'
		}];
	
/*----- System > Vantage CNM -----*/
	
/* cnm.html */
var _cnm=[{
		'_Vantage_CNM':'Vantage CNM',
		'_Enable':'Enable',
		'_Server_IP_Address_FQDN':'Server IP Address/FQDN',
		'_Transfer_Protocol':'Transfer Protocol',
		'_Device_Management_IP':'Device Management IP',
		'_Custom_IP':'Custom IP',
		'_Keepalive_Interval':'Keepalive Interval',
		'_seconds':'seconds',
		'_Periodic_Inform':'Periodic Inform',
		'_Interval':'Interval',
		'_HTTPS_Authentication':'HTTPS Authentication',
		'_Enable_Vantage':'Enable Vantage',
		'_Vantage_Certificate':'Vantage Certificate',
		'_See':'See',
		'_Trusted_CAs':'Trusted CAs'
		}];

/*----- System > Language -----*/

/* language.html */
var _language = [{
		'_Configuration':'Configuration',
		'_Language_Setting':'Language Setting'
		}];

/*----- Maintenance > File Manager -----*/

/* configfile.html */
var _configfile=[{
		'_Configuration_Files':'Configuration Files',
		'_Select_the_file':'Select the file',
		'_File_Name':'File Name',
		'_Size':'Size',
		'_Modify':'Last Modified',
		'_Upload_Configuration_File':'Upload Configuration File',
		'_To_upload_a_configuration':'To upload a configuration file, browse to the location of the file (.conf) and then click Upload.',
		'_File_Path':'File Path'
		}];

/* editfile.html */
var _editfile=[{
		'_Copy_File':'Copy File',
		'_Rename':'Rename', 
		'_Source_file':'Source file : ',
		'_Target_file':'Target file : '
		}];
		
/* fwfile.html */
var _fwfile=[{
		'_Boot_Module':'Boot Module',
		'_Current_Version':'Current Version',
		'_Released_Date':'Released Date',
		'_To_upload_firmware_package':'To upload firmware package, browse to the location of the file and then click Upload.',
		'_File_Path':'File Path',
		'_FW_Version':'Version',
		'_FW_Upload':'Upload File'
		}];

/* shellfile.html */
var _shellfile=[{
		'_Shell_Scripts':'Shell Scripts',
		'_Select_the_file':'Select the file',
		'_File_Name':'File Name',
		'_Size':'Size',
		'_Modify':'Last Modified',
		'_Upload_Shell_Script':'Upload Shell Script',
		'_To_upload_a_shell_script':'To upload a shell script, browse to the location of the file (.zysh) and then click Upload.',
		'_File_Path':'File Path'
		}];

/* edscriptfile.html */
var _edscriptfile=[{
		'_Copy_File':'Copy File', 
		'_Rename':'Rename',
		'_Source_file':'Source file : ',
		'_Target_file':'Target file : '
		}];

/*----- Maintenance > Log -----*/

/* viewlogs.html */
var _viewlogs=[{
		'_Logs':'Logs',
		'_Display':'Display',
		'_Priority':'Priority',
		'_Source_Address':'Source Address',
		'_Destination_Address':'Destination Address',
		'_Service':'Service',
		'_Keyword':'Keyword',
		'_Total_logging_entries':'Total logging entries:',
		'_entries_per_page':'entries per page',
		'_Page':'Page',
		'_Time':'Time',
		'_Category':'Category',
		'_Message':'Message',
		'_Source':'Source',
		'_Destination':'Destination',
		'_Note':'Note'
		}];

/* errCode.html */
var _errCode=[{
		'_Certificate':'Certificate Path Verification Failure Reason Code Table',
		'_Code':'Code',
		'_Description':'Description'
		}];
		
/* logsetting.html */
var _logsetting=[{
		'_Log_Setting':'Log Setting',
		'_Name':'Name',
		'_Log_Format':'Log Format',
		'_Summary':'Summary',
		'_Modify':'Modify'
		}];

/* intermail.html */
var _intermail=[{
		'_E_mail_Server_1':'E-mail Server 1',
		'_Active':'Active',
		'_Mail_Server':'Mail Server',
		'_Outgoing':'(Outgoing SMTP Server Name or IP Address)',
		'_Mail_Subject':'Mail Subject',
		'_Send_From':'Send From',
		'_E_Mail_Address':'(E-Mail Address)',
		'_Send_Log_to':'Send Log to',
		'_Send_Alerts_to':'Send Alerts to',
		'_Sending_Log':'Sending Log',
		'_Day_for_Sending_Log':'Day for Sending Log',
		'_Time_for_Sending_Log':'Time for Sending Log',
		'_Hour':'(Hour)',
		'_Minute':'(Minute)',
		'_SMTP_Authentication':'SMTP Authentication',
		'_User_Name':'User Name',
		'_Password':'Password',
		'_E_mail_Server_2':'E-mail Server 2',
		'_Active_Log_and_Alert':'Active Log and Alert',
		'_Log_Category':'Log Category',
		'_System_Log':'System Log',		
		'_Log_Consolidation':'Log Consolidation',
		'_Log_Consolidation_Interval':'Log Consolidation Interval (seconds)'
		}];

/* remsvr.html */
var _remsvr=[{
		'_Log':'Log Settings for Remote Server ',
		'_Active':'Active',
		'_Log_Format':'Log Format',
		'_ZyXEL_VRPT':'ZyXEL VRPT.',
		'_Server_Address':'Server Address',
		'_Server':'(Server Name or IP Address)',
		'_Log_Facility':'Log Facility',
		'_Active_Log':'Active Log',
		'_Log_Category':'Log Category',
		'_Selection':'Selection'
		}];

/* logsummary.html */
var _logsummary=[{
		'_Active_Log_Summary':'Active Log Summary',
		'_Log_Category':'Log Category',
		'_System_log':'System log',
		'_E_mail_Server_1':'E-mail Server 1',
		'_E_mail_Server_2':'E-mail Server 2',
		'_Remote_Server_1':'Remote Server 1',
		'_Remote_Server_2':'Remote Server 2',
		'_Remote_Server_3':'Remote Server 3',
		'_Remote_Server_4':'Remote Server 4',
		'_E_mail':'E-mail',
		'_Syslog':'Syslog'
		}];

/*----- Maintenance > Traffic -----*/

/* report.html */
var _report=[{
		'_Data_Collection':'Data Collection',
		'_Collect_Statistics':'Collect Statistics',
		'_Reports':'Traffics',
		'_Interface':'Interface',
		'_Report_Type':'Traffic Type',
		'_IP_Address_User':'IP Address/User',
		'_Direction':'Direction',
		'_Amount':'Amount',
		'_Service_Port':'Service/Port',
		'_Web_Site':'Web Site',
		'_Hits':'Hits'
		}];

/* session.html */
var _session=[{
		'_Session':'Session',
		'_View':'View',
		'_User':'User',
		'_Protocol':'Protocol',
		'_Source':'Source',
		'_Destination':'Destination',
		'_Rx':'Rx',
		'_Tx':'Tx',
		'_Duration':'Duration',
		'_Service':'Service',
		'_Source_Address':'Source Address',
		'_Destination_Address':'Destination Address',
		'_Active_Sessions':'Active Sessions',
		'_sessions_per_page':'sessions per page',
		'_Page':'Page'
		}];
		
/* rptIDP.html */
var _rptIDP=[{
		'_Setup':'Setup',
		'_Collect_Statistics':'Collect Statistics',
		'_Summary':'Summary',
		'_Total_Session_Scanned':'Total Session Scanned',
		'_Total_Packet_Dropped':'Total Packet Dropped',
		'_Total_Packet_Reset':'Total Packet Reset',
		'_Statistics':'Statistics',
		'_Top_Entry_By':'Top Entry By',
		'_Signature_Name':'Signature Name',
		'_Type':'Type',
		'_Severity':'Severity',
		'_Occurrence':'Occurrence',
		'_Total':'Total',
		'_Source_IP':'Source IP',
		'_Destination_IP':'Destination IP'
		}];

/* rptAV.html */
var _rptAV=[{
		'_Setup':'Setup',
		'_Collect_Statistics':'Collect Statistics',
		'_Summary':'Summary',
		'_Total_Files_Scanned':'Total Files Scanned',
		'_Infected_Files_Detected':'Infected Files Detected',
		'_Statistics':'Statistics',
		'_Top_Entry_By':'Top Entry By',
		'_Virus_Name':'Virus Name',
		'_Occurrence':'Occurrence',
		'_Total':'Total',
		'_Source_IP':'Source IP',
		'_Destination_IP':'Destination IP'
		}];
		
/*----- Maintenance > Diagnostics -----*/

/* debugCol.html */
var _debugCol=[{
		'_Diagnostic_Information_Collector':'Diagnostic Information Collector',
		'_Filename':'Filename',
		'_Last_modified':'Last modified',
		'_Size':'Size'
		}];

/* col.html */
var _col=[{
		'_Diagnostic_Information_Collecting_Status':'Diagnostic Information Collecting Status',
		'_Please_wait_collecting':'Please wait, collecting...',
		'_Done_the_collection':'Done the collection.'
		}];

/*----- Maintenance > Reboot -----*/

/* reboot.html */
var _reboot=[{
		'_Reboot':'Reboot',
		'_Click':'Click the Reboot button to reboot the device. Please wait a few minutes until the login screen appears. If the login screen does not appear, type the IP address of the device in your Web browser.'
		}];

//access.html file
var _access=[{
		'_andrewc':'andrewc,You now have logged in.',
		'_Clicking':'Clicking the logout button to terminal the access session. You have a maximum login session time of 20 minutes. For security reason you must login in again after 2 hours 40 minutes.',  
		'_User':'User-defind lease time (max 20 minutes)',
		'_Remaining1':'Remaining time before lease time (mm:ss):',
		'_Remaining2':'Remaining time before auth. time (hh:mm): '
		}];

//antispamedit.html file
var _antispamedit=[{
		'_Configuration':'Configuration',
		'_From_ZONE':'From ZONE',
		'_To_ZONE':'To ZONE',
		'_SPAM_Score':'SPAM Score',
		'_SPAM_Log':'SPAM Log',
		'_Protocol':'Protocol',
		'_Action':'Action',
		'_Mark_on_Subject':'Mark on Subject',
		'_Enable':'Enable'
		}];

//asrbl.html file
var _asrbl=[{
		'_Summary':'Summary',
		'_White_Black_List':'White/Black List',
		'_RBL_ORDBL':'RBL/ORDBL',
		'_Update':'Update',
		'_Configuration':'_Configuration',
		'_Enable_RBL_ORDBL':'Enable RBL/ORDBL',
		'_Server_Query_Postfix':'Server Query Postfix',
		'_Maximum':'Maximum RBL/ORDBL Query IPs per Mail',
		'_Maximum_Query_IPs':'Maximum Query IPs'
		}];

//asrbledit.html file
var _asrbledit=[{
		'_RBL_ORDBL_Server':'RBL / ORDBL Server',
		'_Enable':'Enable',
		'_Server_Query_Postfix':'Server Query Postfix'
		}];

//assummary.html file
var _assummary=[{
		'_Summary':'Summary',
		'_White_Black_List':'White/Black List',
		'_RBL_ORDBL':'RBL/ORDBL',
		'_Update':'Update',
		'_Configuration':'Configuration',
		'_Enable_Anti_Spam':'Enable Anti-Spam',
		'_Notify':'Notify SMTP sender ( DROP mail )',
		'_Incoming_ZONE':'Incoming ZONE',
		'_Outgoing_ZONE':'Outgoing ZONE',
		'_Inspect_Mail_Protocol':'Inspect Mail Protocol',
		'_Registration_Status':'Registration Status',
		'_Please_go_to_the':'Please go to the',
		'_Registration':'Registration',
		'_page':'page.',
		'_Registration_Status':'Registration Status:',
		'_Registration_Type':'Registration Type:'
		}];

//asupspam.html file
var _asupspam=[{
		'_Summary':'Summary',
		'_White_Black_List':'White/Black List',
		'_RBL_ORDBL':'RBL/ORDBL',
		'_Update':'Update',
		'_Signature_Information':'Signature Information',
		'_Current_Version':'Current Version:',
		'_Remote_Update':'Remote Update',
		'_Synchronize':'Synchronize the Anti-Spam Signature Package to the latest version with online update server. (myZyXEL.com activation required)',
		'_Auto_Update':'Auto Update',
		'_Hourly':'Hourly',
		'_Daily':'Daily',
		'_Hour':'(Hour)',
		'_Weekly':'Weekly',
		'_Day':'(Day)',
		'_Sunday':'Sunday',
		'_Monday':'Monday',
		'_Tuesday':'Tuesday',
		'_Wednesday':'Wednesday',
		'_Thursday':'Thursday',
		'_Friday':'Friday',
		'_Saturday':'Saturday'
		}];

//aswblist.html file
var _aswblist=[{
		'_Summary':'Summary',
		'_White_Black_List':'White/Black List',
		'_RBL_ORDBL':'RBL/ORDBL',
		'_Update':'Update',
		'_White_List':'White List',
		'_Enable_White_List':'Enable White List',
		'_Type':'Type',
		'_Content':'Content',
		'_Black_List':'Black List',
		'_Enable_Black_List':'Enable Black List'
		}];

//aswblistedit.html file
var _aswblistedit=[{
		'_Rule_Edit':'Rule Edit',
		'_Enable':'Enable',
		'_List':'List',
		'_Type':'Type',
		'_E_Mail_Address':'E-Mail Address',
		'_IP_Address':'IP Address',
		'_Network_Mask':'Network Mask',
		'_Mail_Header':'Mail Header',
		'_Value':'Value'
		}];

//certcert.html file
var _certcert=[{
		'_Name':'Name',
		'_Certification_Path':'Certification Path',
		'_Certificate_Information':'Certificate Information',
		'_Type':'Type',
		'_Version':'Version',
		'_Serial_Number':'Serial Number',
		'_Subject':'Subject',
		'_Issuer':'Issuer',
		'_Signature_Algorithm':'Signature Algorithm',
		'_Valid_From':'Valid From',
		'_Valid_To':'Valid To',
		'_Key_Algorithm':'Key Algorithm',
		'_MD5_Fingerprint':'MD5 Fingerprint',
		'_SHA1_Fingerprint':'SHA1 Fingerprint',
		'_Certificate':'Certificate in PEM (Base-64) Encoded Format'
		}];

//certreq.html file
var _certreq=[{
		'_Name':'Name',
		'_Certificate_Information':'Certificate Information',
		'_Type':'Type',
		'_Serial_Number':'Serial Number',
		'_Subject':'Subject',
		'_Issuer':'Issuer',
		'_Signature_Algorithm':'Signature Algorithm',
		'_Valid_From':'Valid From',
		'_Valid_To':'Valid To',
		'_Key_Algorithm':'Key Algorithm',
		'_Subject_Alternative_Name':'Subject Alternative Name',
		'_Key_Usage':'Key Usage',
		'_MD5_Fingerprint':'MD5 Fingerprint',
		'_SHA1_Fingerprint':'SHA1 Fingerprint',
		'_Certificate':'Certificate in PEM (Base-64) Encoded Format'
		}];

/* chgpw.html */
var _chgpw=[{
		'_Update_Admin_Info':'Update Admin Info',
		'_As':'As a security precaution, it is highly recommended that you change the admin password.',
		'_New_Password':'New Password:',
		'_Retype_to_Confirm':'Retype to Confirm:',
		'_max':'( max. 31 alphanumeric, printable characters and no spaces )'
		}];
		
/* keyin.html */
var _1keyin=[{'_Please':'Please input the File Name'}];

/* logout.html */
var _logout=[{
		'_Thank':'Thank you for using ZyXEL\'s embedded web configurator.',
		'_Good_bye':'Good-bye!'
		}];

/* newvpng.html */
var _newvpng=[{
		'_VPN_Gateway':'VPN Gateway',
		'_VPN_Gateway_Name':'VPN Gateway Name',
		'_IKE_Phase_1':'IKE Phase 1',
		'_Negotiation_Mode':'Negotiation Mode',
		'_Main':'Main',
		'_Aggressive':'Aggressive',
		'_Proposal':'Proposal',
		'_Encryption':'Encryption',
		'_Authentication':'Authentication',
		'_Key_Group':'Key Group',
		'_SA_Life_Time':'SA Life Time (Seconds)',
		'_NAT_Traversal':'NAT Traversal',
		'_Dead_Peer_Detection':'Dead Peer Detection (DPD)',
		'_Property':'Property',
		'_My_Address':'My Address',
		'_Interface':'Interface',
		'_Domain_Name':'Domain Name',
		'_Secure_Gateway_Address':'Secure Gateway Address',
		'_Authentication_Method':'Authentication Method',
		'_Pre_Shared_Key':'Pre-Shared Key',
		'_Certificate':'Certificate',
		'_See':'See',
		'_My_Certificates':'My Certificates',
		'_Local_ID_Type':'Local ID Type',
		'_Content':'Content',
		'_Peer_ID_Type':'Peer ID Type',
		'_Extended_Authentication':'Extended Authentication',
		'_Enable_Extended_Authentication':'Enable Extended Authentication ',
		'_Server_Mode':'Server Mode',
		'_Client_Mode':'Client Mode',
		'_User_Name':'User Name',
		'_Password':'Password'
		}];

/* prdframe.html */
var _prdframe=[{
		'_Incoming':'Incoming',			
		'_Member_List':'Member List',
		'_Please':'Please select one member'
		}];


/* wizard.html */
var _wizard=[{
		'_Welcome':'Welcome to the ZyWALL Wizard Setup',
		'_helps1':'(helps user quickly configure the ',
		'_helps1_1':' to secure Internet connection)',
		'_helps2':' to secure VPN connection)',
		'_Installation_Setup_One_ISP':'Installation Setup, One ISP',
		'_Installation_Setup_Two_ISP':'Installation Setup, Two ISP',
		'_VPN_Setup':'VPN Setup'
		}];

//wizisp1.html file
var _wizisp1=[{
		'_Installation_Setup_Wizard':'Installation Setup Wizard',
		'_Internet_Access':'Internet Access',
		'_ISP_Parameters':'ISP Parameters',
		'_Encapsulation':'Encapsulation:',
		'_WAN':'WAN IP Address Assignments',
		'_WAN_Interface':'WAN Interface:',
		'_Zone':'Zone:',
		'_STEP':'STEP',
		'_IP_Address_Assignment':'IP Address Assignment:',
		'_Second_WAN_Interface':'Second WAN Interface',
		'_First_WAN_Interface':'First WAN Interface'
		}];

//wizisp2.html file
var _wizisp2=[{
		'_Installation_Setup_Wizard':'Installation Setup Wizard',
		'_Internet_Access':'Internet Access',
		'_ISP_Parameters':'ISP Parameters',
		'_Encapsulation':'Encapsulation:',
		'_WAN':'WAN IP Address Assignments',
		'_WAN_Interface':'WAN Interface:',
		'_Zone':'Zone:',
		'_IP_Address_Assignment':'IP Address Assignment:',
		'_Base_Interface':'Base Interface',
		'_Service_Name':'Service Name',
		'_Optional':'(Optional)',
		'_User_Name':'User Name',
		'_Password':'Password',
		'_Retype_to_Confirm':'Retype to Confirm',
		'_Nailed_Up':'Nailed-Up', 
		'_Idle_Timeout':'Idle Timeout',
		'_Seconds':'(Seconds)',
		'_PPTP_Configuration':'PPTP Configuration',
		'_Base_IP_Address':'Base IP Address',
		'_IP_Subnet_Mask':'IP Subnet Mask',
		'_Server_IP':'Server IP',
		'_IP_Address':'(IP Address)',
		'_Connection_ID':'Connection ID',
		'_WAN_IP_Address_Assignments':'WAN IP Address Assignments',
		'_WAN_Interface':'WAN Interface',
		'_Zone':'Zone',
		'_IP_Address':'IP Address', 
		'_Auto':'Auto',
		'_IP_Subnet_Mask':'IP Subnet Mask',
		'_Gateway_IP_Address':'Gateway IP Address',
		'_First_DNS_Server':'First DNS Server',
		'_Second_DNS_Server':'Second DNS Server',
		'_Second_WAN_Interface':'Second WAN Interface',
		'_First_WAN_Interface':'First WAN Interface',
		'_STEP':'STEP'
		}];

//wizisp3.html file
var _wizisp3=[{
		'_Installation_Setup_Wizard':'Installation Setup Wizard',
		'_Internet_Access':'Internet Access',
		'_ISP_Parameters':'ISP Parameters',
		'_You_can':'You can select Ethernet, PPPoE or PPTP according to in which the network you are. If you don\'t know, please ask your network admin. The most popular type of network is Ethernet.',
		'_Encapsulation':'Encapsulation:',
		'_WAN_IP_Address_Assignments':'WAN IP Address Assignments',
		'_The_ZyWall':'The ',
		'_The_ZyWall_1':' ports are run-time configurable. For example change port 4, counted from the left of front panel) from DMZ1 to LAN2. The port name is also run-time configurable. (cute card)',
		'_WAN_Interface':'WAN Interface:',
		'_IP_Address_Assignment':'IP Address Assignment:',
		'_error':'error'
		}];

//wizisp4.html file
var _wizisp4=[{
		'_Installation_Setup_Wizard':'Installation Setup Wizard',
		'_Internet_Detection':'Internet Detection',
		'_Please_wait_a_moment':'Please wait a moment ... ',
		'_STEP':'STEP',
		'_Check_User_Name':'Check User Name...',
		'_Auto_Configure_Device':'Auto Configure Device'
		}];

//wizisp5.html file
var _wizisp5=[{
		'_Installation_Setup_Wizard':'Installation Setup Wizard',
		'_Internet_Access':'Internet Access',
		'_Congratulations':'Congratulations. The Internet Access wizard is completed',
		'_Summary':'Summary of Internet Access configuration: ',
		'_You_can':'You can register ZyWALL on <a href="http://www.myZyXEL.com" target=_top><span class="style">myZyXEL.com</span></a> and activate "Free Trial" of Anti-Virus, IDP/AppPatrol<!--, AntiSpam //Jerry--> and Content Filter services on your ZyWALL.',
		'_Click':'Click "Next" to activate these services for FREE.',
		'_Setting':'Setting:',
		'_First_Setting':'First Setting:',
		'_Encapsulation':'Encapsulation',
		'_Service_Name':'Service Name',
		'_User_Name':'User Name',
		'_Nailed_Up':'Nailed-Up',
		'_Idle_Timeout':'Idle Timeout',
		'_Server_IP':'Server IP',
		'_User_Name':'User Name',
		'_Connection_ID':'Connection ID',
		'_WAN_Interface':'WAN Interface',
		'_Zone':'Zone',
		'_First_WAN_Interface':'First WAN Interface',
		'_IP_Assignment':'IP Assignment',
		'_IP_Address':'IP Address',
		'_IP_Subnet_Mask':'IP Subnet Mask',
		'_Gateway_IP_Address':'Gateway IP Address',
		'_First_DNS_Server':'First DNS Server',
		'_Second_DNS_Server':'Second DNS Server',
		'_Second_Setting':'Second Setting:',
		'_Second_WAN_Interface':'Second WAN Interface',
		'_STEP':'STEP'
		}];
		
/* wizregist.html */
var _wizregist=[{
		'_Installation_Setup_Wizard':'Installation Setup Wizard',
		'_Device_Registration':'Device Registration',
		'_This_device':'<font color="#FF0000">This device is not registered to myZyXEL.com.&nbsp;Please enter information below to <b>register</b> your device.</font> <font color="#FFFFFF">If you don\'t have myZyXEL.com account, please select &quot;new myZyXEL.com account&quot; below. If you have a myZyXEL.com account, but you forget your User Name or Password, please go to <a href="http://www.myZyXEL.com">www.myZyXEL.com</a> for help.</font>',
		'_new':'new myZyXEL.com account',
		'_existing':'existing myZyXEL.com account',
		'_User_Name':'User Name',
		'_you_can':'you can click to check if username exists ',
		'_Password':'Password',
		'_Confirm_Password':'Confirm Password',
		'_E_Mail_Address':'E-Mail Address',
		'_Country_Code':'Country Code',
		'_Trial_Service_Activation':'Trial Service Activation',
		'_IDP':'IDP/AppPatrol',
		'_Anti_Virus':'Anti-Virus',
		'_Content_Filter':'Content Filter',
		'_STEP':'STEP'
		}];

//wizvpn1.html file
var _wizvpn1=[{
		'_VPN_Setup_Wizard':'VPN Setup Wizard',
		'_Please':'Please select the type of VPN policy you wish to setup.',
		'_Express':'Express',
		'_Advanced':'Advanced',
		'_STEP':'STEP'
		}];

//wizvpn2.html file
var _wizvpn2=[{
		'_VPN_Setup_Wizard':'VPN Setup Wizard',
		'_VPN_Access':'VPN Access',
		'_Remote_Gateway':'Remote Gateway',
		'_Name':'Name',
		'_Secure_Gateway':'Secure Gateway',
		'_IP_DNS':'(IP/DNS)',
		'_Pre_Shared_Key':'Pre-Shared Key',
		'_STEP':'STEP'
		}];

//wizvpn3.html file
var _wizvpn3=[{
		'_VPN_Setup_Wizard':'VPN Setup Wizard',
		'_VPN_Access':'VPN Access',
		'_Policy_Setting':'Policy Setting',
		'_Local_Policy':'Local Policy (IP/Mask)',
		'_Remote_Policy':'Remote Policy (IP/Mask)',
		'_STEP':'STEP'
		}];

//wizvpn4.html file
var _wizvpn4=[{
		'_VPN_Setup_Wizard':'VPN Setup Wizard',
		'_VPN_Access':'VPN Access',
		'_Summary':'Summary',
		'_Name':'Name',
		'_Secure_Gateway':'Secure Gateway',
		'_Pre_Shared_Key':'Pre-Shared Key',
		'_Local_Policy':'Local Policy',
		'_Remote_Policy':'Remote Policy',
		'_Configuration_for_Remote_Gateway':'Configuration for Remote Gateway',
		'_Uncomment':'1. Uncomment the CLI below if it is used under zysh script.',
		'_configure_terminal':'configure terminal',
		'_Click':'2. Click "Save" button to write the VPN configuration to ZyWALL.',
		'_STEP':'STEP'
		}];

//wizvpn5.html file
var _wizvpn5=[{
		'_VPN_Setup_Wizard':'VPN Setup Wizard',
		'_VPN_Access':'VPN Access',
		'_Congratulations':'Congratulations. The VPN Access wizard is completed',
		'_Summary':'Summary of VPN Access configuration:',
		'_Now':'Now if you are doing first time installation of this device, you may click this<a href="http://www.myZyXEL.com" target=_top><span class="style">myZyXEL.com</span></a> link and to register this device and activate trial service of advanced security features.(You need to have internet access to register)',
		'_STEP':'STEP',
		'_Encapsulation':'Encapsulation:  ',
		'_Service_Name':'Service Name:  ',
		'_User_Name':'User Name:  ',
		'_Idle_Timeout':'Idle Timeout:  ',
		'_Server_IP':'Server IP:  ',
		'_Connection_ID':'Connection ID:  ',
		'_WAN_Interface':'WAN Interface:  ',
		'_First_WAN_Interface':'First WAN Interface:  ',
		'_IP_Assignment_Auto':'IP Assignment:  Auto ',
		'_IP_Address':'IP Address:    ',
		'_IP_Subnet_Mask':'IP Subnet Mask:  ',
		'_Gateway_IP_Address':'Gateway IP Address:  ',
		'_IP_Assignment_Static':'Gateway IP Address:  ',
		'_Second_WAN_Interface':'Second WAN Interface:  '
		}];

//wizvpna2.html file
var _wizvpna2=[{
		'_VPN_Setup_Wizard':'VPN Setup Wizard',
		'_VPN_Advanced_Access':'VPN Advanced Access',
		'_Remote_Gateway':'Remote Gateway',
		'_Name':'Name',
		'_IP_DNS':'(IP/DNS)',
		'_Secure_Gateway':'Secure Gateway',
		'_My_Address':'My Address (interface)',
		'_Authentication_Method':'Authentication Method',
		'_Pre_Shared_Key':'Pre-Shared Key',
		'_Certificate':'Certificate',
		'_STEP':'STEP'
		}];

//wizvpna3.html file
var _wizvpna3=[{
		'_VPN_Setup_Wizard':'VPN Setup Wizard',
		'_VPN_Advanced_Access':'VPN Advanced Access',
		'_Phase_1_Setting':'Phase 1 Setting',
		'_Negotiation_Mode':'Negotiation Mode',
		'_Encryption_Algorithm':'Encryption Algorithm',
		'_Authentication_Algorithm':'Authentication Algorithm',
		'_Key_Group':'Key Group',
		'_SA_Life_Time':'SA Life Time (Seconds)',
		'_NAT_Traversal':'NAT Traversal',
		'_Dead_Peer_Detection':'Dead Peer Detection (DPD)',
		'_STEP':'STEP'
		}];

//wizvpna4.html file
var _wizvpna4=[{
		'_VPN_Setup_Wizard':'VPN Setup Wizard',
		'_VPN_Advanced_Access':'VPN Advanced Access',
		'_Phase_2_Setting':'Phase 2 Setting',
		'_Active_Protocol':'Active Protocol',
		'_Encapsulation':'Encapsulation',
		'_Encryption_Algorithm':'Encryption Algorithm',
		'_Authentication_Algorithm':'Authentication Algorithm',
		'_SA_Life_Time':'SA Life Time (Seconds)',
		'_Perfect_Forward_Secrecy':'Perfect Forward Secrecy (PFS)',
		'_Policy_Setting':'Policy Setting',
		'_Local_Policy':'Local Policy (IP/Mask)',
		'_Incoming_Interface':'Incoming Interface',
		'_Remote_Policy':'Remote Policy (IP/Mask)',
		'_Property':'Property',
		'_Nailed_Up':'Nailed-Up',
		'_STEP':'STEP'
		}];

//wizvpna5.html file
var _wizvpna5=[{
		'_VPN_Setup_Wizard':'VPN Setup Wizard',
		'_VPN_Access':'VPN Access',
		'_Summary':'Summary',
		'_Name':'Name',
		'_Secure_Gateway':'Secure Gateway',
		'_Pre_Shared_Key':'Pre-Shared Key',
		'_Local_Policy':'Local Policy',
		'_Remote_Policy':'Remote Policy',
		'_Remote_Gateway_CLI':'Remote Gateway CLI',
		'_Uncomment':'1. Uncomment the CLI below if it is used under zysh script.',
		'_configure_terminal':'configure terminal',
		'_Click':'2. Click "Save" button to write the VPN configuration to ZyWALL.',
		'_STEP':'STEP'
		}];

//wizvpna6.html file
var _wizvpna6=[{
		'_VPN_Setup_Wizard':'VPN Setup Wizard',
		'_VPN_Access':'VPN Access',
		'_Congratulations':'Congratulations. The VPN Access wizard is completed',
		'_Summary':'Summary of VPN Access configuration:',
		'_Now':'Now if you are doing first time installation of this device, you may click this<a href="http://www.myZyXEL.com" target=_top><span class="style">myZyXEL.com</span></a> link and to register this device and activate trial service of advanced security features.(You need to have internet access to register) ',
		'_STEP':'STEP',
		'_Name':'Name',
		'_Secure_Gateway':'Secure Gateway',
		'_Pre_Shared_Key':'Pre-Shared Key',
		'_Local_Policy':'Local Policy',
		'_Remote_Policy':'Remote Policy',
		'_Secure_Gateway':'Secure Gateway',
		'_My_Address_interface':'My Address (interface)',
		'_Pre_Shared_Key':'Pre-Shared Key',
		'_Certificate':'Certificate',
		'_Phase_1':'Phase 1',
		'_Negotiation_Mode':'Negotiation Mode',
		'_main':'main',
		'_Negotiation_Mode':'Negotiation Mode',
		'_aggressive':'aggressive',
		'_Encryption_Algorithm':'Encryption Algorithm',
		'_Authentication_Algorithm':'Authentication Algorithm',
		'_Key_Group':'Key Group',
		'_SA_Life_Time_Seconds':'SA Life Time (Seconds)',
		'_NAT_Traversal':'NAT Traversal',
		'_Dead_Peer_Detection_DPD':'Dead Peer Detection (DPD)',
		'_Phase_2':'Phase 2',
		'_Active_Protocol':'Active Protocol',
		'_ESP':'ESP',
		'_AH':'AH',
		'_Encapsulation':'Encapsulation',
		'_Tunnel':'Tunnel',
		'_Transport':'Transport',
		'_Encryption_Algorithm':'Encryption Algorithm',
		'_SA_Life_Time_Seconds':'SA Life Time (Seconds)',
		'_Perfect_Forward_Secrecy':'Perfect Forward Secrecy',
		'_Policy':'Policy',
		'_Local_Policy':'Local Policy',
		'_Remote_Policy':'Remote Policy',
		'_Incoming_Interface':'Incoming Interface',
		'_Nailed_Up':'Nailed-Up'
		}];

/* wizard_error.html */
var _wizard_error=[{
		'_ErrNo':'ErrNo:',
		'_ErrMsg':'ErrMsg:',
		'_Installation_Setup_Wizard':'Installation Setup Wizard',
		'_Error':'Error'
		}];

//wizvpnwait.html file
var _wizvpnwait=[{
		'_Installation_Setup_Wizard':'Installation Setup Wizard',
		'_Internet_Detection':'Internet Detection',
		'_Auto_Configure_WAN':'Auto Configure WAN',
		'_Please':'Please wait a moment ...',
		'_STEP':'STEP'
		}];

/*----- SiteMAP -----*/

//sitemap.html file
var _sitemap=[{
		'_Licensing':'Licensing',
		'_Registration':'Registration',
		'_Service':'Service',
		'_File_Manager':'File Manager',
		'_Configuration_File':'Configuration File',
		'_Firmware_Package':'Firmware Package',
		'_Shell_Script':'Shell Script',
		'_Configuration':'Configuration',
		'_Network':'Network',
		'_Policy':'Policy',
		'_User_Group':'User/Group',
		'_Interface':'Interface',
		'_Ethernet':'Ethernet',
		'_Route':'Route',
		'_Policy_Route':'Policy Route',
		'_User':'User',
		'_Port_Grouping':'Port Grouping',
		'_Static_Route':'Static Route',
		'_Group':'Group',
		'_VLAN':'VLAN',
		'_Firewall':'Firewall',
		'_Setting':'Setting',
		'_Bridge':'Bridge',
		'_App_Patrol':'App Patrol',
		'_Configuration':'Configuration',
		'_PPPoE_PPTP':'PPPoE/PPTP',
		'_Other_Protocol':'Other Protocol',
		'_Auxiliary':'Auxiliary',
		'_IDP':'IDP',
		'_General':'General',
		'_Trunk':'Trunk',
		'_Profile':'Profile',
		'_IPSec_VPN':'IPSec VPN',
		'_VPN_Connection':'VPN Connection',
		'_Custom_Signatures':'Custom Signatures',
		'_VPN_Gateway':'VPN Gateway',
		'_Update':'Update',
		'_Concentrator':'Concentrator',
		'_Content_Filter':'Content Filter',
		'_General':'General',
		'_SA_Monitor':'SA Monitor',
		'_Filter_Profile':'Filter Profile ',
		'_Routing_Protocol':'Routing Protocol',
		'_RIP':'RIP',
		'_Cache':'Cache',
		'_OSPF':'OSPF',
		'_Virtual_Server':'Virtual Server',
		'_Zone':'Zone',
		'_HTTP_Redirect':'HTTP Redirect',
		'_Device_HA':'Device HA',
		'_VRRP_Group':'VRRP Group',
		'_VoIP_passThru':'VoIP passThru',
		'_Synchronize':'Synchronize',
		'_ISP_Account':'ISP Account',
		'_DDNS':'DDNS',
		'_Object':'Object',
		'_System':'System',
		'_Address':'Address',
		'_Address_Group':'Address Group',
		'_Host_Name':'Host Name',
		'_Service':'Service',
		'_Date_Time':'Date/Time',
		'_Service_Group':'Service Group',
		'_Console_Speed':'Console Speed',
		'_Schedule':'Schedule',
		'_ICMP':'ICMP',
		'_AAA_Server':'AAA Server',
		'_LDAP':'LDAP',
		'_DNS':'DNS',
		'_Default':'Default',
		'_Group':'Group',
		'_WWW':'WWW',
		'_RADIUS':'RADIUS',
		'_SSH':'SSH',
		'_TELNET':'TELNET',
		'_Auth_method':'Auth. Method',
		'_FTP':'FTP',
		'_Certificate':'Certificate',
		'_My_Certificates':'My Certificates',
		'_SNMP':'SNMP',
		'_Trusted_Certificates':'Trusted Certificates',
		'_Maintenance':'Maintenance',
		'_Log':'Log',
		'_Traffic':'Traffic',
		'_Reboot':'Reboot',
		'_View_Log':'View Log',
		'_Log_Setting':'Log Setting',
		'_Session':'Session',
		'_Diagnostics':'Diagnostics',
		'_System_Protect':'System Protect',
		'_Anti_Virus':'Anti-Virus',
		'_Interface_Summary':'Interface Summary',
		'_Routing':'Routing',
		'_ALG':'ALG',
		'_VPN':'VPN',
		'_SSL_VPN':'SSL VPN',
		'_Access_Privilege':'Access Privilege',
		'_Connection_Monitor':'Connection Monitor',
		'_Global_Setting':'Global Setting',
		'_L2TP_VPN':'L2TP VPN',
		'_Session_Monitor':'Session Monitor',
		'_General':'General',
		'_Common':'Common',
		'_IM':'IM',
		'_Peer_to_Peer':'Peer to Peer',
		'_VoIP':'VoIP',
		'_Streaming':'Streaming',
		'_Other':'Other',
		'_Statistics':'Statistics',
		'_Anti_X':'Anti-X',
		'_Anti_Virus':'Anti-Virus',
		'_Summary':'Summary',
		'_Setting':'Setting',
		'_Signature':'Signature',
		'_ADP':'ADP',
		'_Active_Directory':'Active Directory',
		'_SSL_Application':'SSL Application',
		'_Dial_in_Mgmt':'Dial-in Mgmt.',
		'_Vantage_CNM':'Vantage CNM',
		'_Anti_Virus':'Anti-Virus',
		'_Diagnostics':'Diagnostics'
		}];

var LangReady=true;

