﻿var langFile='Japan';
//login.html & login_s.html files
var _login=[
		{'_USG_300':'ZyWALL USG 300',
		'_ZW1050':'ZyWALL 1050',	
		'_Enter_User':'ユーザー名/パスワードを入力し、クリックしてログインします。',
		'_User_Name':'ユーザー名:',
		'_Password':'パスワード:',
		'_One_Time':'One-Time パスワード:',
		'_Optional':'(オプション)',
		'_max_alphanumeric':'(最大. 31文字の英数字、記号で設定します。スペースは使用できません。)',
		'_Login_to':'SSL VPN へログイン',
		'_Note':'注意:',
		'_Turn_on':'Web ブラウザのJavascript と Cookie 設定を有効にします。',
		'_Turn_off':'Web ブラウザのポップアップウィンドウ禁止機能を無効にします。',
		'_JRE_on':'Web ブラウザの Java Runtime Environment (JRE) を有効にします。',
		'_Login':'ログイン',
		'_Reset':'リセット'
		}];			

//panel.html file
var _panel=[
		{'_Status':'ステータス',
		'_Licensing':'ライセンス',
		'_Update':'更新',
		'_Registration':'登録',
		'_File_Manager':'ファイルマネージャー',
		'_Configuration':'設定',
		'_Network':'ネットワーク',
		'_Interface':'インターフェース',
		'_VPN':'VPN',
		'_IPSec_VPN':'IPSec VPN',
		'_SSL_VPN':'SSL VPN',
		'_L2TP_VPN':'L2TP VPN',
		'_Routing':'ルーティング',
		'_Route':'ルート',
		'_Routing_Protocol':'ルーティングプロトコル',
		'_Zone':'ゾーン',
		'_Device_HA':'デバイス HA',
		'_ISP_Account':'ISP アカウント',
		'_DDNS':'DDNS',
		'_Policy':'ポリシー',
		'_Firewall':'ファイアウォール',
		'_App_Patrol':'アプリケーションパトロール',
		'_Anti_X':'アンチX',
		'_Anti_Virus':'アンチ－ウイルス',
		'_Anti_Spam':'アンチ－スパム',
		'_IDP':'IDP',
		'_ADP':'ADP',
		'_Signature':'シグネチャ',
		'_Anomaly':'異常',
		'_Content_Filter':'コンテンツフィルタ',
		'_Virtual_Server':'仮想サーバー',		
		'_HTTP_Redirect':'HTTP 変更',
		'_ALG':'ALG',
		'_User_Group':'ユーザー/グループ',
		'_Object':'オブジェクト',
		'_Address':'アドレス',
		'_Service':'サービス',
		'_Schedule':'スケジュール',
		'_AAA_Server':'AAA サーバー',
		'_Auth_method':'認証方法',
		'_Certificate':'証明',
		'_SSL_Application':'SSL アプリケーション',
		'_System':'システム',
		'_Host_Name':'ホスト名',
		'_Date_Time':'日付/時刻',
		'_Console_Speed':'コンソール速度',
		'_DNS':'DNS',
		'_WWW':'WWW',
		'_SSH':'SSH',
		'_TELNET':'TELNET',
		'_FTP':'FTP',
		'_SNMP':'SNMP',
		'_Dial_in_Mgmt':'ダイヤルイン管理',
		'_System_Protect':'システム保護',
		'_Vantage_CNM':'Vantage CNM',
		'_Maintenance':'メンテナンス',
		'_Diagnostics':'診断',
		'_Log':'ログ',
		'_Report':'トラフィック',
		'_Reboot':'再起動',
		'_Language':'言語'
		}];					
//access.html file,  user away login page
var _access=[
		{'_You_now':'ログインできました。',
		'_Click_the_logout':'ログアウトボタンをクリックすると、アクセスセッションを終了します。',
		'_You_could_renew':'[更新] ボタンをクリックすると、リース時間を更新することができます。',
		'_For_security':'セキュリティ上の理由で ',
		'_hours':' 時間 ',
		'_minutes':' 分.',
		'_Renew':'更新',
		'_Logout':'ログアウト',
		'_User_defined':'(max:ユーザー定義のリース時間 (最大 ',
		'_Minutes':' 分):',
		'_Updating_lease':'自動的にリース時間を更新',
		'_Remaining_lease':'リースタイムアウトになるまでの残り時間(hh:mm:ss): ',
		'_Remaining_auth':'承認までの残り時間タイムアウト(hh:mm): '
		}];					
		
//chgpw.html file 
var _chgpw=[
		{'_Update_Admin_Info':'管理者情報の更新',
		'_As_a_security':'セキュリティ上の理由から、管理者パスワードを変更することを強く推奨します。',
		'_New_Password':'新しいパスワード:',
		'_Retype_to_Confirm':' 再入力確認:',
		'_max_alphanumeric':'(最大. 31文字の英数字、記号で設定します。スペースは使用できません。)',
		'_Apply':'適用',
		'_Ignore':'無視'
		}];	
//waitdata.html file
var _waitdata=[
		{'_Please_Wait':'お待ちください...'
		}];		
