﻿var langFile='Traditional_Chinese';
//login.html & login_s.html files
var _login=[
		{'_USG_300':'ZyWALL USG 300',
		'_ZW1050':'ZyWALL 1050',
		'_Enter_User':'輸入您的名稱與密碼並按一下登入',
		'_User_Name':'使用者名稱:',
		'_Password':'密碼:',
		'_One_Time':'One-Time Password:',
		'_Optional':'(可省略)',
		'_max_alphanumeric':'(最多 31 個可列印的文數字字元，中無空格)',
		'_Login_to':'登入到 SSL VPN 模式',
		'_Note':'注意:',
		'_Turn_on':'1. 開啟網頁瀏覽器的 Javascript 與 Cookie 設定.',
		'_Turn_off':'2. 關閉網頁瀏覽器的彈出式視窗攔截功能.',
		'_JRE_on':'3. 開啟網頁瀏覽器的 Java Runtime Environment(JRE).',
		'_Login':'登入',
		'_Reset':'重設'
		}];		

//panel.html file
var _panel=[
		{'_Status':'狀態',
		'_Licensing':'授權',
		'_Update':'更新',
		'_Registration':'註冊',
		'_File_Manager':'檔案管理程式',
		'_Configuration':'設定',
		'_Network':'網路',
		'_Interface':'介面',
		'_VPN':'VPN',
		'_IPSec_VPN':'IPSec VPN',
		'_SSL_VPN':'SSL VPN',
		'_L2TP_VPN':'L2TP VPN',
		'_Routing':'路由',
		'_Route':'路由',
		'_Routing_Protocol':'路由通訊協定',
		'_Zone':'區域',
		'_Device_HA':'裝置 HA',
		'_ISP_Account':'ISP 帳號',
		'_DDNS':'DDNS',
		'_Policy':'策略',
		'_Firewall':'防火牆',
		'_App_Patrol':'應用程式巡查',
		'_Anti_X':'Anti-X',
		'_Anti_Virus':'防毒',
		'_Anti_Spam':'防間諜',
		'_IDP':'入侵偵測與防護',
		'_ADP':'ADP',
		'_Signature':'簽章',
		'_Anomaly':'異常',
		'_Content_Filter':'內容過濾',
		'_Virtual_Server':'虛擬伺服器',		
		'_HTTP_Redirect':'HTTP 重新導向',
		'_ALG':'ALG',
		'_User_Group':'使用者/群組',
		'_Object':'物件',
		'_Address':'位址',
		'_Service':'服務',
		'_Schedule':'排程',
		'_AAA_Server':'AAA 伺服器',
		'_Auth_method':'認證方式',
		'_Certificate':'憑証',
		'_SSL_Application':'SSL 應用程式',
		'_System':'系統',
		'_Host_Name':'主機名稱',
		'_Date_Time':'日期/時間',
		'_Console_Speed':'Console 速度',
		'_DNS':'DNS',
		'_WWW':'WWW',
		'_SSH':'SSH',
		'_TELNET':'TELNET',
		'_FTP':'FTP',
		'_SNMP':'簡易網路管理通訊協定',
		'_Dial_in_Mgmt':'撥接管理',
		'_System_Protect':'系統保護',
		'_Vantage_CNM':'Vantage CNM',
		'_Maintenance':'維護',
		'_Diagnostics':'診斷',
		'_Log':'日誌',
		'_Report':'報告',
		'_Reboot':'重新開機',
		'_Language':'語言'
		}];					

//access.html file,  user away login page
var _access=[
		{'_You_now':'您現在已經登入.',
		'_Click_the_logout':'按一下登出按鈕終止存取工作階段.',
		'_You_could_renew':' 您可以按一下更新按鈕更新租用時間.',
		'_For_security':'為安全起見，您必須於下列時間後重新登入 ',
		'_hours':' 小時 ',
		'_minutes':' 分鐘.',
		'_Renew':'更新',
		'_Logout':'登出',
		'_User_defined':'使用者定義租用時間(最長 ',
		'_Minutes':' 分鐘):',
		'_Updating_lease':'自動更新租用時間',
		'_Remaining_lease':' 租約到期剩餘時間 (時:分:秒): ',
		'_Remaining_auth':' 驗證等候剩餘時間 (時:分): '
		}];	
		
//chgpw.html file 
var _chgpw=[
		{'_Update_Admin_Info':'更新管理資訊',
		'_As_a_security':'為安全起見，強烈建議您變更管理員密碼.',
		'_New_Password':'新密碼:',
		'_Retype_to_Confirm':'重新鍵入確認:',
		'_max_alphanumeric':'(最多 31 個可列印的文數字字元，中無空格)',
		'_Apply':'套用',
		'_Ignore':'忽略'
		}];			
//waitdata.html file
var _waitdata=[
		{'_Please_Wait':'請稍後 ...'
		}];		
