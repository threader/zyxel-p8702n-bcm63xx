﻿var langFile='Traditional_Chinese';

/* for all buttons */
var _button=[{
		'_OK':'確定',
		'_Cancel':'取消',
		'_Apply':'套用',
		'_Reset':'重設',
		'_Synchronize_Now':'立即同步',
		'_Import':'匯入',
		'_Refresh':'重新整理',
		'_Export':'匯出',
		'_Export_Certificate':'匯出憑證',
		'_Export_Certificate_Only':'僅匯出憑證',
		'_Export_Certificate_with_Private_Key':'匯出憑證與私密金鑰',
		'_Show_Filter':'顯示過濾器',
		'_Hide_Filter':'隱藏過濾器',
		'_Search':'搜尋',
		'_Email_Log_Now':'立即以電子郵件傳送日誌',
		'_Clear_Log':'清除日誌',
		'_Active_Log_Summary':'現用日誌摘要',
		'_Flush_Data':'清空資料',
		'_Start_Collection':'開始收集',
		'_Stop_Collection':'停止收集',
		'_Collect_Now':'立即收集',
		'_Close':'關閉',
		'_Download':'下載',
		'_Reboot':'重新開機',
		'_Please_wait_collecting':'請稍待，正在收集中...',
		'_Done_the_collection':'收集完成。',
		'_Update':'更新',
		'_Service_License_Refresh':'服務授權更新',
		'_Copy':'複製',
		'_Rename':'重新命名',
		'_Delete':'刪除',
		'_Upload':'上載',
		'_Run':'執行',
		'_Edit_static_DHCP_table':'編輯靜態 DHCP 表格',
		'_Add_New_VPN_Gateway':'新增 VPN 閘道器',
		'_Advanced':'進階...',
		'_Sync_Now':'立即同步',
		'_Change':'更改... ',
		'_New':'新增...',
		'_Switch_to_query_view':'切換至查詢檢視',
		'_Switch_to_group_view':'切換至群組檢視',
		'_Save':'  儲存  ',
		'_Delete':'刪除',
		'_Export':'匯出',
		'_Update_Now':'立即更新',
		'_Flush':'清空',
		'_Add':'新增',
		'_Basic_cfilter':'基本',
		'_Advanced_cfilter':'進階',
		'_Test_Against_Local_Cache':'測試本機快取',
		'_Test_Against_Web_Filter_Server':'測試網頁過濾伺服器',
		'_Login':'登入',
		'_Refresh_Now':'立即重新整理',
		'_Clear_Warning_Message':'清除警告訊息',
		'_Back':'< 上一步',
		'_Next':'下一步 >',
		'_Check':'檢查',
		'_Set_Interval':'設定間隔',
		'_Stop':'停止',
		'_Clear_RX_Message':'清除接收訊息',
		'_Change_Display_Style':'變更顯示模式',
		'_Advanced_':'進階>>',
		'_Basic_':'基本<<',
		'_Expand':'展開',
		'_Collapse':'收摺',
		'_Reset_Default':'商標重設為預設圖樣',
		'_Preview':'預覽',
		'_Logout':'登出',
		'_Renew':'更新'
		}];
		
/* Global Title Tag */
var _globalTag=[{
		/* Spare bar*/
		'_General_Setup':'一般設定',
		'_Policies':'策略',
		'_Configuration':'設定',
		/* Registration */
		'_Registration':'註冊',
		'_Service':'服務',
		/* Update */
		'_IDP_App_Patrol':'IDP/應用程式巡查',
		'_System_Protect':'系統保護',
		'_Anti_Virus':'防毒',
		/* Network */
		'_Interface_Summary':'介面摘要',
		'_Ethernet':'乙太網路',
		'_Port_Grouping':'埠群組',
		'_VLAN':'VLAN 虛擬區域網路',
		'_Bridge':'橋接器',
		'_PPPoE_PPTP':'PPPoE/PPTP',
		'_Auxiliary':'輔助',
		'_Trunk':'主幹',
		'_Policy_Route':'策略路由',
		'_Static_Route':'靜態路由',
		'_RIP':'RIP',
		'_OSPF':'OSPF',
		/* IPSec VPN */
		'_VPN_Connection':'VPN 連線',
		'_VPN_Gateway':'VPN 閘道器',
		'_Concentrator':'集訊器',
		'_SA_Monitor':'SA 監控程式',
		/* SSL VPN */
		'_Access_Privilege':'存取權限',
		'_Connection_Monitor':'連線監控程式',
		'_Global_Setting':'全域設定',
		/* L2TP VPN */
		'_L2TP_VPN':'L2TP VPN',
		'_Session_Monitor':'工作階段監控程式',
		/* AppPatrol */
		'_General':'一般',
		'_Common':'共用',
		'_Instant_Messenger':'即時通訊軟體',
		'_Peer_to_Peer':'點對點',
		'_VoIP':'IP 語音',
		'_Streaming':'串流',
		'_Other':'其他',
		'_Statistics':'統計',
		/* Anti-X > Anti-Virus */
		'_Summary':'摘要',
		'_Setting':'設定',
		'_Signature':'簽章',
		/* Anti-X > IDP */
		'_General':'一般',
		'_Profile':'設定組合',
		'_Custom_Signatures':'自訂簽章',
		'_Protocol_Anomaly':'協定異常',
		'_Traffic_Anomaly':'流量異常',
		/* Anti-X > Content Filter */
		'_General_CF':'一般',
		'_Filter_Profile':'過濾設定組合 ',
		'_Cache':'快取',
		/* Device HA */
		'_VRRP_Group':'VRRP 群組',
		'_Synchronize':'同步',
		/* Object */
		'_User':'使用者',
		'_Group':'群組',
		'_Setting':'設定',
		'_Address':'位址',
		'_Address_Group':'位址群組',
		'_Service':'服務',
		'_Service_Group':'服務群組',
		'_Active_Directory':'現用目錄',
		'_LDAP':'LDAP',
		'_RADIUS':'RADIUS',
		'_My_Certificates':'我的憑證',
		'_Trusted_Certificates':'受信任憑證',
		/* File Manager */
		'_Configuration_File':'設定檔',
		'_Firmware_Package':'韌體套裝軟體',
		'_Shell_Script':'Shell 指令碼',
		/* Log */
		'_View_Log':'查看日誌',
		'_Log_Setting':'日誌設定',
		/* Traffic */
		'_Traffic':'流量',
		'_Session':'工作階段',
		'_IDP':'入侵偵測與防護',
		'_Anti_Virus':'防毒',
		/* Member List popup*/
		'_Member_List':'成員清單',
		'_Available':'可用',
		'_Member':'成員',
		'_Please_Select':'請選取成員',
		/* app patrol & policy route BWM */
		'_BWM_Global_Setting':'BWM Global Setting',
		'_Enable_BWM':'Enable BWM'
		}];

/* about.html */
var _about=[{
		'_ZyWALL_1050':'ZyWALL 1050',
		'_USG_300':'ZyWALL USG 300',
		'_Copyright':'(C) 2007 合勤科技股份有限公司版權所有',
		'_Did_you_check':'您今天是否已查看過 ',
		'_www_zyxel_com':'www.zyxel.com',
		'_today':' ?'
		}];

/* tx.html */
var _tx=[{
		'_CLI_Message':'CLI 訊息',
		'_Start_CLI_command':'啟動 CLI 命令',
		'_End_CLI_command':'結束 CLI 命令'
		}];

/* rx.html */
var _rx=[{'_RX_Message':'接收訊息'}];

/* status.html */
var _status=[{
		'_Message':'訊息',
		'_Ready':'準備就緒'
		}];

/* grant_access.html */
var _grant_access=[{'_ZyWALL_has_granted_your_access':'ZyWALL 已允許您的接取。'}];

/* fwDone.html */
var _fwDone=[{'_Please_Wait':'請稍後...'}];

/* fwDone.html */
var _fwupdone=[{'_Please_Wait':'請稍後...',
			'_warning_message1':'Firmware upload is in progress -- Do not turn off the power or reset the ZyWALL.',
			'_warning_message2':'The complete firmware update may take up to 5 minutes.'
			}];

/* vpndial.html */		
var _vpndial=[{'_Please_Wait':'請稍後...'}];

/* apacheDone.html */
var _apacheDone=[{'_Please_Wait':'請稍後...'}];

/* rebootDone.html */
var _rebootDone=[{'_Please_Wait':'請稍後...'}];

/* homedial.html */
var _homedial=[{'_Please_Wait':'請稍後...'}];

/* waitdial.html */
var _waitdial=[{'_Please_Wait':'請稍後...'}];

//warning.html file
var _warning=[{'_Warning_Message':'警告訊息'}];

//waitdata.html file
var _waitdata=[{'_Please_Wait':'請稍後...'}];

/*----- Status -----*/

/* home.html */
var _home=[{			
		/* Device Information */
		'_Device_Information':'裝置資訊',
		'_System_Name':'系統名稱',
		'_Model_Name':'型號名稱',
		'_Serial_Number':'序號',
		'_MAC_Address_Range':'MAC 位址範圍',
		'_Firmware_Version':'韌體版本',			
		/* System Resource */
		'_System_Resources':'系統資源',
		'_CPU_Usage':'CPU 使用',
		'_Memory_Usage':'記憶體使用',
		'_Flash_Usage':'Flash 使用',
		'_Active_Sessions':'現用工作階段',			
		/* Interface Status Summary */
		'_Interface_Status_Summary':'介面狀態摘要',
		'_Name':'名稱',
		'_Status':'狀態',
		'_HA_Status':'HA 狀態',
		'_Zone':'區域',
		'_IP_Address':'IP 位址',
		'_Renew_Dial':'更新/撥接',			
		/* System Status */
		'_System_Status':'系統狀態',
		'_System_Uptime':'系統開機時間',
		'_Current_Date_Time':'目前日期/時間',
		'_VPN_Status':'VPN 狀態',
		'_DHCP_Table':'DHCP 表格',
		'_Statistics':'埠統計',
		'_Current_User_List':'登入使用者',
		'_Current_Login_User':'目前登入使用者',
		'_Number_of_Login_Users':'登入使用者數目',			
		/* Licensed Service Status */
		'_Licensed_Service_Status':'授權服務狀態',
		'_IDP':'入侵偵測與防護',
		'_License_Status_Remaining_days':'授權狀態/剩餘天數',
		'_Signature_Version':'簽章版本',
		'_Last_Update_Time':'上次更新時間',
		'_Total_Signature_Number':'完整簽章號碼',
		'_Anti_Virus':'防毒',
		'_Content_Filter':' 內容過濾',
		/* Top 5 Intrusion & Virus Detection*/
		'_Top5':'偵測到的前五大入侵與病毒',
		'_Rank':'等級',
		'_Intrusion_Detected':'偵測到入侵',
		'_Virus_Detected':'偵測到病毒',
		/* Refresh */
		'_Refresh_Interval':'重新整理間隔',
		'_Refresh_Now':'立即重新整理',
		/* force logout */
		'_Current_User_List':'使用者',
		'_User_ID':'使用者 ID',
		'_Reauth_Lease_T_':'再驗證租用時間',
		'_Type':'類型',
		'_IP_address':'IP 位址',
		'_Force_Logout':'強迫登出'
		}];

/*----- Licensing > Registration -----*/ 
/* vpnitval.html */
var _vpnitval=[{'_Poll_Interval':'查詢間隔 (1-60 秒):'}];

/* vpnstatus.html */
var _vpnstatus=[{
		'_VPN_Table':'VPN 表格',
		'_Name':'名稱',
		'_Encapsulation':'封裝',
		'_IPSec_Algorithm':'IPSec 演算法'
		}];

/* dhcpstatus.html */
var _dhcpstatus=[{
		'_DHCP_Table':'DHCP 表格',
		'_Interface':'介面',
		'_IP_Address':'IP 位址',
		'_Host_Name':'主機名稱',
		'_MAC_Address':'MAC 位址',
		'_Reserve':'保留'
		}];

/* ifacestatus.html */
var _ifacestatus=[{
		'_Statistics_Table':'統計表',
		'_Port':'埠',
		'_status':'狀態',
		'_TxPkts':'傳送封包',
		'_RxPkts':'接收封包',
		'_Collisions':'碰撞',
		'_Tx':'每秒傳送位元組',
		'_Rx':'每秒接收位元組',
		'_Up_Time':'已執行時間',
		'_System_Up_Time':'系統已執行時間'
		}];
		
/* ifaceitval.html */
var _ifaceitval=[{'_Poll_Interval':'查詢間隔 (1-60 秒):'}];		

/*----- Licensing > Registration -----*/

/* regist.html */
var _regist=[{
		'_Device_Registration':'裝置註冊',
		'_Trial_Service_Activation':'啟動試用服務',
		'_regtext1':'此裝置並未至 myZyXEL.com 註冊。&nbsp;',
		'_regtext2':'請在下面輸入資訊以<b>註冊</b>裝置 ',
		'_regtext3':'如果您沒有 myZyXEL.com 帳號，但卻忘記使用者名稱或密碼，請前往 ',
		'_regtext4':'<a href="http://www.myZyXEL.com"><font color="#FF0000"><i><u>www.myZyXEL.com</u></i></font></a>',
		'_regtext5':'尋求協助.',
		'_new_myZyXEL_com_account':'新建 myZyXEL.com 帳號',
		'_existing_myZyXEL_com_account':'現有 myZyXEL.com 帳號',
		'_User_Name':'使用者名稱',
		'_you_can_click':'您可以按一下滑鼠檢查使用者名稱是否存在',
		'_Password':'密碼',
		'_Confirm_Password':'確認密碼',
		'_E_Mail_Address':'電子郵件位址',
		'_Country_Code':'國碼',
		'_Trial_Service_Activation':'啟動試用服務',
		'_IDP':'IDP/應用程式巡查',
		'_Anti_Virus':'防毒',
		'_Content_Filter':'內容過濾'
		}];

/* registmgn.html */
var _registmgn=[{
		'_Service_Management':'服務管理',
		'_Service':'服務',
		'_Status':'狀態',
		'_Registration_Type':'註冊類型',
		'_Expiration_day':'截止日期',
		'_Count':'計數',
		'_License_Upgrade':'授權更新',
		'_License_Key':'授權密碼',
		'_Note':' 注意：必須與 myZyXEL.com 同步才能下載授權資訊'				
		}];

/*----- Licensing > Update -----*/

/* idpfile.html */
var _idpfile=[{
		'_Signature_Information':'簽章資訊',
		'_Current_Version':'目前版本',
		'_Signature_Number':'簽章號碼',
		'_Released_Date':'發行日期',
		'_Remote_Update':'遠端更新',				
		'_Synchronize_the_IDP':'利用線上更新伺服器使 IDP 簽章套件同步化為最新版本。&nbsp; (需啟動 myZyXEL.com)',
		'_Auto_Update':'自動更新',
		'_Hourly':'每小時',
		'_Daily':'每日',
		'_Hour':'(時)',
		'_Weekly':'每週',
		'_Day':'(日期)'
		}];

/* idpfile.html */
var _idpfile_1=[{
		'_Signature_Information':'簽章資訊',
		'_Current_Version':'目前版本',
		'_Signature_Number':'簽章號碼',
		'_Released_Date':'發行日期',
		'_Remote_Update':'遠端更新',				
		'_Synchronize':'利用線上更新伺服器使系統保護簽章套件同步化為最新版本。',
		'_Auto_Update':'自動更新',
		'_Hourly':'每小時',
		'_Daily':'每日',
		'_Hour':'(時)',
		'_Weekly':'每週',
		'_Day':'(日期)'
		}];

/* antiupdate.html */
var _antiupdate=[{
		'_Signature_Information':'簽章資訊',
		'_Current_Version':'目前版本',
		'_Signature_Number':'簽章號碼',
		'_Released_Date':'發行日期',
		'_Remote_Update':'遠端更新',
		'_Synchronize':'利用線上更新伺服器使防毒簽章套件同步化為最新版本。&nbsp; (需啟動 myZyXEL.com)',
		'_Auto_Update':'自動更新',
		'_Hourly':'每小時',
		'_Daily':'每日',
		'_Hour':'(時)',
		'_Weekly':'每週',
		'_Day':'(日期)'
		}];

/* upd.html */
var _upd=[{
		'_Rendering':'正在轉譯中...',
		'_ZyWALL':'ZyWALL 線上更新伺服器'
		}];
		
/*----- Network > Interface -----*/

/* ifacesummary.html */
var _ifacesummary=[{
		'_Interface_Summary':'介面摘要',
		'_Name':'名稱',
		'_Status':'狀態',
		'_HA_Status':'HA 狀態',
		'_Zone':'區域',
		'_IP_Netmask':'IP 位址/網路遮罩',
		'_IP_Assignment':'IP 指定',
		'_Services':'服務',
		'_Renew_Dial':'更新/撥接',
		'_Statistics':'介面統計',
		'_Tx_Pkts':'傳送封包',
		'_Rx_Pkts':'接收封包',
		'_Collision':'碰撞',
		'_Tx_Bs':'每秒傳送位元組',
		'_Rx_Bs':'每秒接收位元組'
		}]

/* Interface.html */
var _Interface=[{
		'_Configuration':'設定',
		'_Name':'名稱',
		'_IP_Address':'IP 位址',
		'_Mask':'遮罩',
		'_Modify':'修改'
		}];

/* ifEdit.html file */
var _ifEdit=[{
		'_Ethernet_Interface_Properties':'乙太網路介面內容',
		'_Enable':'啟用',
		'_Interface_Name':'介面名稱',
		'_Description':'說明',
		'_Optional':'(可省略)',
		'_IP_Address_Assignment':'IP 位址指派',
		'_Get_Automatically':'自動取得',
		'_Use_Fixed_IP_Address':'使用固定 IP 位址',
		'_IP_Address':'IP 位址',
		'_Subnet_Mask':'子網路遮罩',
		'_Gateway':'閘道',
		'_Metric':'度量資訊',
		'_Interface_Parameters':'介面頻寬',
		'_Upstream_Bandwidth':'上傳頻寬',
		'_Downstream_Bandwidth':'下傳頻寬',
		'_Kbps':'千位元組',
		'_MTU':'住商大樓',
		'_Bytes':'位元組',
		'_RIP_Setting':'RIP 設定',
		'_Enable_RIP':'啟用 RIP',
		'_Direction':'方向',
		'_Send_Version':'傳送版本',
		'_Receive_Version':'接收版本',
		'_V2_Broadcast':'V2-廣播',
		'_OSPF_Setting':'OSPF 設定',
		'_Area':'區域',
		'_Priority':'優先權',
		'_Link_Cost':'連結成本',
		'_Passive_Interface':'被動介面',
		'_Authentication':'認證',
		'_Text_Authentication_Key':'純文字認證金鑰',
		'_MD5_Authentication_ID':'MD5 認證 ID',
		'_MD5_Authentication_Key':'MD5 認證金鑰',
		'_Type':'類型',
		'_Authentication':'認證',
		'_DHCP_Setting':'DHCP 設定',
		'_DHCP':'DHCP',
		'_Relay_Server_1':'轉送站伺服器 1',
		'_Relay_Server_2':'轉送站伺服器 2',
		'_IP_Address_1':'(IP 位址)',
		'_IP_Pool_Start_Address_Optional':'IP 集區起始位址 (可省略)',
		'_Pool_Size':'集區大小',
		'_First_DNS_Server_Optional':'第一 DNS 伺服器 (可省略)',
		'_Second_DNS_server_Optional':'第二 DNS 伺服器 (可省略)',
		'_Third_DNS_Server_Optional':'第三 DNS 伺服器 (可省略)',
		'_First_WINS':'第一 WINS 伺服器 (可省略)',
		'_Second_WINS':'第二 WINS 伺服器 (可省略)',
		'_Lease_time':'租用時間',
		'_infinite':'無限',
		'_days':'天',
		'_hours_Optional':'小時 (可省略)',
		'_minutes_Optional':'分鐘 (可省略)',
		'_Static_DHCP_Table':'靜態 DHCP 表格',
		'_Ping_Check':'Ping 檢查',
		'_seconds':'秒',
		'_Domain_Name_or_IP_Address':'(網域名稱或 IP 位址)',
		'_Check_Period':'檢查時限',
		'_Check_Timeout':'檢查等候時間',
		'_Check_Fail_Tolerance':'檢查失敗容限',
		'_Ping_Default_Gateway':'Ping 預設閘道器',
		'_Ping_this_address':'Ping 此位址'
		}];

/* viredit.html */
var _viredit=[{
		'_Virtual_Interface_Properties':'虛擬介面內容',
		'_Interface_Name':'介面名稱',
		'_Description':'說明',
		'_Optional':'(可省略)',
		'_IP_Address_Assignment':'IP 位址指派',
		'_IP_Address':'IP 位址',
		'_Subnet_Mask':'子網路遮罩',
		'_Gateway':'閘道',
		'_Metric':'度量資訊',
		'_Interface_Parameters':'介面頻寬',
		'_Upstream_Bandwidth':'上傳頻寬',
		'_Downstream_Bandwidth':'下傳頻寬',
		'_Kbps':'千位元組'
		}];
		
/* portgrouping.html */
var _portgrouping=[{
		'_Port_Grouping':'埠群組',
		'_Representative_Interface':'代表介面',
		'_Physical_Port':'實體埠'
		}];

/* vlan.html */
var _vlan=[{
		'_Configuration':'設定',
		'_Name':'名稱',
		'_Port_VID':'埠/VID',
		'_IP_Address':'IP 位址',
		'_Mask':'遮罩'
		}];

/* vlanedit.html */
var _vlanedit=[{
		'_VLAN_Interface_Properties':'VLAN 介面內容',
		'_Enable':'啟用',
		'_Interface_Name':'介面名稱',
		'_Port':'埠',
		'_Virtual_LAN_Tag':'虛擬區域網路標籤',
		'_Description':'說明',
		'_Optional':'(可省略)',
		'_IP_Address_Assignment':'IP 位址指派',
		'_Get_Automatically':'自動取得',
		'_Use_Fixed_IP_Address':'使用固定 IP 位址',
		'_IP_Address':'IP 位址',
		'_Subnet_Mask':'子網路遮罩',
		'_Gateway':'閘道',
		'_Metric':'度量資訊',
		'_Interface_Parameters':'介面頻寬',
		'_Upstream_Bandwidth':'上傳頻寬',
		'_Downstream_Bandwidth':'下傳頻寬',		
		'_Kbps':'千位元組',
		'_MTU':'住商大樓',
		'_Bytes':'位元組',	
		'_DHCP_Setting':'DHCP 設定',
		'_DHCP':'DHCP',
		'_Relay_Server_1':'轉送站伺服器 1',
		'_Relay_Server_2':'轉送站伺服器 2',		
		'_IP_Address_1':'(IP 位址)',
		'_IP_Pool_Start_Address_Optional':'IP 集區起始位址 (可省略)',
		'_Pool_Size':'集區大小',
		'_First_DNS_Server_Optional':'第一 DNS 伺服器 (可省略)',
		'_Second_DNS_server_Optional':'第二 DNS 伺服器 (可省略)',
		'_Third_DNS_Server_Optional':'第三 DNS 伺服器 (可省略)',
		'_First_WINS':'第一 WINS 伺服器 (可省略)',
		'_Second_WINS':'第二 WINS 伺服器 (可省略)',
		'_Lease_time':'租用時間',
		'_infinite':'無限',
		'_days':'天',
		'_hours_Optional':'小時 (可省略)',
		'_minutes_Optional':'分鐘 (可省略)',
		'_Static_DHCP_Table':'靜態 DHCP 表格',
		'_Ping_Check':'Ping 檢查',
		'_seconds':'秒',
		'_Domain_Name_or_IP_Address':'(網域名稱或 IP 位址)',
		'_Check_Period':'檢查時限',
		'_Check_Timeout':'檢查等候時間',
		'_Check_Fail_Tolerance':'檢查失敗容限',
		'_Ping_Default_Gateway':'Ping 預設閘道器',
		'_Ping_this_address':'Ping 此位址'
		}];

/* bridge.html */
var _bridge=[{
		'_Configuration':'設定',
		'_Name':'名稱',
		'_IP_Address':'IP 位址',
		'_Member':'成員'
		}];

/* bridgeedit.html */
var _bridgeedit=[{
		'_Bridge_Interface_Properties':'橋接器介面內容',
		'_Enable':'啟用',
		'_Interface_Name':'介面名稱',
		'_Description':'說明',
		'_Optional':'(可省略)',
		'_Member_Configuration':'成員設定',
		'_Available':'可用',
		'_Member':'成員',
		'_IP_Address_Assignment':'IP 位址指派',
		'_Get_Automatically':'自動取得',
		'_Use_Fixed_IP_Address':'使用固定 IP 位址',
		'_IP_Address':'IP 位址',
		'_Subnet_Mask':'子網路遮罩',
		'_Gateway':'閘道',
		'_Metric':'度量資訊',
		'_Interface_Parameters':'介面頻寬',
		'_Upstream_Bandwidth':'上傳頻寬',
		'_Downstream_Bandwidth':'下傳頻寬',
		'_Kbps':'千位元組',
		'_MTU':'住商大樓',
		'_Bytes':'位元組',
		'_DHCP_Setting':'DHCP 設定',
		'_DHCP':'DHCP',
		'_Relay_Server_1':'轉送站伺服器 1',
		'_Relay_Server_2':'轉送站伺服器 2',		
		'_IP_Address_1':'(IP 位址)',
		'_IP_Pool_Start_Address_Optional':'IP 集區起始位址 (可省略)',
		'_Pool_Size':'集區大小',
		'_First_DNS_Server_Optional':'第一 DNS 伺服器 (可省略)',
		'_Second_DNS_server_Optional':'第二 DNS 伺服器 (可省略)',
		'_Third_DNS_Server_Optional':'第三 DNS 伺服器 (可省略)',
		'_First_WINS':'第一 WINS 伺服器 (可省略)',
		'_Second_WINS':'第二 WINS 伺服器 (可省略)',
		'_Lease_time':'租用時間',
		'_infinite':'無限',
		'_days':'天',
		'_hours_Optional':'小時 (可省略)',
		'_minutes_Optional':'分鐘 (可省略)',
		'_Static_DHCP_Table':'靜態 DHCP 表格',
		'_Ping_Check':'Ping 檢查',
		'_seconds':'秒',
		'_Domain_Name_or_IP_Address':'(網域名稱或 IP 位址)',
		'_Check_Period':'檢查時限',
		'_Check_Timeout':'檢查等候時間',
		'_Check_Fail_Tolerance':'檢查失敗容限',
		'_Ping_Default_Gateway':'Ping 預設閘道器',
		'_Ping_this_address':'Ping 此位址'
		}];

/* dhcp.html */
var _dhcp=[{
		'_Static_DHCP':'靜態 DHCP',
		'_IP_Address':'IP 位址',
		'_MAC':'MAC 媒體存取控制'
		}];
			
/* pppoe.html */
var _pppoe=[{
		'_Name':'名稱',
		'_Base_Interface':'基礎介面',		
		'_Account_Profile':'帳號設定組合'
		}];

/* pppedit.html */
var _pppedit=[{
		'_PPP_Interface_Properties':'PPP 介面內容',
		'_Enable':'啟用',
		'_Interface_Name':'介面名稱',
		'_Nailed_Up':'永遠連線',
		'_Dial_on_Demand':'需要時撥接',
		'_Description':'說明',
		'_Optional':'(可省略)',
		'_Base_Interface':'基礎介面',
		'_Account_Profile':'帳號設定組合',
		'_Protocol':'通訊協定',
		'_User_Name':'使用者名稱',
		'_Service_Name':'服務名稱',
		'_IP_Address_Assignment':'IP 位址指派',
		'_Get_Automatically':'自動取得',
		'_Use_Fixed_IP_Address':'使用固定 IP 位址',
		'_IP_Address':'IP 位址',
		'_Gateway':'閘道',
		'_Metric':'度量資訊',
		'_Interface_Parameters':'介面頻寬',
		'_Upstream_Bandwidth':'上傳頻寬',
		'_Downstream_Bandwidth':'下傳頻寬',
		'_Kbps':'千位元組',
		'_MTU':'住商大樓',
		'_Bytes':'位元組',
		'_Ping_Check':'Ping 檢查',
		'_seconds':'秒',
		'_Domain_Name_or_IP_Address':'(網域名稱或 IP 位址)',
		'_Check_Period':'檢查時限',
		'_Check_Timeout':'檢查等候時間',
		'_Check_Fail_Tolerance':'檢查失敗容限',
		'_Ping_Default_Gateway':'Ping 預設閘道器',
		'_Ping_this_address':'Ping 此位址'
		}];

/* auxiliary.html */
var _auxiliary=[{
		'_Auxiliary_Interface_Properties':'輔助介面內容',
		'_Enable':'啟用',
		'_Description':'說明',
		'_Optional':'(可省略)',
		'_Port_Speed':'埠速度',
		'_Dialing_Type':'撥號方式',
		'_Tone':'按鍵式',
		'_Pulse':'轉盤式',
		'_Initial_String':'初始字串',
		'_Auxiliary_Configuration':'輔助設定',
		'_Phone_Number':'電話號碼',
		'_User_Name':'使用者名稱',
		'_Password':'密碼',
		'_Retype_to_confirm':'重新鍵入確認',
		'_Authentication_Type':'認證方式',
		'_Timeout':'等候時間',
		'_Seconds':'(秒)',
		'_Idle_timeout':'閒置等候時間'
		}];

/* groups.html */
var _groups=[{
		'_Name':'名稱',
		'_Algorithm':'演算法'
		}];

/* gpedit.html */
var _gpedit=[{
		'_Trunk_Members':'主幹成員',
		'_Name':'名稱',
		'_Load_Balancing_Algorithm':'負載平衡演算法',
		'_Member':'成員',
		'_Mode':'模式',
		'_Weight':'權數',
		'_Downstream_Bandwidth':'下傳頻寬',
		'_Upstream_Bandwidth':'上傳頻寬',
		'_Spillover':'溢載接手'
		}];

/*----- Network > Routing -----*/

/* policyroute.html */
var _policyroute=[{
		'_User':'使用者',
		'_Schedule':'排程',
		'_Incoming':'內送',
		'_Source':'來源',
		'_Destination':'終點',
		'_Service':'服務',
		'_Next_Hop':'下個躍點',
		'_SNAT':'來源網路位址轉譯',
		'_BWM':'頻寬監控程式'
		}];

/* proutedit.html */
var _proutedit=[{
		'_Configuration':'設定',
		'_Enable':'啟用',
		'_Description':'說明',
		'_Optional':'(可省略)',
		'_Criteria':'標準',
		'_User':'使用者',
		'_Incoming':'內送',
		'_Source_Address':'來源位址',
		'_Destination_Address':'終點位址',
		'_Schedule':'排程',
		'_Service':'服務',
		'_Next_Hop':'下個躍點',
		'_Type':'類型',
		'_Gateway':'閘道',
		'_Interface':'介面',
		'_VPN_Tunnel':'VPN 通道',
		'_Trunk':'主幹',
		'_Address_Translation':'位址轉譯',
		'_Source_Network_Address_Translation':'來源網路位址轉譯',
		'_Port_Triggering':'埠觸發',
		'_Incoming_Service':'內送服務',
		'_Trigger_Service':'觸發服務',
		'_Bandwidth_Shaping':'頻寬控制',
		'_Maximum_Bandwidth':'最大頻寬',
		'_Bandwidth_Priority':'頻寬優先權',
		'_is_highest_priority':'為最高優先權',
		'_MBU':'最大頻寬使用'
		}];
		
/* staticroute.html */
var _staticroute=[{
		'_Destination':'終點',
		'_Subnet_Mask':'子網路遮罩',
		'_Next_Hop':'下個躍點',
		'_Metric':'度量資訊'
		}];

/* stroutedit.html */
var _stroutedit=[{
		'_Static_Route_Setting':'靜態路由設定',
		'_Destination_IP':'終點 IP',
		'_Subnet_Mask':'子網路遮罩',
		'_Gateway_IP':'閘道 IP',
		'_Interface':'介面',
		'_Metric':'度量資訊'
		}];
		
/* rip.html */
var _rip=[{
		'_Authentication':'認證',
		'_Text_Authentication_Key':'純文字認證金鑰',
		'_MD5_Authentication_ID':'MD5 認證 ID',
		'_MD5_Authentication_Key':'MD5 認證金鑰',
		'_Redistribute':'重新分配',
		'_Active':'啟動',
		'_Name':'名稱',
		'_Metric':'度量資訊',
		'_OSPF':'OSPF',
		'_Static_Route':'靜態路由'
		}];

/* ospf.html */
var _ospf=[{
		'_OSPF_Router_ID_IP_Address':'OSPF 路由器 ID (IP 位址)',
		'_Default':'預設',
		'_User_Defined':'使用者定義',
		'_Redistribute':'重新分配',
		'_Active':'啟動',
		'_Route':'路由器',
		'_Type':'類型',
		'_Metric':'度量資訊',
		'_RIP':'RIP',
		'_Static_Route':'靜態路由',
		'_Area':'區域',
		'_Authentication':'認證'
		}];

/* ospfedit.html */
var _ospfedit=[{
		'_Area_Setting':'區域設定',
		'_Area_ID':'區域 ID',
		'_Type':'類型',
		'_Authentication':'認證',
		'_Text_Authentication_Key':'純文字認證金鑰',
		'_MD5_Authentication_ID':'MD5 認證 ID',
		'_MD5_Authentication_Key':'MD5 認證金鑰',
		'_Virtual_Link':'虛擬連接',
		'_Peer_Router_ID':'對等路由器 ID'
		}];

/*----- Network > Zone -----*/

/* zone.html */
var _zone=[{
		'_Configuration':'設定',
		'_Name':'名稱',
		'_Block_Intra_zone_Traffic':'封鎖內部區域',
		'_Member':'成員'
		}];

/* zoneedit.html */
var _zoneedit=[{
		'_Group_Members':'群組成員',
		'_Name':'名稱',
		'_Block_Intra_zone_Traffic':'封鎖內部區域流量'
		}];

/*----- Network > DDNS -----*/

/* ddns.html */
var _ddns=[{
		'_My_Domain_Names':'我的網域名稱',
		'_Profile_Name':'設定組合名稱',
		'_Domain_Name':'網域名稱',
		'_DDNS_Type':'DDNS 類型',
		'_Wildcard':'萬用字元',
		'_IP_Address_Update_Policy':'IP 位址更新策略',
		'_WAN_Interface':'WAN 介面',
		'_HA__Interface':'HA* 介面'
		}];

/* ddnsed.html */
var _ddnsed=[{
		'_DDNS_Profile':'DDNS 設定組合',
		'_Profile_Name':'設定組合名稱',
		'_DDNS_Type':'DDNS 類型',
		'_Username':'使用者名稱',
		'_Password':'密碼',
		'_Domain_name':'網域名稱',
		'_wildcard':' 萬用字元',
		'_IP_Address_Update_Policy':'IP 位址更新策略',
		'_Custom_IP':'自訂 IP',
		'_WAN_Interface':'WAN 介面',
		'_HA_Interface':'HA 介面',
		'_Mail_Exchanger':'郵件交換器',
		'_Optional':'(可省略)',
		'_Backup_mail_exchanger':'備份郵件交換器'
		}];

/*----- Network > Virtual Server -----*/

/* virsvr.html */
var _virsvr=[{
		'_Virtual_Server':'虛擬伺服器',
		'_Total_Virtual_Servers':'虛擬伺服器總數：',
		'_entries_per_page':'每頁項目數',
		'_Page':'頁數',
		'_Name':'名稱',
		'_Interface':'介面',
		'_Original_IP':'原始 IP',
		'_Mapped_IP':'對應 IP',
		'_Protocol':'通訊協定',
		'_Original_Port':'原始埠',
		'_Mapped_Port':'對應埠'
		}];

/* virsvredit.html */
var _virsvredit=[{
		'_Enable':'啟用',
		'_Name':'名稱',
		'_Interface':'介面',
		'_Original_IP':'原始 IP',
		'_User_Defined':'使用者定義',
		'_Mapped_IP':'對應 IP',
		'_IP_Address':'(IP 位址)',
		'_Original_Port':'原始埠',
		'_Mapped_Port':'對應埠',
		'_Mapping_Type':'對應類型',
		'_Protocol_Type':'通訊協定類型',		
		'_Original_Port':'原始埠',
		'_Original_Start_Port':'原始起始埠',
		'_Original_End_Port':'原始結束埠',
		'_Mapped_Start_Port':'對應起始埠',
		'_Mapped_End_Port':'對應結束埠',
		'_Please1':'* 請確認防火牆允許虛擬伺服器的傳輸流量通過。',
		'_Please2':'* 如果虛擬伺服器也要建立連至用戶端的連線，請建立對應的策略路由 (NAT 1:1) '
		}];

/*----- Network > HTTP Redirect -----*/

/* httpred.html */
var _httpred=[{
		'_Configuration':'設定',
		'_Name':'名稱',
		'_Interface':'介面',
		'_Proxy_Server':'Proxy 伺服器',
		'_Port':'埠'
		}];

/* httprededit.html */
var _httprededit=[{
		'_Enable':'啟用',
		'_Name':'名稱',
		'_Interface':'介面',
		'_Proxy_server':'Proxy 伺服器',
		'_Port':'埠'
		}];

/*----- Network > ALG -----*/

/* VoipAlg.html */
var _VoipAlg=[{
		'_SIP_Setting':'SIP 設定',
		'_Enable_SIP_Transformations':'啟用 SIP 轉換',
		'_SIP_Signaling_Port':'SIP 發訊埠：',
		'_Additional_SIP_Signaling_Port':'轉譯用額外 SIP 發訊埠 (UDP)：(可省略)',		
		'_SIP_Signaling_inactivity_time_out':'SIP 訊號閒置等候時間：',
		'_seconds':'(秒)',
		'_SIP_Media_inactivity_time_out' :'SIP 媒體閒置等候時間：',		
		'_H_323_Setting':'H.323 設定',
		'_Enable_H_323_transformations':'啟用 H.323 轉換',
		'_H_323_Signaling_Port':'H.323 發訊埠:',
		'_Additional_H_323_Signaling_Port':'轉譯用額外 H.323 發訊埠：(可省略)',
		'_FTP_Setting':'FTP 設定',
		'_Enable_FTP_transformations':'啟用 FTP 轉換',      
		'_FTP_Signaling_Port':'FTP 發訊埠：',
		'_Additional_FTP_Signaling_Port':'轉譯用額外 FTP 發訊埠：(可省略)'
		}];

/*----- Firewall -----*/

/* firewall.html */
var _firewall=[{
		'_Global_Setting':'全域設定',
		'_Enable_Firewall':'啟用防火牆',
		'_Allow_Asymmetrical_Route':'允許非對稱路由',
		'_Maximum_session_per_Host':'每台主機最多工作階段數',
		'_Firewall_rule':'防火牆規則',
		'_Through_ZyWALL_rules':'通過 ZyWALL 規則',
		'_Zone_Pairs':'區域組',
		'_All_rules':'所有規則',
		'_To_ZyWALL_rules':'To-ZyWALL 規則',
		'_From_Zone':'起始區域',
		'_To_Zone':'結束區域',
		'_Priority':'優先權',
		'_Schedule':'排程',
		'_User':'使用者',
		'_Source':'來源',
		'_Destination':'終點',
		'_Service':'服務',
		'_Access':'權限',
		'_Log':'日誌',		
		'_From':'自',
		'_To':'至'
		}];

/* firewalledit.html */
var _firewalledit=[{
		'_Configuration':'設定',
		'_Enable':'啟用',
		'_Description':'說明',
		'_Optional':'(可省略)',
		'_Schedule':'排程',
		'_User':'使用者',
		'_Source':'來源',
		'_Destination':'終點',
		'_Service':'服務',
		'_Access':'權限',
		'_Log':'日誌',				
		'_From':'自',
		'_To':'至'
		}];

/*----- VPN > IPSec VPN -----*/

/* vpnc.html */
var _vpnc=[{
		'_Configuration':'設定',
		'_Total_Connection':'總連線數目',
		'_connection_per_page':'每頁連線數',
		'_Page':'頁數',
		'_Name':'名稱',
		'_VPN_Gateway':'VPN 閘道器',
		'_Encapsulation':'封裝',
		'_Algorithm':'演算法',
		'_Policy':'策略'
		}];
	
/* vpncmkedit.html */
var _vpncmkedit=[{
		'_VPN_Connection':'VPN 連線',
		'_Connection_Name':'連線名稱',
		'_VPN_Gateway':'VPN 閘道器',
		'_Name':'名稱',
		'_Manual_Key':'手動金鑰',
		'_SPI':'SPI 安全參數索引',
		'_Encapsulation_Mode':'封裝模式',
		'_Active_Protocol':'現用通訊協定',
		'_Encryption_Algorithm':'加密演算法',
		'_Authentication_Algorithm':'認證演算法',
		'_Encryption_Key':'加密金鑰',
		'_Authentication_Key':'認證金鑰',
		'_Policy':'策略',
		'_Local_Policy':'本機策略',
		'_Remote_Policy':'遠端策略',
		'_Property':'內容',
		'_My_Address':'我的位址',
		'_Secure_Gateway_Address':'安全閘道位址',
		'_Enable_NetBIOS_broadcast_over_IPSec':'透過 IPSec 啟用 NetBIOS 廣播',
		'_Inbound_Outbound_Traffic_NAT':'進向/出向流量 NAT',
		'_Outbound_Traffic':'出向流量',
		'_Source_NAT':'來源 NAT',
		'_Source':'來源',
		'_Destination':'終點',
		'_SNAT':'來源網路位址轉譯',
		'_Inbound_Traffic':'進向流量',
		'_Source_NAT':'來源 NAT',
		'_Destination_NAT':'終點 NAT',
		'_Original_IP':'原始 IP',
		'_Mapped_IP':'對應 IP',
		'_Protocol':'通訊協定',
		'_Original_Port':'原始埠',
		'_Mapped_Port':'對應埠'
		}];

/* vpncikeedit.html */
var _vpncikeedit=[{
		'_VPN_Connection':'VPN 連線',
		'_Connection_Name':'連線名稱',
		'_VPN_Gateway':'VPN 閘道器',
		'_Name':'名稱',
		'_Phase_2':'階段 2',
		'_Active_Protocol':'現用通訊協定',
		'_Encapsulation':'封裝',
		'_Proposal':'提議',
		'_SA_Life_Time':'SA 存留時間 (秒)',
		'_Perfect_Forward_Secrecy':'完整轉寄密碼 (PFS)',
		'_Policy':'策略',
		'_Policy_Enforcement':'策略強制執行',
		'_Local_policy':'本機策略',
		'_Remote_policy':'遠端策略',
		'_Property':'內容',
		'_Nailed_Up':'永遠連線',
		'_Enable_Replay_Detection':'啟用重播偵測',
		'_Enable_NetBIOS_broadcast_over_IPSec':'透過 IPSec 啟用 NetBIOS 廣播',
		'_Inbound_Outbound_traffic_NAT':'進向/出向流量 NAT',
		'_Outbound_Traffic':'出向流量',
		'_Source_NAT':'來源 NAT',
		'_Source':'來源',
		'_Destination':'終點',
		'_SNAT':'來源網路位址轉譯',
		'_Inbound_Traffic':'進向流量',
		'_Destination_NAT':'終點 NAT',
		'_Original_IP':'原始 IP',
		'_Mapped_IP':'對應 IP',
		'_Protocol':'通訊協定',
		'_Original_Port':'原始埠',
		'_Mapped_Port':'對應埠',
		'_Encryption':'加密',
		'_Authentication':'認證'
		}];

/* vpng.html */
var _vpng=[{
		'_Configuration':'設定',
		'_Name':'名稱',
		'_My_address':'我的位址',
		'_Secure_Gateway':'安全閘道',
		'_VPN_Connection':'VPN 連線'
		}];

/* vpngedit.html */
var _vpngedit=[{
		'_VPN_Gateway':'VPN 閘道器',
		'_VPN_Gateway_Name':'VPN 閘道器名稱',
		'_IKE_Phase_1':'IKE 階段 1',
		'_Negotiation_Mode':'協商模式',
		'_Proposal':'提議',
		'_Encryption':'加密',
		'_Authentication':'認證',
		'_Key_Group':'金鑰群組',
		'_SA_Life_Time_Seconds':'SA 存留時間 (秒)',
		'_NAT_Traversal':'NAT 橫跨',
		'_Dead_Peer_Detection_DPD':'斷線偵測 (DPD)',
		'_Property':'內容',
		'_My_Address':'我的位址',
		'_Interface':'介面',
		'_Domain_Name':'網域名稱',
		'_Secure_Gateway_Address':'安全閘道位址',
		'_Authentication_Method':'認證方式',
		'_Pre_Shared_Key':'預先共用金鑰',
		'_Certificate':'憑證',
		'_See':'請參閱',
		'_My_Certificates':'我的憑證',
		'_Local_ID_Type':'本機 ID 類型',
		'_Content':'內容',
		'_Peer_ID_Type':'對等裝置 ID 類型',
		'_Extended_Authentication':'延伸性認證',
		'_Enable_Extended_Authentication':'啟用延伸性認證',
		'_Server_Mode':'伺服器模式',
		'_Client_Mode':'用戶端模式',
		'_User_Name':'使用者名稱',
		'_Password':'密碼'
		}];

/* contra.html */
var _contra=[{
		'_Configuration':'設定',
		'_Name':'名稱'
		}];

/* contraedit.html */
var _contraedit=[{
		'_Group_Members':'群組成員',
		'_Name':'名稱',
		'_Member':'成員'
		}];
		
/* vpnsa.html */
var _vpnsa=[{
		'_Current_IPSec_Security_Associations':'使用中的 IPSec 安全性關聯',
		'_Name':'名稱',
		'_Encapsulation':'封裝',
		'_Policy':'策略',
		'_Algorithm':'演算法',
		'_Up_Time':'已執行時間',
		'_Timeout':'等候時間',
		'_Inbound':'進向(位元組)',
		'_Outbound':'出向(位元組)'
		}];

/*----- VPN > SSL VPN -----*/

/* sslvpnac.html */
var _sslvpnac=[{
		'_Configuration':'設定',		
		'_Name':'名稱',
		'_User_Group':'使用者/群組',
		'_Application':'應用'
		}];
/* sslvpnacedit.html */
var _sslvpnacedit=[{
		'_Configuration':'設定',
		'_Enable':'啟用',
		'_Name':'名稱',
		'_Description':'說明',
		'_Optional':'(可省略)',		
		'_User_Group_Optional':'使用者/群組 (可省略)',		
		'_Available':'可用',
		'_Member':'成員',
		'_SSL_Application_List_Optional':'SSL 應用程式清單: (可省略)',
		'_Network_Extension_Optional':'網路延伸: (可省略)',
		'_Enable_Network_Extension':'啟用網路延伸',
		'_Assign_IP_Pool':'配置 IP 集區',
		'_DNS_Server_1':'DNS 伺服器 1',
		'_DNS_Server_2':'DNS 伺服器 2',
		'_Wins_Server_1':'WINS 伺服器 1',
		'_Wins_Server_2':'WINS 伺服器 2',
		'_Network_List':'網路表'
		}];
				
/* sslvpnmonitor.html */
var _sslvpnmonitor=[{
		'_Current_SSL_VPN_Connection':'使用中 SSL VPN 連線',		
		'_User':'使用者',
		'_Access':'權限',
		'_Login_Addr':'登入權限',
		'_Connected_Time':'連線時間',
		'_In_Bytes':'進向(位元組)',
		'_Out_Bytes':'出向(位元組)'
		}];	
			
/* sslvpnglobal.html */
var _sslvpnglobal=[{
		'_Global_Setting':'全域設定',
		'_Network_Extension_Local_IP':'網路延伸本機 IP',		
		'_Message':'訊息',
		'_Login_Message':'登入訊息',		
		'_Logout_Message':'登出訊息',
		'_Update_Client':'更新用戶端虛擬桌面 GIF',
		'_To_upload_a_GIF':'若要下載 GIF(Logo.gif) 檔案，請瀏覽至檔案位置再按一下下載。',
		'_File_Path':'檔案路徑：'
		}];	

/*----- VPN > L2TP VPN -----*/

/* l2tps.html */
var _l2tps=[{
		'_Configuration':'設定',
		'_Enable_L2TP_Over_IPSec':'啟用 L2TP Over IPSec',
		'_VPN_Connection':'VPN 連線',
		'_IP_Address_Pool':'IP 位址集區',
		'_Authentication_Method':'認證方式',
		'_Allowed_User':'核可使用者',
		'_Keep_Alive_Timer':'計時器保持運轉',
		'_seconds':'秒',
		'_First_DNS':'第一 DNS 伺服器 (可省略)',
		'_Second_DNS':'第二 DNS 伺服器 (可省略)',
		'_First_WINS':'第一 WINS 伺服器 (可省略)',
		'_Second_WINS':'第二 WINS 伺服器 (可省略)'
		}];

/* l2tps_sm.html */
var _l2tps_sm=[{
		'_Current_L2TP_Session':'使用中 L2TP 工作階段',
		'_User_Name':'使用者名稱',
		'_Hostname':'本機名稱',
		'_Assigned_IP':'配置 IP',
		'_Public_IP':'公用 IP'
		}];	

/*----- AppPatrol -----*/

/* appgeneral.html */
var _appgeneral=[{
		'_General_Setup':'一般設定',
		'_Enable_Application_Patrol':'啟用應用程式巡查功能',
		'_Registration':'註冊',
		'_Registration_Status':'註冊狀態',
		'_Registration_Type':'註冊類型',
		'_Apply_New_Registration':'套用新註冊資料',
		'_Signature_Information':'簽章資訊',
		'_Current_Version':'目前版本',
		'_Signature_Number':'簽章號碼',
		'_Released_Date':'發行日期',
		'_Update_Signatures':'更新簽章'
		}];
				
/* appCommon.html */
var _appCommon=[{
		'_Common_Protocols':'共用協定',
		'_Service':'服務',
		'_Default_Access':'預設權限',
		'_Classify':'分類',
		'_Modify':'修改'
		}];

/* appCommon.html */
var _appIM=[{
		'_Instant_Messenger':'即時通訊軟體',
		'_Service':'服務',
		'_Default_Access':'預設權限',
		'_Classify':'分類',
		'_Modify':'修改'
		}];
				
/* appCommon.html */
var _appP2P=[{
		'_P2P':'點對點',
		'_Service':'服務',
		'_Default_Access':'預設權限',
		'_Classify':'分類',
		'_Modify':'修改'
		}];
				
/* appCommon.html */
var _appVoIP=[{
		'_VoIP':'IP 語音',
		'_Service':'服務',
		'_Default_Access':'預設權限',
		'_Classify':'分類',
		'_Modify':'修改'
		}];

/* appCommon.html */
var _appStream=[{
		'_Streaming_Protocols':'串流協定',
		'_Service':'服務',
		'_Default_Access':'預設權限',
		'_Classify':'分類',
		'_Modify':'修改'
		}];

/* aplpatroledit.html */
var _aplpatroledit=[{
		'_Service':'服務',
		'_Enable_Service':'啟用服務',
		'_Service_Identification':'服務識別資訊',
		'_Name':'名稱',
		'_Auto':'自動',
		'_Service_Ports':'服務埠',
		'_Classification':'類別',
		'_Service_Port':'服務埠',
		'_Policy':'策略',
		'_Port':'埠',
		'_Schedule':'排程',
		'_User':'使用者',
		'_From':'自',
		'_To':'至',
		'_Source':'來源',
		'_Destination':'終點',
		'_Access':'權限',
		'_BWM':'BWM 進向/出向優先權',
		'_Log':'日誌'
		}];

/* appedit.html */
var _appedit=[{
		'_Configuration':'設定',
		'_Bandwidth_Management':'頻寬管理',
		'_Inbound':'進向',
		'_kbp1':'千位元組',
		'_Outbound':'出向',
		'_kbp2':'千位元組&nbsp;(0：停用)',
		'_Priority':'優先權',
		'_MBU':'最大頻寬使用',
		'_Enable_Policy':'啟用策略',
		'_Port':'埠',
		'_any':'(0：任何埠)',
		'_Schedule':'排程',
		'_User':'使用者',
		'_From':'自',
		'_To':'至',
		'_Source':'來源',
		'_Destination':'終點',
		'_Access':'權限',
		'_Action_Block':'封鎖作業',
		'_Login':'登入',
		'_Message':'訊息',
		'_Audio':'音訊',
		'_Video':'視訊',
		'_File_Transfer':'檔案傳輸',
		'_Log':'日誌'
		}];

/* aplother.html */
var _aplother=[{
		'_Policy':'策略',
		'_Port':'埠',
		'_Schedule':'排程',
		'_User':'使用者',
		'_From':'自',
		'_To':'至',
		'_Source':'來源',
		'_Destination':'終點',
		'_Protocol':'通訊協定',
		'_Access':'權限',
		'_BWM':'BWM 進向/出向優先權',
		'_Log':'日誌'
		}];

/* aplotheredit.html */
var _aplotheredit=[{
		'_Configuration':'設定',
		'_Bandwidth_Management':'頻寬管理',
		'_Inbound':'進向',
		'_Outbound':'出向',
		'_kbps1':'千位元組',
		'_kbps2':'千位元組&nbsp;(0：停用)',
		'_MBU':'最大頻寬使用',
		'_Enable':'啟用',
		'_Port':'埠',
		'_any':'(0：任何埠)',
		'_Schedule':'排程',
		'_User':'使用者',
		'_From':'自',
		'_To':'至',
		'_Source':'來源',
		'_Destination':'終點',
		'_Protocol':'通訊協定',
		'_Priority':'優先權',
		'_Access':'權限',
		'_Log':'日誌'
		}];
					
/* appStatic.html */
var _appStatic=[{
		'_Options':'選項',
		'_Refresh_Interval':'重新整理間隔',
		'_Display_Protocols':'顯示通訊協定',
		'_Select_All':'全部選取',
		'_Clear_All':'全部清除',
		'_Bandwidth_Statistics':'頻寬統計',
		'_Protocol_Statistics':'通訊協定統計',
		'_Service':'服務',
		'_Forwarded_Data':'轉遞資料 (千位元組)',
		'_Dropped_Data':'丟棄資料 (千位元組)',
		'_Rejected_Data':'拒絕資料 (千位元組)',
		'_Matched_Auto':'相符自動連線',
		'_Matched_Service_Ports':'相符服務埠連線',
		'_Rule':'規則',
		'_Inbound_Kbps':'進向: 千位元組',
		'_Outbound_Kbps':'出向: 千位元組',
		'_Forwarded_Data':'轉遞資料 (千位元組)',
		'_Dropped_Data':'丟棄資料 (千位元組)',
		'_Rejected_Data':'拒絕資料 (千位元組)',
		'_Destination':'終點',
		'_Protocol':'通訊協定',
		'_Access':'權限',
		'_Log':'日誌'
		}];

/*----- Anti-X > Anti-Virus -----*/
				
/* antivirus.html */
var _antivirus=[{
		'_Configuration':'設定',
		'_Enable_Anti_Virus':'啟用防毒與防間諜服務',
		'_Priority':'優先權',
		'_From':'自',
		'_To':'至',
		'_Protocol':'通訊協定',
		'_Registration':'註冊',
		'_Registration_Status':'註冊狀態',
		'_Registration_Type':'註冊類型',
		'_Apply_New_Registration':'套用新註冊資料',
		'_Signature_Information':'簽章資訊',
		'_Current_Version':'目前版本',
		'_Signature_Number':'簽章號碼',
		'_Released_Date':'發行日期',
		'_Update_Signatures':'更新簽章'
		}];

/* avedit.html */
var _avedit=[{
		'_Configuration':'設定',
		'_Direction':'方向',
		'_Enable':'啟用',
		'_Log':'日誌',
		'_From':'自',
		'_To':'至',
		'_Protocols_to_Scan':'要掃描的通訊協定',
		'_HTTP':'HTTP',
		'_FTP':'FTP',
		'_SMTP':'SMTP',
		'_POP3':'POP3',
		'_IMAP4':'IMAP4',
		'_Actions_When_Matched':'相符時行動',		
		'_Destroy':'銷毀受感染的檔案',
		'_Send':'傳送 Windows 訊息',
		'_White_List_Black_List':'檢查白名單 / 黑名單',
		'_Bypass_white_list':'檢查白名單時略過',
		'_Bypass_black_list':'檢查黑名單時略過',
		'_File_decompression':'檔案解壓縮',
		'_Enable_file_decompression':'啟用檔案解壓縮功能 (ZIP 和 RAR)',
		'_Destroy_compressed_files':'銷毀無法解壓縮的壓縮檔案'
		}];

/* antisetting.html */
var _antiset=[{
		'_General_Setting':'一般設定',
		'_Scan_EICAR':'掃描 EICAR',
		'_White_List':'白名單',
		'_Enable_White_List':'啟用白名單',
		'_Total_Rule':'規則總數：',
		'_Page':'頁數',
		'_File_Pattern':'檔案式樣',
		'_Black_List':'黑名單',
		'_Enable_Black_List':'啟用黑名單',
		'_rules_per_page':'每頁規則數'
		}];

/* antisetedit.html */
var _antisetedit=[{
		'_Configuration':'設定',
		'_Enable':'啟用',
		'_File_Pattern':'檔案式樣'
		}];

/* avsignature.html */
var _avsignature=[{
		'_Query_Signatures':'查詢簽章',
		'_Signatures_Search':'簽章搜尋',
		'_Query_all_signs':'查詢所有簽章並匯出',
		'_Query_Result':'查詢結果',
		'_Total_Signature':'簽章總數：',
		'_signatures_per_page':'每頁簽章數',
		'_Page':'頁數',
		'_Name':'名稱',
		'_ID':'ID',
		'_Severity':'嚴重程度',
		'_Category':'類別'
		}];
				
/*----- Anti-X > IDP -----*/

/* idpgl.html */
var _idpgl=[{
		'_General_Setup':'一般設定',
		'_Enable_Signature_Detection':'啟用簽章偵測功能',
		'_Bindings':'繫結',
		'_Priority':'優先權',	
		'_From':'自',		
		'_To':'至',
		'_IDP_Profile':'IDP 設定組合',		
		'_Registration':'註冊',
		'_Registration_Status':'註冊狀態:',
		'_Registration_Type':'註冊類型:',
		'_Apply_New_Registration':'套用新註冊資料',
		'_Signature_Information':'簽章資訊',
		'_Current_Version':'目前版本:',
		'_Signature_Number':'簽章號碼:',
		'_Released_Date':'發行日期:',
		'_Update_Signatures':'更新簽章',
		/* idpgl_1.html */
		'_Enable_Anomaly_Detection':'啟用異常偵測功能',
		'_Anomaly_Profile':'異常設定組合',
		/* idpzoneedit page*/
		'_Configuration':'設定',
		'_Direction':'方向',
		'_Profile_Selection':'選取設定組合',
		'_Enable':'啟用',
		'_ADP_Profile':'ADP 設定組合'
		}];

/* dataiframe.html */
var _dataiframe=[{
		'_GoTo':'前往',
		'_Page':'頁數'
		}];

/* idppf.html */
var _idppf=[{
		'_Update':'更新',
		'_Profile_Management':'設定組合管理',
		'_Name':'名稱',
		'_Base_Profile':'基礎設定組合',
		'_Please_select_IDP_Profile':'請選取一個 IDP 基礎設定組合。'
		}];

/* idppfedit.html */
var _idppfedit=[{
		'_Name':'名稱',
		'_Signature_Group':'簽章群組',
		'_Service':'服務',
		'_Activation':'啟動',
		'_Log':'日誌',
		'_Action':'動作',
		'_Message':'訊息',
		'_SID':'系統 ID',
		'_Severity':'嚴重程度',
		'_Policy_Type':'策略類型'		
		}];

/* idpfedat.html */
var _idpfedat=[{		
		'_Name':'名稱',
		'_Scan_Detection':'掃描偵測',
		'_Sensitivity':'敏感度',
		'_Block_Period':'封鎖時間',
		'_1_3600_seconds':'(1-3600 秒)',
		'_Flood_Detection':'偵測異常訊務',
		'_Activation':'啟動',
		'_Log':'日誌',
		'_Action':'動作',
		'_Threshold':'臨界值'
		}];

/* idpfedpa.html */
var _idpfedpa=[{
		'_Name':'名稱',
		'_HTTP_Inspection':'HTTP 檢查',
		'_TCP_Decoder':'TCP 解碼器',
		'_UDP_Decoder':'UDP 解碼器',
		'_ICMP_Decoder':'ICMP 解碼器',
		'_Activation':'啟動',
		'_Log':'日誌',
		'_Action':'動作'
		}];		

/* idpquery.html */
var _idpquery=[{
		'_Name':'名稱',
		'_Query_Signatures':'查詢簽章',
		'_Search_all_custom_signature':'搜尋所有自訂簽章',
		'_Optional':'可省略',
		'_Signature_ID':'簽章 ID',
		'_Severity':'嚴重程度',
		'_Attack_Type':'攻擊類型',
		'_Platform':'平台',
		'_Service':'服務',
		'_Activation':'啟動',
		'_Log':'日誌',
		'_Action':'動作',
		'_Page':'頁數:',
		'_Actions_hold':'動作',
		'_Query_Result':'查詢結果',
		'_Total_IDP':'IDP 總數',
		'_IDP_per_page':'每頁 IDP 數',
		'_SID':'系統 ID'
		}];

/* idpcs.html */
var _idpcs=[{
		'_Creating':'建立',
		'_SID':'系統 ID',
		'_Name':'名稱',		
		'_Importing':'匯入',
		'_Import_name':' 匯入名稱規則；自訂規則 = 裝置自訂簽章檔案。',
		'_File_Path':'檔案路徑:'
		}];

/* idpcsedit.html */
var _idpcsedit=[{
		'_Name':'名稱',
		'_Signature_ID':'簽章 ID',
		'_Information':'資訊',
		'_Severity':'嚴重程度',
		'_Platform':'平台',
		'_All':'全部',
		'_Solaris':'Solaris',
		'_Other_Unix':'其他-Unix',
		'_Network_Device':'網路-裝置',
		'_Service':'服務',
		'_Policy_Type':'策略類型',
		'_Frequency':'頻率',
		'_Threshold':'臨界值',
		'_Packet':'封包',
		'_Second':'第二',
		'_Header_Options':'檔頭選項',
		'_Network_Protocol':'網路通訊協定',
		'_Type_of_Service':'服務類型',
		'_Identification':'識別資訊',
		'_Fragmentation':'切割',
		'_Reserved_Bit':'保留位元',
		'_Dont_Fragment':'不要產生區段',
		'_More_Fragment':'更多區段',
		'_Fragment_Offset':'區段位移',
		'_Time_to_Live':'存留時間',
		'_IP_Options':'IP 選項',
		'_Same_IP':'相同 IP',
		'_Transport_Protocol':'傳輸協定',
		'_Port':'埠',
		'_Source_Port':'來源埠',
		'_Destination_Port':'終點埠',
		'_Flow':'流量',
		'_Flags':'旗標',
		'_Type':'類型',
		'_Code':'代碼',
		'_Reserved':'保留',
		'_Sequence_Number':'序列號',
		'_Ack_Number':'ACK 號',
		'_Window_Size':'視窗大小',
		'_Payload_Options':'酬載選項',
		'_Payload_Size':'酬載大小',
		'_Byte':'位元組',
		'_Patterns':'式樣',
		'_Win95_98':'Win95/98',
		'_WinNT':'WinNT',
		'_WinXP_2000':'WinXP/2000',
		'_Linux':'Linux',
		'_FreeBSD':'FreeBSD',
		'_SGI':'SGI',
		'_IPv4':'IPv4',
		'_SYN':'SYN',
		'_FIN':'FIN',
		'_RST':'RST',
		'_PSH':'PSH',
		'_ACK':'ACK',
		'_URG':'URG',
		'_1':'1 (MSB)',
		'_2':'2',
		'_ID':'ID',
		'_Offset':'位移',
		'_Relative_to_start_of_payload':'相對於酬載起始位',
		'_Content':'內容',
		'_Relative_to_end_of_last_match':'相對於 last match 結束位',
		'_Case_insensitive':'不區分大小寫',
		'_Within':'範圍 ',
		'_Bytes':' 位元組',
		'_Decode_as_URI':'URI 解碼'
		}];

/* idpimport.html */
var _idpimport=[{
		'_Custom_Signature':'自訂簽章',
		'_SID':'系統 ID',
		'_Name':'名稱'
		}];

/*----- Anti-X > Content Filter -----*/

/* cfilter.html */
var _cfilter=[{
		'_General_Setup':'一般設定',
		'_Enable_Content_Filter':'啟用內容過濾功能',
		'_Block':'未套用策略時，封鎖 Web 接取',
		'_Policies':'策略',
		'_Address':'位址',
		'_Schedule':'排程',
		'_User':'使用者',
		'_Filter_Profile':'過濾設定組合 ',
		'_Message':'當封鎖網站時顯示的訊息',
		'_Denied_Access_Message':'遭拒絕的存取訊息',
		'_Redirect_URL':'重新導向 URL',
		'_Registration':'註冊',
		'_Registration_Status':'註冊狀態:',
		'_Registration_Type':'註冊類型:',
		'_Apply_New_Registration':'套用新註冊資料'
		}];

/* cfilteredit.html */
var _cfilteredit=[{
		'_Configuration':'設定',
		'_Schedule':'排程',
		'_Address':'位址',
		'_Filter_Profile':'過濾設定組合',
		'_User_Group':'使用者/群組'
		}];

/* cfprofile.html */
var _cfprofile=[{
		'_Profile_Management':'設定組合管理',
		'_Filter_Profile_Name':'過濾設定組合名稱'
		}];

/* cfpcyedit.html */
var _cfpcyedit=[{
		'_Categories':'類別',
		'_Customization':'自訂',
		'_Filter_Profile':'過濾設定組合',
		'_Name':'名稱',
		'_Auto':'自動設定 Web 類別',
		'_External':'外部 Web 過濾服務狀態：',
		'_Enable':'啟用 Web 過濾服務',
		'_Block':'封鎖',
		'_Log':'日誌',
		'_Matched_Web_Pages':'相符網頁',
		'_Unrated_Web_Pages':'未分級網頁',
		'_When':'當 Web 過濾伺服器無法使用時',
		'_Content':'內容過濾伺服器無法使用等候時間',
		'_Seconds':'秒',
		'_Select_Categories':'選取類別',
		'_Select_All_Categories':'選取所有類別',
		'_Clear_All_Categories':'清除所有類別',
		/* check list */
		'_Adult_Mature_Content':'成人內容',
		'_Pornography':'網路色情',
		'_Sex_Education':'性教育',
		'_Intimate_Apparel_Swimsuit':'衣著暴露/泳裝',
		'_Nudity':'裸體',
		'_Alcohol_Tobacco':'酒類/菸草',
		'_Illegal_Questionable':'非法/可疑',
		'_Gambling':'賭博',
		'_Violence_Hate_Racism':'暴力/仇恨/種族歧視',
		'_Weapons':'槍械武器',
		'_Abortion':'墮胎',
		'_Hacking':'駭客攻擊',
		'_Phishing':'網路釣魚',
		'_Arts_Entertainment':'藝文/娛樂',
		'_Business_Economy':'商業/經濟',
		'_Alternative_Spirituality_Occult':'另類靈修/神秘教派',
		'_Illegal_Drugs':'違禁藥品',
		'_Education':'教育',
		'_Cultural_Institutions':'文化/慈善組織',
		'_Financial_Services':'金融服務',
		'_Brokerage_Trading':'仲介服務/線上交易',
		'_Online_Games':'線上遊戲',
		'_Government_Legal':'政府機關/法律相關',
		'_Military':'軍事國防',
		'_Political_Activist_Group':'政黨/激進團體',
		'_Health':'健康',
		'_Computers_Internet':'電腦/網路',		
		'_Search_Engines_Portals':'搜尋引擎/入口網站',		
		'_Spyware_Malware_Sources':'間諜程式/惡意程式來源',
		'_Spyware_Effects_Privacy_Concerns':'間諜程式威脅/隱私議題',		
		'_Job_Search_Careers':'求職徵才',
		'_News_Media':'新聞媒體',
		'_Personals_Dating':'交友/約會',
		'_Reference':'生活資訊',
		'_Open_Image_Media_Search':'影像分享/媒體搜尋',
		'_Chat_Instant_Messaging':'聊天/即時通訊',
		'_Email':'電子郵件',		
		'_Blogs_Newsgroups':'部落格/新聞群組',
		'_Religion':'宗教信仰',		
		'_Social_Networking':'社會網路',		
		'_Online_Storage':'線上儲存服務',		
		'_Remote_Access_Tools':'遠端存取工具',		
		'_Shopping':'購物',
		'_Auctions':'拍賣',
		'_Real_Estate':'房地產',
		'_Society_Lifestyle':'流行議題/生活時尚',		
		'_Sexuality_Alternative_Lifestyles':'性行為/另類生活',		
		'_Restaurants_Dining_Food':'餐廳/美食',
		'_Sports_Recreation_Hobbies':'運動/娛樂/嗜好',
		'_Travel':'旅遊',
		'_Vehicles':'汽車',
		'_Humor_Jokes':'笑話',
		'_Software_Downloads':'軟體下載',
		'_Pay_to_Surf':'上網看廣告賺錢',
		'_Peer_to_Peer':'點對點傳輸',
		'_Streaming_Media_MP3s':'串流媒體/MP3',
		'_Proxy_Avoidance':'代理規避',
		'_For_Kids':'兒童適宜',
		'_Web_Advertisements':'網路廣告',
		'_Web_Hosting':'網路空間',
		/* end check list */
		'_Test1':'測試網站類別',
		'_URL_to_test':'測試 URL'
		}];

/* cfpcsedit.html */
var _cfpcsedit=[{
		'_Categories':'類別',
		'_Customization':'自訂',
		'_Filter_Profile':'過濾設定組合',
		'_Name':'名稱',
		'_Customization_Setup':'自訂安裝',
		'_Enable':'啟用網站自訂功能。',
		'_Allow1':'僅允許來自受信任網站的 Web 流量。',
		'_Restricted_Web_Features':'限制使用的 Web 功能',
		'_Block':'封鎖',
		'_ActiveX':'ActiveX',
		'_Java':'Java',
		'_Cookies':'Cookies',
		'_Web_Proxy':'網頁代理',
		'_Allow2':'允許 Java/ActiveX/Cookies/Web 代理至受信任網站 。',
		'_Trusted_Web_Sites':'受信任的網站',
		'_Add_Trusted_Web_Site':'新增受信任的網站',
		'_Forbidden_Web_Sites':'禁止的網站',
		'_Add_Forbidden_Web_Site':'新增禁止的網站',
		'_Blocked_URL_Keywords':'封鎖的 URL 關鍵字',
		'_Add_Blocked_URL_Keyword':'新增的 URL 關鍵字'
		}];	

/* cfcache.html */
var _cfcache=[{
		'_URL_Cache_Entry':'URL 快取項目',
		'_Total_cache_entries':'快取項目總數:',
		'_entries_per_page':'每頁項目數',
		'_Page':'頁數',
		'_Category':'類別',
		'_URL':'URL',
		'_Remaining_Time_minutes':'剩餘時間 (分鐘)',
		'_Remove':'移除',
		'_URL_Cache_Setup':'URL 快取設定',
		'_Maximum_TTL':'最大 TTL',
		'_hours':'(1~720 小時)'
		}];

/*----- Device HA -----*/

/* vrrpgrp.html */
var _vrrpgrp=[{
		'_Configuration':'設定',
		'_Enable':'啟用',
		'_Link_Monitoring':'連結監控功能',
		'_VRRP_Group':'VRRP 群組',
		'_Name':'名稱',
		'_VRID':'虛擬路由器 ID',
		'_Role':'角色',
		'_Interface':'介面',
		'_Note_LINK':'Note:If a master ZyWALL VRRP interface\'s link is down, shut down all of the master\'s VRRP interfaces so the backup ZyWALL takes over completely.',
		'_HA_Status':'HA 狀態'
		}];

/* vrrpgedit.html */
var _vrrpgedit=[{
		'_Basic_Setting':'基本設定',
		'_Enable':'啟用',
		'_Name':'名稱',
		'_VRID':'虛擬路由器 ID',
		'_Description':'說明',
		'_Optional':'(可省略)',
		'_VRRP_Interface':'VRRP 介面',
		'_Role':'角色',
		'_Master':'正本',
		'_Backup':'備份',
		'_Priority':'優先權',
		'_range_check_for_backup':'備份範圍檢查:',
		'_Preempt':'先佔',
		'_Manage_IP':'管理 IP',
		'_Manage_IP_Subnet_Mask':'管理 IP 子網路遮罩',
		'_Authentication':'認證',
		'_None':'無',
		'_Text':'文字',
		'_IP_AH_MD5':'IP AH (MD5)',
		'_Authentication_key':'認證金鑰'
		}];

/* devhasync.html */
var _devhasync=[{
		'_Authentication':'認證',
		'_Password':'密碼',
		'_Synchronize_from':'同步來源',
		'_IP_or_FQDN':'(IP 或 FQDN)',
		'_on_port':'連接埠',
		'_Auto_Synchronize':'自動同步',
		'_Interval':'間隔',
		'_minutes':'分鐘'
		}];
		
/* dha.html */
var _dha=[{
		'_Synchronize_now':'ZyWALL 立即同步',
		'_Rendering':'正在轉譯中...'
		}];
		
/*----- Object > User/Group -----*/

/* users.html */
var _users=[{
		'_Configuration':'設定',
		'_User_Name':' 使用者名稱',
		'_Description':' 說明'
		}];

/* usersedit.html */
var _usersedit=[{
		'_User_Configuration':'使用者設定',
		'_User_Name':'使用者名稱',
		'_User_Type':'使用者類型',
		'_Password':'密碼',
		'_Retype':'重新鍵入',
		'_Description':'說明',
		'_Lease_Time':'租用時間',
		'_Reauthentication_Time':'再認證時間',
		'_minutes_is_unlimited':'(0-1440 分鐘，0 即為無限制)'
		}];

/* grps.html */
var _grps=[{
		'_Configuration':'設定',
		'_Group_Name':'群組名稱',
		'_Description':'說明',
		'_Member':'成員'
		}];

/* grpsedit.html */
var _grpsedit=[{
		'_Configuration':'設定',
		'_Name':'名稱',
		'_Description':'說明',
		'_Member':'成員',
		'_Optional':'(可省略)'
		}];

/* usrset.html */
var _usrset=[{
		'_User_Default_Setting':'使用者預設設定',
		'_User_Type':'使用者類型',
		'_Lease_Time':'租用時間',
		'_minutes':'分鐘',
		'_minutes_is_unlimited':'(0-1440 分鐘，0 即為無限制)',
		'_Reauthentication_Time':'再認證時間',
		'_User_Logon_Setting':'使用者登入設定',
		'_Limit1':'限制存取帳號同時登入的數量',
		'_Maximum1':'每個存取帳號最多',
		'_Limit2':'限制存取帳號同時登入的數量',
		'_Maximum2':'每個存取帳號最多',
		'_User_Lockout_Setting':'使用者封鎖設定',
		'_Enable_logon_retry_limit':'啟用登入重試限制',
		'_Maximum_retry_count':'最多重試次數',
		'_Lockout_period':'封鎖時間',
		'_User_Miscellaneous_Settings':'使用者其他設定',
		'_Allow':'自動更新租用時間',
		'_Enable_user_idle_detection':'啟用使用者閒置偵測功能',
		'_User_idle_timeout':'使用者閒置等候時間',
		'_Force_User_Authentication_Policy':'強迫使用者認證策略',
		'_Total_Policy':'策略總數',
		'_Policy_per_page':'每頁策略數',
		'_Page':'頁數',
		'_Schedule':'排程',
		'_Source':'來源',
		'_Destination':'終點',
		'_Authenticate':'驗證'
		}];

/* usrsetedit.html */
var _usrsetedit=[{
		'_Configuration':'設定',
		'_Enable':'啟用',
		'_Description':'說明',
		'_Optional':'(可省略)',
		'_Authentication':'認證',
		'_Criteria':'標準',
		'_Source_Address':'來源位址',
		'_Destination_Address':'終點位址',
		'_Schedule':'排程'
		}];

/*----- Object > Address -----*/

/* address.html */
var _address=[{
		'_Configuration':'設定',
		'_Name':'名稱',
		'_Type':'類型',
		'_Address':'位址'
		}];

/* addredit.html */
var _addredit=[{
		'_Configuration':'設定',
		'_Name':'名稱',
		'_Address_Type':'位址類型',
		'_Network':'網路',
		'_Netmask':'網路遮罩',
		'_IP_Address':'IP 位址',
		'_Starting_IP_Address':'起始 IP 位址',
		'_End_IP_Address':'結束 IP 位址'
		}];
				
/* addrgps.html */
var _addrgps=[{
		'_Configuration':'設定',
		'_Name':'名稱',
		'_Description':'說明'
		}];

/* addrgpsedit.html */
var _addrgpsedit=[{
		'_Group_Members':'群組成員',
		'_Name':'名稱',
		'_Description':'說明'
		}];

/*----- Object > Service -----*/

/* service.html */
var _service=[{
		'_Configuration':'設定',
		'_Total_Services':'服務總數',
		'_services_per_page':'每頁服務數',
		'_Page':'頁數',
		'_Name':'名稱',
		'_Content':'內容'
		}];

/* svredit.html */
var _svredit=[{
		'_Configuration':'設定',
		'_Name':'名稱',
		'_IP_Protocol':'IP 通訊協定',
		'_Starting_Port':'起始埠',
		'_ICMP_Type':'ICMP 類型',
		'_IP_Protocol_Number':'IP 通訊協定數目',
		'_Ending_Port':'結束埠'
		}];

/* svrgrp.html */
var _svrgrp=[{
		'_Configuration':'設定',
		'_Name':'名稱',
		'_Description':'說明'
		}];


/* svrgrpedit.html */
var _svrgrpedit=[{
		'_Configuration':'設定',
		'_Name':'名稱',
		'_Description':'說明'
		}];

/*----- Object > Schedule -----*/

/* schedule.html */
var _schedule=[{
		'_One_Time':'一次',
		'_Name':'名稱',
		'_Start_Day':'開始日期',
		'_Stop_Day':'停止日期',
		'_Time':'時間',
		'_Recurring':'重複執行',
		'_Start_Time':'開始時間',
		'_Stop_Time':'停止時間'
		}];

/* schedit.html */
var _schedit=[{
		'_Configuration':'設定',
		'_Name':'名稱',
		'_Day_Time':'日期時間',
		'_Item':'項目',
		'_Date':'日期',
		'_Time':'時間',
		'_Year':'年',
		'_Month':'月',
		'_Day':'日期',
		'_Hour':'時',
		'_minute':'分',
		'_Start':'開始',
		'_Stop':'停止',
		'_Weekly':'每週',
		'_Week_Days':'星期',
		'_Monday':'星期一',
		'_Tuesday':'星期二',
		'_Wednesday':'星期三',
		'_Thursday':'星期四',
		'_Friday':'星期五',
		'_Saturday':'星期六',
		'_Sunday':'星期日',
		/* Inline object. */
		'_Type':'類型'
		}];
			
/*----- Object > AAA Server -----*/

/* activeDir_d.html */
var _ad=[{
		'_Default':'預設',
		'_Group':'群組',
		'_Configuration':'設定',
		'_Host':'主機',
		'_IP_FQDN':'(IP 或 FQDN)',
		'_Port':'埠',
		'_Bind_DN':'繫結 DN',
		'_Optional':'(可省略)',
		'_Password':'密碼',
		'_Base_DN':'基礎 DN',
		'_CN_Identifier':'CN 識別碼',
		'_Search_time_limit':'搜尋時間限制',
		'_Use_SSL':'使用 SSL'
		}];
	      
/* activeDir_g.html */
var _adg=[{
		'_Default':'預設',
		'_Group':'群組',
		'_Configuration':'設定',
		'_Group_Name':'群組名稱'
		}];

/* adgedit.html */
var _adgedit=[{
		'_Default':'預設',
		'_Group':'群組',
		'_Configuration':'設定',
		'_Name':'名稱',
		'_Port':'埠',
		'_Bind_DN':'繫結 DN',
		'_Optional':'(可省略)',
		'_Password':'密碼',
		'_Base_DN':'基礎 DN',
		'_CN_Identifier':'CN 識別碼',
		'_Search_time_limit':'搜尋時間限制',
		'_Use_SSL':'使用 SSL',
		'_Host_Members':'主機成員',
		'_Members':'成員 (IP 或 FQDN)'
		}];

/* aldapd.html */
var _aldapd=[{
		'_Default':'預設',
		'_Group':'群組',
		'_Configuration':'設定',
		'_Host':'主機',
		'_IP_or_FQDN':'(IP 或 FQDN)',
		'_Port':'埠',
		'_Bind_DN':'繫結 DN',
		'_Optional':'(可省略)',
		'_Password':'密碼',
		'_Base_DN':'基礎 DN',
		'_CN_Identifier':'CN 識別碼',
		'_Search_time_limit':'搜尋時間限制',
		'_Use_SSL':'使用 SSL'
		}];

/* aldapg.html */
var _aldapg=[{
		'_Configuration':'設定',
		'_Default':'預設',
		'_Group':'群組',
		'_Group_Name':'群組名稱'
		}];

/* aldapgedit.html */
var _aldapgedit =[{
		'_Configuration':'設定',
		'_Default':'預設',
		'_Group':'群組',
		'_Name':'名稱',
		'_Port':'埠',
		'_Bind_DN':'繫結 DN',
		'_Optional':'(可省略)',
		'_Password':'密碼',
		'_Base_DN':'基礎 DN',
		'_CN_Identifier':'CN 識別碼',
		'_Search_time_limit':'搜尋時間限制',
		'_Use_SSL':'使用 SSL',
		'_Host_Members':'主機成員',
		'_Members':'成員 (IP 或 FQDN)'
		}];

/* aradiusd.html */
var _aradiusd=[{
		'_Configuration':'設定',
		'_Default':'預設',
		'_Group':'群組',
		'_Host':'主機',
		'_IP_or_FQDN':'(IP 或 FQDN)',
		'_Authentication_Port':'認證埠',
		'_Key':'金鑰',
		'_Timeout':'等候時間'
		}];

/* aradiusg.html */
var _aradiusg=[{
		'_Configuration':'設定',
		'_Default':'預設',
		'_Group':'群組',
		'_Group_Name':'群組名稱'
		}];

/* aradiusgedit.html */
var _aradiusgedit=[{
		'_Configuration':'設定',
		'_Default':'預設',
		'_Group':'群組',
		'_Name':'名稱',
		'_Host_Members':'主機成員',
		'_Authentication_Port':'認證埠',
		'_Key':'金鑰',
		'_Timeout':'等候時間',
		'_Members':'成員'
		}];
				  	
/*----- Object > Auth. method -----*/
		
/* Authmeth.html */
var _Authmeth=[{
		'_Configuration':'設定',
		'_Method_Name':'方法名稱',
		'_Method_List':'方法清單'
		}];

/* authedit.html */
var _authedit=[{
		'_Configuration':'設定',
		'_Name':'名稱',
		'_Method_List':'方法清單'
		}];

/*----- Object > Certificate -----*/

/* cert.html */
var _cert=[{
		'_PKI_Storage_Space_in_Use':'使用中 PKI 儲存空間',
		'_My_Certificates_Setting':'我的憑證設定',
		'_Name':'名稱',
		'_Type':'類型',
		'_Subject':'主旨',
		'_Issuer':'發行機構',
		'_Valid_From':'生效日',
		'_Valid_To':'失效日'
		}];

/* certimpt.html */
var _certimpt=[{
		'_Please':'請指定要匯入的憑證檔案位置。憑證檔案必須為下列格式:',
		'_Binary1':'Binary X.509',
		'_PEM1':'PEM (Base-64) encoded X.509',
		'_Binary2':'Binary PKCS#7',
		'_PEM2':'PEM (Base-64) encoded PKCS#7',
		'_Binary3':'Binary PKCS#12',
		'_For':'匯入完成之後，憑證簽發要求會自動刪除。',
		'_File_Path':'檔案路徑:',
		'_Password':'密碼:',
		'_PKCS':'(限 PKCS#12)'
		}];

/* certcrat.html */
var _certcrat=[{
		'_Name':'名稱',
		'_Subject_Information':'主旨資訊',
		'_Common_Name':'共用名稱',
		'_Host_IP_Address':'主機 IP 位址',
		'_Host_Domain_Name':'主機網域名稱',
		'_E_Mail':'電子郵件',
		'_Organizational_Unit':'組織單位',
		'_Optional':'(可省略)',
		'_Organization':'組織',
		'_Country':'國家',
		'_Key_Type':'金鑰類型',
		'_Key_Length':'金鑰長度',
		'_bits':'位元',
		'_Enrollment_Options':'註冊選項',
		'_Create1':'建立自簽憑證',
		'_Create2':'建立憑證簽發要求並將其儲存於本機以便爾後手動註冊使用',
		'_Create3':'建立憑證簽發要求並立即線上註冊以取得憑證',
		'_Enrollment_Protocol':'註冊協定',
		'_CA_Server_Address':'CA 伺服器位址',
		'_CA_Certificate':'CA 憑證',
		'_See':'請參閱',
		'_Trusted_CAs':'受信任的 CA',
		'_Request_Authentication':'要求認證',
		'_Reference_Number':'參考號',
		'_Key':'金鑰'
		}];

/* certself.html */
var _certself=[{
		'_Name':'名稱',
		'_Certification_Path':'憑證路徑',
		'_Certificate_Information':'憑證資訊',
		'_Type':'類型',
		'_Version':'版別',
		'_Serial_Number':'序號',
		'_Subject':'主旨',
		'_Issuer':'發行機構',
		'_Signature_Algorithm':'簽章演算法',
		'_Valid_From':'生效日',
		'_Valid_To':'失效日',
		'_Key_Algorithm':'金鑰演算法',
		'_Subject_Alternative_Name':'主旨別名',
		'_Key_Usage':'金鑰使用',
		'_Basic_Constraint':'基本限制',
		'_MD5_Fingerprint':'MD5 指紋',
		'_SHA1_Fingerprint':'SHA1 指紋',
		'_Certificate':'PEM (Base-64) 編碼格式的憑證',
		'_Password':'密碼:'
		}];
		
/* trscert.html */
var _trscert=[{
		'_PKI_Storage_Space_in_Use':'使用中 PKI 儲存空間',
		'_Trusted_Certificates_Setting':'受信任的憑證設定',
		'_Name':'名稱',
		'_Subject':'主旨',
		'_Issuer':'發行機構',
		'_Valid_From':'生效日',
		'_Valid_To':'失效日'
		}];

/* trsedit.html */
var _trsedit=[{
		'_Name':'名稱',
		'_Certification_Path':'憑證路徑',
		'_Certificate_Validation':'憑證驗証',
		'_Enable':'啟用 X.509v3 CRL 發佈點及 OCSP 檢查功能',
		'_OCSP_Server':'OCSP 伺服器',
		'_URL':'URL',
		'_ID':'ID',
		'_Password':'密碼',
		'_LDAP_Server':'LDAP 伺服器',
		'_Address':'位址',
		'_Port':'埠',
		'_Certificate_Information':'憑證資訊',
		'_Type':'類型',
		'_Version':'版別',
		'_Serial_Number':'序號',
		'_Subject':'主旨',
		'_Issuer':'發行機構',
		'_Signature_Algorithm':'簽章演算法',
		'_Valid_From':'生效日',
		'_Valid_To':'失效日',
		'_Key_Algorithm':'金鑰演算法',
		'_Subject_Alternative_Name':'主旨別名',
		'_Key_Usage':'金鑰使用',
		'_Basic_Constraint':'基本限制',
		'_MD5_Fingerprint':'MD5 指紋',
		'_SHA1_Fingerprint':'SHA1 指紋',
		'_Certificate':'PEM (Base-64) 編碼格式的憑證'
		}];

/* trsimpt.html */
var _trsimpt=[{
		'_Please':'請指定要匯入的憑證檔案位置。憑證檔案必須為下列格式:',
		'_Binary1':'Binary X.509',
		'_PEM1':'PEM (Base-64) encoded X.509',
		'_Binary2':'Binary PKCS#7',
		'_PEM2':'PEM (Base-64) encoded PKCS#7',
		'_File_Path':'檔案路徑:'
		}];
		
/*----- Object > ISP Account -----*/

/* Account.html */
var _Account=[{
		'_Configuration':'設定',
		'_Profile_Name':'設定組合名稱',
		'_Protocol':'通訊協定',
		'_Authentication_Type':'認證方式',
		'_User_Name':'使用者名稱'
		}];

/* acctedit.html */
var _acctedit=[{
		'_Configuration':'設定',
		'_Profile_Name':'設定組合名稱',
		'_Protocol':'通訊協定',
		'_Encryption_Method':'加密方式',
		'_Authentication_Type':'認證方式',
		'_User_Name':'使用者名稱',
		'_Password':'密碼',
		'_Connection_ID':'連線 ID',	
		'_Retype_to_confirm':'重新鍵入確認',	
		'_Server_IP':'伺服器 IP',
		'_IP_Address':'(IP 位址)',
		'_Optional':'(可省略)',
		'_Service_Name':'服務名稱',
		'_Compression':'壓縮',
		'_On':'開',
		'_Off':'關',
		'_Idle_timeout':'閒置等候時間',
		'_Seconds':'(秒)'
		}];

/*----- Object > SSL Application -----*/

/* application.html */
var _application=[{
		'_Configuration':'設定',
		'_Name':'名稱',
		'_Address':'位址',
		'_Type':'類型'
		}];
		
/* applicationedit.html */
var _applicationedit=[{
		'_Object':'物件',
		'_Type':'類型',
		'_Web_Application':'網頁應用程式',
		'_Name':'名稱',
		'_URL':'URL',
		'_Server_Type':'伺服器類型',
		'_File_Sharing':'檔案分享',	
		'_Entry_Point':'進入點',
		'_Optional':'(可省略)',
		'_NameC':'名稱',
		'_Shared_Path':'分享路徑',	
		'_Web_Page_Encryption':'網頁加密'
		}];	

/*----- System > Host Name -----*/

/* hostname.html */
var _hostname=[{
		'_General_settings':'一般設定',
		'_System_Name':'系統名稱',
		'_Optional':'(可省略)',
		'_Domain_Name':'網域名稱'
		}];

/*----- System > Date/Time -----*/

/* myclock.html */
var _myclock=[{
		'_Current_Time_and_Date':'現在的時間與日期',
		'_Current_Time':'現在時間',
		'_Current_Date':'現在日期',
		'_Time_and_Date_Setup':'時間和日期設定',
		'_Manual':'手動',
		'_New_Time':'新的時間 (時:分:秒)',
		'_New_Date':'新的日期 (yyyy-mm-dd)',
		'_Get_from_Time_Server':'從時間伺服器取得',
		'_Time_Server_Address':'時間伺服器位址*',
		'_Optional1':'*Optional. 有預先定義的 NTP 時間伺服器清單.',
		'_Time_Zone_Setup':'時區設定',
		'_Time_Zone':'時區',
		'_Enable_Daylight_Saving':'啟動日光節約時間',
		'_Start_Date':'開始日期',
		'_End_Date':'結束日期',
		'_Offset':'位移',
		'_hours':'時',
		'_of':'的',
		'_at':'於'
		}];

/*----- System > Console Speed -----*/

/* baudrate.html */
var _baudrate=[{
		'_Configuration':'設定',
		'_Console_Port_Speed':'Console 埠速度'
		}];

/*----- System > DNS -----*/

/* dns.html */
var _dns=[{
		'_DNS_Server':'DNS 伺服器',
		'_Address_PTR_Record':'位址/PTR 記錄',
		'_IP_Address':'IP 位址',
		'_Domain_Zone':'網域',
		'_From':'自',
		'_Domain_Zone_Forwarder':'網域轉址',
		'_MX_Record':'MX 記錄 (My FQDN 用)',
		'_Domain_Name':'網域名稱',
		'_Service_Control':'服務控制',
		'_Zone':'區域',
		'_Address':'位址',
		'_FQDN':'FQDN',
		'_IP_FQDN':'IP/FQDN',
		'_Action':'動作'
		}];

/* adnsedit.html */
var _adnsedit=[{
		'_Configuration':'設定',
		'_IP_Address':'IP 位址',
		'_FQDN':'FQDN'
		}];

/* nsdnsedit.html */
var _nsdnsedit=[{
		'_Configuration':'設定',
		'_Domain_Zone':'網域',
		'_DNS_Server':'DNS 伺服器',
		'_DNS_Server1':'ISP 提供的 DNS 伺服器',
		'_First_DNS_Server':'第一 DNS 伺服器',
		'_Second_DNS_Server':'第二 DNS 伺服器',
		'_Third_DNS_Server':'第三 DNS 伺服器',
		'_Public_DNS_Server':'公用 DNS 伺服器',
		'_Private_DNS_Server':'私人 DNS 伺服器'
		}];

/* mxdnsedit.html */
var _mxdnsedit=[{
		'_Configuration':'設定',
		'_Domain_Name':'網域名稱',
		'_IP_Address_FQDN':'IP 位址/FQDN'
		}];

/* dnsedit.html */
var _dnsedit=[{
		'_Service_Control':'服務控制',
		'_Address_Object':'位址物件',
		'_Zone':'區域',
		'_Action':'動作'
		}];

/*----- System > WWW -----*/

/* buinsrv.html */
var _buinsrv=[{
		'_HTTPS':'HTTPS',
		'_Enable':'啟用 ',
		'_Server_Port':'伺服器埠',
		'_Authenticate_Client_Certificates':'驗證用戶端憑證',
		'_See':'請參閱',
		'_Trusted_CAs':'受信任的 CA',
		'_Server_Certificate':'伺服器憑證',
		'_My_Certificates':'我的憑證',
		'_Redirect_HTTP_to_HTTPS':'HTTP 重新導向至 HTTP',
		'_Admin_Service_Control':'管理服務控制',
		'_Zone':'區域',
		'_Address':'位址',
		'_Action':'動作',
		'_User_Service_Control':'使用者服務控制',
		'_HTTP':'HTTP',	
		'_Authentication':'認證',
		'_Client_Authentication_Method':'用戶端認證方式'
		}];

/* httpsedit.html */
var _httpsedit=[{
		'_Admin_Service_Control':'管理服務控制',
		'_Address_Object':'位址物件',
		'_Zone':'區域',
		'_Action':'動作'
		}];

/* httpsuseredit.html */
var _httpsuseredit=[{
		'_User_Service_Control':'使用者服務控制',
		'_Address_Object':'位址物件',
		'_Zone':'區域',
		'_Action':'動作'
		}];

/* wwwedit.html */
var _wwwedit=[{
		'_Admin_Service_Control':'管理服務控制',
		'_Address_Object':'位址物件',
		'_Zone':'區域',
		'_Action':'動作'
		}];

/* wwwuseredit.html */
var _wwwuseredit=[{
		'_User_Service_Control':'使用者服務控制',
		'_Address_Object':'位址物件',
		'_Zone':'區域',
		'_Action':'動作'
		}];

/*----- System > SSH -----*/

/* ssh.html */
var _ssh=[{
		'_SSH':'SSH',
		'_Enable':'啟用',
		'_Version_1':'1 版',
		'_Server_Port':'伺服器埠',
		'_Server_Certificate':'伺服器憑證',
		'_See':'請參閱',
		'_My_Certificates':'我的憑證',
		'_Service_Control':'服務控制',
		'_Zone':'區域',
		'_Address':'位址',
		'_Action':'動作'	
		}];

/* sshedit.html */
var _sshedit=[{
		'_Service_Control':'服務控制',
		'_Address_Object':'位址物件',
		'_Zone':'區域',
		'_Action':'動作'
		}];

/*----- System > Telnet -----*/

/* telnet.html */
var _telnet=[{
		'_TELNET':'TELNET',
		'_Enable':'啟用',
		'_Server_Port':'伺服器埠',
		'_Service_Control':'服務控制',
		'_Zone':'區域',
		'_Address':'位址',
		'_Action':'動作'
		}];

/* telnetedit.html */
var _telnetedit=[{
		'_Service_Control':'服務控制',
		'_Address_Object':'位址物件',
		'_Zone':'區域',
		'_Action':'動作'
		}];
		
/*----- System > FTP -----*/

/* ftp.html */
var _ftp=[{
		'_FTP':'FTP',
		'_Enable':'啟用',
		'_TLS_required':'需要 TLS',
		'_Server_Port':'伺服器埠',
		'_Server_Certificate':'伺服器憑證',
		'_See':'請參閱',
		'_My_Certificates':'我的憑證',
		'_Service_Control':'服務控制',
		'_Zone':'區域',
		'_Address':'位址',
		'_Action':'動作'
		}];

/* ftpedit.html */
var _ftpedit=[{
		'_Service_Control':'服務控制',
		'_Address_Object':'位址物件',
		'_Zone':'區域',
		'_Action':'動作'
		}];

/*----- System > SNMP-----*/

/* snmp.html */
var _snmp=[{
		'_SNMP_Configuration':'SNMP 設定',
		'_Enable':'啟用',
		'_Server_Port':'伺服器埠',
		'_Get_Community':'取得社群',
		'_Set_Community':'設定社群',
		'_Trap':' 設陷:',
		'_Community':'社群',
		'_Destination':'終點',
		'_Optional':'(可省略)',
		'_Service_Control':'服務控制',
		'_Address':'位址',
		'_Zone':'區域',
		'_Action':'動作'
		}];

/* snmpedit.html */
var _snmpedit=[{
		'_Service_Control':'服務控制',
		'_Address_Object':'位址物件',
		'_Zone':'區域',
		'_Action':'動作'
		}];

/*----- System > Dial-in Mgmt.-----*/

/* dialin.html */
var _dialin=[{
		'_Dial_in_Server_Properties':'撥接伺服器內容',
		'_Enable':'啟用',
		'_Description':'說明',
		'_Optional':'(可省略)',
		'_Mute':'無聲',
		'_Answer_Rings':'應答鈴聲',
		'_Rings':'(鈴聲)',
		'_Port_Speed':'埠速度',
		'_Initial_String':'初始字串'
		}];
	
/*----- System > Vantage CNM -----*/
	
/* cnm.html */
var _cnm=[{
		'_Vantage_CNM':'Vantage CNM',
		'_Enable':'啟用',
		'_Server_IP_Address_FQDN':'伺服器 IP 位址/FQDN',
		'_Transfer_Protocol':'傳輸協定',
		'_Device_Management_IP':'裝置管理 IP',
		'_Custom_IP':'自訂 IP',
		'_Keepalive_Interval':'保持活動間隔',
		'_seconds':'秒',
		'_Periodic_Inform':'定期通知',
		'_Interval':'間隔',
		'_HTTPS_Authentication':'HTTPS 認證',
		'_Enable_Vantage':'啟用 Vantage',
		'_Vantage_Certificate':'Vantage 憑證',
		'_See':'請參閱',
		'_Trusted_CAs':'受信任的 CAs'
		}];

/*----- System > Language -----*/

/* language.html */
var _language = [{
		'_Configuration':'設定',
		'_Language_Setting':'語言設定'
		}];

/*----- Maintenance > File Manager -----*/

/* configfile.html */
var _configfile=[{
		'_Configuration_Files':'設定檔',
		'_Select_the_file':'選取檔案',
		'_File_Name':'檔案名稱',
		'_Size':'大小',
		'_Modify':'上次修改',
		'_Upload_Configuration_File':'上載設定檔',
		'_To_upload_a_configuration':'若要上載設定檔 (.conf) ，請瀏覽至檔案位置再按一下上載。',
		'_File_Path':'檔案路徑:'
		}];

/* editfile.html */
var _editfile=[{
		'_Copy_File':'複製檔案',
		'_Rename':'重新命名', 
		'_Source_file':'來源檔案：',
		'_Target_file':'目標檔案：'
		}];
		
/* fwfile.html */
var _fwfile=[{
		'_Boot_Module':'啟動模組',
		'_Current_Version':'目前版本',
		'_Released_Date':'發行日期',
		'_To_upload_firmware_package':'若要韌體套件，請瀏覽至檔案位置再按一下上載。',
		'_File_Path':'檔案路徑:',
		'_FW_Version':'版別',
		'_FW_Upload':'上載檔案'
		}];

/* shellfile.html */
var _shellfile=[{
		'_Shell_Scripts':'Shell 指令碼',
		'_Select_the_file':'選取檔案',
		'_File_Name':'檔案名稱',
		'_Size':'大小',
		'_Modify':'上次修改',
		'_Upload_Shell_Script':'上載 Shell 指令碼',
		'_To_upload_a_shell_script':'若要上載 Shell 指令碼，請瀏覽至檔案 (.zysh) 位置再按一下上載。',
		'_File_Path':'檔案路徑:'
		}];

/* edscriptfile.html */
var _edscriptfile=[{
		'_Copy_File':'複製檔案', 
		'_Rename':'重新命名',
		'_Source_file':'來源檔案：',
		'_Target_file':'目標檔案：'
		}];

/*----- Maintenance > Log -----*/

/* viewlogs.html */
var _viewlogs=[{
		'_Logs':'日誌',
		'_Display':'顯示',
		'_Priority':'優先權',
		'_Source_Address':'來源位址',
		'_Destination_Address':'終點位址',
		'_Service':'服務',
		'_Keyword':'關鍵字',
		'_Total_logging_entries':'日誌項目總數:',
		'_entries_per_page':'每頁項目數',
		'_Page':'頁數',
		'_Time':'時間',
		'_Category':'類別',
		'_Message':'訊息',
		'_Source':'來源',
		'_Destination':'終點',
		'_Note':'備註'
		}];

/* errCode.html */
var _errCode=[{
		'_Certificate':'憑證路徑驗證失敗原因代碼對照表',
		'_Code':'代碼',
		'_Description':'說明'
		}];
		
/* logsetting.html */
var _logsetting=[{
		'_Log_Setting':'日誌設定',
		'_Name':'名稱',
		'_Log_Format':'日誌格式',
		'_Summary':'摘要',
		'_Modify':'修改'
		}];

/* intermail.html */
var _intermail=[{
		'_E_mail_Server_1':'電子郵件伺服器 1',
		'_Active':'啟動',
		'_Mail_Server':'郵件伺服器',
		'_Outgoing':'(外送 SMTP 伺服器名稱或 IP 位址)',
		'_Mail_Subject':'郵件主旨',
		'_Send_From':'寄件者',
		'_E_Mail_Address':'(電子郵件位址)',
		'_Send_Log_to':'將日誌傳送到',
		'_Send_Alerts_to':'將警訊傳送到',
		'_Sending_Log':'傳送日誌',
		'_Day_for_Sending_Log':'日誌傳送日期',
		'_Time_for_Sending_Log':'日誌傳送時間',
		'_Hour':'(時)',
		'_Minute':'(分)',
		'_SMTP_Authentication':'SMTP 身份認證',
		'_User_Name':'使用者名稱',
		'_Password':'密碼',
		'_E_mail_Server_2':'電子郵件伺服器 2',
		'_Active_Log_and_Alert':'現用日誌和警示',
		'_Log_Category':'日誌類別',
		'_System_Log':'系統日誌',		
		'_Log_Consolidation':'日誌彙整',
		'_Log_Consolidation_Interval':'日誌彙整間隔 (秒)'
		}];

/* remsvr.html */
var _remsvr=[{
		'_Log':'遠端伺服器日誌設定 ',
		'_Active':'啟動',
		'_Log_Format':'日誌格式',
		'_ZyXEL_VRPT':'ZyXEL VRPT.',
		'_Server_Address':'伺服器位址',
		'_Server':'(伺服器名稱或 IP 位址)',
		'_Log_Facility':'日誌設備',
		'_Active_Log':'現用日誌',
		'_Log_Category':'日誌類別',
		'_Selection':'選項'
		}];

/* logsummary.html */
var _logsummary=[{
		'_Active_Log_Summary':'現用日誌摘要',
		'_Log_Category':'日誌類別',
		'_System_log':'系統日誌',
		'_E_mail_Server_1':'電子郵件伺服器 1',
		'_E_mail_Server_2':'電子郵件伺服器 2',
		'_Remote_Server_1':'遠端伺服器 1',
		'_Remote_Server_2':'遠端伺服器 2',
		'_Remote_Server_3':'遠端伺服器 3',
		'_Remote_Server_4':'遠端伺服器 4',
		'_E_mail':'電子郵件',
		'_Syslog':'Syslog'
		}];

/*----- Maintenance > Traffic -----*/

/* report.html */
var _report=[{
		'_Data_Collection':'資料收集',
		'_Collect_Statistics':'收集統計資料',
		'_Reports':'流量',
		'_Interface':'介面',
		'_Report_Type':'流量類型',
		'_IP_Address_User':'IP 位址/使用者',
		'_Direction':'方向',
		'_Amount':'數量',
		'_Service_Port':'服務/埠',
		'_Web_Site':'網站',
		'_Hits':'點閱次數'
		}];

/* session.html */
var _session=[{
		'_Session':'工作階段',
		'_View':'檢視',
		'_User':'使用者',
		'_Protocol':'通訊協定',
		'_Source':'來源',
		'_Destination':'終點',
		'_Rx':'接收',
		'_Tx':'傳送',
		'_Duration':'持續時間',
		'_Service':'服務',
		'_Source_Address':'來源位址',
		'_Destination_Address':'終點位址',
		'_Active_Sessions':'現用工作階段',
		'_sessions_per_page':'每頁工作階段數',
		'_Page':'頁數'
		}];
		
/* rptIDP.html */
var _rptIDP=[{
		'_Setup':'設定',
		'_Collect_Statistics':'收集統計資料',
		'_Summary':'摘要',
		'_Total_Session_Scanned':'已掃描工作階段總數',
		'_Total_Packet_Dropped':'丟棄封包總數',
		'_Total_Packet_Reset':'重設封包總數',
		'_Statistics':'統計',
		'_Top_Entry_By':'最常侵入管道',
		'_Signature_Name':'簽章名稱',
		'_Type':'類型',
		'_Severity':'嚴重程度',
		'_Occurrence':'發生次數',
		'_Total':'總計',
		'_Source_IP':'來源 IP',
		'_Destination_IP':'終點 IP'
		}];

/* rptAV.html */
var _rptAV=[{
		'_Setup':'設定',
		'_Collect_Statistics':'收集統計資料',
		'_Summary':'摘要',
		'_Total_Files_Scanned':'已掃描檔案總數',
		'_Infected_Files_Detected':'偵測到遭感染檔案數',
		'_Statistics':'統計',
		'_Top_Entry_By':'最常侵入管道',
		'_Virus_Name':'病毒名稱',
		'_Occurrence':'發生次數',
		'_Total':'總計',
		'_Source_IP':'來源 IP',
		'_Destination_IP':'終點 IP'
		}];
		
/*----- Maintenance > Diagnostics -----*/

/* debugCol.html */
var _debugCol=[{
		'_Diagnostic_Information_Collector':'診斷資訊收集器',
		'_Filename':'檔名',
		'_Last_modified':'上次修改',
		'_Size':'大小'
		}];

/* col.html */
var _col=[{
		'_Diagnostic_Information_Collecting_Status':'診斷資訊收集狀態',
		'_Please_wait_collecting':'請稍待，正在收集中...',
		'_Done_the_collection':'收集完成。'
		}];

/*----- Maintenance > Reboot -----*/

/* reboot.html */
var _reboot=[{
		'_Reboot':'重新開機',
		'_Click':'按一下重新開機按鈕重開裝置。稍待數分鐘，等待登入畫面出現。如果登入畫面沒有出現，請於網頁瀏覽器鍵入裝置的 IP 位址。'
		}];

//access.html file
var _access=[{
		'_andrewc':'andrewc，您現在已經登入。',
		'_Clicking':'按一下登出按鈕終止存取工作階段。已超過登入工作階段最高限值 20 分鐘。為安全起見，您必須在 2 小時 40 分鐘後重新登入。',  
		'_User':'使用者定義租用時間 (最長 20 分鐘)',
		'_Remaining1':'租約到期剩餘時間 (分:秒)：',
		'_Remaining2':'驗證等候剩餘時間 (時:分)：'
		}];

//antispamedit.html file
var _antispamedit=[{
		'_Configuration':'設定',
		'_From_ZONE':'起始區域',
		'_To_ZONE':'結束區域',
		'_SPAM_Score':'SPAM 計分',
		'_SPAM_Log':'SPAM 日誌',
		'_Protocol':'通訊協定',
		'_Action':'動作',
		'_Mark_on_Subject':'主旨標示',
		'_Enable':'啟用'
		}];

//asrbl.html file
var _asrbl=[{
		'_Summary':'摘要',
		'_White_Black_List':'白/黑名單',
		'_RBL_ORDBL':'RBL/ORDBL',
		'_Update':'更新',
		'_Configuration':'設定',
		'_Enable_RBL_ORDBL':'啟用 RBL/ORDBL',
		'_Server_Query_Postfix':'伺服器查詢詞尾',
		'_Maximum':'每封郵件最多 RBL/ORDBL 查詢 IP',
		'_Maximum_Query_IPs':'最多查詢 IP'
		}];

//asrbledit.html file
var _asrbledit=[{
		'_RBL_ORDBL_Server':'RBL / ORDBL 伺服器',
		'_Enable':'啟用',
		'_Server_Query_Postfix':'伺服器查詢詞尾'
		}];

//assummary.html file
var _assummary=[{
		'_Summary':'摘要',
		'_White_Black_List':'白/黑名單',
		'_RBL_ORDBL':'RBL/ORDBL',
		'_Update':'更新',
		'_Configuration':'設定',
		'_Enable_Anti_Spam':'啟用防間諜程式',
		'_Notify':'通知 SMTP 寄件伺服器 (退信)',
		'_Incoming_ZONE':'內送區域',
		'_Outgoing_ZONE':'外送區域',
		'_Inspect_Mail_Protocol':'檢查郵件通訊協定',
		'_Registration_Status':'註冊狀態',
		'_Please_go_to_the':'請前往',
		'_Registration':'註冊',
		'_page':'頁數',
		'_Registration_Status':'註冊狀態:',
		'_Registration_Type':'註冊類型:'
		}];

//asupspam.html file
var _asupspam=[{
		'_Summary':'摘要',
		'_White_Black_List':'白/黑名單',
		'_RBL_ORDBL':'RBL/ORDBL',
		'_Update':'更新',
		'_Signature_Information':'簽章資訊',
		'_Current_Version':'目前版本:',
		'_Remote_Update':'遠端更新',
		'_Synchronize':'利用線上更新伺服器使防間諜簽章套件同步化為最新版本(需啟動 myZyXEL.com)',
		'_Auto_Update':'自動更新',
		'_Hourly':'每小時',
		'_Daily':'每日',
		'_Hour':'(時)',
		'_Weekly':'每週',
		'_Day':'(日期)',
		'_Sunday':'星期日',
		'_Monday':'星期一',
		'_Tuesday':'星期二',
		'_Wednesday':'星期三',
		'_Thursday':'星期四',
		'_Friday':'星期五',
		'_Saturday':'星期六'
		}];

//aswblist.html file
var _aswblist=[{
		'_Summary':'摘要',
		'_White_Black_List':'白/黑名單',
		'_RBL_ORDBL':'RBL/ORDBL',
		'_Update':'更新',
		'_White_List':'白名單',
		'_Enable_White_List':'啟用白名單',
		'_Type':'類型',
		'_Content':'內容',
		'_Black_List':'黑名單',
		'_Enable_Black_List':'啟用黑名單'
		}];

//aswblistedit.html file
var _aswblistedit=[{
		'_Rule_Edit':'規則編輯',
		'_Enable':'啟用',
		'_List':'清單',
		'_Type':'類型',
		'_E_Mail_Address':'電子郵件位址',
		'_IP_Address':'IP 位址',
		'_Network_Mask':'網路遮罩',
		'_Mail_Header':'郵件檔頭',
		'_Value':'值'
		}];

//certcert.html file
var _certcert=[{
		'_Name':'名稱',
		'_Certification_Path':'憑證路徑',
		'_Certificate_Information':'憑證資訊',
		'_Type':'類型',
		'_Version':'版別',
		'_Serial_Number':'序號',
		'_Subject':'主旨',
		'_Issuer':'發行機構',
		'_Signature_Algorithm':'簽章演算法',
		'_Valid_From':'生效日',
		'_Valid_To':'失效日',
		'_Key_Algorithm':'金鑰演算法',
		'_MD5_Fingerprint':'MD5 指紋',
		'_SHA1_Fingerprint':'SHA1 指紋',
		'_Certificate':'PEM (Base-64) 編碼格式的憑證'
		}];

//certreq.html file
var _certreq=[{
		'_Name':'名稱',
		'_Certificate_Information':'憑證資訊',
		'_Type':'類型',
		'_Serial_Number':'序號',
		'_Subject':'主旨',
		'_Issuer':'發行機構',
		'_Signature_Algorithm':'簽章演算法',
		'_Valid_From':'生效日',
		'_Valid_To':'失效日',
		'_Key_Algorithm':'金鑰演算法',
		'_Subject_Alternative_Name':'主旨別名',
		'_Key_Usage':'金鑰使用',
		'_MD5_Fingerprint':'MD5 指紋',
		'_SHA1_Fingerprint':'SHA1 指紋',
		'_Certificate':'PEM (Base-64) 編碼格式的憑證'
		}];

/* chgpw.html */
var _chgpw=[{
		'_Update_Admin_Info':'更新管理資訊',
		'_As':'為安全起見，強烈建議您變更管理員密碼。',
		'_New_Password':'新密碼:',
		'_Retype_to_Confirm':'重新鍵入確認:',
		'_max':'(最多 31 個可列印的文數字字元，中無空格)'
		}];
		
/* keyin.html */
var _1keyin=[{'_Please':'請輸入檔案名稱'}];

/* logout.html */
var _logout=[{
		'_Thank':'感謝您使用 ZyXEL 的網頁設定.',
		'_Good_bye':'再會！'
		}];

/* newvpng.html */
var _newvpng=[{
		'_VPN_Gateway':'VPN 閘道器',
		'_VPN_Gateway_Name':'VPN 閘道器名稱',
		'_IKE_Phase_1':'IKE 階段 1',
		'_Negotiation_Mode':'協商模式',
		'_Main':'主要',
		'_Aggressive':'主動',
		'_Proposal':'提議',
		'_Encryption':'加密',
		'_Authentication':'認證',
		'_Key_Group':'金鑰群組',
		'_SA_Life_Time':'SA 存留時間 (秒)',
		'_NAT_Traversal':'NAT 橫跨',
		'_Dead_Peer_Detection':'斷線偵測 (DPD)',
		'_Property':'內容',
		'_My_Address':'我的位址',
		'_Interface':'介面',
		'_Domain_Name':'網域名稱',
		'_Secure_Gateway_Address':'安全閘道位址',
		'_Authentication_Method':'認證方式',
		'_Pre_Shared_Key':'預先共用金鑰',
		'_Certificate':'憑證',
		'_See':'請參閱',
		'_My_Certificates':'我的憑證',
		'_Local_ID_Type':'本機 ID 類型',
		'_Content':'內容',
		'_Peer_ID_Type':'對等裝置 ID 類型',
		'_Extended_Authentication':'延伸性認證',
		'_Enable_Extended_Authentication':'啟用延伸性認證',
		'_Server_Mode':'伺服器模式',
		'_Client_Mode':'用戶端模式',
		'_User_Name':'使用者名稱',
		'_Password':'密碼'
		}];

/* prdframe.html */
var _prdframe=[{
		'_Incoming':'內送',			
		'_Member_List':'成員清單',
		'_Please':'請選取一個成員'
		}];


/* wizard.html */
var _wizard=[{
		'_Welcome':'歡迎使用 ZyWALL 精靈設定程式',
		'_helps1':'(協助使用者迅速完成設定，',
		'_helps1_1':' 確保網際網路連線安全)',
		'_helps2':' 確保 VPN 連線安全)',
		'_Installation_Setup_One_ISP':'安裝設定，一個 ISP',
		'_Installation_Setup_Two_ISP':'安裝設定，兩個 ISP',
		'_VPN_Setup':'VPN 設定'
		}];

//wizisp1.html file
var _wizisp1=[{
		'_Installation_Setup_Wizard':'安裝設定精靈',
		'_Internet_Access':'網際網路接取',
		'_ISP_Parameters':'ISP 參數',
		'_Encapsulation':'封裝:',
		'_WAN':'WAN IP 位址指派',
		'_WAN_Interface':'WAN 介面:',
		'_Zone':'區域:',
		'_STEP':'步驟',
		'_IP_Address_Assignment':'IP 位址指派:',
		'_Second_WAN_Interface':'第二 WAN 介面',
		'_First_WAN_Interface':'第一 WAN 介面'
		}];

//wizisp2.html file
var _wizisp2=[{
		'_Installation_Setup_Wizard':'安裝設定精靈',
		'_Internet_Access':'網際網路接取',
		'_ISP_Parameters':'ISP 參數',
		'_Encapsulation':'封裝:',
		'_WAN':'WAN IP 位址指派',
		'_WAN_Interface':'WAN 介面:',
		'_Zone':'區域:',
		'_IP_Address_Assignment':'IP 位址指派:',
		'_Base_Interface':'基礎介面',
		'_Service_Name':'服務名稱',
		'_Optional':'(可省略)',
		'_User_Name':'使用者名稱',
		'_Password':'密碼',
		'_Retype_to_Confirm':'重新鍵入確認：',
		'_Nailed_Up':'永遠連線', 
		'_Idle_Timeout':'閒置等候時間',
		'_Seconds':'(秒)',
		'_PPTP_Configuration':'PPTP 設定',
		'_Base_IP_Address':'基礎 IP 位址',
		'_IP_Subnet_Mask':'IP 子網路遮罩',
		'_Server_IP':'伺服器 IP',
		'_IP_Address':'(IP 位址)',
		'_Connection_ID':'連線 ID：',
		'_WAN_IP_Address_Assignments':'WAN IP 位址指派',
		'_WAN_Interface':'WAN 介面',
		'_Zone':'區域',
		'_IP_Address':'IP 位址', 
		'_Auto':'自動',
		'_IP_Subnet_Mask':'IP 子網路遮罩',
		'_Gateway_IP_Address':'閘道 IP 位址',
		'_First_DNS_Server':'第一 DNS 伺服器',
		'_Second_DNS_Server':'第二 DNS 伺服器',
		'_Second_WAN_Interface':'第二 WAN 介面',
		'_First_WAN_Interface':'第一 WAN 介面',
		'_STEP':'步驟'
		}];

//wizisp3.html file
var _wizisp3=[{
		'_Installation_Setup_Wizard':'安裝設定精靈',
		'_Internet_Access':'網際網路接取',
		'_ISP_Parameters':'ISP 參數',
	        '_You_can':'您可以依據所在網路選取乙太網路、PPPoE 或 PPTP. 如果您不清楚, 請問您的網路管理員. 最常見的是網位為乙太網路.',
		'_Encapsulation':'封裝:',
		'_WAN_IP_Address_Assignments':'WAN IP 位址指派',
		'_The_ZyWall':' ',
		'_The_ZyWall_1':' 連接埠可於執行階段設定。例如將前面板左側的埠 4 從 DMZ1 改為 LAN2。埠名亦可於執行階段設定(cute 卡)',
		'_WAN_Interface':'WAN 介面:',
		'_IP_Address_Assignment':'IP 位址指派:',
		'_error':'錯誤'
		}];

//wizisp4.html file
var _wizisp4=[{
		'_Installation_Setup_Wizard':'安裝設定精靈',
		'_Internet_Detection':'網際網路偵測',
		'_Please_wait_a_moment':'請稍待...',
		'_STEP':'步驟',
		'_Check_User_Name':'檢查使用者名稱...',
		'_Auto_Configure_Device':'自動設定裝置'
		}];

//wizisp5.html file
var _wizisp5=[{
		'_Installation_Setup_Wizard':'安裝設定精靈',
		'_Internet_Access':'網際網路接取',
		'_Congratulations':'恭喜， 網際網路接取精靈已完成作業。',
		'_Summary':'網際網路接取設定摘要:',
		'_You_can':'您可以至<a href=「http://www.myZyXEL.com」target=_top><span class="style">myZyXEL.com</span></a>為 ZyWALL 註冊，並免費試用 ZyWALL 的內容過濾<!--、防間諜、防毒 //Jerry--> 及 IDP 服務。',
		'_Click':'按一下「下一步」即可免費啟用以上服務。',
		'_Setting':'設定:',
		'_First_Setting':'第一設定:',
		'_Encapsulation':'封裝',
		'_Service_Name':'服務名稱',
		'_User_Name':'使用者名稱',
		'_Nailed_Up':'永遠連線',
		'_Idle_Timeout':'閒置等候時間',
		'_Server_IP':'伺服器 IP',
		'_User_Name':'使用者名稱',
		'_Connection_ID':'連線 ID：',
		'_WAN_Interface':'WAN 介面',
		'_Zone':'區域',
		'_First_WAN_Interface':'第一 WAN 介面',
		'_IP_Assignment':'IP 指定',
		'_IP_Address':'IP 位址',
		'_IP_Subnet_Mask':'IP 子網路遮罩',
		'_Gateway_IP_Address':'閘道 IP 位址',
		'_First_DNS_Server':'第一 DNS 伺服器',
		'_Second_DNS_Server':'第二 DNS 伺服器',
		'_Second_Setting':'第二設定:',
		'_Second_WAN_Interface':'第二 WAN 介面',
		'_STEP':'步驟'
		}];
		
/* wizregist.html */
var _wizregist=[{
		'_Installation_Setup_Wizard':'安裝設定精靈',
		'_Device_Registration':'裝置註冊',		
	        '_This_device':'<font color="#FF0000">此裝置尚未至 myZyXEL.com 註冊。&nbsp;請在下面輸入資料以<b>註冊</b>裝置。</font> <font color="#FFFFFF"> 如果您沒有 myZyXEL.com 帳號, 請在下面選擇 &quot;新增 myZyXEL.com 帳號&quot; 如果您已有 myZyXEL.com 帳號,但是忘記帳號名稱或密碼, 請前往 <a href="http://www.myZyXEL.com">www.myZyXEL.com</a> 尋求幫助.</font>',
		'_new':'新建 myZyXEL.com 帳號',
		'_existing':'現有 myZyXEL.com 帳號',
		'_User_Name':'使用者名稱',
		'_you_can':'您可以按一下滑鼠檢查使用者名稱是否存在.',
		'_Password':'密碼',
		'_Confirm_Password':'確認密碼',
		'_E_Mail_Address':'電子郵件位址',
		'_Country_Code':'國碼',
		'_Trial_Service_Activation':'啟動試用服務',
		'_IDP':'IDP/應用程式巡查',
		'_Anti_Virus':'防毒',
		'_Content_Filter':'內容過濾',
		'_STEP':'步驟'
		}];

//wizvpn1.html file
var _wizvpn1=[{
		'_VPN_Setup_Wizard':'VPN 設定精靈',
		'_Please':'請選取您要設定的 VPN 策略類型。',
		'_Express':'快速',
		'_Advanced':'進階',
		'_STEP':'步驟'
		}];

//wizvpn2.html file
var _wizvpn2=[{
		'_VPN_Setup_Wizard':'VPN 設定精靈',
		'_VPN_Access':'VPN 接取',
		'_Remote_Gateway':'遠端閘道',
		'_Name':'名稱',
		'_Secure_Gateway':'安全閘道',
		'_IP_DNS':'(IP/DNS)',
		'_Pre_Shared_Key':'預先共用金鑰',
		'_STEP':'步驟'
		}];

//wizvpn3.html file
var _wizvpn3=[{
		'_VPN_Setup_Wizard':'VPN 設定精靈',
		'_VPN_Access':'VPN 接取',
		'_Policy_Setting':'策略設定',
		'_Local_Policy':'本機策略 (IP/遮罩)',
		'_Remote_Policy':'遠端策略 (IP/遮罩)',
		'_STEP':'步驟'
		}];

//wizvpn4.html file
var _wizvpn4=[{
		'_VPN_Setup_Wizard':'VPN 設定精靈',
		'_VPN_Access':'VPN 接取',
		'_Summary':'摘要',
		'_Name':'名稱',
		'_Secure_Gateway':'安全閘道',
		'_Pre_Shared_Key':'預先共用金鑰',
		'_Local_Policy':'本機策略',
		'_Remote_Policy':'遠端策略',
		'_Configuration_for_Remote_Gateway':'遠端閘道設定',
		'_Uncomment':'如果 CLI 無法在 zysh 指令碼之下使用，請取消其註解。',
		'_configure_terminal':'設定終端',
		'_Click':'按一下「儲存」按鈕將 VPN 組態寫入 ZyWALL。',
		'_STEP':'步驟'
		}];

//wizvpn5.html file
var _wizvpn5=[{
		'_VPN_Setup_Wizard':'VPN 設定精靈',
		'_VPN_Access':'VPN 接取',
		'_Congratulations':'恭喜，VPN 接取精靈已完成作業。',
		'_Summary':'VPN 接取設定摘要:',
		'_Now':'如果是首次安裝此裝置，您可以按一下 <a href="http://myZyXEL.com" target=_top><span class="style">myZyXEL.com</span></a> 連結，為此裝置註冊並試用進階安全功能。(需接取網際網路才能註冊)',
		'_STEP':'步驟',
		'_Encapsulation':'封裝:  ',
		'_Service_Name':'服務名稱:  ',
		'_User_Name':'使用者名稱:  ',
		'_Idle_Timeout':'閒置等候時間:  ',
		'_Server_IP':'伺服器 IP:  ',
		'_Connection_ID':'連線 ID:  ',
		'_WAN_Interface':'WAN 介面:  ',
		'_First_WAN_Interface':'第一 WAN 介面:  ',
		'_IP_Assignment_Auto':'IP 指派 : 自動 ',
		'_IP_Address':'IP 位址:    ',
		'_IP_Subnet_Mask':'IP 子網路遮罩:  ',
		'_Gateway_IP_Address':'閘道 IP 位址:  ',
		'_IP_Assignment_Static':'閘道 IP 位址:  ',
		'_Second_WAN_Interface':'第二 WAN 介面:  '
		}];

//wizvpna2.html file
var _wizvpna2=[{
		'_VPN_Setup_Wizard':'VPN 設定精靈',
		'_VPN_Advanced_Access':'VPN 進階接取',
		'_Remote_Gateway':'遠端閘道',
		'_Name':'名稱',
		'_IP_DNS':'(IP/DNS)',
		'_Secure_Gateway':'安全閘道',
		'_My_Address':'我的位址 (介面)',
		'_Authentication_Method':'認證方式',
		'_Pre_Shared_Key':'預先共用金鑰',
		'_Certificate':'憑證',
		'_STEP':'步驟'
		}];

//wizvpna3.html file
var _wizvpna3=[{
		'_VPN_Setup_Wizard':'VPN 設定精靈',
		'_VPN_Advanced_Access':'VPN 進階接取',
		'_Phase_1_Setting':'階段 1 設定',
		'_Negotiation_Mode':'協商模式',
		'_Encryption_Algorithm':'加密演算法',
		'_Authentication_Algorithm':'認證演算法',
		'_Key_Group':'金鑰群組',
		'_SA_Life_Time':'SA 存留時間 (秒)',
		'_NAT_Traversal':'NAT 橫跨',
		'_Dead_Peer_Detection':'斷線偵測 (DPD)',
		'_STEP':'步驟'
		}];

//wizvpna4.html file
var _wizvpna4=[{
		'_VPN_Setup_Wizard':'VPN 設定精靈',
		'_VPN_Advanced_Access':'VPN 進階接取',
		'_Phase_2_Setting':'階段 2 設定',
		'_Active_Protocol':'現用通訊協定',
		'_Encapsulation':'封裝',
		'_Encryption_Algorithm':'加密演算法',
		'_Authentication_Algorithm':'認證演算法',
		'_SA_Life_Time':'SA 存留時間 (秒)',
		'_Perfect_Forward_Secrecy':'完整轉寄密碼 (PFS)',
		'_Policy_Setting':'策略設定',
		'_Local_Policy':'本機策略 (IP/遮罩)',
		'_Incoming_Interface':'內送介面',
		'_Remote_Policy':'遠端策略 (IP/遮罩)',
		'_Property':'內容',
		'_Nailed_Up':'永遠連線',
		'_STEP':'步驟'
		}];

//wizvpna5.html file
var _wizvpna5=[{
		'_VPN_Setup_Wizard':'VPN 設定精靈',
		'_VPN_Access':'VPN 接取',
		'_Summary':'摘要',
		'_Name':'名稱',
		'_Secure_Gateway':'安全閘道',
		'_Pre_Shared_Key':'預先共用金鑰',
		'_Local_Policy':'本機策略',
		'_Remote_Policy':'遠端策略',
		'_Remote_Gateway_CLI':'遠端閘道 CLI',
		'_Uncomment':'如果 CLI 無法在 zysh 指令碼之下使用，請取消其註解。',
		'_configure_terminal':'設定終端',
		'_Click':'按一下「儲存」按鈕將 VPN 組態寫入 ZyWALL。',
		'_STEP':'步驟'
		}];

//wizvpna6.html file
var _wizvpna6=[{
		'_VPN_Setup_Wizard':'VPN 設定精靈',
		'_VPN_Access':'VPN 接取',
		'_Congratulations':'恭喜，VPN 接取精靈已完成作業。',
		'_Summary':'VPN 接取設定摘要:',
		'_Now':'如果是首次安裝此裝置，您可以按一下 <a href="http://myZyXEL.com" target=_top><span class="style">myZyXEL.com</span></a> 連結，為此裝置註冊並試用進階安全功能。(需接取網際網路才能註冊)',
		'_STEP':'步驟',
		'_Name':'名稱',
		'_Secure_Gateway':'安全閘道',
		'_Pre_Shared_Key':'預先共用金鑰',
		'_Local_Policy':'本機策略',
		'_Remote_Policy':'遠端策略',
		'_Secure_Gateway':'安全閘道',
		'_My_Address_interface':'我的位址 (介面)',
		'_Pre_Shared_Key':'預先共用金鑰',
		'_Certificate':'憑證',
		'_Phase_1':'階段 1',
		'_Negotiation_Mode':'協商模式',
		'_main':'主要',
		'_Negotiation_Mode':'協商模式',
		'_aggressive':'主動',
		'_Encryption_Algorithm':'加密演算法',
		'_Authentication_Algorithm':'認證演算法',
		'_Key_Group':'金鑰群組',
		'_SA_Life_Time_Seconds':'SA 存留時間 (秒)',
		'_NAT_Traversal':'NAT 橫跨',
		'_Dead_Peer_Detection_DPD':'斷線偵測 (DPD)',
		'_Phase_2':'階段 2',
		'_Active_Protocol':'現用通訊協定',
		'_ESP':'ESP',
		'_AH':'AH',
		'_Encapsulation':'封裝',
		'_Tunnel':'通道',
		'_Transport':'傳輸',
		'_Encryption_Algorithm':'加密演算法',
		'_SA_Life_Time_Seconds':'SA 存留時間 (秒)',
		'_Perfect_Forward_Secrecy':'完整轉寄密碼',
		'_Policy':'策略',
		'_Local_Policy':'本機策略',
		'_Remote_Policy':'遠端策略',
		'_Incoming_Interface':'內送介面',
		'_Nailed_Up':'永遠連線'
		}];

/* wizard_error.html */
var _wizard_error=[{
		'_ErrNo':'錯誤代號:',
		'_ErrMsg':'錯誤訊息:',
		'_Installation_Setup_Wizard':'安裝設定精靈',
		'_Error':'錯誤'
		}];

//wizvpnwait.html file
var _wizvpnwait=[{
		'_Installation_Setup_Wizard':'安裝設定精靈',
		'_Internet_Detection':'網際網路偵測',
		'_Auto_Configure_WAN':'自動設定 WAN',
		'_Please':'請稍待...',
		'_STEP':'步驟'
		}];

/*----- SiteMAP -----*/

//sitemap.html file
var _sitemap=[{
		'_Licensing':'授權',
		'_Registration':'註冊',
		'_Service':'服務',
		'_File_Manager':'檔案管理程式',
		'_Configuration_File':'設定檔',
		'_Firmware_Package':'韌體套裝軟體',
		'_Shell_Script':'Shell 指令碼',
		'_Configuration':'設定',
		'_Network':'網路',
		'_Policy':'策略',
		'_User_Group':'使用者/群組',
		'_Interface':'介面',
		'_Ethernet':'乙太網路',
		'_Route':'路由器',
		'_Policy_Route':'策略路由',
		'_User':'使用者',
		'_Port_Grouping':'埠群組',
		'_Static_Route':'靜態路由',
		'_Group':'群組',
		'_VLAN':'VLAN 虛擬區域網路',
		'_Firewall':'防火牆',
		'_Setting':'設定',
		'_Bridge':'橋接器',
		'_App_Patrol':'應用程式巡查',
		'_Configuration':'設定',
		'_PPPoE_PPTP':'PPPoE/PPTP',
		'_Other_Protocol':'其他通訊協定',
		'_Auxiliary':'輔助',
		'_IDP':'入侵偵測與防護',
		'_General':'一般',
		'_Trunk':'主幹',
		'_Profile':'設定組合',
		'_IPSec_VPN':'IPSec VPN',
		'_VPN_Connection':'VPN 連線',
		'_Custom_Signatures':'自訂簽章',
		'_VPN_Gateway':'VPN 閘道器',
		'_Update':'更新',
		'_Concentrator':'集訊器',
		'_Content_Filter':'內容過濾',
		'_General':'一般',
		'_SA_Monitor':'SA 監控程式',
		'_Filter_Profile':'過濾設定組合 ',
		'_Routing_Protocol':'路由通訊協定',
		'_RIP':'RIP',
		'_Cache':'快取',
		'_OSPF':'OSPF',
		'_Virtual_Server':'虛擬伺服器',
		'_Zone':'區域',
		'_HTTP_Redirect':'HTTP 重新導向',
		'_Device_HA':'裝置 HA',
		'_VRRP_Group':'VRRP 群組',
		'_VoIP_passThru':'IP 語音通過',
		'_Synchronize':'同步',
		'_ISP_Account':'ISP 帳號',
		'_DDNS':'DDNS',
		'_Object':'物件',
		'_System':'系統',
		'_Address':'位址',
		'_Address_Group':'位址群組',
		'_Host_Name':'主機名稱',
		'_Service':'服務',
		'_Date_Time':'日期/時間',
		'_Service_Group':'服務群組',
		'_Console_Speed':'Console 速度',
		'_Schedule':'排程',
		'_ICMP':'ICMP 網際網路控制訊息協定',
		'_AAA_Server':'AAA 伺服器',
		'_LDAP':'LDAP',
		'_DNS':'DNS',
		'_Default':'預設',
		'_Group':'群組',
		'_WWW':'WWW',
		'_RADIUS':'RADIUS',
		'_SSH':'SSH',
		'_TELNET':'TELNET',
		'_Auth_method':'認證方式',
		'_FTP':'FTP',
		'_Certificate':'憑證',
		'_My_Certificates':'我的憑證',
		'_SNMP':'簡易網路管理通訊協定',
		'_Trusted_Certificates':'受信任憑證',
		'_Maintenance':'維護',
		'_Log':'日誌',
		'_Traffic':'流量',
		'_Reboot':'重新開機',
		'_View_Log':'查看日誌',
		'_Log_Setting':'日誌設定',
		'_Session':'工作階段',
		'_Diagnostics':'診斷',
		'_System_Protect':'系統保護',
		'_Anti_Virus':'防毒',
		'_Interface_Summary':'介面摘要',
		'_Routing':'路由',
		'_ALG':'ALG',
		'_VPN':'VPN',
		'_SSL_VPN':'SSL VPN',
		'_Access_Privilege':'存取權限',
		'_Connection_Monitor':'連線監控程式',
		'_Global_Setting':'全域設定',
		'_L2TP_VPN':'L2TP VPN',
		'_Session_Monitor':'工作階段監控程式',
		'_General':'一般',
		'_Common':'共用',
		'_IM':'IM',
		'_Peer_to_Peer':'點對點',
		'_VoIP':'IP 語音',
		'_Streaming':'串流',
		'_Other':'其他',
		'_Statistics':'統計',
		'_Anti_X':'防色情',
		'_Anti_Virus':'防毒',
		'_Summary':'摘要',
		'_Setting':'設定',
		'_Signature':'簽章',
		'_ADP':'ADP 自動化資料處理',
		'_Active_Directory':'現用目錄',
		'_SSL_Application':'SSL 應用程式',
		'_Dial_in_Mgmt':'撥接管理',
		'_Vantage_CNM':'Vantage CNM',
		'_Anti_Virus':'防毒',
		'_Diagnostics':'診斷'
		}];

var LangReady=true;

