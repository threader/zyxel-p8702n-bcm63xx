function objGlobalList()
{
	this.dataSet = new Array();
	this.addNewRecord = function(mb1, mb2, mb3, mb4, mb5, mb6, mb7, mb8, mb9, mb10, objMb1, objMb2, objMb3, objMb4, objMb5){		
		var data=new objGlobalRecord(mb1, mb2, mb3, mb4, mb5, mb6, mb7, mb8, mb9, mb10, objMb1, objMb2, objMb3, objMb4, objMb5);
		this.dataSet.push(data); 	
	}
	this.getRecord = function(Idx){	
		return this.dataSet[Idx]; 				
	}	
	this.insertRecord = function(idx, mb1, mb2, mb3, mb4, mb5, mb6, mb7, mb8, mb9, mb10, objMb1, objMb2, objMb3, objMb4, objMb5){
		var data=new objGlobalRecord(mb1, mb2, mb3, mb4, mb5, mb6, mb7, mb8, mb9, mb10, objMb1, objMb2, objMb3, objMb4, objMb5);
		this.dataSet.splice(idx,0,data);
	}
	this.insertafterRecord = function(idx, mb1, mb2, mb3, mb4, mb5, mb6, mb7, mb8, mb9, mb10, objMb1, objMb2, objMb3, objMb4, objMb5){
		var data=new objGlobalRecord(mb1, mb2, mb3, mb4, mb5, mb6, mb7, mb8, mb9, mb10, objMb1, objMb2, objMb3, objMb4, objMb5);
		this.dataSet.splice(idx,0,data);
		var olddata = this.dataSet.pop();
		this.dataSet.splice(idx,0,olddata);		
	}
	this.deleteRecord = function(idx){		
		return this.dataSet.splice(idx,1); 
	}
	this.dataCount = function(){		
		return this.dataSet.length;
	}	
}
function objGlobalRecord(mb1, mb2, mb3, mb4, mb5, mb6, mb7, mb8, mb9, mb10, objMb1, objMb2, objMb3, objMb4, objMb5)
{
	this.mb1 	= mb1;
	this.mb2 	= mb2;
	this.mb3 	= mb3;
	this.mb4 	= mb4;
	this.mb5 	= mb5;
	this.mb6 	= mb6;
	this.mb7 	= mb7;
	this.mb8 	= mb8;
	this.mb9 	= mb9;
	this.mb10 = mb10;	
	this.objMb1 = new objGlobalList();
	this.objMb2 = new objGlobalList();
	this.objMb3 = new objGlobalList();
	this.objMb4 = new objGlobalList();
	this.objMb5 = new objGlobalList();

}