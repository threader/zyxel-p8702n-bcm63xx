var langFile='Simplex_Chinese';

/* for all buttons */
var _button=[{
		'_OK':'确认',
		'_Cancel':'取消',
		'_Apply':'应用',
		'_Reset':'重置',
		'_Synchronize_Now':'立即同步',
		'_Import':'导入',
		'_Refresh':'刷新',
		'_Export':'导出',
		'_Export_Certificate':'导出证书',
		'_Export_Certificate_Only':'只导出证书',
		'_Export_Certificate_with_Private_Key':'导出带私钥的证书',
		'_Show_Filter':'显示过滤',
		'_Hide_Filter':'隐藏过滤',
		'_Search':'查询',
		'_Email_Log_Now':'立即以E-mail形式发送日志',
		'_Clear_Log':'清除日志',
		'_Active_Log_Summary':'启用日志摘要',
		'_Flush_Data':'清空数据',
		'_Start_Collection':'开始收集',
		'_Stop_Collection':'停止收集',
		'_Collect_Now':'立即收集',
		'_Close':'关闭',
		'_Download':'下载',
		'_Reboot':'重新启动',
		'_Please_wait_collecting':'收集中，请稍候...',
		'_Done_the_collection':'收集完毕。',
		'_Update':'更新',
		'_Service_License_Refresh':'服务许可证更新',
		'_Copy':'拷贝',
		'_Rename':'重命名',
		'_Delete':'删除',
		'_Upload':'上传',
		'_Run':'运行',
		'_Edit_static_DHCP_table':'编辑静态DHCP表',
		'_Add_New_VPN_Gateway':'添加新的VPN网关',
		'_Advanced':'高级...',
		'_Sync_Now':'立即同步',
		'_Change':'更改...',
		'_New':'新增...',
		'_Switch_to_query_view':'切换至查询视图',
		'_Switch_to_group_view':'切换至分类视图',
		'_Save':'  保存  ',
		'_Delete':'删除',
		'_Export':'导出',
		'_Update_Now':'立即更新',
		'_Flush':'清空',
		'_Add':'添加',
		'_Basic_cfilter':'基本',
		'_Advanced_cfilter':'高级',
		'_Test_Against_Local_Cache':'用本地缓存测试',
		'_Test_Against_Web_Filter_Server':'用Web过滤服务器测试',
		'_Login':'登录',
		'_Refresh_Now':'立即刷新',
		'_Clear_Warning_Message':'清除警告消息',
		'_Back':'< 后退',
		'_Next':'下一个 >',
		'_Check':'检查',
		'_Set_Interval':'设置间隔',
		'_Stop':'停止',
		'_Clear_RX_Message':'清除RX消息',
		'_Change_Display_Style':'更改显示风格',
		'_Advanced_':'高级>>',
		'_Basic_':'基本<<',
		'_Expand':'展开',
		'_Collapse':'折叠',
		'_Reset_Default':'恢复默认',
		'_Preview':'预览',
		'_Logout':'登出',
		'_Renew':'更新'
		}];
		
/* Global Title Tag */
var _globalTag=[{
		/* Spare bar*/
		'_General_Setup':'常规设置',
		'_Policies':'策略',
		'_Configuration':'设定',
		/* Registration */
		'_Registration':'注册',
		'_Service':'服务',
		/* Update */
		'_IDP_App_Patrol':'入侵检测与保护/应用控制',
		'_System_Protect':'系统保护',
		'_Anti_Virus':'防病毒',
		/* Network */
		'_Interface_Summary':'接口摘要',
		'_Ethernet':'以太网',
		'_Port_Grouping':'端口分组',
		'_VLAN':'VLAN',
		'_Bridge':'网桥',
		'_PPPoE_PPTP':'PPPoE/PPTP',
		'_Auxiliary':'辅助',
		'_Trunk':'中继',
		'_Policy_Route':'策略路由',
		'_Static_Route':'静态路由',
		'_RIP':'RIP',
		'_OSPF':'OSPF',
		/* IPSec VPN */
		'_VPN_Connection':'VPN连接',
		'_VPN_Gateway':'VPN网关',
		'_Concentrator':'集中器',
		'_SA_Monitor':'SA监控',
		/* SSL VPN */
		'_Access_Privilege':'访问权限',
		'_Connection_Monitor':'连接监控',
		'_Global_Setting':'通用设定',
		/* L2TP VPN */
		'_L2TP_VPN':'L2TP VPN',
		'_Session_Monitor':'会话监控',
		/* AppPatrol */
		'_General':'通用',
		'_Common':'通用设定',
		'_Instant_Messenger':'即时通讯',
		'_Peer_to_Peer':'P2P',
		'_VoIP':'VoIP',
		'_Streaming':'流媒体',
		'_Other':'其他',
		'_Statistics':'统计',
		/* Anti-X > Anti-Virus */
		'_Summary':'摘要',
		'_Setting':'设定',
		'_Signature':'特征码',
		/* Anti-X > IDP */
		'_General':'通用',
		'_Profile':'设定组合',
		'_Custom_Signatures':'定制特征码',		
		'_Protocol_Anomaly':'协议异常',
		'_Traffic_Anomaly':'流量异常',
		/* Anti-X > Content Filter */
		'_General_CF':'通用',
		'_Filter_Profile':'过滤文件',
		'_Cache':'缓存',
		/* Device HA */
		'_VRRP_Group':'VRRP群组',
		'_Synchronize':'同步',	
		/* Object */
		'_User':'用户',
		'_Group':'群组',
		'_Setting':'设定',
		'_Address':'地址',
		'_Address_Group':'地址群组',
		'_Service':'服务',
		'_Service_Group':'服务群组',
		'_Active_Directory':'现有目录',
		'_LDAP':'LDAP',
		'_RADIUS':'RADIUS',
		'_My_Certificates':'本方证书',
		'_Trusted_Certificates':'可信证书',
		/* File Manager */
		'_Configuration_File':'配置文件',
		'_Firmware_Package':'韧体包',
		'_Shell_Script':'Shell脚本',
		/* Log */
		'_View_Log':'查看日志',
		'_Log_Setting':'日志设定',		
		/* Traffic */
		'_Traffic':'报告',
		'_Session':'会话',
		'_IDP':'入侵检测与保护',
		'_Anti_Virus':'防病毒',
		/* Member List popup*/
		'_Member_List':'成员列表',
		'_Available':'可用',
		'_Member':'成员',
		'_Please_Select':'请选择',
		/* app patrol & policy route BWM */
		'_BWM_Global_Setting':'带宽管理通用设定',
		'_Enable_BWM':'启用带宽管理'
		}];

/* about.html */
var _about=[{
		'_ZyWALL_1050':'ZyWALL 1050',
		'_USG_300':'ZyWALL USG 300',
		'_Copyright':'( C ) 版权所有 2007 合勤科技股份有限公司。',
		'_Did_you_check':'今天您查看',
		'_www_zyxel_com':'www.zyxel.com',
		'_today':' 了吗?'
		}];

/* tx.html */
var _tx=[{
		'_CLI_Message':'CLI消息',
		'_Start_CLI_command':'开始CLI命令',
		'_End_CLI_command':'结束CLI命令'
		}];

/* rx.html */
var _rx=[{'_RX_Message':'RX消息'}];

/* status.html */
var _status=[{
		'_Message':'消息',
		'_Ready':'就绪'
		}];

/* grant_access.html */
var _grant_access=[{'_ZyWALL_has_granted_your_access':'ZyWALL准许了您的访问。'}];

/* fwDone.html */
var _fwDone=[{'_Please_Wait':'请稍候...'}];

/* fwDone.html */
var _fwupdone=[{'_Please_Wait':'请稍候...',
			'_warning_message1':'Firmware upload is in progress -- Do not turn off the power or reset the ZyWALL.',
			'_warning_message2':'The complete firmware update may take up to 5 minutes.'
			}];

/* vpndial.html */	
var _vpndial=[{'_Please_Wait':'请稍候...'}];

/* apacheDone.html */
var _apacheDone=[{'_Please_Wait':'请稍候...'}];

/* rebootDone.html */
var _rebootDone=[{'_Please_Wait':'请稍候...'}];

/* homedial.html */
var _homedial=[{'_Please_Wait':'请稍候...'}];

/* waitdial.html */
var _waitdial=[{'_Please_Wait':'请稍候 ...'}];

//warning.html file
var _warning=[{'_Warning_Message':'警告消息'}];

//waitdata.html file
var _waitdata=[{'_Please_Wait':'请稍候 ...'}];

/*----- Status -----*/

/* home.html */
var _home=[{
		/* Device Information */
		'_Device_Information':'设备信息',
		'_System_Name':'系统名称',
		'_Model_Name':'型号',
		'_Serial_Number':'序列号',
		'_MAC_Address_Range':'MAC地址范围',
		'_Firmware_Version':'韧体版本',
		/* System Resource */
		'_System_Resources':'系统资源',
		'_CPU_Usage':'CPU利用率',
		'_Memory_Usage':'内存利用率',
		'_Flash_Usage':'闪存利用率',
		'_Active_Sessions':'活动会话',
		/* Interface Status Summary */ 
		'_Interface_Status_Summary':'接口状态摘要',
		'_Name':'名称',
		'_Status':'状态',
		'_HA_Status':'高可用性状态',
		'_Zone':'区域',
		'_IP_Address':'IP地址',
		'_Renew_Dial':'更新/拨号',
		/* System Status */
		'_System_Status':'系统状态',
		'_System_Uptime':'系统运行时间',
		'_Current_Date_Time':'当前日期/时间',
		'_VPN_Status':'VPN状态',
		'_DHCP_Table':'DHCP表',
		'_Statistics':'统计',
		'_Current_User_List':'登录用户',
		'_Current_Login_User':'当前登录用户',
		'_Number_of_Login_Users':'登录用户数量',
		/* Licensed Service Status */
		'_Licensed_Service_Status':'注册服务状态',
		'_IDP':'入侵检测与保护',
		'_License_Status_Remaining_days':'许可证状态/剩余天数',
		'_Signature_Version':'特征码版本',
		'_Last_Update_Time':'上次更新时间',
		'_Total_Signature_Number':'特征码总数',
		'_Anti_Virus':'防病毒',
		'_Content_Filter':'内容过滤', 
		/* Top 5 Intrusion & Virus Detection*/
		'_Top5':'前五大入侵及病毒',
		'_Rank':'排名',
		'_Intrusion_Detected':'入侵侦测',
		'_Virus_Detected':'病毒侦测', 
		/* Refresh */
		'_Refresh_Interval':'刷新间隔',
		'_Refresh_Now':'立即刷新',
		/* force logout */
		'_User_ID':'用户ID',
		'_Reauth_Lease_T_':'重新验证延续时间',
		'_Type':'类型',
		'_IP_address':'IP地址',
		'_Force_Logout':'强制注销'
		}];

/*----- Licensing > Registration -----*/ 
/* vpnitval.html */
var _vpnitval=[{'_Poll_Interval':'统计间隔 (1-60 秒):'}];

/* vpnstatus.html */
var _vpnstatus=[{
		'_VPN_Table':'VPN表',
		'_Name':'名称',
		'_Encapsulation':'封装',
		'_IPSec_Algorithm':'IPSec算法'
		}];

/* dhcpstatus.html */
var _dhcpstatus=[{
		'_DHCP_Table':'DHCP表',
		'_Interface':'接口',
		'_IP_Address':'IP地址',
		'_Host_Name':'主机名称',
		'_MAC_Address':'MAC地址',
		'_Reserve':'保留'
		}];

/* ifacestatus.html */
var _ifacestatus=[{
		'_Statistics_Table':'统计表',
		'_Port':'Port',
		'_status':'Status',
		'_TxPkts':'TxPkts',
		'_RxPkts':'RxPkts',
		'_Collisions':'Collisions',
		'_Tx':'Tx B/s',
		'_Rx':'Rx B/s',
		'_Up_Time':'Up Time',
		'_System_Up_Time':'系统运行时间'
		}];

/* ifaceitval.html */
var _ifaceitval=[{'_Poll_Interval':'统计间隔 (1-60 秒):'}];

/*----- Licensing > Registration -----*/

/* regist.html */
var _regist=[{
		'_Device_Registration':'设备注册',
		'_Trial_Service_Activation':'试用服务激活',
		'_regtext1':'此设备没有在myZyXEL.com&nbsp注册过；请输入以下设备信息进行 <b>注册</b> 。',
		'_regtext2':'如果您没有myZyXEL.com帐号，请选择下面的&quot;新建myZyXEL.com帐号&quot;。如果您有',
		'_regtext3':'myZyXEL.com帐号，但是忘记了用户名或密码，请到',
		'_regtext4':'<a href="http://www.myZyXEL.com"><font color="#FF0000"><i><u>www.myZyXEL.com</u></i></font></a>',
		'_regtext5':'上寻求帮助。',
		'_new_myZyXEL_com_account':'新建myZyXEL.com帐号',
		'_existing_myZyXEL_com_account':'已有myZyXEL.com帐号',
		'_User_Name':'用户名',
		'_you_can_click':'您可以点击来检查用户名是否存在',
		'_Password':'密码',
		'_Confirm_Password':'确认密码',
		'_E_Mail_Address':'E-mail地址',
		'_Country_Code':'国家代码',
		'_Trial_Service_Activation':'试用服务激活',
		'_IDP':'入侵检测与保护',
		'_Anti_Virus':'防病毒',
		'_Content_Filter':'内容过滤'
		}];

/* registmgn.html */
var _registmgn=[{
		'_Service_Management':'服务管理',
		'_Service':'服务',
		'_Status':'状态', 
		'_Registration_Type':'注册类型',
		'_Expiration_day':'失效日期', 
		'_Count':'计数',
		'_License_Upgrade':'许可证升级',
		'_License_Key':'注册码',
		'_Note':'注：与myZyXEL.com进行同步下载许可证信息'
		}];

/*----- Licensing > Update -----*/ 

/* idpfile.html */
var _idpfile=[{		
		'_Signature_Information':'特征码信息',
		'_Current_Version':'当前版本',
		'_Signature_Number':'特征码数量',
		'_Released_Date':'发布日期',
		'_Remote_Update':'远程更新',				
		'_Synchronize_the_IDP':'到在线更新服务器上更新IDP特征码到最新版本。&nbsp; （myZyXEL.com激活）',
		'_Auto_Update':'自动更新',
		'_Hourly':'每小时',
		'_Daily':'每天',
		'_Hour':'(小时)',
		'_Weekly':'每周',
		'_Day':'(天)'
		}];

/* idpfile.html */
var _idpfile_1=[{
		'_Signature_Information':'特征码信息',
		'_Current_Version':'当前版本',
		'_Signature_Number':'特征码数量',
		'_Released_Date':'发布日期',
		'_Remote_Update':'远程更新',				
		'_Synchronize':'到在线更新服务器上更新系统保护特征码到最新版本。',
		'_Auto_Update':'自动更新',
		'_Hourly':'每小时',
		'_Daily':'每天',
		'_Hour':'(小时)',
		'_Weekly':'每周',
		'_Day':'(天)'
		}];

/* antiupdate.html */
var _antiupdate=[{
		'_Signature_Information':'特征码信息',
		'_Current_Version':'当前版本',
		'_Signature_Number':'特征码数量',
		'_Released_Date':'发布日期',
		'_Remote_Update':'远程更新',
		'_Synchronize':'到在线更新服务器上更新病毒特征码到最新版本。&nbsp; （myZyXEL.com需要激活）',
		'_Auto_Update':'自动更新',
		'_Hourly':'每小时',
		'_Daily':'每天',
		'_Hour':'(小时)',
		'_Weekly':'每周',
		'_Day':'(天)'
		}]; 

/* upd.html */
var _upd=[{
		'_Rendering':'系统处理中...',
		'_ZyWALL':'ZyWALL在线更新服务器'
		}];
		
/*----- Network > Interface -----*/

/* ifacesummary.html */
var _ifacesummary=[{
		'_Interface_Summary':'接口摘要',
		'_Name':'名称',
		'_Status':'状态',
		'_HA_Status':'HA状态',
		'_Zone':'区域',
		'_IP_Netmask':'IP地址/掩码',
		'_IP_Assignment':'IP分配',
		'_Services':'服务',
		'_Renew_Dial':'更新/拨号',
		'_Statistics':'统计',
		'_Tx_Pkts':'TxPkts',
		'_Rx_Pkts':'RxPkts',
		'_Collision':'Collision',
		'_Tx_Bs':'Tx B/s',
		'_Rx_Bs':'Rx B/s'
		}] 
			
/* Interface.html */
var _Interface=[{
		'_Configuration':'配置',
		'_Name':'名称',
		'_IP_Address':'IP地址',
		'_Mask':'掩码',
		'_Modify':'修改'
		}];

/* ifEdit.html file */
var _ifEdit=[{
		'_Ethernet_Interface_Properties':'以太网接口属性',
		'_Enable':'启用',
		'_Interface_Name':'接口名称',
		'_Description':'描述',
		'_Optional':'(可选)',
		'_IP_Address_Assignment':'IP地址分配',
		'_Get_Automatically':'自动获得',
		'_Use_Fixed_IP_Address':'使用固定IP地址',
		'_IP_Address':'IP地址',
		'_Subnet_Mask':'子网掩码',
		'_Gateway':'网关',
		'_Metric':'跳数',
		'_Interface_Parameters':'接口参数',
		'_Upstream_Bandwidth':'上行带宽',
		'_Downstream_Bandwidth':'下行带宽',
		'_Kbps':'Kbps',
		'_MTU':'MTU',
		'_Bytes':'Bytes',
		'_RIP_Setting':'RIP设置',
		'_Enable_RIP':'启用RIP',
		'_Direction':'方向',
		'_Send_Version':'发送版本',
		'_Receive_Version':'接收版本',
		'_V2_Broadcast':'V2-广播',
		'_OSPF_Setting':'OSPF设置',
		'_Area':'区域',
		'_Priority':'优先级',
		'_Link_Cost':'开销',
		'_Passive_Interface':'被动接口',
		'_Authentication':'验证',
		'_Text_Authentication_Key':'文本认证密钥',
		'_MD5_Authentication_ID':'MD5验证ID',
		'_MD5_Authentication_Key':'MD5验证密钥',
		'_Type':'类型',
		'_Authentication':'验证',
		'_DHCP_Setting':'DHCP设置',
		'_DHCP':'DHCP',
		'_Relay_Server_1':'Relay服务器1',
		'_Relay_Server_2':'Relay服务器2',
		'_IP_Address_1':'(IP地址)',
		'_IP_Pool_Start_Address_Optional':'IP地址池起始地址(可选)',
		'_Pool_Size':'地址池大小',
		'_First_DNS_Server_Optional':'第一DNS服务器(可选)',
		'_Second_DNS_server_Optional':'第二DNS服务器(可选)',
		'_Third_DNS_Server_Optional':'第三DNS服务器(可选)',
		'_First_WINS':'第一WINS服务器(可选)',
		'_Second_WINS':'第二WINS服务器(可选)',
		'_Lease_time':'租期',
		'_infinite':'无限',
		'_days':'天',
		'_hours_Optional':'小时(可选)',
		'_minutes_Optional':'分钟(可选)',
		'_Static_DHCP_Table':'静态DHCP表',
		'_Ping_Check':'Ping检查',
		'_seconds':'秒',
		'_Domain_Name_or_IP_Address':'(域名或IP地址)',
		'_Check_Period':'检查周期',
		'_Check_Timeout':'检查超时',
		'_Check_Fail_Tolerance':'检查容错度',
		'_Ping_Default_Gateway':'Ping默认网关',
		'_Ping_this_address':'Ping这个地址'
		}];

/* viredit.html */
var _viredit=[{
		'_Virtual_Interface_Properties':'虚拟接口属性',
		'_Interface_Name':'接口名称',
		'_Description':'描述',
		'_Optional':'(可选)',
		'_IP_Address_Assignment':'IP地址分配',
		'_IP_Address':'IP地址',
		'_Subnet_Mask':'子网掩码',
		'_Gateway':'网关',
		'_Metric':'跳数',
		'_Interface_Parameters':'接口参数',
		'_Upstream_Bandwidth':'上行带宽',
		'_Downstream_Bandwidth':'下行带宽',
		'_Kbps':'Kbps'
		}];
		
/* portgrouping.html */
var _portgrouping=[{
		'_Port_Grouping':'端口分组',
		'_Representative_Interface':'代表接口',
		'_Physical_Port':'物理端口'
		}];

/* vlan.html */
var _vlan=[{
		'_Configuration':'配置',
		'_Name':'名称',
		'_Port_VID':'端口VID',
		'_IP_Address':'IP地址',
		'_Mask':'掩码'
		}];

/* vlanedit.html */
var _vlanedit=[{
		'_VLAN_Interface_Properties':'VLAN接口属性',
		'_Enable':'启用',
		'_Interface_Name':'接口名称',
		'_Port':'端口',
		'_Virtual_LAN_Tag':'虚拟局域网标签',
		'_Description':'描述',
		'_Optional':'(可选)',
		'_IP_Address_Assignment':'IP地址分配',
		'_Get_Automatically':'自动获得',
		'_Use_Fixed_IP_Address':'使用固定IP地址',
		'_IP_Address':'IP地址',
		'_Subnet_Mask':'子网掩码',
		'_Gateway':'网关',
		'_Metric':'跳数',
		'_Interface_Parameters':'接口参数',
		'_Upstream_Bandwidth':'上行带宽',
		'_Downstream_Bandwidth':'下行带宽',
		'_Kbps':'Kbps',
		'_MTU':'MTU',
		'_Bytes':'Bytes',
		'_DHCP_Setting':'DHCP设置',
		'_DHCP':'DHCP',
		'_Relay_Server_1':'Relay服务器1',
		'_Relay_Server_2':'Relay服务器2',		
		'_IP_Address_1':'(IP地址)',
		'_IP_Pool_Start_Address_Optional':'IP地址池起始地址(可选)',
		'_Pool_Size':'地址池大小',
		'_First_DNS_Server_Optional':'第一DNS服务器(可选)',
		'_Second_DNS_server_Optional':'第二DNS服务器(可选)',
		'_Third_DNS_Server_Optional':'第三DNS服务器(可选)',
		'_First_WINS':'第一WINS服务器(可选)',
		'_Second_WINS':'第二WINS服务器(可选)',
		'_Lease_time':'租期',
		'_infinite':'无限',
		'_days':'天',
		'_hours_Optional':'小时(可选)',
		'_minutes_Optional':'分钟(可选)',
		'_Static_DHCP_Table':'静态DHCP表',
		'_Ping_Check':'Ping检查',
		'_seconds':'秒',
		'_Domain_Name_or_IP_Address':'(域名或IP地址)',
		'_Check_Period':'检查周期',
		'_Check_Timeout':'检查响应时间',
		'_Check_Fail_Tolerance':'检查容错度',
		'_Ping_Default_Gateway':'Ping默认网关',
		'_Ping_this_address':'Ping这个地址'
		}];

/* bridge.html */
var _bridge=[{
		'_Configuration':'配置',
		'_Name':'名称',
		'_IP_Address':'IP地址',
		'_Member':'成员'
		}];

/* bridgeedit.html */
var _bridgeedit=[{
		'_Bridge_Interface_Properties':'网桥接口属性',
		'_Enable':'启用',
		'_Interface_Name':'接口名称',
		'_Description':'描述',
		'_Optional':'(可选)',
		'_Member_Configuration':'成员设置',
		'_Available':'可用',
		'_Member':'成员',
		'_IP_Address_Assignment':'IP地址分配',
		'_Get_Automatically':'自动获得',
		'_Use_Fixed_IP_Address':'使用固定IP地址',
		'_IP_Address':'IP地址',
		'_Subnet_Mask':'子网掩码',
		'_Gateway':'网关',
		'_Metric':'跳数',
		'_Interface_Parameters':'接口参数',
		'_Upstream_Bandwidth':'上行带宽',
		'_Downstream_Bandwidth':'下行带宽',
		'_Kbps':'Kbps',
		'_MTU':'MTU', 
		'_Bytes':'Bytes',
		'_DHCP_Setting':'DHCP设置',
		'_DHCP':'DHCP',
		'_Relay_Server_1':'Relay服务器1',
		'_Relay_Server_2':'Relay服务器2',
		'_IP_Address_1':'(IP地址)',
		'_IP_Pool_Start_Address_Optional':'IP地址池起始地址(可选)',
		'_Pool_Size':'地址池大小',
		'_First_DNS_Server_Optional':'第一DNS服务器(可选)',
		'_Second_DNS_server_Optional':'第二DNS服务器(可选)',
		'_Third_DNS_Server_Optional':'第三DNS服务器(可选)',
		'_First_WINS':'第一WINS服务器(可选)',
		'_Second_WINS':'第二WINS服务器(可选)',
		'_Lease_time':'租期',
		'_infinite':'无限',
		'_days':'天',
		'_hours_Optional':'小时(可选)',
		'_minutes_Optional':'分钟(可选)',
		'_Static_DHCP_Table':'静态DHCP表',
		'_Ping_Check':'Ping检查',
		'_seconds':'秒',
		'_Domain_Name_or_IP_Address':'(域名或IP地址)',
		'_Check_Period':'检查周期',
		'_Check_Timeout':'检查超时',
		'_Check_Fail_Tolerance':'检查容错度',
		'_Ping_Default_Gateway':'Ping默认网关',
		'_Ping_this_address':'Ping这个地址'
		}];

/* dhcp.html */
var _dhcp=[{
		'_Static_DHCP':'静态DHCP',
		'_IP_Address':'IP地址',
		'_MAC':'MAC'
		}];

/* pppoe.html */
var _pppoe=[{
		'_Name':'名称',
		'_Base_Interface':'基本接口',	
		'_Account_Profile':'帐号记录文件'
		}];

/* pppedit.html */
var _pppedit=[{
		'_PPP_Interface_Properties':'PPP接口属性',
		'_Enable':'启用',
		'_Interface_Name':'接口名称',
		'_Nailed_Up':'永久连接',
		'_Dial_on_Demand':'仅在有流量时连接',
		'_Description':'描述',
		'_Optional':'(可选)',
		'_Base_Interface':'基本接口',
		'_Account_Profile':'帐号记录文件',
		'_Protocol':'协议',
		'_User_Name':'用户名',
		'_Service_Name':'服务名称 ',
		'_IP_Address_Assignment':'IP地址分配',
		'_Get_Automatically':'自动获得',
		'_Use_Fixed_IP_Address':'使用固定IP地址',
		'_IP_Address':'IP地址',
		'_Gateway':'网关',
		'_Metric':'跳数',
		'_Interface_Parameters':'接口参数',
		'_Upstream_Bandwidth':'上行带宽',
		'_Downstream_Bandwidth':'下行带宽',
		'_Kbps':'Kbps',
		'_MTU':'MTU',
		'_Bytes':'Bytes',
		'_Ping_Check':'Ping检查',
		'_seconds':'秒',
		'_Domain_Name_or_IP_Address':'(域名或IP地址)',
		'_Check_Period':'检查周期',
		'_Check_Timeout':'检查超时',
		'_Check_Fail_Tolerance':'检查容错度',
		'_Ping_Default_Gateway':'Ping默认网关',
		'_Ping_this_address':'Ping这个地址'
		}];

/* auxiliary.html */
var _auxiliary=[{
		'_Auxiliary_Interface_Properties':'辅助接口属性',
		'_Enable':'启用',
		'_Description':'描述',
		'_Optional':'(可选)',
		'_Port_Speed':'端口速率',
		'_Dialing_Type':'拨号类型',
		'_Tone':'音频',
		'_Pulse':'脉冲',
		'_Initial_String':'初始字符串',
		'_Auxiliary_Configuration':'辅助配置',
		'_Phone_Number':'电话号码',
		'_User_Name':'用户名',
		'_Password':'密码',
		'_Retype_to_confirm':' 重新输入以便确认',
		'_Authentication_Type':'验证类型',
		'_Timeout':'超时',
		'_Seconds':'(秒)',
		'_Idle_timeout':'闲置时间'
		}];

/* groups.html */
var _groups=[{
		'_Name':'名称',
		'_Algorithm':'算法'
		}];
		
/* gpedit.html */
var _gpedit=[{
		'_Trunk_Members':'中继成员',
		'_Name':'名称',
		'_Load_Balancing_Algorithm':'负载均衡算法',
		'_Member':'成员',
		'_Mode':'模式',
		'_Weight':'权值',
		'_Downstream_Bandwidth':'下行带宽',
		'_Upstream_Bandwidth':'上行带宽',
		'_Spillover':'溢出'
		}]; 
		
/*----- Network > Routing -----*/ 

/* policyroute.html */
var _policyroute=[{
		'_User':'用户',
		'_Schedule':'时间表',
		'_Incoming':'流入',
		'_Source':'源',
		'_Destination':'目的',
		'_Service':'服务',
		'_Next_Hop':'下一跳 ',
		'_SNAT':'SNAT',
		'_BWM':'带宽限制'
		}];

/* proutedit.html */
var _proutedit=[{
		'_Configuration':'设定',
		'_Enable':'启用',
		'_Description':'描述',
		'_Optional':'(可选)',
		'_Criteria':'标准 ',
		'_User':'用户',
		'_Incoming':'流入',
		'_Source_Address':'源地址 ',
		'_Destination_Address':'目的地址 ',
		'_Schedule':'时间表',
		'_Service':'服务',
		'_Next_Hop':'下一跳 ',
		'_Type':'类型',
		'_Gateway':'网关',
		'_Interface':'接口',
		'_VPN_Tunnel':'VPN通道 ',
		'_Trunk':'中继 ',
		'_Address_Translation':'地址转换',
		'_Source_Network_Address_Translation':'源网络地址转换',
		'_Port_Triggering':'端口触发',
		'_Incoming_Service':'流入服务',
		'_Trigger_Service':'触发服务',
		'_Bandwidth_Shaping':'带宽整形',
		'_Maximum_Bandwidth':'最大带宽',
		'_Bandwidth_Priority':'带宽优先级',
		'_is_highest_priority':'最高优先级',
		'_MBU':'最大带宽利用'
		}];

/* staticroute.html */
var _staticroute=[{
		'_Destination':'目的',
		'_Subnet_Mask':'子网掩码',
		'_Next_Hop':'下一跳 ',
		'_Metric':'度量'
		}];

/* stroutedit.html */
var _stroutedit=[{
		'_Static_Route_Setting':'静态路由设置',
		'_Destination_IP':'目的IP',
		'_Subnet_Mask':'子网掩码',
		'_Gateway_IP':'网关IP',
		'_Interface':'接口',
		'_Metric':'度量'
		}]; 

/* rip.html */
var _rip=[{
		'_Authentication':'认证',
		'_Text_Authentication_Key':'文本认证密钥',
		'_MD5_Authentication_ID':'MD5验证ID',
		'_MD5_Authentication_Key':'MD5验证密钥',
		'_Redistribute':'重新发布',
		'_Active':'启用',
		'_Name':'名称',
		'_Metric':'度量',
		'_OSPF':'OSPF',
		'_Static_Route':'静态路由'
		}];

/* ospf.html */
var _ospf=[{
		'_OSPF_Router_ID_IP_Address':'OSPF 路由器ID (IP地址)',
		'_Default':'默认',
		'_User_Defined':'用户自定义',
		'_Redistribute':'重新发布',
		'_Active':'启用',
		'_Route':'路由',
		'_Type':'类型',
		'_Metric':'度量',
		'_RIP':'RIP',
		'_Static_Route':'静态路由',
		'_Area':'区域',
		'_Authentication':'认证'
		}];

/* ospfedit.html */
var _ospfedit=[{
		'_Area_Setting':'区域设置',
		'_Area_ID':'区域ID',
		'_Type':'类型',
		'_Authentication':'认证',
		'_Text_Authentication_Key':'文本认证密钥',
		'_MD5_Authentication_ID':'MD5验证ID',
		'_MD5_Authentication_Key':'MD5验证密钥',
		'_Virtual_Link':'虚拟链路',
		'_Peer_Router_ID':'远端路由器ID'		
		}];
				
/*----- Network > Zone -----*/ 

/* zone.html */
var _zone=[{
		'_Configuration':'配置',
		'_Name':'名称',
		'_Block_Intra_zone_Traffic':'阻断内部区域流量',
		'_Member':'成员'
		}];

/* zoneedit.html */
var _zoneedit=[{
		'_Group_Members':'组成员',
		'_Name':'名称',
		'_Block_Intra_zone_Traffic':'阻断内部区域流量'
		}];

/*----- Network > DDNS -----*/

/* ddns.html */
var _ddns=[{
		'_My_Domain_Names':'我的域名',
		'_Profile_Name':'记录名称',
		'_Domain_Name':'域名',
		'_DDNS_Type':'动态域名解析类型',
		'_Wildcard':'通配符',
		'_IP_Address_Update_Policy':'IP地址更新策略',
		'_WAN_Interface':'WAN接口',
		'_HA__Interface':'HA接口'
		}];

/* ddnsed.html */
var _ddnsed=[{
		'_DDNS_Profile':'动态域名解析记录文件',
		'_Profile_Name':'档案名称',
		'_DDNS_Type':'动态域名解析类型',
		'_Username':'用户名',
		'_Password':'密码',
		'_Domain_name':'域名',
		'_wildcard':' 通配符',
		'_IP_Address_Update_Policy':'IP地址更新策略',
		'_Custom_IP':'定制IP',
		'_WAN_Interface':'WAN接口',
		'_HA_Interface':'HA接口',
		'_Mail_Exchanger':'邮件服务器',
		'_Optional':'(可选)',
		'_Backup_mail_exchanger':'备用邮件服务器'
		}];

/*----- Network > Virtual Server -----*/

/* virsvr.html */
var _virsvr=[{
		'_Virtual_Server':'虚拟服务器',
		'_Total_Virtual_Servers':'虚拟服务器数目: ',
		'_entries_per_page':'项/页',
		'_Page':'页面',
		'_Name':'名称',
		'_Interface':'接口',
		'_Original_IP':'原始地址',
		'_Mapped_IP':'映射IP地址',
		'_Protocol':'通讯协议',
		'_Original_Port':'原始端口',
		'_Mapped_Port':'映射端口'
		}];

/* virsvredit.html */
var _virsvredit=[{
		'_Enable':'启用',
		'_Name':'名称',
		'_Interface':'接口',
		'_Original_IP':'原始地址',
		'_User_Defined':'用户定义',
		'_Mapped_IP':'映射地址',
		'_IP_Address':'IP地址',
		'_Original_Port':'原始端口',
		'_Mapped_Port':'映射端口',
		'_Mapping_Type':'映射类型',
		'_Protocol_Type':'协议类型',
		'_Original_Port':'原始端口',
		'_Original_Start_Port':'原始起始端口',
		'_Original_End_Port':'原始终止端口',
		'_Mapped_Start_Port':'映射起始端口',
		'_Mapped_End_Port':'映射终止端口',
		'_Please1':'* 请确保防火墙允许虚拟服务器数据流。',
		'_Please2':'* 如果虚拟服务器也要和客户端建立连接，请创建一条对应的路由策略(NAT 1:1)。',
		'_General_Setup':'常规设置',
		'_Mapping_Rule':'映射规则',
		'_Related_Setting':'相关设置',
		'_nat_1_1_p1':'Add corresponding',
		'_nat_1_1_p2':'rule for NAT 1:1 mapping.',
		'_Policy_Route':'Policy Route',
		'_User_Defined_2':'User-Defined Mapped IP',
		'_Original_Service':'Original Service',
		'_Mapped_Service':'Mapped Service',
		'_nat_p1':'Add corresponding',
		'_nat_p2':'rule for NAT Loopback.',
		'_Configure':'Configure',
		'_Firewall':'Firewall'
		}];

/*----- Network > HTTP Redirect -----*/ 

/* httpred.html */
var _httpred=[{
		'_Configuration':'设定',
		'_Name':'名称',
		'_Interface':'接口',
		'_Proxy_Server':'代理服务器',
		'_Port':'端口'
		}];

/* httprededit.html */
var _httprededit=[{
		'_Enable':'启用',
		'_Name':'名称',
		'_Interface':'接口',
		'_Proxy_server':'代理服务器',
		'_Port':'端口'
		}];

/*----- Network > ALG -----*/ 

/* VoipAlg.html */
var _VoipAlg=[{
		'_SIP_Setting':'SIP设置',
		'_Enable_SIP_Transformations':'启用SIP转换',
		'_SIP_Signaling_Port':'SIP信令端口：',
		'_Additional_SIP_Signaling_Port':'额外SIP信令端口（UDP）：（可选的）',		
		'_SIP_Signaling_inactivity_time_out':'SIP闲置溢出时间：',
		'_seconds':'(秒)',
		'_SIP_Media_inactivity_time_out' :'SIP媒体闲置溢出时间：',		
		'_H_323_Setting':'H.323设置',
		'_Enable_H_323_transformations':'启用H.323转换',
		'_H_323_Signaling_Port':'H.323信令端口：',
		'_Additional_H_323_Signaling_Port':'额外H.323信令端口：（可选的）',
		'_FTP_Setting':'FTP设置',
		'_Enable_FTP_transformations':'启用FTP变换',
		'_FTP_Signaling_Port':'FTP信令端口：',
		'_Additional_FTP_Signaling_Port':'额外FTP信令端口：（可选的）'
		}]; 
		
/*----- Firewall -----*/
  
/* firewall.html */
var _firewall=[{
		'_Global_Setting':'通用设定',
		'_Enable_Firewall':'启用防火墙',
		'_Allow_Asymmetrical_Route':'允许非对称路由',
		'_Maximum_session_per_Host':'主机最大会话数目',
		'_Firewall_rule':'防火墙规则',
		'_Through_ZyWALL_rules':'通过ZyWALL规则',
		'_Zone_Pairs':'区域对',
		'_All_rules':'所有规则',
		'_To_ZyWALL_rules':'到ZyWALL规则',
		'_From_Zone':'来自区域',
		'_To_Zone':'发往区域',
		'_Priority':'优先权',
		'_Schedule':'日程',
		'_User':'用户',
		'_Source':'源',
		'_Destination':'目的',
		'_Service':'服务',
		'_Access':'访问',
		'_Log':'日志',	
		'_From':'发送者',
		'_To':'往'
		}];

/* firewalledit.html */
var _firewalledit=[{
		'_Configuration':'配置',
		'_Enable':'启用',
		'_Description':'描述',
		'_Optional':'(可选)',
		'_Schedule':'时间表',
		'_User':'用户',
		'_Source':'源',
		'_Destination':'目的',
		'_Service':'服务',
		'_Access':'访问',
		'_Log':'日志',	
		'_From':'从 ',
		'_To':'到'
		}]; 
		
/*----- VPN > IPSec VPN -----*/

/* vpnc.html */
var _vpnc=[{
		'_Configuration':'配置',
		'_Total_Connection':'总的连接数',
		'_connection_per_page':'每页可显示连接数',
		'_Page':'页面 ',
		'_Name':'名称',
		'_VPN_Gateway':'VPN网关',
		'_Encapsulation':'封装',
		'_Algorithm':'算法',
		'_Policy':'策略',
		'_Use_PR_to_Ctrl_Dyn_IPSec':'使用策略路由来控制动态 IPSec规则'
		}];
	
/* vpncmkedit.html */
var _vpncmkedit=[{
		'_VPN_Connection':'VPN连接',
		'_Connection_Name':'连接名称',
		'_VPN_Gateway':'VPN网关',
		'_Name':'名称',
		'_Manual_Key':'手动密钥',
		'_SPI':'SPI',
		'_Encapsulation_Mode':'封装模式',
		'_Active_Protocol':'启用协议',
		'_Encryption_Algorithm':'加密算法',
		'_Authentication_Algorithm':'验证算法',
		'_Encryption_Key':'加密密钥',
		'_Authentication_Key':'验证密钥',
		'_Policy':'策略',
		'_Local_Policy':'本地策略',
		'_Remote_Policy':'远程策略',
		'_Property':'属性',
		'_My_Address':'我的地址',
		'_Secure_Gateway_Address':'安全网关地址',
		'_Enable_NetBIOS_broadcast_over_IPSec':'启用IPSec上的NetBIOS广播',
		'_Inbound_Outbound_Traffic_NAT':'流入/流出NAT',
		'_Outbound_Traffic':'流出流量',
		'_Source_NAT':'源NAT',
		'_Source':'源',
		'_Destination':'目的',
		'_SNAT':'SNAT',
		'_Inbound_Traffic':'流入流量',
		'_Source_NAT':'源NAT',
		'_Destination_NAT':'目的NAT',
		'_Original_IP':'初始IP',
		'_Mapped_IP':'映射IP',
		'_Protocol':'协议',
		'_Original_Port':'原始端口',
		'_Mapped_Port':'映射端口'
		}];

/* vpncikeedit.html */
var _vpncikeedit=[{
		'_VPN_Connection':'VPN连接',
		'_Connection_Name':'连接名称',
		'_VPN_Gateway':'VPN网关',
		'_Name':'名称',
		'_Phase_2':'阶段2',
		'_Active_Protocol':'启用协议',
		'_Encapsulation':'封装',
		'_Proposal':'协商提议',
		'_SA_Life_Time':'SA使用期限(秒)',
		'_Perfect_Forward_Secrecy':'完美前向保密(PFS)',
		'_Policy':'策略',
		'_Policy_Enforcement':'策略强制实施',
		'_Local_policy':'本地策略',
		'_Remote_policy':'远程策略',
		'_Property':'属性',
		'_Nailed_Up':'永久连接',
		'_Enable_Replay_Detection':'启用重发检测',
		'_Enable_NetBIOS_broadcast_over_IPSec':'允许NetBIOS广播数据包通过IPSec安全连接',
		'_Inbound_Outbound_traffic_NAT':'流入/流出NAT',
		'_Outbound_Traffic':'流出流量',
		'_Source_NAT':'源NAT',
		'_Source':'源',
		'_Destination':'目的',
		'_SNAT':'SNAT',
		'_Inbound_Traffic':'流入流量',
		'_Destination_NAT':'目的NAT',
		'_Original_IP':'原始IP',
    		'_Mapped_IP':'映射IP',
		'_Protocol':'协议',
		'_Original_Port':'原始端口',
		'_Mapped_Port':'映射端口',
		'_Encryption':'加密',
		'_Authentication':'验证'
		}];

/* vpng.html */
var _vpng=[{
		'_Configuration':'配置',
		'_Name':'名称',
		'_My_address':'我的地址',
		'_Secure_Gateway':'安全网关',
		'_VPN_Connection':'VPN连接'
		}];

/* vpngedit.html */
var _vpngedit=[{
		'_VPN_Gateway':'VPN网关',
		'_VPN_Gateway_Name':'VPN网关名称',
		'_IKE_Phase_1':'IKE 阶段 1',
		'_Negotiation_Mode':'协商模式',
		'_Proposal':'协商提议',
		'_Encryption':'加密',
		'_Authentication':'验证',
		'_Key_Group':'密钥群组',
		'_SA_Life_Time_Seconds':'SA生命时间(秒)',
		'_NAT_Traversal':'NAT穿透',
		'_Dead_Peer_Detection_DPD':'对方失效检测(DPD)',
		'_Property':'属性',
		'_My_Address':'我的地址',
		'_Interface':'接口',
		'_Domain_Name':'域名',
		'_Secure_Gateway_Address':'安全网关地址',
		'_Authentication_Method':'验证方法',
		'_Pre_Shared_Key':'预共享密钥',
		'_Certificate':'证书',
		'_See':'参见',
		'_My_Certificates':'我的证书',
		'_Local_ID_Type':'本地ID类型',
		'_Content':'内容',
		'_Peer_ID_Type':'对方ID类型',
		'_Extended_Authentication':'扩展认证',
		'_Enable_Extended_Authentication':'启用扩展认证',
		'_Server_Mode':'服务器模式',
		'_Client_Mode':'客户端模式',
		'_User_Name':'用户名',
		'_Password':'密码'
		}];

/* contra.html */
var _contra=[{
		'_Configuration':'配置',
		'_Name':'名称'
		}];

/* contraedit.html */
var _contraedit=[{
		'_Group_Members':'组成员',
		'_Name':'名称',
		'_Member':'成员'
		}];
		
/* vpnsa.html */
var _vpnsa=[{
		'_Current_IPSec_Security_Associations':'当前安全连接',
		'_Name':'名称',
		'_Encapsulation':'封装',
		'_Policy':'策略',
		'_Algorithm':'算法',
		'_Up_Time':'运行时间',
		'_Timeout':'等候时间',
		'_Inbound':'流入(字节)',
		'_Outbound':'流出(字节)'
		}];

/*----- VPN > SSL VPN -----*/

/* sslvpnac.html */
var _sslvpnac=[{
		'_Configuration':'设定',		
		'_Name':'名称',
		'_User_Group':'使用者/群组',
		'_Application':'应用'
		}];
/* sslvpnacedit.html */
var _sslvpnacedit=[{
		'_Configuration':'设定',
		'_Enable':'启用',
		'_Name':'名称',
		'_Description':'描述',
		'_Optional':'(可选)',		
		'_User_Group_Optional':'使用者/群组',
		'_Available':'可用',
		'_Member':'成员',
		'_SSL_Application_List_Optional':'SSL应用列表(可选)',
		'_Network_Extension_Optional':'网络扩展(可选)',
		'_Enable_Network_Extension':'启用网络扩展',
		'_Assign_IP_Pool':'IP地址池',
		'_DNS_Server_1':'第一DNS服务器',
		'_DNS_Server_2':'第二DNS服务器',
		'_Wins_Server_1':'第一WINS服务器',
		'_Wins_Server_2':'第二WINS服务器',
		'_Network_List':'网络列表'
		}];		
				
/* sslvpnmonitor.html */
var _sslvpnmonitor=[{
		'_Current_SSL_VPN_Connection':'当前 SSL VPN 连接',		
		'_User':'用户',
		'_Access':'访问',
		'_Login_Addr':'登录地址',
		'_Connected_Time':'连接时间',
		'_In_Bytes':'流入 (字节)',
		'_Out_Bytes':'流出 (字节)'
		}];		
			
/* sslvpnglobal.html */
var _sslvpnglobal=[{
		'_Global_Setting':'通用设定',
		'_Network_Extension_Local_IP':'网络扩展本地IP',		
		'_Message':'消息',
		'_Login_Message':'登录消息',		
		'_Logout_Message':'注销消息',
		'_Update_Client':'更新客户端',
		'_To_upload_a_GIF':'浏览至文件位置然后点击，上传GIF文件。',
		'_File_Path':'文件路径：'
		}];		

/*----- VPN > L2TP VPN -----*/

/* l2tps.html */
var _l2tps=[{
		'_Configuration':'配置',
		'_Enable_L2TP_Over_IPSec':'启用L2TP Over IPSec',
		'_VPN_Connection':'VPN连接',
		'_IP_Address_Pool':'IP地址池',
		'_Authentication_Method':'验证方式',
		'_Allowed_User':'允许用户',
		'_Keep_Alive_Timer':'保持存活时间',
		'_seconds':'秒',
		'_First_DNS':'第一DNS服务器(可选)',
		'_Second_DNS':'第二DNS服务器(可选)',
		'_First_WINS':'第一WINS服务器(可选)',
		'_Second_WINS':'第二WINS服务器(可选)'
		}];

/* l2tps_sm.html */
var _l2tps_sm=[{
		'_Current_L2TP_Session':'当前L2TP会话',
		'_User_Name':'用户名',
		'_Hostname':'主机名',
		'_Assigned_IP':'分配IP地址',
		'_Public_IP':'公共IP地址'
		}];	

/*----- AppPatrol -----*/

/* appgeneral.html */ 
var _appgeneral=[{
		'_General_Setup':'常规设置',
		'_Enable_Application_Patrol':'启用应用控制',
		'_Registration':'注册',
		'_Registration_Status':'注册码状态',
		'_Registration_Type':'授权类型',
		'_Apply_New_Registration':'应用新注册',
		'_Signature_Information':'特征码信息',
		'_Current_Version':'当前版本',
		'_Signature_Number':'特征码数目',
		'_Released_Date':'发布日期',
		'_Update_Signatures':'更新特征码'
		}];

/* appCommon.html */
var _appCommon=[{
		'_Common_Protocols':'常用协议',
		'_Service':'服务',
		'_Default_Access':'默认接入',
		'_Classify':'分类',
		'_Modify':'修改'
		}]; 

/* appCommon.html */
var _appIM=[{
		'_Instant_Messenger':'即时通讯',
		'_Service':'服务',
		'_Default_Access':'默认接入',
		'_Classify':'分类',
		'_Modify':'修改'
		}];

/* appCommon.html */
var _appP2P=[{
		'_P2P':'P2P',
		'_Service':'服务',
		'_Default_Access':'默认接入',
		'_Classify':'分类',
		'_Modify':'修改'
		}];
		
/* appCommon.html */
var _appVoIP=[{
		'_VoIP':'VoIP',
		'_Service':'服务',
		'_Default_Access':'默认接入',
		'_Classify':'分类',
		'_Modify':'修改'
		}];	

/* appCommon.html */
var _appStream=[{
		'_Streaming_Protocols':'流媒体协议',
		'_Service':'服务',
		'_Default_Access':'默认接入',
		'_Classify':'分类',
		'_Modify':'修改'
		}];

/* aplpatroledit.html */
var _aplpatroledit=[{
		'_Service':'服务',
		'_Enable_Service':'启用服务',
		'_Service_Identification':'服务标识',
		'_Name':'名称',
		'_Auto':'自动',
		'_Service_Ports':'基于端口',
		'_Classification':'分类',
		'_Service_Port':'默认端口',
		'_Policy':'策略',
		'_Port':'端口',
		'_Schedule':'日程',
		'_User':'用户',
		'_From':'发送者',
		'_To':'往',
		'_Source':'源',
		'_Destination':'目的',
		'_Access':'访问',
		'_BWM':'BWM In/Out/Pri',
		'_Log':'日志'
		}];

/* appedit.html */
var _appedit=[{
		'_Configuration':'设定',
		'_Bandwidth_Management':'带宽管理',
		'_Inbound':'流入',
		'_kbp1':'kbps',
		'_Outbound':'流出',
		'_kbp2':'kbps&nbsp;(0 : 不限制)',
		'_Priority':'优先权',
		'_MBU':'最大带宽利用',
		'_Enable_Policy':'启用策略',
		'_Port':'端口',
		'_any':'(0 : any)',
		'_Schedule':'时间表',
		'_User':'用户',
		'_From':'从',
		'_To':'到',
		'_Source':'源',
		'_Destination':'目的',
		'_Access':'访问',
		'_Action_Block':'阻挡访问',
		'_Login':'登录',
		'_Message':'消息',
		'_Audio':'音频',
		'_Video':'视频',
		'_File_Transfer':'文件传输',
		'_Log':'日志'
		}]; 
		
/* aplother.html */
var _aplother=[{
		'_Policy':'策略',
		'_Port':'端口',
		'_Schedule':'日程',
		'_User':'用户',
		'_From':'发送者',
		'_To':'往',
		'_Source':'源',
		'_Destination':'目的',
		'_Protocol':'通讯协议',
		'_Access':'访问',
		'_BWM':'BWM In/Out/Pri',
		'_Log':'日志'
		}];

/* aplotheredit.html */
var _aplotheredit=[{
		'_Configuration':'配置',
		'_Bandwidth_Management':'带宽管理',
		'_Inbound':'流入',
		'_Outbound':'流出',
		'_kbps1':'kbps',
		'_kbps2':'kbps&nbsp;(0 : 不限制)',
		'_MBU':'最大带宽利用',
		'_Enable':'启用',
		'_Port':'端口',
		'_any':'(0 : any)',
		'_Schedule':'时间表',
		'_User':'用户',
		'_From':'从',
		'_To':'到',
		'_Source':'源',
		'_Destination':'目的',
		'_Protocol':'协议',
		'_Priority':'优先级',
		'_Access':'访问',
		'_Log':'日志'
		}];

/* appStatic.html */
var _appStatic=[{
		'_Options':'选项',
		'_Refresh_Interval':'更新间隔',
		'_Display_Protocols':'显示协议',
		'_Select_All':'选择All',
		'_Clear_All':'清除All',
		'_Bandwidth_Statistics':'带宽统计',
		'_Protocol_Statistics':'协议统计',
		'_Service':'服务',
		'_Forwarded_Data':'转发数据(KB)',
		'_Dropped_Data':'丢弃数据(KB)',
		'_Rejected_Data':'拒绝数据(KB)',
		'_Matched_Auto':'匹配自动连接',
		'_Matched_Service_Ports':'匹配服务端口连接',
		'_Rule':'规则',
		'_Inbound_Kbps':'Inbound Kbps',
		'_Outbound_Kbps':'Outbound Kbps',
		'_Forwarded_Data':'转发数据(KB)',
		'_Dropped_Data':'丢弃数据(KB)',
		'_Rejected_Data':'拒绝数据(KB)',
		'_Destination':'目的',
		'_Protocol':'协议',
		'_Access':'访问',
		'_Log':'日志'
		}];

/*----- Anti-X > Anti-Virus -----*/
			
/* antivirus.html */
var _antivirus=[{
		'_Configuration':'配置',
		'_Enable_Anti_Virus':'启用防病毒',
		'_Priority':'优先级',
		'_From':'从',
		'_To':'到',
		'_Protocol':'协议',
		'_Registration':'注册',
		'_Registration_Status':'注册状态',
		'_Registration_Type':'注册类型',
		'_Apply_New_Registration':'应用新注册',
		'_Signature_Information':'特征码信息',
		'_Current_Version':'当前版本',
		'_Signature_Number':'特征码数目',
		'_Released_Date':'发布日期',
		'_Update_Signatures':'更新特征码'
		}];

/* avedit.html */
var _avedit=[{
		'_Configuration':'设定',
		'_Direction':'方向',
		'_Enable':'启用',
		'_Log':'日志',
		'_From':'发送者',
		'_To':'往',
		'_Protocols_to_Scan':'要扫描的通讯协议',
		'_HTTP':'HTTP',
		'_FTP':'FTP',
		'_SMTP':'简单邮件传输协议',
		'_POP3':'POP3',
		'_IMAP4':'IMAP4',
		'_Actions_When_Matched':'侦测到病毒的动作',		
		'_Destroy':'破坏感染文件',
		'_Send':'发送窗口信息',
		'_White_List_Black_List':'检查白名单/黑名单',
		'_Bypass_white_list':'检查白名单',
		'_Bypass_black_list':'检查黑名单',
		'_File_decompression':'文件解压缩',
		'_Enable_file_decompression':'启用文件解压缩 (ZIP和RAR)',
		'_Destroy_compressed_files':'破坏不能解压缩的文件'
		}];

/* antisetting.html */
var _antiset=[{
		'_General_Setting':'常规设定',
		'_Scan_EICAR':'扫描EICAR',
		'_White_List':'白名单',
		'_Enable_White_List':'启用白名单',
		'_Total_Rule':'全部规则:',
		'_Page':'页面',
		'_File_Pattern':'文件类型',
		'_Black_List':'黑名单',
		'_Enable_Black_List':'启用黑名单',
		'_rules_per_page':'每页规则'
		}];

/* antisetedit.html */
var _antisetedit=[{
		'_Configuration':'设定',
		'_Enable':'启用',
		'_File_Pattern':'文件类型'
		}];

/* avsignature.html */
var _avsignature=[{
		'_Query_Signatures':'查询特征码',
		'_Signatures_Search':'特征码搜索',
		'_Query_all_signs':'查询所有特征码并导出',
		'_Query_Result':'查询结果',
		'_Total_Signature':'全部特征码:',
		'_signatures_per_page':'每页特征码',
		'_Page':'页面',
		'_Name':'名称',
		'_ID':'ID',
		'_Severity':'等级',
		'_Category':'分类'
		}];
				
/*----- Anti-X > IDP -----*/

/* idpgl.html */
var _idpgl=[{
		'_General_Setup':'常规设置',
		'_Enable_Signature_Detection':'启用特征码侦测',
		'_Bindings':'绑定',
		'_Priority':'优先权',	
		'_From':'发送者',		
		'_To':'往',
		'_IDP_Profile':'IDP记录文件',		
		'_Registration':'授权',
		'_Registration_Status':'注册状态:',
		'_Registration_Type':'注册类型:',
		'_Apply_New_Registration':'应用新注册',
		'_Signature_Information':'特征码信息',
		'_Current_Version':'当前版本:',
		'_Signature_Number':'特征码数目:',
		'_Released_Date':'发布日期:',
		'_Update_Signatures':'更新特征码',
		/* idpgl_1.html */
		'_Enable_Anomaly_Detection':'启用异常检测',
		'_Anomaly_Profile':'异常记录文件',
		/* idpzoneedit page*/
		'_Configuration':'配置',
		'_Direction':'方向',
		'_Profile_Selection':'记录文件选择',
		'_Enable':'启用',
		'_ADP_Profile':'异常检测记录文件'
		}];

/* dataiframe.html */
var _dataiframe=[{
		'_GoTo':'转到',
		'_Page':'页面 '
		}];

/* idppf.html */
var _idppf=[{
		'_Update':'更新',
		'_Profile_Management':'记录文件管理',
		'_Name':'名称',
		'_Base_Profile':'基本记录文件',
		'_Please_select_IDP_Profile':'请选择一个IDP基本记录文件。'
		}];

/* idppfedit.html */
var _idppfedit=[{
		'_Name':'名称',
		'_Signature_Group':'特征码群组',
		'_Service':'服务',
		'_Activation':'启用',
		'_Log':'日志',
		'_Action':'动作',
		'_Message':'消息',
		'_SID':'特征码ID',
		'_Severity':'等级',
		'_Policy_Type':'策略类型'		
		}];

/* idpfedat.html */
var _idpfedat=[{		
		'_Name':'名称',
		'_Scan_Detection':'扫描侦测',
		'_Sensitivity':'灵敏度',
		'_Block_Period':'阻挡周期',
		'_1_3600_seconds':'(1-3600秒)',
		'_Flood_Detection':'Flood检测',
		'_Activation':'启用',
		'_Log':'日志',
		'_Action':'动作',
		'_Threshold':'临界值'
		}];

/* idpfedpa.html */
var _idpfedpa=[{
		'_Name':'名称',
		'_HTTP_Inspection':'HTTP 检测',
		'_TCP_Decoder':'TCP 解码器',
		'_UDP_Decoder':'UDP 解码器',
		'_ICMP_Decoder':'ICMP 解码器',
		'_Activation':'启用',
		'_Log':'日志',
		'_Action':'动作'
		}];

/* idpquery.html */
var _idpquery=[{
		'_Name':'名称',
		'_Query_Signatures':'查询特征码',
		'_Search_all_custom_signature':'搜索所有定制特征码',
		'_Optional':'可选',
		'_Signature_ID':'特征码ID',		
		'_Severity':'等级',
		'_Attack_Type':'攻击类型',
		'_Platform':'操作系统',
		'_Service':'服务',
		'_Activation':'激活',
		'_Log':'日志',
		'_Action':'动作',
		'_Page':'页:',
		'_Actions_hold':'动作',
		'_Query_Result':'查询结果',
		'_Total_IDP':'IDP总数',
		'_IDP_per_page':'每页IDP数目',
		'_SID':'特征码ID'
		}];

/* idpcs.html */
var _idpcs=[{
		'_Creating':'创建',
		'_SID':'特征码ID',
		'_Name':'名称',		
		'_Importing':'导入',
		'_Import_name':'"导入""name.rules;custom.rules""等于定制特征码文件。"',
		'_File_Path':'文件路径'
		}];

/* idpcsedit.html */
var _idpcsedit=[{
		'_Name':'名称',
		'_Signature_ID':'特征码ID',
		'_Information':'信息',
		'_Severity':'等级',
		'_Platform':'操作系统',
		'_All':'全部',
		'_Solaris':'Solaris',
		'_Other_Unix':'其他Unix',
		'_Network_Device':'网络设备',
		'_Service':'服务',
		'_Policy_Type':'策略类型',
		'_Frequency':'频率',
		'_Threshold':'临界值',
		'_Packet':'包',
		'_Second':'秒',
		'_Header_Options':'头选项',
		'_Network_Protocol':'网络协议',
		'_Type_of_Service':'服务类型',
		'_Identification':'标识',
		'_Fragmentation':'区块分割',
		'_Reserved_Bit':'保留位',
		'_Dont_Fragment':'不分割',
		'_More_Fragment':'更多分割',
		'_Fragment_Offset':'分割偏移',
		'_Time_to_Live':'存活时间',
		'_IP_Options':'IP选项',
		'_Same_IP':'相同IP',
		'_Transport_Protocol':'传输层协议',
		'_Port':'端口',
		'_Source_Port':'源端口 ',
		'_Destination_Port':'目的端口 ',
		'_Flow':'数据流',
		'_Flags':'标记',
		'_Type':'类型',
		'_Code':'编码',
		'_Reserved':'保留的',
		'_Sequence_Number':'序列值',
		'_Ack_Number':'ACK值',
		'_Window_Size':'窗口大小',
		'_Payload_Options':'有效载荷选项',
		'_Payload_Size':'有效载荷大小',
		'_Byte':'字节',
		'_Patterns':'类型',
		'_Win95_98':'Win95/98',
		'_WinNT':'WinNT',
		'_WinXP_2000':'WinXP/2000',
		'_Linux':'Linux',
		'_FreeBSD':'FreeBSD',
		'_SGI':'SGI',
		'_IPv4':'IPv4',
		'_SYN':'SYN',
		'_FIN':'FIN',
		'_RST':'RST',
		'_PSH':'PSH',
		'_ACK':'ACK',
		'_URG':'URG',
		'_1':'1 (MSB)',
		'_2':'2',
		'_ID':'ID',
		'_Offset':'偏移',
		'_Relative_to_start_of_payload':'相对于有效荷载开始处',
		'_Content':'内容',
		'_Relative_to_end_of_last_match':'相对于最后匹配末端的距离',
		'_Case_insensitive':'区分大小写',
		'_Within':'Within ',
		'_Bytes':' bytes',
		'_Decode_as_URI':'统一资源标识符（URI）解码'
		}];
		
/* idpimport.html */
var _idpimport=[{
		'_Custom_Signature':'定制特征码',
		'_SID':'特征码ID',
		'_Name':'名称'
		}];

/*----- Anti-X > Content Filter -----*/

/* cfilter.html */
var _cfilter=[{
		'_General_Setup':'常规设置',
		'_Enable_Content_Filter':'启用内容过滤',
		'_Block':'当没有匹配的内容过滤策略时，阻止用户访问互联网',
		'_Policies':'策略',
		'_Address':'地址',
		'_Schedule':'日程',
		'_User':'用户',
		'_Filter_Profile':'过滤档案',
		'_Message':'Web被阻挡时的显示信息',
		'_Denied_Access_Message':'阻挡服务信息',
		'_Redirect_URL':'URL重定向',
		'_Registration':'内容过滤分类服务授权状态',
		'_Registration_Status':' 	注册码状态：',
		'_Registration_Type':'授权类型：',
		'_Apply_New_Registration':'应用新注册',
		'_Enable_Content_Filter_Rpt':'“Enable Content Filter'
		}];

/* cfilteredit.html */
var _cfilteredit=[{
		'_Configuration':'配置',
		'_Schedule':'时间表',
		'_Address':'地址',
		'_Filter_Profile':'过滤档案',
		'_User_Group':'用户组'
		}];

/* cfprofile.html */
var _cfprofile=[{
		'_Profile_Management':'档案管理',
		'_Filter_Profile_Name':'过滤档案名称'
		}];

/* cfpcyedit.html */
var _cfpcyedit=[{
		'_Categories':'类别',
		'_Customization':'定制',
		'_Filter_Profile':'过滤档案',
		'_Name':'名称',
		'_Auto':'自动类别设置',
		'_External':'外部内容过滤服务注册状态:',
		'_Enable':'启用外部数据库内容过滤',
		'_Block':'拦截',
		'_Log':'日志',
		'_Matched_Web_Pages':'符合的网页',
		'_Unrated_Web_Pages':'未分级的网页',
		'_When':'无法使用内容过滤服务器时',
		'_Content':'内容过滤服务器无回应超时',
		'_Seconds':'秒',
		'_Select_Categories':'选择类别',
		'_Select_All_Categories':'选择所有类别',
		'_Clear_All_Categories':'清除所有类别',
		/* check list */
		'_Adult_Mature_Content':'成人/性爱相关内容',
		'_Pornography':'色情图片',
		'_Sex_Education':'性教育',
		'_Intimate_Apparel_Swimsuit':'内衣/泳装',
		'_Nudity':'裸体',
		'_Alcohol_Tobacco':'酒类/烟草',
		'_Illegal_Questionable':'非法的/内容可疑的',
		'_Gambling':'赌博',
		'_Violence_Hate_Racism':'暴力/仇恨/种族歧视',
		'_Weapons':'武器',
		'_Abortion':'堕胎',
		'_Hacking':'黑客',
		'_Phishing':'钓鱼',	
		'_Arts_Entertainment':'艺术/娱乐',
		'_Business_Economy':'商业/经济',
		'_Alternative_Spirituality_Occult':'迷信/神秘',
		'_Illegal_Drugs':'违禁药物',
		'_Education':'教育',
		'_Cultural_Charitable_Organizations':'文化/慈善团体',
		'_Financial_Services':'金融服务',
		'_Brokerage_Trading':'经纪/贸易',
		'_Online_Games':'在线游戏',
		'_Government_Legal':'政府/法律',
		'_Military':'军事',
		'_Political_Activist_Group':'政治/激进团体',
		'_Health':'健康',
		'_Computers_Internet':'电脑/互联网',
		'_Search_Engines_Portals':'搜寻引擎/入口网站',
		'_Spyware_Malware_Sources':'间谍软件/恶意软件来源',
		'_Spyware_Effects_Privacy_Concerns':'间谍软件效果/个人隐私相关',
		'_Job_Search_Careers':'求职/职业',
		'_News_Media':'新闻/媒体',
		'_Personals_Dating':'私人/约会',
		'_Reference':'参考',
		'_Open_Image_Media_Search':'公开图片/媒体搜索',
		'_Chat_Instant_Messaging':'聊天/实时传讯',
		'_Email':'电子邮件',
		'_Blogs_Newsgroups':'Blogs/新闻群组',
		'_Religion':'宗教',
		'_Social_Networking':'社交网络',   
		'_Online_Storage':'联机存储器',
		'_Remote_Access_Tools':'远程访问工具', 
		'_Shopping':'购物',
		'_Auctions':'拍卖',
		'_Real_Estate':'不动产',
		'_Society_Lifestyle':'社会/生活方式',
		'_Sexuality_Alternative_Lifestyles':'性行为/另类生活方式',
		'_Restaurants_Dining_Food':'餐厅/用餐/食物',
		'_Sports_Recreation_Hobbies':'运动/健身/爱好',
		'_Travel':'旅游',
		'_Vehicles':'车辆',
		'_Humor_Jokes':'幽默/笑话',
		'_Software_Downloads':'软件下载',
		'_Pay_to_Surf':'付费上网',
		'_Peer_to_Peer':'P2P',
		'_Streaming_Media_MP3':'流媒体/MP3',
		'_Proxy_Avoidance':'代理',
		'_For_Kids':'儿童专用',
		'_Web_Advertisements':'网页广告',
		'_Web_Hosting':'网页管理',
		/* end check list */
		'_Test1':'测试网站类别',
		'_URL_to_test':'测试URL'
		}];

/* cfpcsedit.html */
var _cfpcsedit=[{
		'_Categories':'类别',
		'_Customization':'定制',
		'_Filter_Profile':'过滤档案',
		'_Name':'名称',
		'_Customization_Setup':'定制设置',
		'_Enable':'启用网站定制功能。',
		'_Allow1':'只允许访问受信任网站',
		'_Restricted_Web_Features':'受限web特征',
		'_Block':'拦截',
		'_ActiveX':'ActiveX',
		'_Java':'Java',
		'_Cookies':'Cookies',
		'_Web_Proxy':'Web Proxy',
		'_Allow2':'允许受信任站点的Java/ActiveX/Cookies/Web',
		'_Trusted_Web_Sites':'受信任网站',
		'_Add_Trusted_Web_Site':'添加受信任网站',
		'_Forbidden_Web_Sites':'禁用网站',
		'_Add_Forbidden_Web_Site':'添加禁用网站',
		'_Blocked_URL_Keywords':'拦截含有关键字的URL',
		'_Add_Blocked_URL_Keyword':'添加URL关键字'
		}];	

/* cfcache.html */
var _cfcache=[{
		'_URL_Cache_Entry':'URL缓存',
		'_Total_cache_entries':'全部缓存:',
		'_entries_per_page':'项/页',
		'_Page':'页面',
		'_Category':'类别',
		'_URL':'URL',
		'_Remaining_Time_minutes':'剩余时间（分钟）',
		'_Remove':'删除',
		'_URL_Cache_Setup':'URL缓存设置',
		'_Maximum_TTL':'最大TTL',
		'_hours':'(1~720小时)'
		}];

/*----- Device HA -----*/		

/* vrrpgrp.html */
var _vrrpgrp=[{
		'_Configuration':'配置',
		'_Enable':'启用',
		'_Link_Monitoring':'链路监控',
		'_VRRP_Group':'VRRP群组',
		'_Name':'名称',
		'_VRID':'VRID',
		'_Role':'角色',
		'_Interface':'接口',
		'_Note_LINK':'注意：如果主ZyWALL VRRP接口不可用，关闭主ZyWALL所有VRRP接口，备份ZyWALL随即开始取代所有工作。',
		'_HA_Status':'HA状态'
		}];

/* vrrpgedit.html */
var _vrrpgedit=[{
		'_Basic_Setting':'基本设置',
		'_Enable':'启用',
		'_Name':'名称',
		'_VRID':'VRID',
		'_Description':'描述',
		'_Optional':'(可选)',
		'_VRRP_Interface':'VRRP接口',
		'_Role':'角色',
		'_Master':'主机',
		'_Backup':'备份',
		'_Priority':'优先级',
		'_range_check_for_backup':'备份设备范围检查',
		'_Preempt':'可抢占',
		'_Manage_IP':'管理IP',
		'_Manage_IP_Subnet_Mask':'管理IP子网掩码',
		'_Authentication':'验证',
		'_None':'无',
		'_Text':'文本',
		'_IP_AH_MD5':'IP AH (MD5)',
		'_Authentication_key':'认证密钥'
		}];

/* devhasync.html */
var _devhasync=[{
		'_Authentication':'验证',
		'_Password':'密码',
		'_Synchronize_from':'同步',
		'_IP_or_FQDN':'(IP或者FQDN)',
		'_on_port':'在端口',
		'_Auto_Synchronize':'自动同步',
		'_Interval':'间隔',
		'_minutes':'分钟'
		}];

/* dha.html */
var _dha=[{
		'_Synchronize_now':'ZyWALL立即同步！',
		'_Rendering':'系统处理中...'
		}];

/*----- Object > User/Group -----*/

/* users.html */
var _users=[{
		'_Configuration':'配置',
		'_User_Name':'用户名',
		'_Description':' 描述'
		}];

/* usersedit.html */
var _usersedit=[{
		'_User_Configuration':'用户配置',
		'_User_Name':'用户名',
		'_User_Type':'用户类型',
		'_Password':'密码',
		'_Retype':'重试',
		'_Description':'描述',
		'_Lease_Time':'租期',
		'_Reauthentication_Time':'再验证时间',
		'_minutes_is_unlimited':'"(0-1440分钟, 0表示没有限制)"'
		}];

/* grps.html */
var _grps=[{
		'_Configuration':'配置',
		'_Group_Name':'组名称',
		'_Description':'描述',
		'_Member':'成员'
		}];

/* grpsedit.html */
var _grpsedit=[{
		'_Configuration':'配置',
		'_Name':'名称',
		'_Description':'描述',
		'_Member':'成员',
		'_Optional':'(可选)'
		}];

/* usrset.html */
var _usrset=[{
		'_User_Default_Setting':'用户默认设置',
		'_User_Type':'用户',
		'_Lease_Time':'租期',
		'_minutes':'分钟',
		'_minutes_is_unlimited':'“(0-1440分钟, 0表示没有限制)”',
		'_Reauthentication_Time':'再验证时间',
		'_User_Logon_Setting':'用户登录设置',
		'_Limit1':'限制管理员用户同时登录的数量',
		'_Maximum1':'管理员用户的最大数量',
		'_Limit2':'限制访问用户同时登录的数量',
		'_Maximum2':'每个访问用户同时登录的最大次数',
		'_User_Lockout_Setting':'用户锁定设置',
		'_Enable_logon_retry_limit':'启用失败登陆的次数限制',
		'_Maximum_retry_count':'失败登陆的最大次数',
		'_Lockout_period':'锁定时间',
		'_User_Miscellaneous_Settings':'用户混杂设置',
		'_Allow':'允许自动更新租期',
		'_Enable_user_idle_detection':'启用监控用户闲置时间',
		'_User_idle_timeout':'用户闲置超时时间',
		'_Force_User_Authentication_Policy':'强制实施能够识别用户的策略',
		'_Total_Policy':'所有策略数量',
		'_Policy_per_page':'每页策略数目',
		'_Page':'页面 ',
		'_Schedule':'时间表',
		'_Source':'源',
		'_Destination':'目的',
		'_Authenticate':'验证'
		}];

/* usrsetedit.html */
var _usrsetedit=[{
		'_Configuration':'设定',
		'_Enable':'启用',
		'_Description':'描述',
		'_Optional':'选项',
		'_Authentication':'认证',
		'_Criteria':'标准 ',
		'_Source_Address':'源地址 ',
		'_Destination_Address':'目的地址 ',
		'_Schedule':'日程'
		}];

/*----- Object > Address -----*/

/* address.html */
var _address=[{
		'_Configuration':'配置',
		'_Name':'名称',
		'_Type':'类型',
		'_Address':'地址'
		}];

/* addredit.html */
var _addredit=[{
		'_Configuration':'配置',
		'_Name':'名称',
		'_Address_Type':'地址类型',
		'_Network':'网络',
		'_Netmask':'子网掩码',
		'_IP_Address':'IP地址',
		'_Starting_IP_Address':'起始IP地址',
		'_End_IP_Address':'结束IP地址'
		}];

/* addrgps.html */
var _addrgps=[{
		'_Configuration':'配置',
		'_Name':'名称',
		'_Description':'描述'
		}];

/* addrgpsedit.html */
var _addrgpsedit=[{
		'_Group_Members':'组成员',
		'_Name':'名称',
		'_Description':'描述'
		}];

/*----- Object > Service -----*/

/* service.html */
var _service=[{
		'_Configuration':'配置',
		'_Total_Services':'所有服务',
		'_services_per_page':'每页服务数目',
		'_Page':'页面 ',
		'_Name':'名称',
		'_Content':'内容'
		}];

/* svredit.html */
var _svredit=[{
		'_Configuration':'设定',
		'_Name':'名称',
		'_IP_Protocol':'IP协议',
		'_Starting_Port':'起始端口 ',
		'_ICMP_Type':'ICMP类型',
		'_IP_Protocol_Number':'IP协议编号',
		'_Ending_Port':'结束端口 '
		}];

/* svrgrp.html */
var _svrgrp=[{
		'_Configuration':'设定',
		'_Name':'名称',
		'_Description':'描述'
		}];


/* svrgrpedit.html */
var _svrgrpedit=[{
		'_Configuration':'设定',
		'_Name':'名称',
		'_Description':'描述'
		}];

/*----- Object > Schedule -----*/

/* schedule.html */
var _schedule=[{
		'_One_Time':'一次',
		'_Name':'名称',
		'_Start_Day':'开始日期',
		'_Stop_Day':'结束日期',
		'_Time':'时间',
		'_Recurring':'循环',
		'_Start_Time':'开始时间',
		'_Stop_Time':'结束时间'
		}];

/* schedit.html */
var _schedit=[{
		'_Configuration':'配置',
		'_Name':'名称',
		'_Day_Time':'日期时间',
		'_Item':'项目',
		'_Date':'日期',
		'_Time':'时间',
		'_Year':'年',
		'_Month':'月',
		'_Day':'天',
		'_Hour':'小时',
		'_minute':'分钟',
		'_Start':'开始',
		'_Stop':'结束',
		'_Weekly':'每周',
		'_Week_Days':'工作日',
		'_Monday':'星期一',
		'_Tuesday':'星期二',
		'_Wednesday':'星期三',
		'_Thursday':'星期四',
		'_Friday':'星期五',
		'_Saturday':'星期六',
		'_Sunday':'星期日',
		/* Inline object. */
		'_Type':'类型'
		}];

/*----- Object > AAA Server -----*/

/* activeDir_d.html */
var _ad=[{
		'_Default':'默认',
		'_Group':'群组',
		'_Configuration':'配置',
		'_Host':'主机',
		'_IP_FQDN':'(IP或者FQDN)',
		'_Port':'端口',
		'_Bind_DN':'绑定DN',
		'_Optional':'(可选)',
		'_Password':'密码',
		'_Base_DN':'基本DN',
		'_CN_Identifier':'CN标识',
		'_Search_time_limit':'查询时间限制',
		'_Use_SSL':'使用SSL'
		}];
	      
/* activeDir_g.html */
var _adg=[{
		'_Default':'默认',
		'_Group':'群组',
		'_Configuration':'配置',
		'_Group_Name':'组名称'
		}];

/* adgedit.html */
var _adgedit=[{
		'_Default':'默认',
		'_Group':'群组',
		'_Configuration':'配置',
		'_Name':'名称',
		'_Port':'端口',
		'_Bind_DN':'绑定DN',
		'_Optional':'(可选)',
		'_Password':'密码',
		'_Base_DN':'基本DN',
		'_CN_Identifier':'CN标识',
		'_Search_time_limit':'查询时间限制',
		'_Use_SSL':'使用SSL',
		'_Host_Members':'主机成员',
		'_Members':'成员(IP或者FQDN)'
		}];

/* aldapd.html */
var _aldapd=[{
		'_Default':'默认',
		'_Group':'分组',
		'_Configuration':'配置',
		'_Host':'主机',
		'_IP_or_FQDN':'IP或者FQDN',
		'_Port':'端口',
		'_Bind_DN':'绑定DN',
		'_Optional':'(可选)',
		'_Password':'密码',
		'_Base_DN':'基本DN',
		'_CN_Identifier':'CN标识',
		'_Search_time_limit':'查询时间限制',
		'_Use_SSL':'使用SSL'
		}];

/* aldapg.html */
var _aldapg=[{
		'_Configuration':'配置',
		'_Default':'默认',
		'_Group':'群组',
		'_Group_Name':'组名称'
		}];

/* aldapgedit.html */
var _aldapgedit =[{
		'_Configuration':'配置',
		'_Default':'默认',
		'_Group':'群组',
		'_Name':'名称',
		'_Port':'端口',
		'_Bind_DN':'绑定DN',
		'_Optional':'(可选)',
		'_Password':'密码',
		'_Base_DN':'基本DN',
		'_CN_Identifier':'CN标识',
		'_Search_time_limit':'查询时间限制',
		'_Use_SSL':'使用SSL',
		'_Host_Members':'主机成员',
		'_Members':'成员(IP或者FQDN)'
		}];

/* aradiusd.html */
var _aradiusd=[{
		'_Configuration':'配置',
		'_Default':'默认',
		'_Group':'群组',
		'_Host':'主机',
		'_IP_or_FQDN':'(IP或者FQDN)',
		'_Authentication_Port':'验证端口',
		'_Key':'密钥',
		'_Timeout':'超时'
		}];

/* aradiusg.html */
var _aradiusg=[{
		'_Configuration':'设定',
		'_Default':'默认',
		'_Group':'群组',
		'_Group_Name':'组名称'
		}];

/* aradiusgedit.html */
var _aradiusgedit=[{
		'_Configuration':'配置',
		'_Default':'默认',
		'_Group':'群组',
		'_Name':'名称',
		'_Host_Members':'主机成员',
		'_Authentication_Port':'验证端口',
		'_Key':'密钥',
		'_Timeout':'超时',
		'_Members':'成员'
		}];

/*----- Object > Auth. method -----*/		

/* Authmeth.html */
var _Authmeth=[{
		'_Configuration':'设定',
		'_Method_Name':'方式名称',
		'_Method_List':'方式列表'
		}];

/* authedit.html */
var _authedit=[{
		'_Configuration':'配置',
		'_Name':'名称',
		'_Method_List':'方式列表'
		}];

/*----- Object > Certificate -----*/

/* cert.html */
var _cert=[{
		'_PKI_Storage_Space_in_Use':'已用PKI储存空间',
		'_My_Certificates_Setting':'证书设置',
		'_Name':'名称',
		'_Type':'类型',
		'_Subject':'所有者',
		'_Issuer':'发行者',
		'_Valid_From':'有效期自',
		'_Valid_To':'有效期至'
		}];

/* certimpt.html */
var _certimpt=[{
		'_Please':'请指定需要导入的证书文件位置。证书文件必须是以下格式之一。',
		'_Binary1':'二进制 X.509',
		'_PEM1':'PEM (Base-64)编码的X.509',
		'_Binary2':'二进制PKCS#7',
		'_PEM2':'PEM (Base-64)编码的PKCS#7',
		'_Binary3':'二进制PKCS#12',
		'_For':'要成功导入我方证书，ZyWALL上必须存在一个证书请求，该请求是为被导入的证书而产生的。在成功导入之后，证书请求便会被自动删除。',
		'_File_Path':'文件路径：',
		'_Password':'密码：',
		'_PKCS':'(仅PKCS#12)'
		}];

/* certcrat.html */
var _certcrat=[{
		'_Name':'名称',
		'_Subject_Information':'所有者信息',
		'_Common_Name':'通用名称',
		'_Host_IP_Address':'主机IP地址',
		'_Host_Domain_Name':'主机域名',
		'_E_Mail':'电子邮件',
		'_Organizational_Unit':'组织单位',
		'_Optional':'(可选)',
		'_Organization':'组织',
		'_Country':'国家',
		'_Key_Type':'密钥类型',
		'_Key_Length':'密钥长度',
		'_bits':'位数',
		'_Enrollment_Options':'注册选项',
		'_Create1':'产生一个自行签发的证书',
		'_Create2':'产生一个证书请求，并在本地保存一份副本以备稍后手动登记',
		'_Create3':'产生一个证书请求，并立即在线登记证书',
		'_Enrollment_Protocol':'登记协议',
		'_CA_Server_Address':'CA 服务器地址',
		'_CA_Certificate':'CA 证书',
		'_See':'参阅',
		'_Trusted_CAs':'可信的CA',
		'_Request_Authentication':'请求识别',
		'_Reference_Number':'参阅',
		'_Key':'密钥'
		}];

/* certself.html */
var _certself=[{
		'_Name':'名称',
		'_Certification_Path':'证书路径',
		'_Certificate_Information':'证书信息',
		'_Type':'类型',
		'_Version':'版本',
		'_Serial_Number':'序列号',
		'_Subject':'主题',
		'_Issuer':'发行者',
		'_Signature_Algorithm':'特征码算法',
		'_Valid_From':'有效期自',
		'_Valid_To':'有效期至',
		'_Key_Algorithm':'密钥算法',
		'_Subject_Alternative_Name':'主题可选名称',
		'_Key_Usage':'密钥使用',
		'_Basic_Constraint':'一般约束',
		'_MD5_Fingerprint':'MD5指纹',
		'_SHA1_Fingerprint':'SHA1指纹',
		'_Certificate':'PEM (Base-64)编码格式的证书',
		'_Password':'密码：'
		}];

/* trscert.html */
var _trscert=[{
		'_PKI_Storage_Space_in_Use':'使用中的PKI储存空间',
		'_Trusted_Certificates_Setting':'受信任的证书设置',
		'_Name':'名称',
		'_Subject':'所有者',
		'_Issuer':'发行者',
		'_Valid_From':'有效期自',
		'_Valid_To':'有效期至'
		}];

/* trsedit.html */
var _trsedit=[{
		'_Name':'名称',
		'_Certification_Path':'证书路径',
		'_Certificate_Validation':'证书确认',
		'_Enable':'启用X.509v3 CRL分发点和OCSP检查',
		'_OCSP_Server':'OCSP服务器',
		'_URL':'URL',
		'_ID':'ID',
		'_Password':'密码',
		'_LDAP_Server':'LDAP服务器',
		'_Address':'地址',
		'_Port':'端口',
		'_Certificate_Information':'证书信息',
		'_Type':'类型',
		'_Version':'版本',
		'_Serial_Number':'序列号',
		'_Subject':'主题',   //
		'_Issuer':'发行者',     //
		'_Signature_Algorithm':'特征码算法',   //
		'_Valid_From':'有效期自',  //
		'_Valid_To':'有效期至',   //
		'_Key_Algorithm':'密钥算法',  //
		'_Subject_Alternative_Name':'主题可选名称',  //
		'_Key_Usage':'密钥使用',  //
		'_Basic_Constraint':'一般约束',
		'_MD5_Fingerprint':'MD5指纹',
		'_SHA1_Fingerprint':'SHA1指纹',
		'_Certificate':'PEM (Base-64)编码格式的证书'
		}];

/* trsimpt.html */
var _trsimpt=[{
		'_Please':'请指定需要导入的证书文件位置。证书文件必须是以下格式之一。',
		'_Binary1':'二进制 X.509',
		'_PEM1':'PEM (Base-64)编码的 X.509',
		'_Binary2':'二进制PKCS#7',
		'_PEM2':'PEM (Base-64)编码的PKCS#7',
		'_File_Path':'文件路径：'
		}];

/*----- Object > ISP Account -----*/

/* Account.html */
var _Account=[{
		'_Configuration':'配置',
		'_Profile_Name':'档案名称',
		'_Protocol':'协议',
		'_Authentication_Type':'认证类型',
		'_User_Name':'用户名'
		}];

/* acctedit.html */
var _acctedit=[{
		'_Configuration':'配置',
		'_Profile_Name':'档案名称',
		'_Protocol':'协议',
		'_Encryption_Method':'加密方式',
		'_Authentication_Type':'验证类型',
		'_User_Name':'用户名',
		'_Password':'密码',
		'_Connection_ID':'连接ID',
		'_Retype_to_confirm':' 重新输入以便确认',
		'_Server_IP':'服务器IP',
		'_IP_Address':'IP地址',
		'_Optional':'(可选)',
		'_Service_Name':'服务名称 ',
		'_Compression':'压缩',
		'_On':'打开',
		'_Off':'关闭',
		'_Idle_timeout':'闲置时间',
		'_Seconds':'(秒)'
		}];

/*----- Object > SSL Application -----*/

/* application.html */
var _application=[{
		'_Configuration':'配置',
		'_Name':'名称',
		'_Address':'地址',
		'_Type':'类型'
		}];		

/* applicationedit.html */
var _applicationedit=[{
		'_Object':'对象',
		'_Type':'类型',
		'_Web_Application':'Web应用',
		'_Name':'名称',
		'_URL':'URL',
		'_Server_Type':'服务器类型',
		'_File_Sharing':'文件共享',
		'_Entry_Point':'入口点',
		'_Optional':'(可选)',
		'_NameC':'名称',
		'_Shared_Path':'共享路径',
		'_Web_Page_Encryption':'Web页面加密'
		}];		

/*----- System > Host Name -----*/

/* hostname.html */
var _hostname=[{
		'_General_settings':'常规设置',
		'_System_Name':'系统名称',
		'_Optional':'(可选)',
		'_Domain_Name':'域名'
		}];

/*----- System > Date/Time -----*/

/* myclock.html */
var _myclock=[{
		'_Current_Time_and_Date':'当前时间和日期',
		'_Current_Time':'当前时间',
		'_Current_Date':'当前日期',
		'_Time_and_Date_Setup':'时间和日期设置',
		'_Manual':'手动设置',
		'_New_Time':'新时间 （时：分：秒）',
		'_New_Date':'新日期 （年－月－日）',
		'_Get_from_Time_Server':'从时间服务器获取',
		'_Time_Server_Address':'时间服务器地址*',
		'_Optional1':'*可选项。预先确定的NTP时间服务器列表。',
		'_Time_Zone_Setup':'时区设置',
		'_Time_Zone':'时区',
		'_Enable_Daylight_Saving':'启动夏时制时间',
		'_Start_Date':'开始日期',
		'_End_Date':'结束日期',
		'_Offset':'偏移',
		'_hours':'小时',
		'_of':'的',
		'_at':'在'
		}];

/*----- System > Console Speed -----*/

/* baudrate.html */
var _baudrate=[{
		'_Configuration':'配置',
		'_Console_Port_Speed':'Console速度'
		}];

/*----- System > DNS -----*/

/* dns.html */
var _dns=[{
		'_DNS_Server':'DNS服务器',
		'_Address_PTR_Record':'地址/PTR记录',
		'_IP_Address':'IP地址',
		'_Domain_Zone':'域名区域',
		'_From':'发送者',
		'_Domain_Zone_Forwarder':'域名区域转发',
		'_MX_Record':'MX记录(FQDN)',
		'_Domain_Name':'域名',
		'_Service_Control':'服务控制',
		'_Zone':'区域',
		'_Address':'地址',
		'_FQDN':'FQDN',
		'_IP_FQDN':'IP/FQDN',
		'_Action':'动作'
		}];

/* adnsedit.html */
var _adnsedit=[{
		'_Configuration':'设定',
		'_IP_Address':'IP地址',
		'_FQDN':'FQDN'
		}];

/* nsdnsedit.html */
var _nsdnsedit=[{
		'_Configuration':'设定',
		'_Domain_Zone':'域名区域',
		'_DNS_Server':'DNS服务器',
		'_DNS_Server1':'来自ISP的DNS服务器',
		'_First_DNS_Server':'第一DNS服务器',
		'_Second_DNS_Server':'第二DNS服务器',
		'_Third_DNS_Server':'第三DNS服务器',
		'_Public_DNS_Server':'公共DNS服务器',
		'_Private_DNS_Server':'私有DNS服务器'
		}];

/* mxdnsedit.html */
var _mxdnsedit=[{
		'_Configuration':'设定',
		'_Domain_Name':'域名',
		'_IP_Address_FQDN':'IP地址/FQDN'
		}];

/* dnsedit.html */
var _dnsedit=[{
		'_Service_Control':'服务控制',
		'_Address_Object':'地址对象',
		'_Zone':'区域',
		'_Action':'动作'
		}];

/*----- System > WWW -----*/

/* buinsrv.html */
var _buinsrv=[{
		'_HTTPS':'HTTPS',
		'_Enable':'启用',
		'_Server_Port':'服务器端口',
		'_Authenticate_Client_Certificates':'验证客户端证书 ',
		'_See':'参阅',
		'_Trusted_CAs':'可信CA',
		'_Server_Certificate':'服务器证书',
		'_My_Certificates':'我方证书',
		'_Redirect_HTTP_to_HTTPS':'重定向HTTP到HTTPS',
		'_Admin_Service_Control':'管理员服务控制',
		'_Zone':'区域',
		'_Address':'地址',
		'_Action':'动作',
		'_User_Service_Control':'用户服务控制',
		'_HTTP':'HTTP',
		'_Authentication':'认证',
		'_Client_Authentication_Method':'客户端验证方式'
		}];

/* httpsedit.html */
var _httpsedit=[{
		'_Admin_Service_Control':'管理员服务控制',
		'_Address_Object':'地址对象',
		'_Zone':'区域',
		'_Action':'动作'
		}];

/* httpsuseredit.html */
var _httpsuseredit=[{
		'_User_Service_Control':'用户服务控制',
		'_Address_Object':'地址对象',
		'_Zone':'区域',
		'_Action':'动作'
		}];

/* wwwedit.html */
var _wwwedit=[{
		'_Admin_Service_Control':'管理员服务控制',
		'_Address_Object':'地址对象',
		'_Zone':'区域',
		'_Action':'动作'
		}];

/* wwwuseredit.html */
var _wwwuseredit=[{
		'_User_Service_Control':'用户服务控制',
		'_Address_Object':'地址对象',
		'_Zone':'区域',
		'_Action':'动作'
		}];

/*----- System > SSH -----*/

/* ssh.html */
var _ssh=[{
		'_SSH':'SSH',
		'_Enable':'启用',
		'_Version_1':'版本1',
		'_Server_Port':'服务器端口',
		'_Server_Certificate':'服务器证书',
		'_See':'参阅',
		'_My_Certificates':'我方证书',
		'_Service_Control':'服务控制',
		'_Zone':'区域',
		'_Address':'地址',
		'_Action':'动作'
		}];

/* sshedit.html */
var _sshedit=[{
		'_Service_Control':'服务控制',
		'_Address_Object':'地址对象',
		'_Zone':'区域',
		'_Action':'动作'
		}];

/*----- System > Telnet -----*/

/* telnet.html */
var _telnet=[{
		'_TELNET':'TELNET',
		'_Enable':'启用',
		'_Server_Port':'服务器端口',
		'_Service_Control':'服务控制',
		'_Zone':'区域',
		'_Address':'地址',
		'_Action':'动作'
		}];

/* telnetedit.html */
var _telnetedit=[{
		'_Service_Control':'服务控制',
		'_Address_Object':'地址对象',
		'_Zone':'区域',
		'_Action':'动作'
		}];

/*----- System > FTP -----*/

/* ftp.html */
var _ftp=[{
		'_FTP':'FTP',
		'_Enable':'启用',
		'_TLS_required':'需要TLS',
		'_Server_Port':'服务器端口',
		'_Server_Certificate':'服务器证书',
		'_See':'参阅',
		'_My_Certificates':'我方证书',
		'_Service_Control':'服务控制',
		'_Zone':'区域',
		'_Address':'地址',
		'_Action':'动作'
		}];

/* ftpedit.html */
var _ftpedit=[{
		'_Service_Control':'服务控制',
		'_Address_Object':'地址对象',
		'_Zone':'区域',
		'_Action':'动作'
		}];

/*----- System > SNMP-----*/

/* snmp.html */
var _snmp=[{
		'_SNMP_Configuration':'配置',
		'_Enable':'启用',
		'_Server_Port':'服务器端口',
		'_Get_Community':'进入社区',
		'_Set_Community':'Set Community',
		'_Trap':' 陷阱:',
		'_Community':'社区',
		'_Destination':'目的',
		'_Optional':'选项',
		'_Service_Control':'服务控制',
		'_Address':'地址',
		'_Zone':'区域',
		'_Action':'动作'
		}];

/* snmpedit.html */
var _snmpedit=[{
		'_Service_Control':'服务控制',
		'_Address_Object':'地址对象',
		'_Zone':'区域',
		'_Action':'动作'
		}];

/*----- System > Dial-in Mgmt.-----*/

/* dialin.html */
var _dialin=[{
		'_Dial_in_Server_Properties':'Dial-in服务器属性',
		'_Enable':'启用',
		'_Description':'描述',
		'_Optional':'(可选)',
		'_Mute':'静音',
		'_Answer_Rings':'答复音',
		'_Rings':'(铃声)',
		'_Port_Speed':'端口速度',
		'_Initial_String':'初始字符串'
		}];

/*----- System > Vantage CNM -----*/

/* cnm.html */
var _cnm=[{
		'_Vantage_CNM':'Vantage CNM',
		'_Enable':'启用',
		'_Server_IP_Address_FQDN':'服务器IP地址/FQDN',
		'_Transfer_Protocol':'传输协议',
		'_Device_Management_IP':'设备管理IP',
		'_Custom_IP':'Custom IP',
		'_Keepalive_Interval':'保持存活间隔',
		'_seconds':'秒',
		'_Periodic_Inform':'周期信息',
		'_Interval':'间隔',
		'_HTTPS_Authentication':'HTTPS验证',
		'_Enable_Vantage':'启用Vantage',
		'_Vantage_Certificate':'Vantage证书',
		'_See':'参阅',
		'_Trusted_CAs':'可信CA'
		}];

/*----- System > Language -----*/

/* language.html */
var _language = [{
		'_Configuration':'配置',
		'_Language_Setting':'语言设置'
		}];

/*----- Maintenance > File Manager -----*/

/* configfile.html */
var _configfile=[{
		'_Configuration_Files':'配置文件',
		'_Select_the_file':'选择文件',
		'_File_Name':'文件名',
		'_Size':'大小',
		'_Modify':'上次修改',
		'_Upload_Configuration_File':'上传配置文件',
		'_To_upload_a_configuration':'浏览至文件的位置(.conf)然后点击上传来上传配置文件。',
		'_File_Path':'文件路径'
		}];

/* editfile.html */
var _editfile=[{
		'_Copy_File':'拷贝文件', 
		'_Rename':'重命名',
		'_Source_file':'源文件：',
		'_Target_file':'目标文件：'
		}];

/* fwfile.html */
var _fwfile=[{
		'_Boot_Module':'启动模块 ',
		'_Current_Version':'当前版本',
		'_Released_Date':'发布日期',
		'_To_upload_firmware_package':'浏览至文件的位置然后点击上传来上传韧体文件包。',
		'_File_Path':'文件路径',
		'_FW_Version':'版本',
		'_FW_Upload':'上传文件'
		}];

/* shellfile.html */
var _shellfile=[{
		'_Shell_Scripts':'Shell脚本 ',
		'_Select_the_file':'选择文件',
		'_File_Name':'文件名',
		'_Size':'大小',
		'_Modify':'上次修改',
		'_Upload_Shell_Script':'上传Shell脚本',
		'_To_upload_a_shell_script':'浏览至文件的位置(.zysh)然后点击上传来上传Shell脚本。',
		'_File_Path':'文件路径'
		}];

/* edscriptfile.html */
var _edscriptfile=[{
		'_Copy_File':'拷贝文件', 
		'_Rename':'重命名',
		'_Source_file':'源文件：',
		'_Target_file':'目标文件：'
		}];

/*----- Maintenance > Log -----*/

/* viewlogs.html */
var _viewlogs=[{
		'_Logs':'日志',
		'_Display':'显示',
		'_Priority':'优先级',
		'_Source_Address':'源地址 ',
		'_Destination_Address':'目的地址 ',
		'_Service':'服务',
		'_Keyword':'关键字',
		'_Total_logging_entries':'所有记录项:',
		'_entries_per_page':'每页项目数量',
		'_Page':'页面 ',
		'_Time':'时间',
		'_Category':'类别',
		'_Message':'消息',
		'_Source':'源',
		'_Destination':'目的',
		'_Note':'注意'
		}];

/* errCode.html */
var _errCode=[{
		'_Certificate':'证书路径校验失败错误代码表',
		'_Code':'代码',
		'_Description':'描述'
		}];

/* logsetting.html */
var _logsetting=[{
		'_Log_Setting':'日志设置',
		'_Name':'名称',
		'_Log_Format':'日志格式',
		'_Summary':'摘要',
		'_Modify':'修改'
		}];

/* intermail.html */
var _intermail=[{
		'_E_mail_Server_1':'E-mail服务器1：',
		'_Active':'启用：',
		'_Mail_Server':'邮件服务器',
		'_Outgoing':'(流出SMTP服务器名称或IP地址)',
		'_Mail_Subject':'邮件主题',
		'_Send_From':'发送自',
		'_E_Mail_Address':'(E-mail地址)',
		'_Send_Log_to':'发送日志到',
		'_Send_Alerts_to':'发送警告到',
		'_Sending_Log':'日志发送中',
		'_Day_for_Sending_Log':'发送日志日',
		'_Time_for_Sending_Log':'发送日志时间 ',
		'_Hour':'(小时)',
		'_Minute':'(分钟)',
		'_SMTP_Authentication':'SMTP认证',
		'_User_Name':'用户名',
		'_Password':'密码',
		'_E_mail_Server_2':'E-mail服务器2：',
		'_Active_Log_and_Alert':'启用日志和警告',
		'_Log_Category':'日志分类',
		'_System_Log':'系统日志',
		'_Log_Consolidation':'日志合并',
		'_Log_Consolidation_Interval':'日志合并间隔(秒)'
		}];

/* remsvr.html */
var _remsvr=[{
		'_Log':'远程服务器日志设置 ',
		'_Active':'启用',
		'_Log_Format':'日志格式',
		'_ZyXEL_VRPT':'ZyXEL VRPT.',
		'_Server_Address':'服务器地址',
		'_Server':'(服务器名称或IP地址)',
		'_Log_Facility':'日志管理工具',
		'_Active_Log':'启用日志',
		'_Log_Category':'日志分类',
		'_Selection':'选择'
		}];

/* logsummary.html */
var _logsummary=[{
		'_Active_Log_Summary':'启用日志摘要',
		'_Log_Category':'日志分类',
		'_System_log':'系统日志',
		'_E_mail_Server_1':'E-mail服务器1',
		'_E_mail_Server_2':'E-mail服务器2',
		'_Remote_Server_1':'远程服务器1',
		'_Remote_Server_2':'远程服务器2',
		'_Remote_Server_3':'远程服务器3',
		'_Remote_Server_4':'远程服务器4',
		'_E_mail':'E-mail',
		'_Syslog':'Syslog'
		}];

/*----- Maintenance > Traffic -----*/

/* report.html */
var _report=[{
		'_Data_Collection':'数据收集',
		'_Collect_Statistics':'收集统计',
		'_Reports':'报告',
		'_Interface':'接口',
		'_Report_Type':'报告类型',
		'_IP_Address_User':'IP地址/用户',
		'_Direction':'方向',
		'_Amount':'总计',
		'_Service_Port':'服务/端口',
		'_Web_Site':'Web站点',
		'_Hits':'点击'
		}];

/* session.html */
var _session=[{
		'_Session':'会话',
		'_View':'查询',
		'_User':'用户',
		'_Protocol':'协议',
		'_Source':'源',
		'_Destination':'目的',
		'_Rx':'Rx',
		'_Tx':'Tx',
		'_Duration':'持续时间',
		'_Service':'服务',
		'_Source_Address':'源地址 ',
		'_Destination_Address':'目的地址 ',
		'_Active_Sessions':'活动会话：',
		'_sessions_per_page':'每页会话数目',
		'_Page':'页面 '
		}];

/* rptIDP.html */
var _rptIDP=[{
		'_Setup':'设置',
		'_Collect_Statistics':'收集统计',
		'_Summary':'摘要',
		'_Total_Session_Scanned':'总计扫描会话',
		'_Total_Packet_Dropped':'总计丢弃数据包',
		'_Total_Packet_Reset':'总计重置数据包',
		'_Statistics':'统计',
		'_Top_Entry_By':'Top排名',
		'_Signature_Name':'特征码名称',
		'_Type':'类型',
		'_Severity':'等级',
		'_Occurrence':'检测次数',
		'_Total':'总计',
		'_Source_IP':'源IP',
		'_Destination_IP':'目的IP'
		}];

/* rptAV.html */
var _rptAV=[{
		'_Setup':'设置',
		'_Collect_Statistics':'收集统计',
		'_Summary':'摘要',
		'_Total_Files_Scanned':'总计扫描文件',
		'_Infected_Files_Detected':'侦测被感染文件',
		'_Statistics':'统计',
		'_Top_Entry_By':'Top排名',
		'_Virus_Name':'病毒名称',
		'_Occurrence':'检测次数',
		'_Total':'总计',
		'_Source_IP':'源IP',
		'_Destination_IP':'目的IP'
		}];
		
/*----- Maintenance > Diagnostics -----*/

/* debugCol.html */
var _debugCol=[{
		'_Diagnostic_Information_Collector':'诊断信息收集器',
		'_Filename':'文件名称:',
		'_Last_modified':'最后修改：',
		'_Size':'大小：'
		}];

/* col.html */
var _col=[{
		'_Diagnostic_Information_Collecting_Status':'诊断信息收集状态',
		'_Please_wait_collecting':'请稍等, 系统正在收集中...',
		'_Done_the_collection':'收集完成。'
		}];

/*----- Maintenance > Reboot -----*/

/* reboot.html */
var _reboot=[{
		'_Reboot':'重新启动',
		'_Click':'点击重新启动按钮重启设备。请等待几分钟直到登录界面出现。如果登录界面没有出现，请在您的浏览器内输入设备IP地址。'
		}];

//access.html file
var _access=[{
		'_andrewc':'Andrewc,您已经成功登录。',
		'_Clicking':'点击注销按钮结束访问。您最长登录会话时间为20分钟。出于安全考虑，在成功登录2小时40分钟后，您必须重新登录。',  
		'_User':'用户自定义租期 (最长20分钟)',
		'_Remaining1':'距离租期到期时间 (mm:ss):',
		'_Remaining2':'距离重新验证时间 (hh:mm): '
		}];

//antispamedit.html file
var _antispamedit=[{
		'_Configuration':'配置',
		'_From_ZONE':'来自区域',
		'_To_ZONE':'发往区域',
		'_SPAM_Score':'垃圾邮件分数',
		'_SPAM_Log':'垃圾邮件日志',
		'_Protocol':'协议',
		'_Action':'动作',
		'_Mark_on_Subject':'标记主题',
		'_Enable':'启用'
		}];

//asrbl.html file
var _asrbl=[{
		'_Summary':'摘要',
		'_White_Black_List':'白/黑名单',
		'_RBL_ORDBL':'RBL/ORDBL',
		'_Update':'更新',
		'_Configuration':'配置 ',
		'_Enable_RBL_ORDBL':'启用RBL/ORDBL',
		'_Server_Query_Postfix':'服务器查询后缀',
		'_Maximum':'每邮件最大RBL/ORDBL查询IP数目',
		'_Maximum_Query_IPs':'最大查询IP数目'
		}];

//asrbledit.html file
var _asrbledit=[{
		'_RBL_ORDBL_Server':'RBL/ORDBL服务器',
		'_Enable':'启用',
		'_Server_Query_Postfix':'服务器查询后缀'
		}];

//assummary.html file
var _assummary=[{
		'_Summary':'摘要',
		'_White_Black_List':'白/黑名单',
		'_RBL_ORDBL':'RBL/ORDBL',
		'_Update':'更新',
		'_Configuration':'配置',
		'_Enable_Anti_Spam':'启用防垃圾邮件',
		'_Notify':'通知SMTP发送方(丢弃邮件)',
		'_Incoming_ZONE':'流入区域',
		'_Outgoing_ZONE':'流出区域',
		'_Inspect_Mail_Protocol':'检查邮件协议',
		'_Registration_Status':'注册状态',
		'_Please_go_to_the':'请到',
		'_Registration':'注册',
		'_page':'页面。',
		'_Registration_Status':'注册状态：',
		'_Registration_Type':'注册类型：'
		}];

//asupspam.html file
var _asupspam=[{
		'_Summary':'摘要',
		'_White_Black_List':'白/黑名单',
		'_RBL_ORDBL':'RBL/ORDBL',
		'_Update':'更新',
		'_Signature_Information':'特征码信息',
		'_Current_Version':'当前版本：',
		'_Remote_Update':'远程更新',
		'_Synchronize':'与在线更新服务器同步，更新防垃圾邮件特征码到最新版本。(myZyXEL.com需要激活)',
		'_Auto_Update':'自动更新',
		'_Hourly':'每小时',
		'_Daily':'每天',
		'_Hour':'(小时)',
		'_Weekly':'每周',
		'_Day':'(天)',
		'_Sunday':'周日',
		'_Monday':'周一',
		'_Tuesday':'周二',
		'_Wednesday':'周三',
		'_Thursday':'周四',
		'_Friday':'周五',
		'_Saturday':'周六'
		}];

//aswblist.html file
var _aswblist=[{
		'_Summary':'摘要',
		'_White_Black_List':'白/黑名单',
		'_RBL_ORDBL':'RBL/ORDBL',
		'_Update':'更新',
		'_White_List':'白名单',
		'_Enable_White_List':'使用白名单',
		'_Type':'类型',
		'_Content':'内容',
		'_Black_List':'黑名单',
		'_Enable_Black_List':'使用黑名单'
		}];

//aswblistedit.html file
var _aswblistedit=[{
		'_Rule_Edit':'规则编辑',
		'_Enable':'启用',
		'_List':'列表',
		'_Type':'类型',
		'_E_Mail_Address':'E-mail地址',
		'_IP_Address':'IP地址',
		'_Network_Mask':'网络掩码',
		'_Mail_Header':'邮件头',
		'_Value':'值'
		}];

//certcert.html file
var _certcert=[{
		'_Name':'名称',
		'_Certification_Path':'证书路径',
		'_Certificate_Information':'证书信息',
		'_Type':'类型',
		'_Version':'版本',
		'_Serial_Number':'序列号',
		'_Subject':'主题',
		'_Issuer':'发行者',
		'_Signature_Algorithm':'特征码算法',
		'_Valid_From':'有效期自',
		'_Valid_To':'有效期至',
		'_Key_Algorithm':'密钥算法',
		'_MD5_Fingerprint':'MD5指纹',
		'_SHA1_Fingerprint':'SHA1指纹',
		'_Certificate':'PEM (Base-64) 编码格式的证书'
		}];

//certreq.html file
var _certreq=[{
		'_Name':'名称',
		'_Certificate_Information':'证书信息',
		'_Type':'类型',
		'_Serial_Number':'序列号',
		'_Subject':'主题',
		'_Issuer':'发行者',
		'_Signature_Algorithm':'特征码算法',
		'_Valid_From':'有效期自',
		'_Valid_To':'有效期至',
		'_Key_Algorithm':'密钥算法',
		'_Subject_Alternative_Name':'主题可选名称',
		'_Key_Usage':'密钥使用',
		'_MD5_Fingerprint':'MD5指纹',
		'_SHA1_Fingerprint':'SHA1指纹',
		'_Certificate':'PEM (Base-64)编码格式的证书'
		}];

/* chgpw.html */
var _chgpw=[{
		'_Update_Admin_Info':'更新管理员信息',
		'_As':'出于安全考虑,建议更改管理员密码。',
		'_New_Password':'新密码:',
		'_Retype_to_Confirm':'重新确认:',
		'_max':'(最多31个可打印字符和数字，无空格)'
		}];

/* keyin.html */
var _1keyin=[{'_Please':'请输入文件名'}];

/* logout.html */
var _logout=[{
		'_Thank':'谢谢您使用ZyXEL Web配置管理器。',
		'_Good_bye':'再见！'
		}];

/* newvpng.html */
var _newvpng=[{
		'_VPN_Gateway':'VPN网关',
		'_VPN_Gateway_Name':'VPN网关名称',
		'_IKE_Phase_1':'IKE阶段1',
		'_Negotiation_Mode':'协商模式',
		'_Main':'主模式',
		'_Aggressive':'野蛮模式',			
		'_Proposal':'协商提案',
		'_Encryption':'加密',
		'_Authentication':'验证',
		'_Key_Group':'密钥群组',
		'_SA_Life_Time':'SA使用期限(秒)',
		'_NAT_Traversal':'NAT穿透',
		'_Dead_Peer_Detection':'对方失效探测(DPD)',
		'_Property':'特性',
		'_My_Address':'我的ZyWALL地址',
		'_Interface':'接口',
		'_Domain_Name':'域名',
		'_Secure_Gateway_Address':'安全网关地址',
		'_Authentication_Method':'验证方式',
		'_Pre_Shared_Key':'预共享密钥',
		'_Certificate':'证书',
		'_See':'参阅',
		'_My_Certificates':'我方证书',        
		'_Local_ID_Type':'本地ID类型',
		'_Content':'内容',
		'_Peer_ID_Type':'对方ID类型',
		'_Extended_Authentication':'扩展验证',
		'_Enable_Extended_Authentication':'启用扩展验证',
		'_Server_Mode':'服务器模式',
		'_Client_Mode':'客户端模式',
		'_User_Name':'用户名',
		'_Password':'密码'
		}];

/* prdframe.html */
var _prdframe=[{
		'_Incoming':'流入',
		'_Member_List':'成员列表',
		'_Please':'请选择成员'
		}];


/* wizard.html */
var _wizard=[{
		'_Welcome':'欢迎来到ZyWALL设置向导',
		'_helps1':'(帮助用户快速配置 ',
		'_helps1_1':' 安全连接互联网)',
		'_helps2':' 安全连接VPN)',
		'_Installation_Setup_One_ISP':'安装设置，一个ISP',
		'_Installation_Setup_Two_ISP':'安装设置，两个ISP',
		'_VPN_Setup':'VPN设置'
		}];

//wizisp1.html file
var _wizisp1=[{
		'_Installation_Setup_Wizard':'安装步骤向导',
		'_Internet_Access':'互联网访问 ',
		'_ISP_Parameters':'ISP参数',
		'_Encapsulation':'封装：',
		'_WAN':'WAN IP地址分配',
		'_WAN_Interface':'WAN接口：',
		'_Zone':'区域',
		'_STEP':'步骤',
		'_IP_Address_Assignment':'IP地址分配：',
		'_Second_WAN_Interface':'第二个WAN接口 ',
		'_First_WAN_Interface':'第一个WAN接口 '
		}];

//wizisp2.html file
var _wizisp2=[{
		'_Installation_Setup_Wizard':'安装步骤向导',
		'_Internet_Access':'互联网访问 ',
		'_ISP_Parameters':'ISP参数',
		'_Encapsulation':'封装：',
		'_WAN':'WAN IP地址分配',
		'_WAN_Interface':'WAN接口：',
		'_Zone':'区域',
		'_IP_Address_Assignment':'IP地址分配：',
		'_Base_Interface':'基础端口',
		'_Service_Name':'服务名称 ',
		'_Optional':'选项',
		'_User_Name':'用户名',
		'_Password':'密码',
		'_Retype_to_Confirm':' 重新确认',
		'_Nailed_Up':'固定联机 ', 
		'_Idle_Timeout':'闲置时间',
		'_Seconds':'(秒)',
		'_PPTP_Configuration':'PPTP配置',
		'_Base_IP_Address':'基础IP地址',
		'_IP_Subnet_Mask':'IP子网掩码',
		'_Server_IP':'服务器IP',
		'_IP_Address':'(IP地址)',
		'_Connection_ID':'连接ID ',
		'_WAN_IP_Address_Assignments':'WAN IP地址分配',
		'_WAN_Interface':'WAN接口',
		'_Zone':'区域',
		'_IP_Address':'IP地址', 
		'_Auto':'Auto',
		'_IP_Subnet_Mask':'IP子网掩码',
		'_Gateway_IP_Address':'网关IP地址',
		'_First_DNS_Server':'第一DNS服务器',
		'_Second_DNS_Server':'第二DNS服务器',
		'_Second_WAN_Interface':'第二个WAN接口 ',
		'_First_WAN_Interface':'第一个WAN接口 ',
		'_STEP':'步骤'
		}];

//wizisp3.html file
var _wizisp3=[{
		'_Installation_Setup_Wizard':'安装步骤向导',
		'_Internet_Access':'互联网访问 ',
		'_ISP_Parameters':'ISP参数',
		'_You_can':'您可以根据所处网络类型选择Ethernet，PPPoE或PPTP。如果您不知道，请询问网络管理员。最常见的网络类型是以太网。',
		'_Encapsulation':'封装：',
		'_WAN_IP_Address_Assignments':'WAN IP地址分配',
		'_The_ZyWall':'',
		'_The_ZyWall_1':' 端口是实时可配置的。例如将端口4(从前面板左数)从DMZ1改为LAN2。端口名称也是实时可配置的。',
		'_WAN_Interface':'WAN接口：',
		'_IP_Address_Assignment':'IP地址分配：',
		'_STEP':'步骤',
		'_error':'错误 '
		}];

//wizisp4.html file
var _wizisp4=[{
		'_Installation_Setup_Wizard':'安装步骤向导',
		'_Internet_Detection':'互联网检测',
		'_Please_wait_a_moment':'请稍候 ...',
		'_STEP':'步骤',
		'_Check_User_Name':'检查用户名...',
		'_Auto_Configure_Device':'自动配置设备'
		}];
		
//wizisp5.html file
var _wizisp5=[{
		'_Installation_Setup_Wizard':'安装步骤向导',
		'_Internet_Access':'互联网访问 ',
		'_Congratulations':'祝贺您，互联网访问向导完成 ',
		'_Summary':'互联网访问配置摘要：',
		'_You_can':'您可以在<a href="http://www.myZyXEL.com" target=_top><span class="style">myZyXEL.com</span></a> 上注册ZyWALL并激活ZyWALL中安全服务的“免费试用”。',
		'_Click':'点击“下一步”来免费激活服务。',
		'_Setting':'设置：',
		'_First_Setting':'第一步设置：',
		'_Encapsulation':'封装',
		'_Service_Name':'服务名称 ',
		'_User_Name':'用户名',
		'_Nailed_Up':'永久连接',
		'_Idle_Timeout':'闲置时间',
		'_Server_IP':'服务器IP',
		'_User_Name':'用户名',
		'_Connection_ID':'连接ID ',
		'_WAN_Interface':'WAN接口',
		'_Zone':'区域',
		'_First_WAN_Interface':'第一个WAN接口 ',
		'_IP_Assignment':'IP分配',
		'_IP_Address':'IP地址',
		'_IP_Subnet_Mask':'IP子网掩码',
		'_Gateway_IP_Address':'网关IP地址',
		'_First_DNS_Server':'第一DNS服务器',
		'_Second_DNS_Server':'第二DNS服务器',
		'_Second_Setting':'第二步设置：',
		'_Second_WAN_Interface':'第二个WAN接口 ',
		'_STEP':'步骤'
		}];
		
/* wizregist.html */
var _wizregist=[{
		'_Installation_Setup_Wizard':'安装步骤向导',
		'_Device_Registration':'设备注册',
		'_This_device':'<font color="#FF0000">此设备没有向myZyXEL.com&nbsp注册过；请输入以下设备信息进行 <b>注册</b> 。</font> <font color="#FFFFFF">如果您没有myZyXEL.com账户，请选择下面的&quot;新建myZyXEL.com账户&quot;。 如果您有myZyXEL.com账户，但是忘记了用户名或密码，请到<a href="http://www.myZyXEL.com">www.myZyXEL.com</a>上寻求帮助。</font>',
		'_new':'新建myZyXEL.com账户',
		'_existing':'已有myZyXEL.com账户',
		'_User_Name':'用户名',
		'_you_can':'您可以点击来检查用户名是否存在',
		'_Password':'密码',
		'_Confirm_Password':'确认密码',
		'_E_Mail_Address':'E-mail地址',
		'_Country_Code':'国家代码',
		'_Trial_Service_Activation':'试用服务激活',
		'_IDP':'入侵检测与保护',
		'_Anti_Virus':'防病毒',
		'_Content_Filter':'内容过滤',
		'_STEP':'步骤'
		}];

//wizvpn1.html file
var _wizvpn1=[{
		'_VPN_Setup_Wizard':'VPN设置向导',
		'_Please':'请选择您希望建立的VPN策略。 ',
		'_Express':'快速 ',
		'_Advanced':'高级 ',
		'_STEP':'步骤'
		}];

//wizvpn2.html file
var _wizvpn2=[{
		'_VPN_Setup_Wizard':'VPN设置向导',
		'_VPN_Access':'VPN访问',
		'_Remote_Gateway':'远程网关',
		'_Name':'名称',
		'_Secure_Gateway':'安全网关',
		'_IP_DNS':'(IP/域名服务器)',
		'_Pre_Shared_Key':'预设共享密钥',
		'_STEP':'步骤'
		}];

//wizvpn3.html file
var _wizvpn3=[{
		'_VPN_Setup_Wizard':'VPN设置向导',
		'_VPN_Access':'VPN访问',
		'_Policy_Setting':'策略设置',
		'_Local_Policy':'本地策略(IP/掩码)',
		'_Remote_Policy':'远程策略(IP/掩码)',
		'_STEP':'步骤'
		}];

//wizvpn4.html file
var _wizvpn4=[{
		'_VPN_Setup_Wizard':'VPN设置向导',
		'_VPN_Access':'VPN访问',
		'_Summary':'摘要',
		'_Name':'名称',
		'_Secure_Gateway':'安全网关',
		'_Pre_Shared_Key':'预共享密钥',
		'_Local_Policy':'本地策略',
		'_Remote_Policy':'远程策略',
		'_Configuration_for_Remote_Gateway':'远程网关配置 ',
		'_Uncomment':'1. 如果在zysh脚本下使用请去掉下面CLI的注释。',
		'_configure_terminal':'配置终端',
		'_Click':'2. 点击“保存”按钮将VPN配置写入ZyWALL。',
		'_STEP':'步骤'
		}];

//wizvpn5.html file
var _wizvpn5=[{
		'_VPN_Setup_Wizard':'VPN设置向导',
		'_VPN_Access':'VPN访问',
		'_Congratulations':'祝贺您。VPN访问向导完成。',
		'_Summary':'VPN访问配置摘要：',
		'_Now':'如果您现在正在进行首次设备安装，您可以点击以下链接<a href="http://www.myZyXEL.com" target=_top><span class="style">myZyXEL.com</span></a> 来注册此设备并激活高级安全功能的试用服务。(您需要有网络接入来进行注册) ',
		'_STEP':'步骤',
		'_Encapsulation':'封装：',
		'_Service_Name':'服务名称： ',
		'_User_Name':'用户名： ',
		'_Idle_Timeout':'闲置超时：  ',
		'_Server_IP':'服务器IP：  ',
		'_Connection_ID':'连接ID：  ',
		'_WAN_Interface':'WAN接口：',
		'_First_WAN_Interface':'第一个WAN接口：  ',
		'_IP_Assignment_Auto':'IP地址分配：自动',
		'_IP_Address':'IP地址',
		'_IP_Subnet_Mask':'IP子网掩码： ',
		'_Gateway_IP_Address':'网关IP地址： ',
		'_IP_Assignment_Static':'网关IP地址： ',
		'_Second_WAN_Interface':'第二个WAN接口：  '
		}];

//wizvpna2.html file
var _wizvpna2=[{
		'_VPN_Setup_Wizard':'VPN设置向导',
		'_VPN_Advanced_Access':'VPN高级访问',
		'_Remote_Gateway':'远程网关',
		'_Name':'名称',
		'_IP_DNS':'(IP/DNS)',
		'_Secure_Gateway':'安全网关',
		'_My_Address':'我方ZyWALL地址(接口)',
		'_Authentication_Method':'验证方式',
		'_Pre_Shared_Key':'预共享密钥',
		'_Certificate':'证书',
		'_STEP':'步骤'
		}];

//wizvpna3.html file
var _wizvpna3=[{
		'_VPN_Setup_Wizard':'VPN设置向导',
		'_VPN_Advanced_Access':'VPN高级访问',
		'_Phase_1_Setting':'阶段1设置',
		'_Negotiation_Mode':'协商模式',
		'_Encryption_Algorithm':'加密算法',
		'_Authentication_Algorithm':'验证算法',
		'_Key_Group':'密钥群组',
		'_SA_Life_Time':'SA使用期限(秒)',
		'_NAT_Traversal':'NAT穿透',
		'_Dead_Peer_Detection':'对方失效探测(DPD)',
		'_STEP':'步骤'
		}];

//wizvpna4.html file
var _wizvpna4=[{
		'_VPN_Setup_Wizard':'VPN设置向导',
		'_VPN_Advanced_Access':'VPN高级访问',
		'_Phase_2_Setting':'阶段2设置',
		'_Active_Protocol':'启用协议',
		'_Encapsulation':'封装',
		'_Encryption_Algorithm':'加密算法',
		'_Authentication_Algorithm':'验证算法',
		'_SA_Life_Time':'SA使用期限(秒)',
		'_Perfect_Forward_Secrecy':'完美前向保密(PFS)',
		'_Policy_Setting':'策略设置',
		'_Local_Policy':'本地策略(IP/掩码)',
		'_Incoming_Interface':'流入接口',
		'_Remote_Policy':'远程策略(IP/掩码)',
		'_Property':'特性',
		'_Nailed_Up':'永久连接',
		'_STEP':'步骤'
		}];

//wizvpna5.html file
var _wizvpna5=[{
		'_VPN_Setup_Wizard':'VPN设置向导',
		'_VPN_Access':'VPN访问',
		'_Summary':'摘要',
		'_Name':'名称',
		'_Secure_Gateway':'安全网关',
		'_Pre_Shared_Key':'预共享密钥',
		'_Local_Policy':'本地策略',
		'_Remote_Policy':'远程策略',
		'_Remote_Gateway_CLI':'远程网关CLI',
		'_Uncomment':'1. 如果在zysh脚本下使用请去掉下面CLI的注释。',
		'_configure_terminal':'配置终端',
		'_Click':'2. 点击“保存”按钮将VPN设置写入ZyWALL。',
		'_STEP':'步骤'
		}];

//wizvpna6.html file
var _wizvpna6=[{
		'_VPN_Setup_Wizard':'VPN设置向导',
		'_VPN_Access':'VPN访问',
		'_Congratulations':'祝贺您。VPN访问向导完成。',
		'_Summary':'VPN访问配置摘要：',
		'_Now':'如果您现在正在进行首次设备安装，您可以点击这条连接<a href="http://www.myZyXEL.com" target=_top><span class="style">myZyXEL.com</span></a> 来注册此设备并激活高级安全功能的试用服务。(您需要有互联网接入来进行注册) ',
		'_STEP':'步骤',
		'_Name':'名称',
		'_Secure_Gateway':'安全网关',
		'_Pre_Shared_Key':'预共享密钥',
		'_Local_Policy':'本地策略',
		'_Remote_Policy':'远程策略',
		'_Secure_Gateway':'安全网关',
		'_My_Address_interface':'我方ZyWALL地址(接口)',
		'_Pre_Shared_Key':'预共享密钥',
		'_Certificate':'证书',
		'_Phase_1':'阶段1',
		'_Negotiation_Mode':'协商模式',
		'_main':'主模式',
		'_Negotiation_Mode':'协商模式',
		'_aggressive':'野蛮模式',
		'_Encryption_Algorithm':'加密算法',
		'_Authentication_Algorithm':'验证算法',
		'_Key_Group':'密钥群组',
		'_SA_Life_Time_Seconds':'SA使用期限(秒)',
		'_NAT_Traversal':'NAT穿透',
		'_Dead_Peer_Detection_DPD':'对方失效探测(DPD)',
		'_Phase_2':'阶段2',
		'_Active_Protocol':'启用协议',
		'_ESP':'ESP',
		'_AH':'AH',
		'_Encapsulation':'封装',
		'_Tunnel':'通道',
		'_Transport':'传输',
		'_Encryption_Algorithm':'加密算法',
		'_SA_Life_Time_Seconds':'SA使用期限(秒)',
		'_Perfect_Forward_Secrecy':'完美前向保密',
		'_Policy':'策略',
		'_Local_Policy':'本地策略',
		'_Remote_Policy':'远程策略',
		'_Incoming_Interface':'流入接口',
		'_Nailed_Up':'永久连接'
		}];

/* wizard_error.html */
var _wizard_error=[{
		'_ErrNo':'错误代码',
		'_ErrMsg':'错误消息',
		'_Installation_Setup_Wizard':'安装向导',
		'_Error':'错误'
		}];

//wizvpnwait.html file
var _wizvpnwait=[{
		'_Installation_Setup_Wizard':'安装向导',
		'_Internet_Detection':'互联网检测',
		'_Auto_Configure_WAN':'自动配置WAN',
		'_Please':'请稍候 ...',
		'_STEP':'步骤'
		}];

/*----- SiteMAP -----*/

//sitemap.html file
var _sitemap=[{
		'_Licensing':'许可证',
		'_Registration':'注册',
		'_Service':'服务',
		'_File_Manager':'文件管理',
		'_Configuration_File':'配置文件',
		'_Firmware_Package':'韧体上传',
		'_Shell_Script':'Shell脚本',
		'_Configuration':'配置',
		'_Network':'网络',
		'_Policy':'策略',
		'_User_Group':'用户组',
		'_Interface':'接口',
		'_Ethernet':'以太网',
		'_Route':'路由',
		'_Policy_Route':'策略路由',
		'_User':'用户',
		'_Port_Grouping':'端口群组',
		'_Static_Route':'静态路由',
		'_Group':'群组',
		'_VLAN':'VLAN',
		'_Firewall':'防火墙',
		'_Setting':'设置',
		'_Bridge':'网桥',
		'_App_Patrol':'应用控制',
		'_Configuration':'配置',
		'_PPPoE_PPTP':'PPPoE/PPTP',
		'_Other_Protocol':'其它协议',
		'_Auxiliary':'辅助',
		'_IDP':'入侵检测与保护',
		'_General':'常规',
		'_Trunk':'中继',
		'_Profile':'记录文件',
		'_IPSec_VPN':'IPSec VPN',
		'_VPN_Connection':'VPN连接',
		'_Custom_Signatures':'定制特征码',
		'_VPN_Gateway':'VPN网关',
		'_Update':'更新',
		'_Concentrator':'VPN集中器',
		'_Content_Filter':'内容过滤',
		'_General':'常规',
		'_SA_Monitor':'SA监控',
		'_Filter_Profile':'过滤档案',
		'_Routing_Protocol':'路由协议',
		'_RIP':'RIP',
		'_Cache':'缓存',
		'_OSPF':'OSPF',
		'_Virtual_Server':'虚拟服务器',
		'_Zone':'区域',
		'_HTTP_Redirect':'HTTP重定向',
		'_Device_HA':'设备高可用性',
		'_VRRP_Group':'VRRP群组',
		'_VoIP_passThru':'VoIP传输',
		'_Synchronize':'同步',
		'_ISP_Account':'ISP账户',
		'_DDNS':'DDNS',
		'_Object':'对象',
		'_System':'系统',
		'_Address':'地址',
		'_Address_Group':'地址群组',
		'_Host_Name':'主机名称',
		'_Service':'服务',
		'_Date_Time':'日期/时间',
		'_Service_Group':'服务群组',
		'_Console_Speed':'Console速度',
		'_Schedule':'时间表',
		'_ICMP':'ICMP',
		'_AAA_Server':'AAA服务器',
		'_LDAP':'LDAP',
		'_DNS':'DNS',
		'_Default':'默认',
		'_Group':'群组',
		'_WWW':'WWW',
		'_RADIUS':'RADIUS',
		'_SSH':'SSH',
		'_TELNET':'TELNET',
		'_Auth_method':'验证方式',
		'_FTP':'FTP',
		'_Certificate':'证书',
		'_My_Certificates':'我方证书',
		'_SNMP':'SNMP',
		'_Trusted_Certificates':'可信证书',
		'_Maintenance':'设备维护',
		'_Log':'日志',
		'_Traffic':'报告',
		'_Reboot':'重新启动',
		'_View_Log':'观察日志',
		'_Log_Setting':'日志设置',
		'_Session':'会话',
		'_Diagnostics':'诊断',
		'_System_Protect':'系统保护',
		'_Anti_Virus':'防病毒',
		'_Interface_Summary':'接口摘要',
		'_Routing':'路由',
		'_ALG':'ALG',
		'_VPN':'VPN',
		'_SSL_VPN':'SSL VPN',
		'_Access_Privilege':'访问权限',
		'_Connection_Monitor':'连接监控',
		'_Global_Setting':'通用设定',
		'_L2TP_VPN':'L2TP VPN',
		'_Session_Monitor':'会话监控',
		'_General':'常规',
		'_Common':'通用',
		'_IM':'IM',
		'_Peer_to_Peer':'P2P',
		'_VoIP':'VoIP',
		'_Streaming':'流媒体',
		'_Other':'其他',
		'_Statistics':'统计',
		'_Anti_X':'Anti-X',
		'_Anti_Virus':'防病毒',
		'_Summary':'摘要',
		'_Setting':'设置',
		'_Signature':'特征码',
		'_ADP':'异常检测',
		'_Active_Directory':'Active Directory',
		'_SSL_Application':'SSL应用',
		'_Dial_in_Mgmt':'Dial-in管理',
		'_Vantage_CNM':'Vantage CNM',
		'_Anti_Virus':'防病毒',
		'_Diagnostics':'诊断'
		}];

var LangReady=true;

